<? 
require("_functions.php");
require("_header.php");
require("_board_jump.php");

$boardcache=array();
$permissioncache=array();
$modcache=array();

if($boardid == -1) {
	eval ("\$output = \"".gettemplate("error3")."\";");
	eval("dooutput(\"".gettemplate("action_error")."\");");
	exit;
}
if($boardid == "home") {
	header("LOCATION: main.php$session2");
	exit;
}
if($boardid == "pm") {
	header("LOCATION: pms.php$session2");
	exit;
}
if($boardid == "search") {
	header("LOCATION: search.php$session2");
	exit;
}
if($boardid == "profil") {
	header("LOCATION: profile.php$session2");
	exit;
}

$binfo = $db_zugriff->query_first("SELECT * FROM bb".$n."_boards WHERE boardid='$boardid'");
$binfo[boardname] = editDBdata($binfo[boardname]);

$result = $db_zugriff->query("
	SELECT
	bb".$n."_boards.*,
	bb".$n."_posts.threadparentid,
	bb".$n."_posts.userid,
	bb".$n."_posts.posttime,
	bb".$n."_threads.threadname,
	bb".$n."_threads.topicicon,
	bb".$n."_threads.boardparentid as parentid,
	bb".$n."_user_table.username	
	FROM bb".$n."_boards
	LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid) 
	LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid) 
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid) 
	WHERE bb".$n."_boards.boardparentid>0
	ORDER by boardparentid ASC, sort ASC");
while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row[boardparentid]][$row[sort]][$row[boardid]] = $row;
$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row[boardid]] = 1;
$result = $db_zugriff->query("SELECT userid, username, boardid FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid = bb".$n."_user_table.userid) WHERE mod = 1 ORDER BY username ASC");
while ($row = $db_zugriff->fetch_array($result)) $modcache[$row[boardid]][] = $row;
$board_boardbit = makeforumbit($boardid);
$db_zugriff->free_result($result);
if($board_boardbit) eval ("\$subboards .= \"".gettemplate("board_subboards")."\";");
$navi_chain = makenavichain("board",$boardid);
if(!$binfo[isboard]) {
	eval("dooutput(\"".gettemplate("board_cat")."\");");
	exit;
}
$time = time()+$timeoffset*3600;
$result = $db_zugriff->query("SELECT announcementid, topic, bb".$n."_announcements.userid, username FROM bb".$n."_announcements LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_announcements.userid) WHERE starttime <= '$time' AND endtime >= '$time' AND (boardid=0 OR boardid='$boardid') ORDER BY starttime DESC");
while($row = $db_zugriff->fetch_array($result)) {
	$row[topic] = editDBdata($row[topic]);
	eval ("\$board_threadbit .= \"".gettemplate("announcementbit")."\";");
}
$db_zugriff->free_result($result);

switch($sortfield) {
 case "threadname"; break;
 case "starttime": break;	
 case "replies": break;	
 case "views": break;	
 case "authorid": break;	
 default: $sortfield = "timelastreply"; break; 	
}

switch($sortorder) {
 case "ASC"; break;
 default: $sortorder = "DESC"; break; 	
}

if(!$daysprune && !$prunedays) $daysprune = $default_daysprune;
if(!$daysprune && $prunedays) $daysprune = $prunedays;
if($daysprune!=1000) $date = time()-(86400*intval($daysprune));
else $date="";

$anzahl = $db_zugriff->query_first("SELECT COUNT(threadid)as anzahl FROM bb".$n."_threads WHERE (boardparentid='$boardid' OR putoffid='$boardid') AND (timelastreply>='$date' OR important='1')");
$anzahl = $anzahl[anzahl];
if(!$page) $page=1;
$getthreadids=$db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE (boardparentid='$boardid' OR putoffid='$boardid') AND (timelastreply>='$date' OR important='1') ORDER by important DESC, $sortfield $sortorder LIMIT ".($tproseite*($page-1)).",".($tproseite));
while($row=$db_zugriff->fetch_array($getthreadids)) $threadids.=",".$row[threadid];

$thread_result = $db_zugriff->query("SELECT bb".$n."_threads.*, bb".$n."_user_table.username AS lastpostername FROM bb".$n."_threads
 LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_threads.lastposterid)
 WHERE threadid IN (0$threadids)
 ORDER by important DESC, $sortfield $sortorder");
$pages=ceil($anzahl/$tproseite);

while($threads = $db_zugriff->fetch_array($thread_result)) {						
		
	unset($folder_image);
	unset($thread_link);
	unset($rate);
	unset($anonymous_lp);
	unset($anonymous);
	unset($thread_starter);
	unset($lastauthor);
	
	$sthreadname = "sthread_".$threads[threadid];	
	if($boardid == $threads[putoffid]) $folder_image = "<img src=\"images/movedfolder.gif\">";
	else {
		if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) $folder_image .= "new";		
		if($threads[replies] > $hotthread_reply || $threads[views] > $hotthread_view) $folder_image .= "hot";
		if($threads[flags]==1) $folder_image .= "lock";
		$folder_image = "<img src=\"images/".$folder_image."folder.gif\">";
	}
	if($threads[topicicon]) $posticon = "<img src=\"$threads[topicicon]\">";
	else $posticon = "&nbsp;";
		
	if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
	$thread_link .= "<font size=2 face=\"{font}\"><b>";
	if($boardid == $threads[putoffid]) eval ("\$thread_link .= \"".gettemplate("board_moved")."\";");
	elseif($threads[important]) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
	if($threads[pquestion]) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
	$thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session\">".prepare_topic($threads[threadname])."</a></b></font>";
	if(($threads[replies]+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"$font\"> ( <img src=\"images/multipage.gif\"> <a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=1\">1</a> <a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=2\">2</a> ";
	if(($threads[replies]+1)/$eproseite > 2) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=3\">3</a> ";
	if(($threads[replies]+1)/$eproseite > 3) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads[threadid]."&boardid=$threads[boardparentid]&styleid=$styleid$session&page=4\">4</a> ";
	if(($threads[replies]+1)/$eproseite > 4) {
		$pagesx=ceil(($threads[replies]+1)/$eproseite);
		eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
	}
	if(($threads[replies]+1)/$eproseite > 1) $thread_link .= ")</font>";
		
	$starttime = formatdate($threads[starttime],$longdateformat,1);
	if($threads[authorid]) $thread_starter = $threads[author];
	else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
	$lastposttime = formatdate($threads[timelastreply],$longdateformat,1);
	$lastauthorid = $threads[lastposterid];
	if($lastauthorid) $lastauthor = $threads[lastpostername];
	else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
	eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");
				
	if($threads[rated] && $threads[rate_points]) {
		$j = round($threads[rate_points]/$threads[rated]);
		for ($j; $j > 0; $j--) $rate .= "<img src=\"images/star.gif\" border=0>";
	}
	else $rate = "&nbsp;";
		
	eval ("\$board_threadbit .= \"".gettemplate("board_threadbit")."\";");
}
$db_zugriff->free_result($thread_result);
if($pages>1) $page_link = makepagelink("board.php?boardid=$boardid$session", $page, $pages);
if($mods = getMod($boardid)) eval ("\$mods = \"".gettemplate("board_moderate")."\";");

$l_threads = 1+($page-1)*$tproseite;
$h_threads = $page*$tproseite;
if($h_threads > $anzahl) $h_threads = $anzahl;
$all_threads = $anzahl;

if($sortfield == "threadname") $f_select[0] = "selected";
if($sortfield == "timelastreply") $f_select[1] = "selected";
if($sortfield == "replies") $f_select[2] = "selected";
if($sortfield == "views") $f_select[3] = "selected";
if($sortfield == "author") $f_select[4] = "selected";
if($sortfield == "starttime") $f_select[5] = "selected";

if($sortorder == "ASC") $o_select[0] = "selected";
if($sortorder == "DESC") $o_select[1] = "selected";

if($daysprune == "1") $d_select[0] = "selected";
if($daysprune == "2") $d_select[1] = "selected";
if($daysprune == "5") $d_select[2] = "selected";
if($daysprune == "10") $d_select[3] = "selected";
if($daysprune == "20") $d_select[4] = "selected";
if($daysprune == "30") $d_select[5] = "selected";
if($daysprune == "45") $d_select[6] = "selected";
if($daysprune == "60") $d_select[7] = "selected";
if($daysprune == "75") $d_select[8] = "selected";
if($daysprune == "100") $d_select[9] = "selected";
if($daysprune == "365") $d_select[10] = "selected";
if($daysprune == "1000") $d_select[11] = "selected";

if($board_threadbit) {
	eval ("\$threads_order  .= \"".gettemplate("board_threads_order")."\";");
	eval("dooutput(\"".gettemplate("board")."\");");
}
else eval("dooutput(\"".gettemplate("board_no_threads")."\");");
?>		