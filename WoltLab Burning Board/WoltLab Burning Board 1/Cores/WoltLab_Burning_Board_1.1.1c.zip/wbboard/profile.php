<?
require("_functions.php");

if($user_id) {
        require("_header.php");
        require("_board_jump.php");
        
        if($mode == "avatars") {
        	if($send == "send") {
        		if($avatarid!="useown") {
        			$oldavatar = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
        			if($oldavatar[id]) {
        				@unlink("images/avatars/avatar-".$oldavatar[id].".".$oldavatar[extension]);
        				$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$oldavatar[id]'");
        			}
        			$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = '$avatarid' WHERE userid = '$user_id'");
        		}
        		else {
        			if($uploadfile) {
        				$oldavatar = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
        				if($oldavatar[id]) {
        					@unlink("images/avatars/avatar-".$oldavatar[id].".".$oldavatar[extension]);
        			       		$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$oldavatar[id]'");
        				}
        			       	$conf[avatar_size] = $avatar_size;
        			       	$conf[avatar_width] = $avatar_width;
        			       	$conf[avatar_height] = $avatar_height;
        			       	$setuserid = $user_id;
        			       			
        				$mimetype = explode("\n", $avatarimage_ext);
					for($i = 0; $i < count($mimetype); $i++) $mimetype[$i] = trim($mimetype[$i]); 
		
					require_once("./admin/Upload.class.php");
					$upload = new Upload();
		
					$upload->setAllowedMimeTypes($mimetype);	
					$upload->setUploadPath("images/avatars");
	
					if ($upload->doUpload()) $db_zugriff->query("UPDATE bb".$n."_user_table set avatarid = '$insertid' WHERE userid = '$user_id'");
					else eval ("\$error = \"".gettemplate("error3")."\";");
					
				}
        			elseif(!$havatarid) eval ("\$error = \"".gettemplate("error3")."\";");
			}
        	}
        	$info = $db_zugriff->query_first("SELECT userposts, avatarid FROM bb".$n."_user_table WHERE userid = '$user_id'");
        	if(!$info[avatarid] || !$avatars) $checked = " CHECKED";
        	if($avatars) {
        	
        		$anzahl = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_avatars WHERE (groupid = '$user_group' OR groupid = 0) AND posts <= '$info[userposts]' AND userid = 0");
        		if($anzahl[0]) {
        			if(!$page) $page=1;
        			$pages=ceil($anzahl[0]/25);
				$result = $db_zugriff->query("SELECT * FROM bb".$n."_avatars WHERE (groupid = '$user_group' OR groupid = 0) AND posts <= '$info[userposts]' AND userid = 0 ORDER BY name ASC LIMIT ".(25*($page-1)).", 25");
        			while($row = $db_zugriff->fetch_array($result)) {
        				if($row[id]==$info[avatarid]) $avatarArray[] = "<input type=\"RADIO\" name=\"avatarid\" value=\"$row[id]\" CHECKED><img src=\"images/avatars/avatar-".$row[id].".".$row[extension]."\">";
        				else $avatarArray[] = "<input type=\"RADIO\" name=\"avatarid\" value=\"$row[id]\"><img src=\"images/avatars/avatar-".$row[id].".".$row[extension]."\">";
        			}
        			$tableRows = ceil(count($avatarArray)/5);
        			$count = 0;
        			for ($i=0; $i<$tableRows; $i++) {
                			$avatarbit .= "\t<tr bgcolor=\"{tableb}\" id=\"tableb\">\n";
               				for ($j=0; $j<5; $j++) {
               					$avatarbit .= "\t<td align=\"center\">".$avatarArray[$count]."&nbsp;</td>\n";
                        			$count++;
                        		}
                        		$avatarbit .= "\t</tr>\n";
                        	}
                        	$countall = $anzahl[0];
                        	$countvon = 1+25*($page-1);
                        	$countbis = 25*$page;
                        	if($countbis > $countall) $countbis = $countall;
                        	
                        	if($pages>1) {
					$page_link .= "<br>[ ";
					if($page!=1) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=1\">&laquo;</a> <a href=\"profile.php?mode=$mode$session&page=".($page-1)."\">�</a> ";
					if($page>=6) $page_link .= "<a href=\"profile.php?mode=$mode$sessionpage=".($page-5)."\">...</a> ";
					if($page+4>=$pages) $pagex=$pages;
					else $pagex=$page+4;
					for($i=$page-4 ; $i<=$pagex ; $i++) { 	
						if($i<=0) $i=1;
						if($i==$page) $page_link .= $i." ";
						else $page_link .= "<a href=\"profile.php?mode=$mode$session&page=$i\">$i</a> ";
					}
					if(($pages-$page)>=5) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=".($page+5)."\">...</a> ";
					if($page!=$pages) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=".($page+1)."\">�</a> <a href=\"profile.php?mode=$mode$session&page=".$pages."\">&raquo;</a>";
					$page_link .= " ]";
				}
                        	                        	
        			eval ("\$avatar_choice = \"".gettemplate("profile_avatar_choice")."\";");
        		}
        		if($userdata[canuploadavatar]) {
        			$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
        			if($info[id]) {
        				$ownavatar = "<img src=\"images/avatars/avatar-".$info[id].".".$info[extension]."\">";
        				$havatar = "<input type=\"hidden\" name=\"havatarid\" value=\"$info[id]\">";
        				$checked2= " CHECKED";
        			}
        			eval ("\$avatar_choice .= \"".gettemplate("profile_avatar_useown")."\";");
        		}
        	} 
        	eval("dooutput(\"".gettemplate("profile_avatars")."\");");
        }
        
        if(!$mode) {

                $buddylist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND buddylist = 1");
                while($row = $db_zugriff->fetch_array($buddylist)) {
                        if(checkuseronline($row[objectid])) {
                        	if($online) $online .= ", ";
                                $online .= "<a href=\"members.php?mode=profile&userid=".$row[objectid]."&boardid=$boardid$session\">".$row[username]."</a>";
                        } else {
                        	if($offline) $offline .= ", ";
                                $offline .= "<a href=\"members.php?mode=profile&userid=".$row[objectid]."&boardid=$boardid$session\">".$row[username]."</a>";
                        }
                }
                
                if($pms && $userdata[canusepms]) eval ("\$profile_pmlink= \"".gettemplate("profile_pmlink")."\";");
                eval("dooutput(\"".gettemplate("profile_main")."\");");
        }

        if($mode=="editprofile") {
		if($send == "send") {
			if(!$email || !$emailconfirm || $email != $emailconfirm || strlen($usertext) > $usertextlength || (getUserEmail($user_id) != $email && checkemail($email)) || checkemail($email,1)) eval ("\$error = \"".gettemplate("errorn1")."\";");
                        else { 
                        	if($homepage) $homepage = editURL($homepage);
        			$db_zugriff->query("UPDATE bb".$n."_user_table SET useremail='$email', userhp='$homepage', usericq='".editPostdata($icq)."', aim='".editPostdata($aim)."', yim='".editPostdata($yim)."', age_m='$month', age_d='$day', age_y='".editPostdata($year)."', location='".editPostdata($location)."', interests='".editPostdata(nt_wordwrap($interests,20))."', work='".editPostdata($work)."', gender = '$gender', usertext = '".editPostdata(nt_wordwrap($usertext,25))."' WHERE userid='$user_id'");
                        }
		}
                                
                $user_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid='$user_id'");
                if(!$user_info[age_d]) $day_select = "<option value=\"\" selected></option>";
                else $day_select = "<option value=\"\"></option>";
		
		if($user_info[usertext]) $usertext = editDBdata($user_info[usertext]);	
		if($user_info[gender]==1) $gender_sel[1] = " selected";
		elseif($user_info[gender]==2) $gender_sel[2] = " selected";
		
                for($i = 1; $i <= 31; $i++) {
                        $day_select .= "<option value=\"$i\"";
                        if($user_info[age_d]=="$i") $day_select .= " selected";
                        $day_select .= ">$i</option>";
                }

                if(!$user_info[age_m]) $month_sel[0] = " selected";
                if($user_info[age_m]=="Januar") $month_sel[1] = " selected";
                if($user_info[age_m]=="Februar") $month_sel[2] = " selected";
                if($user_info[age_m]=="M�rz") $month_sel[3] = " selected";
                if($user_info[age_m]=="April") $month_sel[4] = " selected";
                if($user_info[age_m]=="Mai") $month_sel[5] = " selected";
                if($user_info[age_m]=="Juni") $month_sel[6] = " selected";
                if($user_info[age_m]=="Juli") $month_sel[7] = " selected";
                if($user_info[age_m]=="August") $month_sel[8] = " selected";
                if($user_info[age_m]=="September") $month_sel[9] = " selected";
                if($user_info[age_m]=="Oktober") $month_sel[10] = " selected";
                if($user_info[age_m]=="November") $month_sel[11] = " selected";
                if($user_info[age_m]=="Dezember") $month_sel[12] = " selected";

		$usericq = editDBdata($user_info[usericq]);
		$aim = editDBdata($user_info[aim]);
		$yim = editDBdata($user_info[yim]);
		$age_y = editDBdata($user_info[age_y]);
		$location = editDBdata($user_info[location]);
		$interests = editDBdata($user_info[interests]);
		$work = editDBdata($user_info[work]);
		
                eval("dooutput(\"".gettemplate("profile_editprofile")."\");");

        }

	if($mode=="editsignature") {

                if($send && !$preview) {
                	if(strlen($message) > $siglength || check_signature($message)) eval ("\$error = \"".gettemplate("errorn1")."\";");
                	else $db_zugriff->query("UPDATE bb".$n."_user_table set signatur = '".editPostdata(parseURL(nt_wordwrap($message)))."' WHERE userid = '$user_id'");                
                }
                
                if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
		if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);
                
                if($sightml) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
		else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
		if(!$sigsmilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
		if(!$sigbbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");
                
                $user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE userid='$user_id'");
                if($user_info[signatur]) {
                	$old_signature = editSignatur($user_info[signatur],0);
                	eval ("\$old_signatur = \"".gettemplate("profile_old_signature")."\";");
                	if(!$preview) $signature = editDBdata($user_info[signatur]);
                }
                if($preview) {
                	$preview_signature = editSignatur($message,0);
                	eval ("\$preview = \"".gettemplate("profile_preview_signature")."\";");
                	$signature = stripslashes($message);
                
                }
                eval("dooutput(\"".gettemplate("profile_editsignature")."\");");

        }

        if($mode=="changepw") {
        	if($send == "send") {
        	
        		if(!$password || !$confirmpassword || !$old_password || $password!=$confirmpassword || !checkpw($user_id,md5($old_password))) eval ("\$error = \"".gettemplate("errorn1")."\";");
                	else {
                		$user_password = md5($password);
                        	$db_zugriff->query("UPDATE bb".$n."_user_table SET userpassword='$user_password' WHERE userid='$user_id'");
                        	session_register("user_password");
				setcookie("user_password", "$user_password", time()+(3600*24*365));
				header("Location: profile.php?boardid=$boardid$session");
				exit;
			}		
                }
                
        	eval("dooutput(\"".gettemplate("profile_changepw")."\");");
        }
        if($mode=="editoptions") {
		if($send == "send") {
			$db_zugriff->query("UPDATE bb".$n."_user_table SET invisible='$ghost', session_link='$slink', mods_may_email='$mod_email', users_may_email='$form_email', show_email_global='$hide_email', hide_signature='$show_signature', hide_userpic='$show_userpic', prunedays='$s_prunedays', umaxposts='$s_umaxposts', bbcode='$use_bbcode', style_set='$ustyleset' WHERE userid='$user_id'");
                	header("Location: profile.php?boardid=$boardid$session");
			exit;
                }
                $user = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid='$user_id'");
                
		if($user[invisible]) $ghost[1] = "Checked";
		else $ghost[0] = "Checked";
		
		if($user[session_link]) $slink[1] = "Checked";
		else $slink[0] = "Checked";
		
		if($user[mods_may_email]) $mod_email[1] = "Checked";
		else $mod_email[0] = "Checked";
		
		if($user[show_email_global]) $hide_email[1] = "Checked";
		else $hide_email[0] = "Checked";
		
		if($user[users_may_email]) $form_email[1] = "Checked";
		else $form_email[0] = "Checked";
		
		if($user[hide_signature]) $show_signature[1] = "Checked";
		else $show_signature[0] = "Checked";
		
		if($user[hide_userpic]) $show_userpic[1] = "Checked";
		else $show_userpic[0] = "Checked";
		
		if(!$user[prunedays]) $s_prunedays[0] = "selected";
		if($user[prunedays]==1) $s_prunedays[1] = "selected";
                if($user[prunedays]==2) $s_prunedays[2] = "selected";
                if($user[prunedays]==5) $s_prunedays[3] = "selected";
                if($user[prunedays]==10) $s_prunedays[4] = "selected";
                if($user[prunedays]==20) $s_prunedays[5] = "selected";
                if($user[prunedays]==30) $s_prunedays[6] = "selected";
                if($user[prunedays]==45) $s_prunedays[7] = "selected";
                if($user[prunedays]==60) $s_prunedays[8] = "selected";
                if($user[prunedays]==75) $s_prunedays[9] = "selected";
                if($user[prunedays]==100) $s_prunedays[10] = "selected";
                if($user[prunedays]==365) $s_prunedays[11] = "selected";
                if($user[prunedays]==1000) $s_prunedays[12] = "selected";
                
		if(!$user[umaxposts]) $s_umaxposts[0] = "selected";
		if($user[umaxposts]==5) $s_umaxposts[1] = "selected";
                if($user[umaxposts]==10) $s_umaxposts[2] = "selected";
                if($user[umaxposts]==20) $s_umaxposts[3] = "selected";
                if($user[umaxposts]==30) $s_umaxposts[4] = "selected";
                if($user[umaxposts]==40) $s_umaxposts[5] = "selected";
                
                if($user[bbcode]) $use_bbcode[1] = "Checked";
		else $use_bbcode[0] = "Checked";
		
		$style_result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style = 0 ORDER by stylename ASC");
		while($row = $db_zugriff->fetch_array($style_result)) {
			if($user[style_set]==$row[styleid]) $u_style .= "<option value=\"$row[styleid]\" selected>$row[stylename]</option>";
			else $u_style .= "<option value=\"$row[styleid]\">$row[stylename]</option>";
		}
		$db_zugriff->free_result($style_result);
		 eval("dooutput(\"".gettemplate("profile_editoptions")."\");");
        }

	if($mode=="buddy") {
		if($send == "send" && $buddylist) {
			$buddylist = explode(",",$buddylist);
        		for($i = 0; $i < count($buddylist); $i++) {
        			$buddylist[$i] = getUserid(trim($buddylist[$i]));
        			if(!$buddylist[$i] || $buddylist[$i]==$user_id) continue;
        			if(check_userobject($user_id,$buddylist[$i],"buddylist")) $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$user_id' AND objectid = '$buddylist[$i]' AND buddylist = 1");
        			else $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,buddylist) VALUES ('$user_id','$buddylist[$i]','1')");
        		}
		}	

                $buddylist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND buddylist = 1");
                while($row = $db_zugriff->fetch_array($buddylist)) {
                        if(checkuseronline($row[objectid])) {
                        	if($online) $online .= ", ";
                                $online .= "<a href=\"members.php?mode=profile&userid=".$row[objectid]."&boardid=$boardid$session\">".$row[username]."</a>";
                        } else {
                        	if($offline) $offline .= ", ";
                                $offline .= "<a href=\"members.php?mode=profile&userid=".$row[objectid]."&boardid=$boardid$session\">".$row[username]."</a>";
                        }
                }
                eval("dooutput(\"".gettemplate("profile_buddy")."\");");
        }

	if($mode=="ignore") {
		if($send == "send" && $ignorelist) {
			$ignorelist = explode(",",$ignorelist);
        		for($i = 0; $i < count($ignorelist); $i++) {
        			$ignorelist[$i] = getUserid(trim($ignorelist[$i]));
        			if(!$ignorelist[$i] || $ignorelist[$i]==$user_id) continue;
        			if(check_userobject($user_id,$ignorelist[$i],"ignorelist")) $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$user_id' AND objectid = '$ignorelist[$i]' AND ignorelist = 1");
        			else $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,ignorelist) VALUES ('$user_id','$ignorelist[$i]','1')");
        		}
		}	

                $ignorelist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND ignorelist = 1");
                while($row = $db_zugriff->fetch_array($ignorelist)) {
                	if($ignoreusers) $ignoreusers .= "<br>";
                	$ignoreusers .= "<a href=\"members.php?mode=profile&userid=".$row[objectid]."&boardid=$boardid$session\">".$row[username]."</a>";
                }
                eval("dooutput(\"".gettemplate("profile_ignore")."\");");
        }

	if($mode=="subscripe") {
		
		$result = $db_zugriff->query("
			SELECT
			bb".$n."_object2user.objectid as boardid,
			bb".$n."_boards.*,
			bb".$n."_posts.threadparentid,
			bb".$n."_posts.userid,
			bb".$n."_posts.posttime,
			bb".$n."_threads.threadname,
			bb".$n."_threads.topicicon,
			bb".$n."_threads.boardparentid as parentid,
			bb".$n."_user_table.username	
			FROM bb".$n."_object2user
			LEFT JOIN bb".$n."_boards ON (bb".$n."_object2user.objectid = bb".$n."_boards.boardid)
			LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid) 
			LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid) 
			LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid) 
			WHERE bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favboards = 1
			ORDER by boardparentid ASC, sort ASC");
		while ($row = $db_zugriff->fetch_array($result)) {
			if($row[invisible] && !check_boardobject($row[boardid],$user_group,"boardpermission")) continue; 
			if(!$firstid) $firstid = $row[boardparentid];
			$boardcache[$row[boardparentid]][$row[sort]][$row[boardid]] = $row;
		}
		$boardbit = makeforumbit($firstid,1,1);
		$db_zugriff->free_result($result);
		if($boardbit) eval ("\$subscripe_boards = \"".gettemplate("profile_subscripe_board")."\";");
		
		$thread_result = $db_zugriff->query("SELECT DISTINCT bb".$n."_threads.threadid, bb".$n."_threads.* FROM bb".$n."_threads, bb".$n."_object2user WHERE bb".$n."_object2user.objectid = bb".$n."_threads.threadid AND bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favthreads = 1 ORDER by important DESC, timelastreply DESC");
             	if($db_zugriff->num_rows($thread_result)) {
             		while($threads = $db_zugriff->fetch_array($thread_result)){						
		
				unset($folder_image);
				unset($thread_link);
				unset($rate);
				unset($anonymous_lp);
				unset($anonymous);
				unset($thread_starter);
				unset($lastauthor);
				
				$sthreadname = "sthread_".$threads[threadid];	
				if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) $folder_image .= "new";		
				if($threads[replies] > "15" || $threads[views] > "150") $folder_image .= "hot";
				if($threads[flags]==1) $folder_image .= "lock";
				$folder_image = "<img src=\"images/".$folder_image."folder.gif\">";
				
				if($threads[topicicon]) $posticon = "<img src=\"$threads[topicicon]\">";
				else $posticon = "&nbsp;";
		
				if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
				$thread_link .= "<font size=2 face=\"{font}\"><b>";
				if($threads[important]) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
				if($threads[pquestion]) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
				$thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session\">".prepare_topic($threads[threadname])."</a></b></font>";
				if(($threads[replies]+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"$font\"> ( <img src=\"images/multipage.gif\"> <a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=1\">1</a> <a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=2\">2</a> ";
				if(($threads[replies]+1)/$eproseite > 2) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=3\">3</a> ";
				if(($threads[replies]+1)/$eproseite > 3) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads[threadid]."&boardid=$threads[boardparentid]&styleid=$styleid$session&page=4\">4</a> ";
				if(($threads[replies]+1)/$eproseite > 4) {
					$pagesx=ceil(($threads[replies]+1)/$eproseite);
					eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
					$pages = 0;
				}
				if(($threads[replies]+1)/$eproseite > 1) $thread_link .= ")";
				eval ("\$thread_link .= \"".gettemplate("profile_subscripe_delthread")."\";");
		
				$starttime = formatdate($threads[starttime],$longdateformat,1);
				if($threads[authorid]) $thread_starter = getUsername($threads[authorid]);
				else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
				$lastposttime = formatdate($threads[timelastreply],$longdateformat,1);
				$lastauthorid = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE threadparentid='$threads[threadid]' ORDER by posttime DESC LIMIT 1");
				$lastauthorid = $lastauthorid[userid];
				if($lastauthorid) $lastauthor = getUsername($lastauthorid);
				else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
		
				eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");
				
				if($threads[rated] && $threads[rate_points]) {
					$j = round($threads[rate_points]/$threads[rated]);
					for ($j; $j > 0; $j--) $rate .= "<img src=\"images/star.gif\" border=0>";
				}
				else $rate = "&nbsp;";
		
				eval ("\$threadbit .= \"".gettemplate("board_threadbit")."\";");
			}
			$db_zugriff->free_result($thread_result);
			eval ("\$subscripe_threads .= \"".gettemplate("profile_subscripe_thread")."\";");
             	}
                
                
                eval("dooutput(\"".gettemplate("profile_subscripe")."\");");
        }

} else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>

