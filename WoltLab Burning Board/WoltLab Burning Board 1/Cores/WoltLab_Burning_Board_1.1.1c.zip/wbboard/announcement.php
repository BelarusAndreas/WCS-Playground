<? 
require("_functions.php");
require("_header.php");
require("_board_jump.php");

$result = $db_zugriff->query_first("
	SELECT bb".$n."_announcements.*, bb".$n."_avatars.*, bb".$n."_user_table.* FROM bb".$n."_announcements
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_announcements.userid = bb".$n."_user_table.userid)
	LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id = bb".$n."_user_table.avatarid)
	WHERE announcementid ='$id'");

$result[topic] = prepare_topic($result[topic]);
if($result[statusextra]) $status = editDBdata($result[statusextra]);
else $status = getUserrang($result[userposts],$result[groupid]); 
$stars = getUserStars($result[userposts],$result[groupid]);
if($result[avatarid] && !$hide_userpic && $avatars) $user_pic = "<br><img src=\"images/avatars/avatar-".$result[avatarid].".".$result[extension]."\" border=0>";
$result[location] = prepare_topic($result[location]);
$result[message] = editPost($result[message]);	
$regdate = formatdate($result[regdate],$regdateformat);
eval("dooutput(\"".gettemplate("announcement")."\");");	
?>
			
					