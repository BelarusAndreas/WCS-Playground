<?
require "_functions.php";
// ############## Login ###############
if($action=="login") {
$kennwort = md5($kennwort);
$username = htmlspecialchars(trim($username));
$usercheck = checkUser($username,$kennwort);
if($usercheck==2) {
	if(!$link) $ride = urldecode($url_jump);
	else $ride = urldecode($link);

	$user_id = getUserid($username);
	$user_password = $kennwort;
	session_register("user_id");
	session_register("user_password");

	setcookie("user_id", "$user_id", time()+(3600*24*365));
	setcookie("user_password", "$user_password", time()+(3600*24*365));

	eval ("\$output = \"".gettemplate("note1")."\";");
}
if($usercheck==0) eval ("\$output = \"".gettemplate("error1")."\";");
if($usercheck==1) eval ("\$output = \"".gettemplate("error2")."\";");
}

// ############## Logout ###############
if($action=="logout") {
	$ride = urldecode($url_jump);
	if(!@session_destroy()) @session_unset();
	setcookie("user_id");
	setcookie("user_password");
	if(count($cbpassword)) while(list($key,$val)=each($cbpassword)) setcookie("cbpassword[$key]");
	eval ("\$output = \"".gettemplate("note2")."\";");
}
// ############## als gelesen markieren ###############
if($action=="makeallread") {

        $old_time = time();
        $new_time = time();
        
        if($user_id) $db_zugriff->query("UPDATE bb".$n."_user_table SET lastvisit = '$old_time', lastactivity = '$new_time' WHERE userid = '$user_id'");
        else {
        	session_register("old_time");
        	session_register("new_time");
        }
        $ride = urldecode($url_jump);
        eval ("\$output = \"".gettemplate("note7")."\";");
}

// ############## unsubscripe thread ###############
if($action=="delthread") {
        if($user_id) {
                unsubscripe($threadid,$user_id,"threads");
                $threadname = getThreadname($threadid);
                eval ("\$output = \"".gettemplate("note11")."\";");
                $ride = urldecode($url_jump);
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## unsubscripe board ###############
if($action=="delboard") {
        if($user_id) {
                unsubscripe($boardid,$user_id,"boards");
                $boardname = getBoardname($boardid);
                eval ("\$output = \"".gettemplate("note10")."\";");
                $ride = urldecode($url_jump);
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## noemail ###############
if($action=="noemail") {
        if($threadid && $userid) {
                $db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid = '$threadid' AND userid = '$userid'");
                eval ("\$output = \"".gettemplate("note12")."\";");
                $ride = "main.php?$session2";
        }
        else eval ("\$output = \"".gettemplate("error3")."\";");
}

// ############## Formmailer ###############
if($action=="formmail") {
        if($userid) {
                $useremail = getUserEmail($userid);
                $username = getUsername($userid);
        }
        if($absender && $message && $useremail) {
                formmail($absender,$message,$betreff,$useremail);
                $name = ($username ? $username : $useremail);
                eval ("\$output = \"".gettemplate("note13")."\";");
                $ride = urldecode($url_jump);
        } else eval ("\$output = \"".gettemplate("error17")."\";");
}

// ############## Report ###############
if($action=="report") {
        if($user_id) {
                if($reason) {
                        report($user_id,$postid,$boardid);
                        eval ("\$output = \"".gettemplate("note14")."\";");
                        $ride = "thread.php?styleid=$styleid&boardid=$boardid&threadid=$threadid&page=$page$session";
                } else eval ("\$output = \"".gettemplate("error17")."\";");
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## Activation ###############
if($action=="activation") {
        $result = activat($userid,$code);
        if($result == 1) eval ("\$output = \"".gettemplate("error1")."\";");
        if($result == 2) eval ("\$output = \"".gettemplate("error22")."\";");
        if($result == 3) eval ("\$output = \"".gettemplate("error23")."\";");
        if(!$result) {
                $user_id = $userid;
                eval ("\$output = \"".gettemplate("note21")."\";");
                $user_password = getUserPW($userid);
                session_register("user_id");
                session_register("user_password");
                setcookie("user_id", "$user_id", time()+(3600*24*365));
		setcookie("user_password", "$user_password", time()+(3600*24*365));
	}
        $ride = "main.php?styleid=$styleid$session";
}
// ############## addfriend ###############
if($action=="addfriend") {
        if($user_id) {
                $ride = urldecode($url_jump);
                if($user_id != $userid) {
                	$check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2user WHERE userid='$user_id' AND objectid = '$userid' AND buddylist = 1");
			if(!$check[0]) $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,buddylist) VALUES ('$user_id','$userid','1')");	
			$name = getUsername($userid);
                        eval ("\$output = \"".gettemplate("buddy_note5")."\";");
                }
                else eval ("\$output = \"".gettemplate("buddy_note2")."\";");
        } 
        else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## addboard ###############
if($action=="addboard") {
        if($user_id) {
                $ride = urldecode($url_jump);
                $output = subscripe($user_id,$boardid,"boards");
                if(!$output) {
                        $boardname = getBoardname($boardid);
                        eval ("\$output = \"".gettemplate("note22")."\";");
                }
        } else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## addthread ###############
if($action=="addthread") {
        if($user_id) {
                $ride = urldecode($url_jump);
                $output = subscripe($user_id,$threadid,"threads");
                if(!$output) {
                        $threadname = getThreadname($threadid);
                        eval ("\$output = \"".gettemplate("note23")."\";");
                }
        } else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## getLastPost main ###############
if($action=="getlastmain") {
        header("LOCATION: ".getLastPost($boardid,1)."");
        exit;
}
// ############## getLastPost board ###############
if($action=="getlastboard") {
        header("LOCATION: ".getLastPost($threadid,2)."");
        exit;
}
// ############## getLastPost Autor ###############
if($action=="getlastautor") {
        $username = getUsername($userid);
        header("LOCATION: ".getLastPost($username,4)."");
        exit;
}

// ############## getLastPost main ###############
if($action=="firstnew") {
        header("LOCATION: ".firstnewPost($threadid,$old_time)."");
        exit;
}

// ############## getLastPost main ###############
if($action=="vote") {
        if(!$vote) {
        	header("LOCATION: ".urldecode($url_jump)."");
        	exit;
        }
        if(!$userdata[canvotepoll]) {
        	header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
        	exit;       
        }
        $thread_info = $db_zugriff->query_first("SELECT starttime,ptimeout FROM bb".$n."_threads WHERE threadid = '$threadid'");
	$poll_check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_vote WHERE threadid='$threadid' AND userid = '$user_id'");
	if($poll_check[0] || ($thread_info[ptimeout] && time() >= ($thread_info[starttime]+$thread_info[ptimeout]*(24*3600)))) {
		eval ("\$output = \"".gettemplate("error25")."\";");	
        	$ride = urldecode($url_jump)."&presult=1";
        }
        else {
        	$db_zugriff->query("UPDATE bb".$n."_poll set votes=votes+1 WHERE id='$vote'");
        	if($user_id) $db_zugriff->query("INSERT INTO bb".$n."_vote VALUES ('$threadid','$user_id')");
        	eval ("\$output = \"".gettemplate("note24")."\";");	
        	$ride = urldecode($url_jump)."&presult=1";
        	setcookie("vote_poll[$pollid]", "1", time()+(3600*24*365));
        }
}

// ############## rate thread ###############
if($action=="rate_thread") {
        if($rate!=-1) {
                $db_zugriff->query("UPDATE bb".$n."_threads set rate_points=rate_points+$rate, rated=rated+1 WHERE threadid='$threadid'");
                $output = "Bewertung erfolgreich durchgef�hrt!";
                $ride = urldecode($url_jump);

        }
        else eval ("\$output = \"".gettemplate("error3")."\";");
}

if($action=="thread_order") {
        header("LOCATION: board.php?boardid=$boardid&styleid=$styleid$session&sortfield=$sortfield&sortorder=$sortorder&daysprune=$daysprune&page=$page");
        exit;
}

// ############## boardpw ###############
if($action == "boardpw") {
	if(!$boardpassword) eval ("\$output = \"".gettemplate("error3")."\";");
	else {
		if($db_zugriff->query_first("SELECT boardid FROM bb".$n."_boards WHERE boardid='$boardid' AND boardpassword='$boardpassword'")) {
			setcookie("cbpassword[$boardid]",md5($boardpassword), time()+3600*24*365);
			$ride = urldecode($url_jump);
        	        eval ("\$output = \"".gettemplate("note25")."\";");	
		}
		else eval ("\$output = \"".gettemplate("error2")."\";");
	}
}

if($action == "forgotpw") {
	$result = $db_zugriff->query_first("SELECT userid, username, useremail FROM bb".$n."_user_table WHERE userid = '$userid' AND userpassword = '$code'");
	if(!$result[userid]) eval ("\$output = \"".gettemplate("error3")."\";");
	else {
		$kette = "abcdefghijklmnopqrstuvwxyz";
		for($i = 0; $i < 6; $i++) {
			$datum = date("s", time()+$i*4567);
                	mt_srand($datum);
                        $zahl = mt_rand(0,25);
                        $newpw .= substr($kette, $zahl, 1);
		}
		eval ("\$betreff = \"".gettemplate("forgotpw_betreff2","txt")."\";");
		eval ("\$inhalt = \"".gettemplate("forgotpw_mail2","txt")."\";");
		mail($result[useremail],$betreff,$inhalt,"From: $master_email");
		$db_zugriff->query("UPDATE bb".$n."_user_table SET userpassword = '".md5($newpw)."' WHERE userid = '$userid'");
		
		header("Location: main.php$session2");	
		exit;
	}
}

eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
if($ride) eval("dooutput(\"".gettemplate("action_ride")."\");");
else eval("dooutput(\"".gettemplate("action_error")."\");");
?>
