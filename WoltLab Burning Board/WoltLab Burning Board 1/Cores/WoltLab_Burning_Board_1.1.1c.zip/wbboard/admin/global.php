<?
require "./../_data.inc.php";
require "./../class_db_zugriff.php";

$db_zugriff = new db_zugriff;

$db_zugriff->appname="WoltLab Burning Board";
$db_zugriff->database=$mysqldb;
$db_zugriff->server=$mysqlhost;
$db_zugriff->user=$mysqluser;
$db_zugriff->password=$mysqlpassword;

$db_zugriff->connect();

// ####################### Sessions ##############################

session_name("sid");
session_start();
if(!$sid) $sid = session_id();

$user_id=$HTTP_COOKIE_VARS['user_id'];
$user_password=$HTTP_COOKIE_VARS['user_password'];
if(!$user_id) $user_id = $HTTP_SESSION_VARS[user_id];
if(!$user_password) $user_password = $HTTP_SESSION_VARS[user_password];

$session = "&sid=".$sid;
$session2 = "?sid=".$sid;


function gettemplate($template) {

        $file = file("templates/".$template.".htm");
        $template = implode("",$file);
        $template = str_replace("\"","\\\"",$template);
        return $template;
}

function dooutput($template) {

        echo $template;
}

function getUserid($usernick) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username='$usernick'");
        return $result[userid];
}

function getUser_stat($userid,$password)  {
	global $n,$db_zugriff;
	$result = $db_zugriff->query_first("SELECT groupid, blocked FROM bb".$n."_user_table WHERE userid='$userid' AND userpassword='$password' AND activation='1'");
        $result = $db_zugriff->query_first("SELECT canuseacp FROM bb".$n."_groups WHERE id = '$result[groupid]'");
        return $result[0];
}

function editDBdata($data) {
	$data = str_replace("&acute;","'", $data);
	$data = str_replace("&quot;","\"", $data);
	return $data;
}

function editPostdata($data) {
	$data = str_replace("'","&acute;", $data);
	$data = str_replace("\"","&quot;", $data);
	return $data;
}

function check_boardobject($boardid,$objectid,$field) {
	global $db_zugriff, $n;
	$result = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$boardid' AND objectid = '$objectid' AND $field = 1");
	return $result[0];
}

function checkemail($email) {
	
	global $db_zugriff, $n;
	if(!substr_count($email,"@") || substr_count($email,"@")>1) return 1;
	$position1 = strrpos($email,"@");
	if(!$position1) return 1;
	$position2 = strrpos($email,".");
	if(!$position2) return 1;
	if(strlen(substr($email, $position2)) < 3)return 1;
	if(strlen(substr($email, $position1,$position2-$position1-1))<2) return 1;

	$result = $db_zugriff->query_first("SELECT multi_email, banemail FROM bb".$n."_config");
	if(!$result[0]) {
		$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE useremail = '$email'");
		if($check[0]) return 1;
	}
	$banemail = explode("\n",$result[banemail]);
	for($i = 0; $i < count($banemail); $i++) {
		if(!trim($banemail[$i])) continue;
		if(ereg("\*", $banemail[$i])) {
			$banemail[$i] = str_replace("*",".*", trim($banemail[$i]));
			if(eregi("$banemail[$i]", $email)) return 1;
			break;
		}
		elseif(strtolower($email)==strtolower(trim($banemail[$i]))) {
			return 1;
			break;
		}  
	}
	
}

function checkname($name) {
	global $db_zugriff, $n;
	$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE username = '$name'");
	return $check[0];
}

function Hackdate($time) {
	global $db_zugriff, $n;
	$config = $db_zugriff->query_first("SELECT timeoffset, shortdateformat, timetype  FROM bb".$n."_config");
	$out = str_replace("DD",date("d", $time+(3600*$config[timeoffset])), $config[shortdateformat]);
	$out = str_replace("MM",date("m", $time+(3600*$config[timeoffset])), $out);
	$out = str_replace("YYYY",date("Y", $time+(3600*$config[timeoffset])), $out);
	$out = str_replace("YY",date("y", $time+(3600*$config[timeoffset])), $out);
	$out = str_replace("MN",get_month_name(date("n", $time+(3600*$config[timeoffset]))), $out);
	if($config[timetype]) { #12 Stunden
		$out = str_replace("II","II ".date("A", $time+(3600*$config[timeoffset])), $out);	
		$out = str_replace("HH",date("h", $time+(3600*$config[timeoffset])), $out);
	}
	else $out = str_replace("HH",date("H", $time+(3600*$config[timeoffset])), $out);
	$out = str_replace("II",date("i", $time+(3600*$config[timeoffset])), $out);
	return $out;
}

function get_month_name($month_number) {
	$name_monat[1]    =  "Januar";  
	$name_monat[2]    =  "Februar";  
	$name_monat[3]    =  "M&auml;rz";  
	$name_monat[4]    =  "April";  
	$name_monat[5]    =  "Mai";  
	$name_monat[6]    =  "Juni";  
	$name_monat[7]    =  "Juli";  
	$name_monat[8]    =  "August";  
	$name_monat[9]    =  "September";  
	$name_monat[10]  =  "Oktober";  
	$name_monat[11]  =  "November";  
	$name_monat[12]  =  "Dezember";
	
	return $name_monat[$month_number];
}

function bb_order() {
	global $db_zugriff, $n;
	
	$board_result = $db_zugriff->query("SELECT boardid FROM bb".$n."_boards");
	while($boards = $db_zugriff->fetch_array($board_result)) {
		$countp = $db_zugriff->query_first("SELECT COUNT(postid) FROM bb".$n."_posts WHERE boardparentid = '$boards[boardid]'");
               	$countt = $db_zugriff->query_first("SELECT COUNT(threadid) FROM bb".$n."_threads WHERE boardparentid = '$boards[boardid]'");
                $lastpost = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$boards[boardid]' ORDER BY posttime DESC LIMIT 1");
                $db_zugriff->query("UPDATE bb".$n."_boards SET posts = '$countp[0]', threads = '$countt[0]', lastposttime = '$lastpost[posttime]', lastpostid = '$lastpost[postid]' WHERE boardid = '$boards[boardid]'");	
	}
}

function ifelse ($expression,$returntrue,$returnfalse) {
	if (!$expression) return $returnfalse;
	else return $returntrue;
}

?>
