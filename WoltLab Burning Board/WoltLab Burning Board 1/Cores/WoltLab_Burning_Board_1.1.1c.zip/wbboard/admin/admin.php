<? 
@set_time_limit(1200);
require "global.php"; 

if(!getUser_stat($user_id,$user_password)) {
	header("LOCATION: index.php");
	exit;
} 

eval ("\$headinclude = \"".gettemplate("headinclude")."\";");	

if($action == "welcome") {

	$inaktiv = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE activation <> 1");
	$blocked = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE blocked <> 0");
	$pms_count = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_pms");
	$inaktiv = $inaktiv[0];
	$blocked = $blocked[0];
	$pms_count = $pms_count[0];
	eval("dooutput(\"".gettemplate("welcome")."\");");
}
if($action == "switch_onoff") {
	if($send == "send") $db_zugriff->query("UPDATE bb".$n."_config SET boardoff = '$onoff', boardoff_text = '".editPostdata($offlinemessage)."'");
	$info = $db_zugriff->query_first("SELECT boardoff, boardoff_text FROM bb".$n."_config");
	if(!$info[0]) $selected[0] = " selected";
	else $selected[1] = " selected";
	$offlinemessage = editDBdata($info[1]);
	eval("dooutput(\"".gettemplate("switch_onoff")."\");");
}

if($action == "board_options") {
	if($send == "send") {
	
		if(!$boardname || !$masteremail || !$php_path || !$regdateformat || !$shortdateformat || !$longdateformat) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET php_path = '".editPostdata($php_path)."', master_board_name = '".editPostdata($boardname)."', master_email = '".editPostdata($masteremail)."', regdateformat = '".editPostdata($regdateformat)."', shortdateformat = '".editPostdata($shortdateformat)."', longdateformat = '".editPostdata($longdateformat)."', today = '".editPostdata($today)."', timetype = '$timetype', timeoffset = '$timeoffset'");
	}
	$info = $db_zugriff->query_first("SELECT php_path, master_board_name, master_email, regdateformat, shortdateformat, longdateformat, today, timetype, timeoffset FROM bb".$n."_config");
	
	$boardname = editDBdata($info[master_board_name]);
	$php_path = editDBdata($info[php_path]);
	$masteremail = editDBdata($info[master_email]);
	$regdateformat = editDBdata($info[regdateformat]);
	$shortdateformat = editDBdata($info[shortdateformat]);
	$longdateformat = editDBdata($info[longdateformat]);
	$today = editDBdata($info[today]);
	
	if(!$info[timetype]) $selected[0] = " selected";
	else $selected[1] = " selected";
	
	for($i = -24; $i <= 24; $i++) {
		$timeoffset_select .= "<option value=\"$i\"";
		if($i == $info[timeoffset]) $timeoffset_select .= " selected";
		$timeoffset_select .= ">$i</option>\n";
	}	
	eval("dooutput(\"".gettemplate("board_options")."\");");
}

if($action == "foren_options") {
	if($send == "send") {
	
		$tproseite = (int)($tproseite);
		if(!$tproseite) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET tproseite = '$tproseite', default_daysprune = '$default_daysprune', show_subboards = '$show_subboards'");
	}
	$info = $db_zugriff->query_first("SELECT tproseite, default_daysprune, show_subboards FROM bb".$n."_config");
	
	$tproseite = $info[tproseite];
	if(!$info[show_subboards]) $selected[0] = " selected";
	else $selected[1] = " selected";
	
	switch($info[default_daysprune]) {
		case 1: $s_prunedays[1] = " selected"; break;
		case 2: $s_prunedays[2] = " selected"; break; 
		case 5: $s_prunedays[3] = " selected"; break;
		case 10: $s_prunedays[4] = " selected"; break;
		case 20: $s_prunedays[5] = " selected"; break;
		case 30: $s_prunedays[6] = " selected"; break;
		case 45: $s_prunedays[7] = " selected"; break;
		case 60: $s_prunedays[8] = " selected"; break;
		case 75: $s_prunedays[9] = " selected"; break;
		case 100: $s_prunedays[10] = " selected"; break;
		case 365: $s_prunedays[11] = " selected"; break;
		case 1000: $s_prunedays[12] = " selected"; break;
	}	
	eval("dooutput(\"".gettemplate("foren_options")."\");");
}

if($action == "thread_options") {
	if($send == "send") {
		$eproseite = (int)($eproseite);
		$hotthread_view = (int)($hotthread_view);
		$hotthread_reply = (int)($hotthread_reply);
		if(!$eproseite || !$hotthread_view || !$hotthread_reply) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET eproseite = '$eproseite', postorder = '$postorder', hotthread_reply = '$hotthread_reply', hotthread_view = '$hotthread_view'");
	}
	$info = $db_zugriff->query_first("SELECT eproseite, postorder, hotthread_view, hotthread_reply FROM bb".$n."_config");
	$eproseite = $info[eproseite];
	$hotthread_view = $info[hotthread_view];
	$hotthread_reply = $info[hotthread_reply];
	
	if(!$info[postorder]) $selected[0] = " selected";
	else $selected[1] = " selected";
	
	eval("dooutput(\"".gettemplate("thread_options")."\");");
}

if($action == "post_options") {
	if($send == "send") {
		$anzahl_smilies = (int)($anzahl_smilies);
		if(!$anzahl_smilies || !$cover || ($anzahl_smilies && round($anzahl_smilies/3)-($anzahl_smilies/3)!=0)) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET html = '$html', smilies = '$smilies', bbcode = '$bbcode', maximage = '$maximage', polls = '$polls', image = '$image', image_ext = '".editPostdata($image_ext)."', ch_parseurl = '$ch_parseurl', ch_email = '$ch_email', ch_disablesmilies = '$ch_disablesmilies', ch_signature = '$ch_signature', anzahl_smilies = '$anzahl_smilies', badwords = '".editPostdata($badwords)."', cover = '".editPostdata($cover)."'");
	}
	$info = $db_zugriff->query_first("SELECT html, smilies, bbcode, maximage, polls, image, image_ext, ch_parseurl, ch_email, ch_disablesmilies, ch_signature, anzahl_smilies, badwords, cover FROM bb".$n."_config");
	
	if(!$info[html]) $html_selected[0] = " selected";
	else $html_selected[1] = " selected";
	if(!$info[smilies]) $smilies_selected[0] = " selected";
	else $smilies_selected[1] = " selected";
	if(!$info[bbcode]) $bbcode_selected[0] = " selected";
	else $bbcode_selected[1] = " selected";
	if(!$info[polls]) $polls_selected[0] = " selected";
	else $polls_selected[1] = " selected";
	if(!$info[image]) $image_selected[0] = " selected";
	else $image_selected[1] = " selected";
	if(!$info[ch_parseurl]) $ch_parseurl_selected[0] = " selected";
	else $ch_parseurl_selected[1] = " selected";
	if(!$info[ch_email]) $ch_email_selected[0] = " selected";
	else $ch_email_selected[1] = " selected";
	if(!$info[ch_disablesmilies]) $ch_disablesmilies_selected[0] = " selected";
	else $ch_disablesmilies_selected[1] = " selected";
	if(!$info[ch_signature]) $ch_signature_selected[0] = " selected";
	else $ch_signature_selected[1] = " selected";
	
	$image_ext = editDBdata($info[image_ext]);
	$badwords = editDBdata($info[badwords]);
	$cover = editDBdata($info[cover]);
	$maximage = $info[maximage];
	$anzahl_smilies = $info[anzahl_smilies];
	
	eval("dooutput(\"".gettemplate("post_options")."\");");
}

if($action == "register_options") {
	if($send == "send") $db_zugriff->query("UPDATE bb".$n."_config SET register = '$register', act_code = '$act_code', act_permail = '$act_permail', regnotify = '$regnotify', multi_email = '$multi_email', banname = '".editPostdata($banname)."', banemail = '".editPostdata($banemail)."'");
	$info = $db_zugriff->query_first("SELECT register, act_code, act_permail, regnotify, multi_email, banname, banemail FROM bb".$n."_config");
	
	if(!$info[register]) $register_selected[0] = " selected";
	else $register_selected[1] = " selected";
	if(!$info[act_code]) $act_code_selected[0] = " selected";
	else $act_code_selected[1] = " selected";
	if(!$info[act_permail]) $act_permail_selected[0] = " selected";
	else $act_permail_selected[1] = " selected";
	if(!$info[regnotify]) $regnotify_selected[0] = " selected";
	else $regnotify_selected[1] = " selected";
	if(!$info[multi_email]) $multi_email_selected[0] = " selected";
	else $multi_email_selected[1] = " selected";
	
	$banname = editDBdata($info[banname]);
	$banemail = editDBdata($info[banemail]);
	
	eval("dooutput(\"".gettemplate("register_options")."\");");
}

if($action == "member_options") {
	if($send == "send") {
		$avatar_width = (int)($avatar_width);
		$avatar_height = (int)($avatar_height);
		$avatar_size = (int)($avatar_size);
		if(!$avatar_size || !$avatar_width || !$avatar_height) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET sigsmilies = '$sigsmilies', sigbbcode = '$sigbbcode', sightml = '$sightml', sigimage = '$sigimage', sigmaximage = '".(int)($sigmaximage)."', sigimage_ext = '".editPostdata($sigimage_ext)."', siglength = '".(int)($siglength)."', avatars = '$avatars', avatarimage_ext = '".editPostdata($avatarimage_ext)."', avatar_width = '".(int)($avatar_width)."', avatar_height = '".(int)($avatar_height)."', avatar_size = '".(int)($avatar_size)."', usertextlength = '".(int)($usertextlength)."', favboards = '".(int)($favboards)."', favthreads = '".(int)($favthreads)."'");
	}
	$info = $db_zugriff->query_first("SELECT sigsmilies, sigbbcode, sightml, sigimage, sigmaximage, sigimage_ext, siglength, avatars, avatarimage_ext, avatar_width, avatar_height, avatar_size, usertextlength, favboards, favthreads FROM bb".$n."_config");
	
	if(!$info[sigsmilies]) $sigsmilies_selected[0] = " selected";
	else $sigsmilies_selected[1] = " selected";
	if(!$info[sigbbcode]) $sigbbcode_selected[0] = " selected";
	else $sigbbcode_selected[1] = " selected";
	if(!$info[sightml]) $sightml_selected[0] = " selected";
	else $sightml_selected[1] = " selected";
	if(!$info[sigimage]) $sigimage_selected[0] = " selected";
	else $sigimage_selected[1] = " selected";
	if(!$info[avatars]) $avatars_selected[0] = " selected";
	else $avatars_selected[1] = " selected";
		
	$sigmaximage = $info[sigmaximage];
	$siglength = $info[siglength];
	$avatar_width = $info[avatar_width];
	$avatar_height = $info[avatar_height];
	$avatar_size = $info[avatar_size];
	$usertextlength = $info[usertextlength];
	$favboards = $info[favboards];
	$favthreads = $info[favthreads];
	
	$sigimage_ext = editDBdata($info[sigimage_ext]);
	$avatarimage_ext = editDBdata($info[avatarimage_ext]);
		
	eval("dooutput(\"".gettemplate("member_options")."\");");
}

if($action == "pms_options") {
	if($send == "send") $db_zugriff->query("UPDATE bb".$n."_config SET pms = '$pms', maxpms = '".(int)($maxpms)."', maxfolder = '".(int)($maxfolder)."'");
	$info = $db_zugriff->query_first("SELECT pms, maxpms, maxfolder FROM bb".$n."_config");
	
	if(!$info[pms]) $pms_selected[0] = " selected";
	else $pms_selected[1] = " selected";
	
	$maxpms = $info[maxpms];
	$maxfolder = $info[maxfolder];
	
	eval("dooutput(\"".gettemplate("pms_options")."\");");
}

function makeboardlist($boardid) {
 global $boardcache;

 if(!isset($boardcache[$boardid])) return;
 
 $out.="<ul>";
 while (list($key1,$val1) = each($boardcache[$boardid])) {
  while(list($key2,$boards) = each($val1)) {
   $count = countboards($boardcache[$boardid]);
   unset($options);
   for($i = 1; $i <= $count; $i++) $options .= " <option value=\"$i\"".ifelse($boards[sort]==$i," selected","").">$i</option>";
   eval ("\$out .= \"".gettemplate("board_viewbit")."\";");
   $out .= makeboardlist($boards[boardid]);
  } 
 } 
 unset($boardcache[$boardid]);
 return $out."</ul>";
}

function countboards($array) {
 $count=0;
 reset($array);
 while(list($key,$val)=each($array)) $count+=count($val);
 return $count;
}

if($action == "board_view") {
 if($send == "send") while(list($key,$val)=each($boardorder)) $db_zugriff->query("UPDATE bb".$n."_boards SET sort='$val' WHERE boardid = '$key'");
 	
 $result = $db_zugriff->query("SELECT boardid, boardparentid, sort, boardname FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
 while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row[boardparentid]][$row[sort]][$row[boardid]] = $row;	
 $boardlist = makeboardlist(0);
	
 eval("dooutput(\"".gettemplate("board_view")."\");");	
}

if($action == "board_del") {
	if($send == "send" && $boardid) {
		$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE boardid = $boardid AND (mod = 1 OR boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
		$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid = $boardid AND favboards = 1");
		$db_zugriff->query("UPDATE bb".$n."_boards SET boardparentid = 0 WHERE boardparentid = $boardid");
		$db_zugriff->query("DELETE FROM bb".$n."_boards WHERE boardid = $boardid");
		$result = $db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE boardparentid = $boardid");
		while($row=$db_zugriff->fetch_array($result)) $threadids .= ",$row[threadid]";
		$db_zugriff->query("DELETE FROM bb".$n."_threads WHERE boardparentid = $boardid");
		$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid IN (0$threadids) AND favthreads = 1");
		
		$result = $db_zugriff->query("SELECT COUNT(postid) AS posts, userid FROM bb".$n."_posts WHERE boardparentid = $boardid GROUP BY userid");
		while($row=$db_zugriff->fetch_array($result)) $db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts-'$row[posts]' WHERE userid=$row[userid]");
		
		$db_zugriff->query("DELETE FROM bb".$n."_posts WHERE boardparentid = $boardid");
		header("Location: admin.php?action=board_view$session");
		exit();
	}

	$board = $db_zugriff->query_first("SELECT boardname FROM bb".$n."_boards WHERE boardid='$boardid'");
	eval("dooutput(\"".gettemplate("board_del")."\");");
}

if($action == "board_add") {
	if($send == "send") {
		$boardname = trim($boardname);
		if(!$boardname || !count($boardpermission)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("INSERT INTO bb".$n."_boards VALUES ('','$boardparentid','".editPostdata($boardname)."','".trim($boardpassword)."','".editPostdata($descriptiontext)."','0','0','0','0','1','$isboard','$invisible','$style_set')");
			$insertid = $db_zugriff->insert_id();
			for($i = 0; $i < count($boardmods); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,mod) VALUES ('$insertid','$boardmods[$i]','1')");
			if($boardpermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$insertid','$row[id]','1')");
			}
			else for($i = 0; $i < count($boardpermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$insertid','$boardpermission[$i]','1')");
			if($startpermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$insertid','$row[id]','1')");
			}
			else for($i = 0; $i < count($startpermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$insertid','$startpermission[$i]','1')");
			if($replypermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$insertid','$row[id]','1')");
			}
			else for($i = 0; $i < count($replypermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$insertid','$replypermission[$i]','1')");
			header("Location: admin.php?action=board_view$session");
			exit();
		}
	}
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) $boardparentid_options .= "<option value=\"$row[boardid]\">".editDBdata($row[boardname])."</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style <> 1 ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) $style_options .= "<option value=\"$row[styleid]\">$row[stylename]</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT userid, username FROM bb".$n."_groups LEFT JOIN bb".$n."_user_table ON (bb".$n."_groups.id = bb".$n."_user_table.groupid) WHERE ismod = 1 OR issupermod = 1");
	while($row = $db_zugriff->fetch_array($result)) $mod_options .= "<option value=\"$row[userid]\">$row[username]</option>\n";
	$db_zugriff->free_result($result);
		
	eval("dooutput(\"".gettemplate("board_add")."\");");
}

if($action == "board_edit") {
	if($send == "send") {
		$boardname = trim($boardname);
		if(!$boardname || !count($boardpermission)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("UPDATE bb".$n."_boards set boardparentid = '$boardparentid', boardname = '".editPostdata($boardname)."', boardpassword = '".trim($boardpassword)."', descriptiontext = '".editPostdata($descriptiontext)."', isboard = '$isboard', invisible = '$invisible', style_set = '$style_set' WHERE boardid = '$boardid'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE boardid = '$boardid' AND (mod = 1 OR boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
			for($i = 0; $i < count($boardmods); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,mod) VALUES ('$boardid','$boardmods[$i]','1')");
			if($boardpermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$boardid','$row[id]','1')");
			}
			else for($i = 0; $i < count($boardpermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$boardid','$boardpermission[$i]','1')");
			if($startpermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$boardid','$row[id]','1')");
			}
			else for($i = 0; $i < count($startpermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$boardid','$startpermission[$i]','1')");
			if($replypermission[0]=="*") {
				$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
				while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$boardid','$row[id]','1')");
			}
			else for($i = 0; $i < count($replypermission); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$boardid','$replypermission[$i]','1')");
		}
	} 
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_boards WHERE boardid = '$boardid'");
	
	$boardname = editDBdata($info[boardname]);
	$descriptiontext = editDBdata($info[descriptiontext]);
	$boardpassword = $info[boardpassword];
	
	if($info[invisible]) $invisible_selected[1] = " selected";
	else $invisible_selected[0] = " selected";
	
	if(!$info[isboard]) $isboard_select = " selected";
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE boardid <> '$boardid' ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$boardparentid_options .= "<option value=\"$row[boardid]\"";
		if($row[boardid] == $info[boardparentid]) $boardparentid_options .= " selected";
		$boardparentid_options .= ">$row[boardname]</option>\n";
	}
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style <> 1 ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$style_options .= "<option value=\"$row[styleid]\"";
		if($row[styleid]==$info[style_set]) $style_options .= " selected";
		$style_options .= ">$row[stylename]</option>\n";
	}
	$db_zugriff->free_result($result);
	
	
	$check1 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_groups");
	$check2 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$info[boardid]' AND boardpermission = 1");
	$check3 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$info[boardid]' AND startpermission = 1");
	$check4 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$info[boardid]' AND replypermission = 1");
	
	if($check1[0] == $check2[0]) $bp_selected = " selected";
	if($check1[0] == $check3[0]) $sp_selected = " selected";
	if($check1[0] == $check4[0]) $rp_selected = " selected";
	
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$bp_options .= "<option value=\"$row[id]\"";
		$sp_options .= "<option value=\"$row[id]\"";
		$rp_options .= "<option value=\"$row[id]\"";
		
		if(!$bp_selected && check_boardobject($info[boardid],$row[id],"boardpermission")) $bp_options .= " selected";
		if(!$sp_selected && check_boardobject($info[boardid],$row[id],"startpermission")) $sp_options .= " selected";
		if(!$rp_selected && check_boardobject($info[boardid],$row[id],"replypermission")) $rp_options .= " selected";
		
		$bp_options .= ">$row[title]</option>\n";
		$sp_options .= ">$row[title]</option>\n";
		$rp_options .= ">$row[title]</option>\n";		
	}
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups WHERE ismod = 1 OR issupermod = 1");
	while($row = $db_zugriff->fetch_array($result)) {
		if($where) $where .= " OR ";
		$where .= "groupid = '$row[id]'";
	}
	$db_zugriff->free_result($result);
	if($where) {
		$result = $db_zugriff->query("SELECT userid, username FROM bb".$n."_user_table WHERE $where");
		while($row = $db_zugriff->fetch_array($result)) {
			$mod_options .= "<option value=\"$row[userid]\"";
			if(check_boardobject($info[boardid],$row[userid],"mod")) $mod_options .= " selected";
			$mod_options .= ">$row[username]</option>\n";
		}
		$db_zugriff->free_result($result);
	}
	
	eval("dooutput(\"".gettemplate("board_edit")."\");");
}

if($action == "member_add") {
	if($send == "send") {
		if(!$username || !trim($userpassword) || !$useremail || checkname($username) || checkemail($useremail)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,session_link,activation) VALUES ('".trim($username)."','".md5(trim($userpassword))."','".trim($useremail)."','".trim($useremail)."','$groupid','".time()."','$session_link','1')");
			header("Location: admin.php?action=welcome$session");
		}
	}
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY default_group DESC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>\n";
	eval("dooutput(\"".gettemplate("member_add")."\");");
}

if($action == "member_view_inactiv") {
	if($send == "send" && count($userid)) {
		if($delete) for($i = 0; $i < count($userid); $i++) $db_zugriff->query("DELETE FROM bb".$n."_user_table WHERE userid = '$userid[$i]'");
		else for($i = 0; $i < count($userid); $i++) $db_zugriff->query("UPDATE bb".$n."_user_table SET activation = 1 WHERE userid = '$userid[$i]'");
	}
	$result = $db_zugriff->query("SELECT userid, username, useremail, regdate FROM bb".$n."_user_table WHERE activation <> 1 ORDER BY regdate DESC");
	while($row = $db_zugriff->fetch_array($result)) {
		$regdate = Hackdate($row[regdate]);		
		eval ("\$member_view_inactivbit .= \"".gettemplate("member_view_inactivbit")."\";");
	}
	eval("dooutput(\"".gettemplate("member_view_inactiv")."\");");
}

if($action == "member_search") {
	if($send == "send" && $userid) header("Location: admin.php?action=member_edit&userid=$userid$session");
	if(trim($search)) {
		$search = htmlspecialchars($search);
		if($mode == 1) $result = $db_zugriff->query("SELECT userid, username, useremail, regemail, regdate FROM bb".$n."_user_table WHERE activation = 1 AND username LIKE '%".trim($search)."%' ORDER BY username ASC");
		else $result = $db_zugriff->query("SELECT userid, useremail, username, regemail, regdate FROM bb".$n."_user_table WHERE activation = 1 AND userid = '".trim($search)."' ORDER BY username ASC");
		while ($row = $db_zugriff->fetch_array($result)) {
			$regdate = Hackdate($row[regdate]);		
			eval ("\$member_search_resultbit .= \"".gettemplate("member_search_resultbit")."\";");
		}
		eval("dooutput(\"".gettemplate("member_search_result")."\");");
		exit;
	}
	eval("dooutput(\"".gettemplate("member_search")."\");");
}

if($action == "member_edit") {
	if($send == "send") {
		if($delete) {
			$db_zugriff->query("UPDATE bb".$n."_posts SET userid = 0 WHERE userid = '$userid'");
			$db_zugriff->query("UPDATE bb".$n."_threads SET authorid = 0 WHERE authorid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_folders WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE objectid = '$userid' AND mod = 1");
			$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid = '$userid' AND (buddylist = 1 OR ignorelist = 1)");
			$db_zugriff->query("DELETE FROM bb".$n."_pms WHERE recipientid = '$userid' OR senderid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_pmsend WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_useronline WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_user_table WHERE userid = '$userid'");
			$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE userid = '$userid'");
					
			header("Location: admin.php?action=member_search$session");
			exit;
		}
		
		$username = trim($username);
		$useremail = trim($useremail);
		
		$check = $db_zugriff->query_first("SELECT username, useremail FROM bb".$n."_user_table WHERE userid = '$userid'");
		if($username!=$check[username]) $check_username = checkname($username);
		if($useremail!=$check[useremail]) $check_useremail = checkname($useremail);
		if(!$username || !$useremail || $check_useremail || $check_username) eval ("\$error = \"".gettemplate("error")."\";");
		else {
		 $db_zugriff->query("UPDATE bb".$n."_user_table SET username = '$username', useremail = '$useremail', userhp = '".editPostdata($userhp)."', usericq = '".editPostdata($usericq)."', aim = '".editPostdata($aim)."', yim = '".editPostdata($yim)."', interests = '".editPostdata($interests)."', location = '".editPostdata($location)."', work = '".editPostdata($work)."', signatur = '".editPostdata($signatur)."', usertext = '".editPostdata($usertext)."', statusextra = '".editPostdata($statusextra)."', groupid = '$groupid', blocked = '$blocked' WHERE userid = '$userid'");
		 $db_zugriff->query("UPDATE bb".$n."_threads SET author = '$username' WHERE authorid = '$userid'");
		}
	}

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid = '$userid'");
	
	$userhp = editDBdata($info[userhp]);
	$usericq = editDBdata($info[usericq]);
	$aim = editDBdata($info[aim]);
	$yim = editDBdata($info[yim]);
	$interests = editDBdata($info[interests]);
	$location = editDBdata($info[location]);
	$signatur = editDBdata($info[signatur]);
	$usertext = editDBdata($info[usertext]);
	$work = editDBdata($info[work]);
	$statusextra = editDBdata($info[statusextra]);

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY default_group DESC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"$row[id]\"";
		if($row[id]==$info[groupid]) $options .= " selected";
		$options .= ">$row[title]</option>\n";
	}
	

	if($info[blocked]) $selected = " selected";
	eval("dooutput(\"".gettemplate("member_edit")."\");");

}

if($action == "group_add") {
	if($send == "send") {
		if(!$title) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ('','$title','$canviewboard','$canviewoffboard','$canusesearch','$canusepms','$canstarttopic','$canreplyowntopic','$canreplytopic','$caneditownpost','$candelownpost','$cancloseowntopic','$candelowntopic','$canpostpoll','$canvotepoll','$canuploadavatar','$appendeditnote','$avoidfc','$ismod','$issupermod','$canuseacp','')");
		header("Location: admin.php?action=group_view_edit$session");
	}
	
	eval("dooutput(\"".gettemplate("group_add")."\");");

}	

if($action == "group_view_edit") {
	if($send == "send" && $groupid) header("Location: admin.php?action=group_edit&groupid=$groupid$session");

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) eval ("\$group_view_editbit .= \"".gettemplate("group_view_editbit")."\";");
	eval("dooutput(\"".gettemplate("group_view_edit")."\");");
}

if($action == "group_edit") {
	if($send == "send") {
		if(!$title) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_groups SET title = '$title', canviewboard = '$canviewboard', canviewoffboard = '$canviewoffboard', canusesearch = '$canusesearch', canusepms = '$canusepms', canstarttopic = '$canstarttopic', canreplyowntopic = '$canreplyowntopic', canreplytopic = '$canreplytopic', caneditownpost = '$caneditownpost', candelownpost = '$candelownpost', cancloseowntopic = '$cancloseowntopic', candelowntopic = '$candelowntopic', canpostpoll = '$canpostpoll', canvotepoll = '$canvotepoll', canuploadavatar = '$canuploadavatar', appendeditnote = '$appendeditnote', avoidfc = '$avoidfc', ismod = '$ismod', issupermod = '$issupermod', canuseacp = '$canuseacp' WHERE id = '$groupid'");
	}

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_groups WHERE id = '$groupid'");

	if($info[canviewboard]) $s_canviewboard[1] = " selected";
	else $s_canviewboard[0] = " selected";
	if($info[canusesearch]) $s_canusesearch[1] = " selected";
	else $s_canusesearch[0] = " selected";
	if($info[canusepms]) $s_canusepms[1] = " selected";
	else $s_canusepms[0] = " selected";
	if($info[canstarttopic]) $s_canstarttopic[1] = " selected";
	else $s_canstarttopic[0] = " selected";
	if($info[canreplyowntopic]) $s_canreplyowntopic[1] = " selected";
	else $s_canreplyowntopic[0] = " selected";
	if($info[canreplytopic]) $s_canreplytopic[1] = " selected";
	else $s_canreplytopic[0] = " selected";
	if($info[caneditownpost]) $s_caneditownpost[1] = " selected";
	else $s_caneditownpost[0] = " selected";
	if($info[candelownpost]) $s_candelownpost[1] = " selected";
	else $s_candelownpost[0] = " selected";
	if($info[cancloseowntopic]) $s_cancloseowntopic[1] = " selected";
	else $s_cancloseowntopic[0] = " selected";
	if($info[candelowntopic]) $s_candelowntopic[1] = " selected";
	else $s_candelowntopic[0] = " selected";
	if($info[canpostpoll]) $s_canpostpoll[1] = " selected";
	else $s_canpostpoll[0] = " selected";
	if($info[canvotepoll]) $s_canvotepoll[1] = " selected";
	else $s_canvotepoll[0] = " selected";
	if($info[canuploadavatar]) $s_canuploadavatar[1] = " selected";
	else $s_canuploadavatar[0] = " selected";
	if($info[appendeditnote]) $s_appendeditnote[1] = " selected";
	else $s_appendeditnote[0] = " selected";
	if($info[avoidfc]) $s_avoidfc[1] = " selected";
	else $s_avoidfc[0] = " selected";
	if($info[canviewoffboard]) $s_canviewoffboard[1] = " selected";
	else $s_canviewoffboard[0] = " selected";
	if($info[ismod]) $s_ismod[1] = " selected";
	else $s_ismod[0] = " selected";
	if($info[issupermod]) $s_issupermod[1] = " selected";
	else $s_issupermod[0] = " selected";
	if($info[canuseacp]) $s_canuseacp[1] = " selected";
	else $s_canuseacp[0] = " selected";
	
	eval("dooutput(\"".gettemplate("group_edit")."\");");
}

if($action == "group_del") {
	if($send == "send" && count($groupid)) {
		for($i = 0; $i < count($groupid); $i++) {
			$check = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_groups WHERE id = '$groupid[$i]' AND default_group <> 0");
			if($check[0]) continue;
			$default = $db_zugriff->query_first("SELECT id FROM bb".$n."_groups WHERE default_group = 2");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET groupid = '$default[id]' WHERE groupid = '$groupid[$i]'");
			$db_zugriff->query("UPDATE bb".$n."_ranks SET groupid = '$default[id]' WHERE groupid = '$groupid[$i]'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE objectid = '$groupid[$i]' AND (boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
			$db_zugriff->query("DELETE FROM bb".$n."_groups WHERE id = '$groupid[$i]'");
		}
	} 

	$result = $db_zugriff->query("SELECT id, title, default_group FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		if($row[default_group]) $disabled = " disabled";
		else $disabled = "";
		eval ("\$group_delbit .= \"".gettemplate("group_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("group_del")."\");");
}

if($action == "menue") eval("dooutput(\"".gettemplate("menue")."\");"); 
if($action == "top") eval("dooutput(\"".gettemplate("oben")."\");");


if($action == "group_default") {
	if($send == "send") {
		if($default1 == $default2) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 0");
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 1 WHERE id = '$default1'");
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 2 WHERE id = '$default2'");
		}
	}
	
	$result = $db_zugriff->query("SELECT id, title, default_group FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options1 .= "<option value=\"$row[id]\"";
		if($row[default_group]==1) $options1 .= " selected";
		$options1 .= ">$row[title]</option>\n";
		
		$options2 .= "<option value=\"$row[id]\"";
		if($row[default_group]==2) $options2 .= " selected";
		$options2 .= ">$row[title]</option>\n";
	}
	eval("dooutput(\"".gettemplate("group_default")."\");");
}

if($action == "rank_add") {
	if($send == "send") {
		if(!$rank) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ('', '$groupid', '".(int)($posts)."', '".editPostdata($rank)."', '$grafik', '".(int)($mal)."')");
		header("Location: admin.php?action=rank_view_edit$session");
	}

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>";
	
	eval("dooutput(\"".gettemplate("rank_add")."\");");
}

if($action == "rank_view_edit") {
	if($send == "send" && $rankid) header("Location: admin.php?action=rank_edit&rankid=$rankid$session");
	
	$result = $db_zugriff->query("SELECT id, groupid, posts, rank FROM bb".$n."_ranks ORDER BY groupid ASC, posts ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$rank = editDBdata($row[rank]);
		$groupname = $db_zugriff->query_first("SELECT title FROM bb".$n."_groups WHERE id = '$row[groupid]'");
		$groupname = $groupname[0];
		eval ("\$rank_view_editbit .= \"".gettemplate("rank_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("rank_view_edit")."\");");
}

if($action == "rank_edit") {
	if($send == "send") {
		if(!$rank) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_ranks SET groupid = '$groupid', posts = '".(int)($posts)."', rank = '".editPostdata($rank)."', grafik = '$grafik', mal = '".(int)($mal)."' WHERE id = '$rankid'");
	}

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE id = '$rankid'");
	$rank = editDBdata($info[rank]);

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"$row[id]\"";
		if($row[id]==$info[groupid]) $options .= " selected";
		$options .= ">$row[title]</option>";
	}
	eval("dooutput(\"".gettemplate("rank_edit")."\");");
}

if($action == "rank_del") {
	if($send == "send" && count($rankid)) {
		for($i = 0; $i < count($rankid); $i++) $db_zugriff->query("DELETE FROM bb".$n."_ranks WHERE id = '$rankid[$i]'");
	}
	
	$result = $db_zugriff->query("SELECT id, groupid, posts, rank FROM bb".$n."_ranks ORDER BY groupid ASC, posts ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$rank = editDBdata($row[rank]);
		$groupname = $db_zugriff->query_first("SELECT title FROM bb".$n."_groups WHERE id = '$row[groupid]'");
		$groupname = $groupname[0];
		eval ("\$rank_delbit .= \"".gettemplate("rank_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("rank_del")."\");");
}

if($action == "style_add") {
	if($send == "send") {
		if(!$stylename || !$templatefolder || !file_exists("../".$templatefolder."/main.htm")) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_style VALUES ('','".editPostdata($stylename)."','$templatefolder','$font','$fontcolor','$fontcolorsec','$fontcolorthi','$fontcolorfour','$bgcolor','$tablebg','$tablea','$tableb','$tablec','$tabled','$imageurl','".editPostdata($css)."','$bgimage','$bgfixed','')");
		header("Location: admin.php?action=style_view_edit$session");
	}
	eval("dooutput(\"".gettemplate("style_add")."\");");
}

if($action == "style_view_edit") {
	if($send == "send" && $styleid) header("Location: admin.php?action=style_edit&styleid=$styleid$session");
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$stylename = editDBdata($row[stylename]);
		eval ("\$style_view_editbit .= \"".gettemplate("style_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("style_view_edit")."\");");
}

if($action == "style_edit") {
	if($send == "send") {
		if(!$stylename || !$templatefolder || !file_exists("../".$templatefolder."/main.htm")) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_style SET stylename = '".editPostdata($stylename)."', templatefolder = '$templatefolder', font = '$font', fontcolor = '$fontcolor', fontcolorsec = '$fontcolorsec', fontcolorthi = '$fontcolorthi', fontcolorfour = '$fontcolorfour', bgcolor = '$bgcolor', tablebg = '$tablebg', tablea = '$tablea', tableb = '$tableb', tablec = '$tablec', tabled = '$tabled', imageurl = '$imageurl', css = '".editPostdata($css)."', bgimage = '$bgimage', bgfixed = '$bgfixed' WHERE styleid = '$styleid'");
	}
	
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_style WHERE styleid = '$styleid'");
	$stylename = editDBdata($info[stylename]);
	$css = editDBdata($info[css]);
	if(!$info[bgfixed]) $selected = " selected";
	eval("dooutput(\"".gettemplate("style_edit")."\");");
}

if($action == "style_del") {
	if($send == "send" && count($styleid)) {
		for($i = 0; $i < count($styleid); $i++) {
			$check = $db_zugriff->query_first("SELECT COUNT(styleid) FROM bb".$n."_style WHERE styleid = '$styleid[$i]' AND default_style = 1");
			if($check[0]) continue;
			$db_zugriff->query("UPDATE bb".$n."_boards SET style_set = '0' WHERE style_set = '$styleid[$i]'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET style_set = '0' WHERE style_set = '$styleid[$i]'");
			$db_zugriff->query("DELETE FROM bb".$n."_style WHERE styleid = '$styleid[$i]'");
		}	
	}
	$result = $db_zugriff->query("SELECT styleid, stylename, default_style FROM bb".$n."_style ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$stylename = editDBdata($row[stylename]);
		if($row[default_style]) $disabled = " disabled";
		else $disabled = "";
		eval ("\$style_delbit .= \"".gettemplate("style_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("style_del")."\");");
}

if($action == "style_default") {
	if($send == "send") {
		$db_zugriff->query("UPDATE bb".$n."_style SET default_style = '0'");
		$db_zugriff->query("UPDATE bb".$n."_style SET default_style = '1' WHERE styleid = '$styleid'");
	}
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style ORDER BY default_style DESC, stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[styleid]\">".editDBdata($row[stylename])."</option>";
	
	eval("dooutput(\"".gettemplate("style_default")."\");");
}

if($action == "avatar_add") {
	if($send == "send") {
		$conf = $db_zugriff->query_first("SELECT avatarimage_ext, avatar_width, avatar_height, avatar_size FROM bb".$n."_config");
		$mimetype = explode("\n", $conf[avatarimage_ext]);
		for($i = 0; $i < count($mimetype); $i++) $mimetype[$i] = trim($mimetype[$i]); 
		
		require_once("Upload.class.php");
		$upload = new Upload();
		
		$upload->setAllowedMimeTypes($mimetype);	
		$upload->setUploadPath("../images/avatars");
	
		if ($upload->doUpload()) header("Location: admin.php?action=avatar_view_edit$session");
		else eval ("\$error = \"".gettemplate("error")."\";");
	}
	
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>";
	eval("dooutput(\"".gettemplate("avatar_add")."\");");
}

if($action == "avatar_view_edit") {
	if($send == "send" && $avatarid) header("Location: admin.php?action=avatar_edit&avatarid=$avatarid$session");

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid = 0");
	$anzahl = $anzahl[0];
	if(!$page) $page=1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, bb".$n."_groups.title FROM bb".$n."_avatars LEFT JOIN bb".$n."_groups ON (bb".$n."_groups.id=groupid) WHERE userid = 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row[id].".".$row[extension];
		$oriname = $row[name].".".$row[extension];
		if($row[groupid]) $groupname = $row[title];
		else eval ("\$groupname = \"".gettemplate("lg_all")."\";");
				
		eval ("\$avatar_view_editbit .= \"".gettemplate("avatar_view_editbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_view_edit$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_view_edit$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}

	eval("dooutput(\"".gettemplate("avatar_view_edit")."\");");
}

if($action == "avatar_edit") {
	if($send == "send") $db_zugriff->query("UPDATE bb".$n."_avatars SET groupid = '$groupid', posts = '$posts' WHERE id = '$avatarid'");

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE id = '$avatarid'");
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"$row[id]\"";
		if($row[id]==$info[groupid]) $options .= " selected";
		$options .= ">$row[title]</option>";
		
	}
	$imgfile = "../images/avatars/avatar-".$info[id].".".$info[extension];
	$oriname = $info[name].".".$info[extension];

	eval("dooutput(\"".gettemplate("avatar_edit")."\");");
}

if($action == "avatar_del") {
	if($send == "send" && $avatarid) {
		for($i = 0; $i < count($avatarid); $i++) {
			$ext = $db_zugriff->query_first("SELECT extension FROM bb".$n."_avatars WHERE id = '$avatarid[$i]'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = 0 WHERE avatarid = '$avatarid[$i]'");
			$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$avatarid[$i]'");
			@unlink("../images/avatars/avatar-".$avatarid[$i].".".$ext[0]);
		}
	}

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid = 0");
	$anzahl = $anzahl[0];
	if(!$page) $page=1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, bb".$n."_groups.title FROM bb".$n."_avatars LEFT JOIN bb".$n."_groups ON (bb".$n."_groups.id=groupid) WHERE userid = 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row[id].".".$row[extension];
		$oriname = $row[name].".".$row[extension];
		if($row[groupid]) $groupname = $row[title];
		else eval ("\$groupname = \"".gettemplate("lg_all")."\";");
				
		eval ("\$avatar_delbit .= \"".gettemplate("avatar_delbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_del$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_del$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}

	eval("dooutput(\"".gettemplate("avatar_del")."\");");
}

if($action == "avatar_user_del") {
	if($send == "send" && $avatarid) {
		for($i = 0; $i < count($avatarid); $i++) {
			$ext = $db_zugriff->query_first("SELECT extension FROM bb".$n."_avatars WHERE id = '$avatarid[$i]'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = 0 WHERE avatarid = '$avatarid[$i]'");
			$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$avatarid[$i]'");
			@unlink("../images/avatars/avatar-".$avatarid[$i].".".$ext[0]);
		}
	}

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid > 0");
	$anzahl = $anzahl[0];
	if(!$page) $page=1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, username FROM bb".$n."_avatars LEFT JOIN bb".$n."_user_table ON (bb".$n."_avatars.userid=bb".$n."_user_table.userid) WHERE bb".$n."_avatars.userid > 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row[id].".".$row[extension];
		$oriname = $row[name].".".$row[extension];
		eval ("\$avatar_delbit .= \"".gettemplate("avatar_user_delbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_user_del$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_user_del$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}

	eval("dooutput(\"".gettemplate("avatar_user_del")."\");");
}

if($action == "announcements_add") {
	if($send == "send") {
		if(!$topic || !$message || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$starttime, $st_exp) || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$endtime, $et_exp)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$starttime = mktime($st_exp[4], $st_exp[5], 0, $st_exp[2], $st_exp[1], $st_exp[3]);
			$endtime = mktime($et_exp[4], $et_exp[5], 0, $et_exp[2], $et_exp[1], $et_exp[3]);
			$db_zugriff->query("INSERT INTO bb".$n."_announcements VALUES ('', '$boardid', '$user_id', '$starttime', '$endtime', '".editPostdata($topic)."', '".editPostdata($message)."')");
			header("Location: admin.php?action=announcements_view_edit$session");
		}
	}
	$starttime = date("d-m-Y H:i");
	$endtime = date("d-m-Y H:i", time()+24*3600);
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE isboard = 1 ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) $board_options .= "<option value=\"$row[boardid]\">$row[boardname]</option>\n";
	eval("dooutput(\"".gettemplate("announcements_add")."\");");
}

if($action == "announcements_view_edit") {
	if($send == "send" && $announcementid) header("Location: admin.php?action=announcements_edit&announcementid=$announcementid$session");
	
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_announcements");
	while($row = $db_zugriff->fetch_array($result)) {
		$row[topic] = editDBdata($row[topic]);
		$row[starttime] = date("d-m-Y H:i", $row[starttime]);
		$row[endtime] = date("d-m-Y H:i", $row[endtime]);
		eval ("\$announcements_view_editbit .= \"".gettemplate("announcements_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("announcements_view_edit")."\");");
}

if($action == "announcements_edit") {
	if($send == "send") {
		if(!$topic || !$message || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$starttime, $st_exp) || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$endtime, $et_exp)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$starttime = mktime($st_exp[4], $st_exp[5], 0, $st_exp[2], $st_exp[1], $st_exp[3]);
			$endtime = mktime($et_exp[4], $et_exp[5], 0, $et_exp[2], $et_exp[1], $et_exp[3]);
			$db_zugriff->query("UPDATE bb".$n."_announcements SET topic = '".editPostdata($topic)."', message = '".editPostdata($message)."', starttime = '$starttime', endtime = '$endtime', boardid = '$boardid' WHERE announcementid = '$announcementid'");
		}
	}

	$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_announcements WHERE announcementid = '$announcementid'");
	$starttime = date("d-m-Y H:i", $row[starttime]);
	$endtime = date("d-m-Y H:i", $row[endtime]);
	$row[topic] = editDBdata($row[topic]);
	$row[message] = editDBdata($row[message]);
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE isboard = 1 ORDER BY boardname ASC");
	while($brow = $db_zugriff->fetch_array($result)) {
		if($brow[boardid]==$row[boardid]) $board_options .= "<option value=\"$brow[boardid]\" selected>$brow[boardname]</option>\n";
		else $board_options .= "<option value=\"$brow[boardid]\">$brow[boardname]</option>\n";
	}
	eval("dooutput(\"".gettemplate("announcements_edit")."\");");
}

if($action == "announcements_del") {
	if($send == "send" && count($announcementid)) for($i = 0; $i < count($announcementid); $i++) $db_zugriff->query("DELETE FROM bb".$n."_announcements WHERE announcementid = '$announcementid[$i]'");
		
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_announcements");
	while($row = $db_zugriff->fetch_array($result)) {
		$row[topic] = editDBdata($row[topic]);
		$row[starttime] = date("d-m-Y H:i", $row[starttime]);
		$row[endtime] = date("d-m-Y H:i", $row[endtime]);
		eval ("\$announcements_delbit .= \"".gettemplate("announcements_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("announcements_del")."\");");
}

if($action == "smilies_add") {
	if($send == "send") {
		if(!$smiliespath || !$smiliestext || !@file_exists("../".$smiliespath)) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ('', '$smiliespath', '$smiliestext', '$smiliestitle')");
		header("Location: admin.php?action=smilies_view_edit$session");
	}

	eval("dooutput(\"".gettemplate("smilies_add")."\");");
}

if($action == "smilies_view_edit") {
	if($send == "send" && $smilieid) header("Location: admin.php?action=smilies_edit&smilieid=$smilieid$session");
	
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) eval ("\$smilies_view_editbit .= \"".gettemplate("smilies_view_editbit")."\";");
	eval("dooutput(\"".gettemplate("smilies_view_edit")."\");");
}

if($action == "smilies_edit") {
	if($send == "send") {
		if(!$smiliespath || !$smiliestext || !@file_exists("../".$smiliespath)) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_smilies SET smiliespath = '$smiliespath', smiliestext = '$smiliestext', smiliestitle = '$smiliestitle' WHERE id = '$smilieid'");
	}

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_smilies WHERE id = '$smilieid'");
	
	eval("dooutput(\"".gettemplate("smilies_edit")."\");");
}

if($action == "smilies_del") {
	if($send == "send" && count($smilieid)) {
		for($i = 0; $i < count($smilieid); $i++) $db_zugriff->query("DELETE FROM bb".$n."_smilies WHERE id = '$smilieid[$i]'");
	}
	
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) eval ("\$smilies_delbit .= \"".gettemplate("smilies_delbit")."\";");
	eval("dooutput(\"".gettemplate("smilies_del")."\");");
}

if($action == "newsletter") {
	if($send == "send") {
		if(!$subject || !$message) eval ("\$error = \"".gettemplate("error")."\";");
		if($groupid[0]) {
			for($i = 0; $i < count($groupid); $i++) {
				if($where) $where.=" OR ";
				$where.="groupid='$groupid[$i]'";
			}
		}
		$conf = $db_zugriff->query_first("SELECT master_email FROM bb".$n."_config");
		$result = $db_zugriff->query("SELECT useremail, username FROM bb".$n."_user_table WHERE mods_may_email = 1".ifelse($where," AND ($where)",""));
		while($row = $db_zugriff->fetch_array($result)) {
			$inhalt = str_replace("{username}","$row[username]", stripslashes($message));
			mail($row[useremail],stripslashes($subject),$inhalt,"From: $conf[0]");
		}
	}

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1");
	while($row = $db_zugriff->fetch_array($result)) $group_options .= "<option value=\"$row[id]\">$row[title]</option>";
	eval("dooutput(\"".gettemplate("newsletter")."\");");
}
?>