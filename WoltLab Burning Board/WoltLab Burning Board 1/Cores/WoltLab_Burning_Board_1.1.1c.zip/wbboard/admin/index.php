<? 
require "global.php"; 
if($mode=="login") {
	$userpassword = md5($userpassword);
	$check = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username = '$username' AND userpassword = '$userpassword'");
	if($check[0]) {
	
		$user_id = $check[0];
		$user_password = $userpassword;
		session_register("user_id");
		session_register("user_password");
		setcookie("user_id", "$user_id", time()+(3600*24*365));
		setcookie("user_password", "$user_password", time()+(3600*24*365));
	
		header("LOCATION: index.php?action=1");
		exit;
	}
	else $error = "Zugriff verweigert!";
}

if(getUser_stat($user_id,$user_password)) eval("dooutput(\"".gettemplate("frameset")."\");");
else {
	eval ("\$headinclude = \"".gettemplate("headinclude")."\";");	
	eval("dooutput(\"".gettemplate("login")."\");");
}
?>