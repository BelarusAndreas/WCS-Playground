<?php
if (!function_exists("is_uploaded_file") and get_cfg_var("safe_mode")==0) {
	function is_uploaded_file($filename) {
    		if (!$tmp_file = get_cfg_var('upload_tmp_dir')) $tmp_file = dirname(tempnam('', ''));
    		$tmp_file .= '/' . basename($filename);
    		return (ereg_replace('/+', '/', $tmp_file) == $filename);
  	} 
	function move_uploaded_file($filename, $destination) {
     		if (is_uploaded_file($filename))  {
       			if (copy($filename,$destination)) return true;
       			else return false;
       		}
      		else return false;
   	}
}

if (!defined('UPLOAD_MAX_FILE_SIZE')) {
   define('UPLOAD_MAX_FILE_SIZE', $conf[avatar_size]); // 1MB = 1048576
}
if (!defined('UPLOAD_IMAGE_MAX_WIDTH')) {
    define('UPLOAD_IMAGE_MAX_WIDTH', $conf[avatar_width]);
}
if (!defined('UPLOAD_IMAGE_MAX_HEIGHT')) {
    define('UPLOAD_IMAGE_MAX_HEIGHT', $conf[avatar_height]);
}
if (!defined('UPLOAD_FIELD_NAME')) {
    define('UPLOAD_FIELD_NAME', "uploadFile");
}

class Upload
{

	
	
	// array
	var $uploadErrors;
	var $registeredMimeTypes;
	var $allowedMimeTypes;
	
	// int
	var $maxImageWidth;
	var $maxImageHeight;
	var $maxFileSize;
	var $insertid;
	var $fieldCounter;
	
	// string
	var $uploadPath;
	var $uploadFieldName;
	var $fieldName;
	var $errorType;
	var $file_extension;
	
	// bool
	var $imageSizeOk;
	var $uploadValidated;
	var $uploadFail;
	
	function Upload() {
		$this->uploadErrors 		= array();
		$this->registeredMimeTypes 	= array();
		$this->allowedMimeTypes 	= array();
		
		$this->maxImageWidth		= 0;
		$this->maxImageHeight		= 0;
		$this->maxFileSize			= 0;
		$this->fieldCounter			= 0;
		
		$this->uploadFieldName 		= "";
		$this->uploadPath			= "";
		
		$this->imageSizeOk			= false;
		$this->uploadValidated		= false;
		$this->uploadFail			= false;
		
		
		if(!$this->maxImageWidth || !$this->maxImageHeight) {
			$this->setMaxImageSize();
		}
		
		if(!$this->maxFileSize) {
			$this->setMaxFileSize();
		}
		
	}
	
	function setMaxImageSize($maxImageWidth = UPLOAD_IMAGE_MAX_WIDTH, $maxImageHeight = UPLOAD_IMAGE_MAX_HEIGHT)
	{
		$this->maxImageWidth 	= $maxImageWidth;
		$this->maxImageHeight 	= $maxImageHeight;
	}
	
	function setUploadPath($uploadPath)
	{
		$this->uploadPath 	= $uploadPath;
	}
	
	function setAllowedMimeTypes($allowedMimeTypes = array())
	{
		$this->allowedMimeTypes = $allowedMimeTypes;
	}
	
	function setMaxFileSize($maxFileSize = UPLOAD_MAX_FILE_SIZE)
	{
		$this->maxFileSize = $maxFileSize;
	}
	
	function getUploadErrors()
	{
		return $this->uploadErrors; // array
	}
	
	function setError($errorType)
	{
		$this->uploadErrors[$this->HTTP_POST_FILES[$this->uploadFieldName]['name']][] = $errorType; //+++
	}

	function getAllowedMimeTypes()
	{
		return $this->allowedMimeTypes;
	}
	
	function getUploadImageSize()
	{
		$dimensions = @GetImageSize($this->uploadFile); 
		return array($dimensions[0],$dimensions[1]);
	}
	
	function checkMimeType()
	{
		if (!in_array($this->file_extension,$this->getAllowedMimeTypes())) {
			$this->setError("mimeException");
			return false;
		} else return true;
	}
	
	function checkImageSize() {
		$this->imageSize = $this->getUploadImageSize($this->uploadFile); 
		
		$imageSizeOK = true;
		
		if ($this->imageSize[0] > $this->maxImageWidth) {
			$imageSizeOK = false;
			$this->setError("imageWidthException");
		}

		if ($this->imageSize[1] > $this->maxImageHeight) {
			$imageSizeOK= false;
			$this->setError("imageHeightException");
		}
		return $imageSizeOK;
	}
	
	function copyFile() 
	{
		$ok = move_uploaded_file($this->uploadFile, $this->uploadPath . "/avatar-".$this->insertid.".".$this->file_extension); //+++
		@chmod( $this->uploadPath . "/avatar-".$this->insertid.".".$this->file_extension, 0777);
		return $ok;
	}
	
	function checkMaxFileSize()
	{
		if ($this->HTTP_POST_FILES[$this->uploadFieldName]['size'] > $this->maxFileSize) { 		//+++ ISSUE
			return false;
		} else {
			return true;
		}
	}
	
	function setRegisteredMimeTypes($registeredMimeTypes = array())
	{
		if (sizeof($registeredMimeTypes) == 0) {
			$this->registeredMimeTypes = 
				array(
					"application/x-gzip-compressed" 	=> ".tar.gz, .tgz",
					"application/x-zip-compressed" 		=> ".zip",
					"application/x-tar"					=> ".tar",
					"text/plain"						=> ".php, .txt, .inc (etc)",
					"text/html"							=> ".html, .htm (etc)",
					"image/bmp" 						=> ".bmp, .ico",
					"image/gif" 						=> ".gif",
					"image/pjpeg"						=> ".jpg, .jpeg",
					"image/jpeg"						=> ".jpg, .jpeg",
					"image/x-png"						=> ".png",
					"audio/mpeg"						=> ".mp3 etc",
					"audio/wav"							=> ".wav",
					"application/pdf"					=> ".pdf",
					"application/x-shockwave-flash" 	=> ".swf",
					"application/msword"				=> ".doc",
					"application/vnd.ms-excel"			=> ".xls",
					"application/octet-stream"			=> ".exe, .fla, .psd (etc)"
				);
		} else {
			$this->registeredMimeTypes = $registeredMimeTypes;
		}
	}
	
	function setDefaults()
	{
		if(!$this->registeredMimeTypes) {
			$this->setRegisteredMimeTypes();
		}
		
		if(!$this->maxImageWidth || !$this->maxImageHeight) {
			$this->setMaxImageSize();
		}
		
		if(!$this->maxFileSize) {
			$this->setMaxFileSize();
		}
	}
	
	
	function processUpload() { 
		
		$this->uploadFile = $this->HTTP_POST_FILES[$this->uploadFieldName]['tmp_name'];
		$this->setDefaults();

		if ($this->uploadFile == "none") {
			$this->setError("noFileException");
			$this->uploadFail = true;
		}
		
		if (!$this->checkMaxFileSize()) {
			$this->setError("fileTooBigException");
			$this->uploadFail = true;
		} elseif(in_array("cannotGetImageSize",$this->getUploadErrors())) {
			$this->uploadFail = true;
		}
		
		if (!$this->uploadFail) {
			if (ereg("image",$this->HTTP_POST_FILES[$this->uploadFieldName]['type'])) {
				$this->imageSizeOk = $this->checkImageSize();
			} else {
				$this->imageSizeOk = true;
			}
		}
		
		$this->file_extension = strtolower(substr(strrchr($this->HTTP_POST_FILES[$this->uploadFieldName]['name'],"."),1));
  		$this->file_name = substr($this->HTTP_POST_FILES[$this->uploadFieldName]['name'], 0, (intval(strlen($this->file_extension))+1)*-1);
  
		if($this->checkMimeType() && $this->imageSizeOk && !$this->uploadFail) {
			global $db_zugriff, $n, $groupid, $posts, $setuserid, $insertid;
			
			$db_zugriff->query("INSERT INTO bb".$n."_avatars VALUES ('','".$this->file_name."','".$this->file_extension."','$groupid','$posts','$setuserid')");
			$this->insertid = $db_zugriff->insert_id();
			$insertid = $this->insertid;
			if (!$this->copyFile()) {
				$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$this->insertid'");
				$this->setError("fileCopyException");
			}
		}
		
		if (sizeof($this->uploadErrors) == 0)
		{
			$this->uploadValidated = true;
		}
		return $this->uploadValidated;
	}
	
	function doUpload() {
	
		$this->HTTP_POST_FILES 	= $GLOBALS['HTTP_POST_FILES']; 	//array
		$this->fieldCounter 	= $GLOBALS['fieldCounter'];	//int

		for ($i=0; $i<$this->fieldCounter; $i++) {
		
			$this->uploadFieldName	= $GLOBALS['uploadFileName'][$i];
			$currentUpload = $this->processUpload();

			if (!$currentUpload) {
				$errorsOccured = true;
			}
		}
		
		if ($errorsOccured) {
			return false;
		} else {
			return true;
		}
	}
}
?>
