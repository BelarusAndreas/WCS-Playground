<?
// ############# Posticons ############### 
$posticons = array(
			"images/icons/ausrufezeichen.gif",
			"images/icons/frage.gif",
			"images/icons/lampe.gif",
			"images/icons/biggrin.gif",
			"images/icons/boese.gif",
			"images/icons/cool.gif",
			"images/icons/frown.gif",
			"images/icons/pfeil.gif",
			"images/icons/smilie.gif",
			"images/icons/text.gif",
			"images/icons/thumb_up.gif",
			"images/icons/thumb_down.gif",
			"images/icons/wink.gif",
			"images/icons/mad.gif",
			"images/icons/eek.gif",
			"images/icons/sad.gif",
			"images/icons/tongue.gif",
			"images/icons/icon1.gif"
			); 
?>