<?php
require ("_functions.php");
eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
	
$posts = $db_zugriff->query("SELECT
COUNT(postid) AS posts, bb".$n."_posts.userid, bb".$n."_user_table.username
FROM bb".$n."_posts
LEFT JOIN bb".$n."_user_table USING (userid)
WHERE threadparentid='$threadid'
GROUP BY bb".$n."_posts.userid
ORDER BY posts DESC");

while ($post = $db_zugriff->fetch_array($posts))
	{
	if (($counter++ % 2) != 0)
		$rowinfo = "bgcolor=\"{tableb}\" id = \"tableb\"";
	else
		$rowinfo = "bgcolor=\"{tablec}\" id = \"tablec\"";
	$totalposts += $post[posts];
	if($post[userid]) $authorname = "<a href=\"members.php?mode=profile&boardid=$boardid&styleid=$styleid&userid=$post[userid]$session\" target=\"_blank\"><b>$post[username]</b></a>";
	else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
	eval("\$posters .= \"".gettemplate("whopostedbit")."\";");
	}
	
$totalposts = number_format($totalposts);
eval("dooutput(\"".gettemplate("whoposted")."\");");
?>
