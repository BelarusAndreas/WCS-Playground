<?
require("_functions.php");
require("_header.php");
require("_board_jump.php");

if($user_id && $pms && $userdata[canusepms]) {
if(!$box) $box = "inbox";
if($action == "send" || $action == "new" || $action == "reply" || $action == "forward") {

	if($action == "send" && !$preview) {
		$userid = getUserid($recipient);
		$count_pm = $db_zugriff->query_first("SELECT COUNT(pmid) FROM bb".$n."_pms WHERE recipientid = '$userid'");
		if(!$userid || $userid == $user_id || check_userobject($userid,$user_id,"ignorelist")) eval ("\$error = \"".gettemplate("pm_error1")."\";");
		elseif($count_pm[0] >= $maxpms) eval("\$error = \"".gettemplate("pm_error2")."\";");
		else {
			$subject = editPostdata($subject);
                	$message = nt_wordwrap($message);
                	if($parseurl) $message = parseURL($message);
			$message = editPostdata($message);
			$db_zugriff->query("INSERT INTO bb".$n."_pms (senderid,recipientid,sendtime,subject,message,icon,disable_smilies,signature)VALUES ('$user_id','$userid','".time()."','$subject','$message','$posticon','$disablesmilies','$signature')");       
                	if($copy) {
                		$nr = $db_zugriff->insert_id();
                		$db_zugriff->query("INSERT INTO bb".$n."_pmsend VALUES ('$user_id','$userid','$nr','','".time()."','$subject','$message','$posticon','$disablesmilies','$signature')");
                	}
                	if($replyid) $db_zugriff->query("UPDATE bb".$n."_pms SET reply = 1 WHERE pmid = '$replyid'");
                	if($forwardid) $db_zugriff->query("UPDATE bb".$n."_pms SET forward = 1 WHERE pmid = '$forwardid'");
                	header("LOCATION: pms.php?box=inbox$session");
                }        
	}
	if($action == "reply") {
		$pmdata = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
		$subject = prepare_topic($pmdata[subject]);
		$message = prepare_quote($pmdata[message]);
		$sendername = $recipient = getUsername($pmdata[senderid]);
		$sendtime = formatdate($pmdata[sendtime],$longdateformat,0);
		eval ("\$message = \"".gettemplate("pm_reply_message")."\";");
		eval ("\$subject = \"".gettemplate("pm_reply_subject")."\";");
		$replyid = $pmid;
	}
	if($action == "forward") {
		$pmdata = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
		$subject = prepare_topic($pmdata[subject]);
		$message = prepare_quote($pmdata[message]);
		$sendername = getUsername($pmdata[senderid]);
		$sendtime = formatdate($pmdata[sendtime],$longdateformat,0);
		eval ("\$message = \"".gettemplate("pm_forward_message")."\";");
		eval ("\$subject = \"".gettemplate("pm_forward_subject")."\";");
		$forwardid = $pmid;
	}
	if($userid) $recipient = getUsername($userid);
			
	if($ch_parseurl) $checked[0] = "CHECKED";
	if($ch_disablesmilies) $checked[2] = "CHECKED";
	if($ch_signature) $checked[3] = "CHECKED";
	
	if($preview) {
		$subject = prepare_topic($subject);
                        $user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE username='$user_name'");
                        if($user_info[signatur] && $signature && !$hide_signature) {
                        	$signatur = editPost($user_info[signatur],$disablesmilies);
				eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
			}
                        if($posticon) $pre_posticon = "<img src=\"".$posticon."\">";
                        else $pre_posticon = "&nbsp;";
                        $post = editPost($message,$disablesmilies);
                        $message = stripslashes($message);             
                        eval ("\$preview = \"".gettemplate("preview")."\";");
                        
                        if($parseurl) $checked[0] = "CHECKED";
			else $checked[0] = "";
			if($copy) $checked[1] = "CHECKED";
			else $checked[1] = "";
			if($disablesmilies) $checked[2] = "CHECKED";
			else $checked[2] = "";
			if($signature) $checked[3] = "CHECKED";
			else $checked[3] = "";
        }
	
	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);
	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");
	include("templates/posticons.php");
	for($i = 0; $i < count($posticons); $i++) {
		if(is_int($i/6) && $i) $choice_posticons .= "<br>";
		elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
		$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
		if($posticon == $posticons[$i]) $choice_posticons .= " CHECKED";
		$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
	}
	if(!$posticon) $noicon[0] = "CHECKED"; 
	if($session) $session_post = "<INPUT TYPE=\"HIDDEN\" NAME=\"sid\" VALUE=\"$sid\">";
	
	eval("dooutput(\"".gettemplate("pm_new")."\");");
	exit;
}
if($action == "print") {

	$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
	if(!$row[pmid]) {
		header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
		exit;
	}
	
	$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
	$sendername = $user_info[username];
	$subject = prepare_topic($row[subject]);
	$message = editPost($row[message],$row[disable_smilies]);
	if($user_info[signatur] && $row[signature] && !$hide_signature) {
		$signatur = editSignatur($user_info[signatur],$row[disable_smilies]);
		eval ("\$signature = \"".gettemplate("thread_signature")."\";");
	}
	$sendtime = formatdate($row[sendtime],$longdateformat,0);
	
	eval("dooutput(\"".gettemplate("pm_print")."\");");
	exit;
}
if($action == "download") {
	
	$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
	if(!$row[pmid]) {
		header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
		exit;
	}

	$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
	$sendername = $user_info[username];
	$subject = prepare_topic($row[subject]);
	$message = prepare_topic($row[message]);
	if($user_info[signatur] && $row[signature] && !$hide_signature) {
		$signatur = prepare_topic($user_info[signatur]);
		eval ("\$signature = \"".gettemplate("thread_signature")."\";");
	}
	$sendtime = formatdate($row[sendtime],$longdateformat,0);
	
	header("Content-disposition: filename=message-".$pmid.".txt"); 
	header("Content-type: application/octet-stream"); 
	header("Pragma: no-cache"); 
	header("Expires: 0"); 
	
	eval("dooutput(\"".gettemplate("pm_download")."\");");
	exit;
}
if($action == "delete") {

	$check = $db_zugriff->query_first("SELECT pmid FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
	if(!$check[pmid]) {
		header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
		exit;
	}
	if(!$save) eval("dooutput(\"".gettemplate("pm_delete_check")."\");");
	else {
		$db_zugriff->query("DELETE FROM bb".$n."_pms WHERE pmid = '$pmid'");
		header("LOCATION: pms.php?boardid=$boardid&styleid=$styleid$session");
	}	
	exit;
}
if($action == "massdel") {

	unset($where);
	for($i = 0; $i < count($select); $i++) {
		if($where) $where .= " OR ";
		$where .= "pmid='".$select[$i]."'";	
	}
	if($where) $db_zugriff->query("DELETE FROM bb".$n."_pms WHERE $where");
	header("LOCATION: pms.php$session2");	
	exit;
}

if(substr($action, 0 , 2) == "->") {
	
	$folderid = substr($action, 2);
	unset($where);
	for($i = 0; $i < count($select); $i++) {
		if($where) $where .= " OR ";
		$where .= "pmid='".$select[$i]."'";	
	}
	if($where) $db_zugriff->query("UPDATE bb".$n."_pms SET folderid = '$folderid' WHERE $where");
	header("LOCATION: pms.php?box=$folderid$session");	
	exit;
}

if($action == "massdel_send") {
	unset($where);
	for($i = 0; $i < count($select); $i++) {
		if($where) $where .= " OR ";
		$where .= "pmid='".$select[$i]."'";	
	}
	if($where) $db_zugriff->query("DELETE FROM bb".$n."_pmsend WHERE $where");
	header("LOCATION: pms.php?box=outbox$session");	
	exit;
}

if($action == "createfolder" && $foldername = trim($foldername)) {
	$check = $db_zugriff->query_first("SELECT folderid FROM bb".$n."_folders WHERE userid = '$user_id' AND foldername = '".editPostdata($foldername)."'");
	$count = $db_zugriff->query_first("SELECT COUNT(folderid) FROM bb".$n."_folders WHERE userid = '$user_id'");
	if($check[0] || $count[0] >= $maxfolder) {
		eval ("\$output = \"".gettemplate("error28")."\";");
		eval("dooutput(\"".gettemplate("action_error")."\");");
		exit;
	}
	$db_zugriff->query("INSERT INTO bb".$n."_folders VALUES ('','$user_id','".editPostdata($foldername)."')");
	header("LOCATION: pms.php?box=".$db_zugriff->insert_id()."$session");	
	exit;
}

if($action == "delfolder" && $folderid) {
	$check = $db_zugriff->query_first("SELECT folderid FROM bb".$n."_folders WHERE userid = '$user_id' AND folderid = '$folderid'");
	if($check[0]) {
		$db_zugriff->query("UPDATE bb".$n."_pms SET folderid = 0 WHERE folderid = '$folderid'");
		$db_zugriff->query("DELETE FROM bb".$n."_folders WHERE folderid = '$folderid'");
		header("LOCATION: pms.php?box=inbox$session");	
		exit;
	}
	exit;
}

if($box == "inbox" && !$pmid) { 

	$result = $db_zugriff->query("SELECT bb".$n."_pms.*, bb".$n."_user_table.username AS sendername FROM bb".$n."_pms LEFT JOIN bb".$n."_user_table ON (bb".$n."_pms.senderid=bb".$n."_user_table.userid) WHERE recipientid = '$user_id' AND folderid = 0 ORDER BY sendtime DESC");
	while ($row = $db_zugriff->fetch_array($result)) {
	
		if($row[icon]) $icon = "<img src=\"$row[icon]\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row[subject]);
		$sendername = $row[sendername];
		$sendtime = formatdate($row[sendtime],$longdateformat,1);
		
		if($row[sendtime] >= $old_time) $folder_image = "<img src=\"images/pmnew.gif\">";
		elseif(!$row[view]) $folder_image = "<img src=\"images/pmunread.gif\">";
		else {
			if($row[reply] && $row[forward]) $folder_image = "<img src=\"images/pmreward.gif\">";
			elseif($row[reply]) $folder_image = "<img src=\"images/pmreply.gif\">";
			elseif($row[forward]) $folder_image = "<img src=\"images/pmforward.gif\">";
			else  $folder_image = "<img src=\"images/pmnormal.gif\">";
		}
		
		eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit")."\";");
	}
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id' ORDER BY foldername ASC");
	while($folder = $db_zugriff->fetch_array($result)) {
		$folderdel_options .= "<option value=\"".$folder[folderid]."\">".editDBdata($folder[foldername])."</option>\n";
		$change_options .= "<option value=\"".$folder[folderid]."\">".editDBdata($folder[foldername])."</option>\n";
		$move_options .= "<option value=\"->".$folder[folderid]."\">Verschieben nach: ".editDBdata($folder[foldername])."</option>\n";
	}
	$foldername = "Inbox";
	
	if($folderdel_options) eval ("\$del_folder = \"".gettemplate("pm_delfolder")."\";");
	if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
	eval("dooutput(\"".gettemplate("pm_inbox")."\");");
}

if($box != "inbox" && $box != "outbox" && !$pmid) {

	$result = $db_zugriff->query("
				SELECT bb".$n."_pms.*, username, foldername FROM bb".$n."_pms
				LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_pms.senderid)
				LEFT JOIN bb".$n."_folders ON (bb".$n."_folders.folderid=bb".$n."_pms.folderid)
				WHERE recipientid = '$user_id' AND bb".$n."_pms.folderid = '$box' ORDER BY sendtime DESC");
	while ($row = $db_zugriff->fetch_array($result)) {
	
		if($row[icon]) $icon = "<img src=\"$row[icon]\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row[subject]);
		$sendername = $row[username];
		$sendtime = formatdate($row[sendtime],$longdateformat,1);
		
		if($row[sendtime] >= $old_time) $folder_image = "<img src=\"images/pmnew.gif\">";
		elseif(!$row[view]) $folder_image = "<img src=\"images/pmunread.gif\">";
		else {
			if($row[reply] && $row[forward]) $folder_image = "<img src=\"images/pmreward.gif\">";
			elseif($row[reply]) $folder_image = "<img src=\"images/pmreply.gif\">";
			elseif($row[forward]) $folder_image = "<img src=\"images/pmforward.gif\">";
			else  $folder_image = "<img src=\"images/pmnormal.gif\">";
		}
		eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit")."\";");
	}
	$move_options .= "<option value=\"->inbox\">Verschieben nach: Inbox</option>\n";
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id' ORDER BY foldername ASC");
	while($folder = $db_zugriff->fetch_array($result)) {
		if($box==$folder[folderid]) $foldername = editDBdata($folder[foldername]);
		$folderdel_options .= "<option value=\"".$folder[folderid]."\">".editDBdata($folder[foldername])."</option>\n";
		$change_options .= "<option value=\"".$folder[folderid]."\">".editDBdata($folder[foldername])."</option>\n";
		if($folder[folderid]!=$box)$move_options .= "<option value=\"->".$folder[folderid]."\">Verschieben nach: ".editDBdata($folder[foldername])."</option>\n";
	}
	if($folderdel_options) eval ("\$del_folder = \"".gettemplate("pm_delfolder")."\";");
	if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
	eval("dooutput(\"".gettemplate("pm_inbox")."\");");
}

if($box == "outbox" && !$pmid) {

	$result = $db_zugriff->query("SELECT bb".$n."_pmsend.*, bb".$n."_user_table.username FROM bb".$n."_pmsend LEFT JOIN bb".$n."_user_table ON (bb".$n."_pmsend.recipientid=bb".$n."_user_table.userid) WHERE bb".$n."_pmsend.userid = '$user_id' ORDER BY sendtime DESC");
	while ($row = $db_zugriff->fetch_array($result)) {
		
		if($row[icon]) $icon = "<img src=\"$row[icon]\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row[subject]);
		$recipientname = $row[username];
		$sendtime = formatdate($row[sendtime],$longdateformat,1);
		$folder_image = "<img src=\"images/pmnormal.gif\">";
		eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit2")."\";");
	}
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id'");
	while($folder = $db_zugriff->fetch_array($result)) $change_options .= "<option value=\"".$folder[folderid]."\">".editDBdata($folder[foldername])."</option>\n";
	if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
	eval("dooutput(\"".gettemplate("pm_outbox")."\");");
}
	if($pmid && $box != "outbox") {

		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid'");
		if($row[senderid]==$user_id) $links = "&nbsp;";
		elseif($row[recipientid]==$user_id) {
			$db_zugriff->query("UPDATE bb".$n."_pms SET view=1 WHERE pmid = '$pmid'");
			eval ("\$links = \"".gettemplate("pm_links")."\";");
		}
		else {
			header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
			exit;
		}
		$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
		$sendername = $user_info[username];
		$recipientname = $db_zugriff->query_first("SELECT username FROM bb".$n."_user_table WHERE userid = '$row[recipientid]'");
		$recipientname = $recipientname[username];
		
		if($row[icon]) $icon = "<img src=\"".$row[icon]."\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row[subject]);
		$message = editPost($row[message],$row[disable_smilies]);
		if($user_info[signatur] && $row[signature] && !$hide_signature) {
			$signatur = editSignatur($user_info[signatur],$row[disable_smilies]);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		$sendtime = formatdate($row[sendtime],$longdateformat,0);
			
		eval("dooutput(\"".gettemplate("pm_view")."\");");
	}
	elseif($pmid) {
	
		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pmsend WHERE pmid = '$pmid' AND userid = '$user_id'");
		$sendername = $user_name;
		$recipientname = getUsername($row[recipientid]);
		
		if($row[icon]) $icon = "<img src=\"".$row[icon]."\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row[subject]);
		$message = editPost($row[message],$row[disable_smilies]);
		if($user_info[signatur] && $row[signature] && !$hide_signature) {
			$signatur = editSignatur($user_info[signatur],$row[disable_smilies]);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		$sendtime = formatdate($row[sendtime],$longdateformat,0);
			
		eval("dooutput(\"".gettemplate("pm_view")."\");");
	}
}
else header("LOCATION: misc.php?action=access_error$session");
?>