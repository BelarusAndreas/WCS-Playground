<? 
require("_functions.php");
require("_header.php");
require("_board_jump.php");

if($goto) {
	$time = $db_zugriff->query_first("SELECT timelastreply as time FROM bb".$n."_threads WHERE threadid='$threadid'");
	if($goto == "nextoldest") $nextthread = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE timelastreply < '".$time[time]."' AND boardparentid='$boardid' ORDER by timelastreply DESC LIMIT 1");
	if($goto == "nextnewest") $nextthread = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE timelastreply > '".$time[time]."' AND boardparentid='$boardid' ORDER by timelastreply ASC LIMIT 1");
	$threadid = $nextthread[threadid];
}
$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info[boardparentid]) { 
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
$threadname = prepare_topic($thread_info[threadname]);

$db_zugriff->query("UPDATE bb".$n."_threads SET views=views+1 WHERE threadid='$threadid'");
$sthreadname = "sthread_".$threadid;
$$sthreadname = $thread_info[timelastreply];
session_register("$sthreadname");

$anzahl = $thread_info[replies]+1;
if(!$page) $page=1;

$result = $db_zugriff->query("SELECT * FROM bb".$n."_ranks ORDER BY posts DESC");
while($row=$db_zugriff->fetch_array($result)) $rankcache[$row[groupid]][]=$row;

function getRank($posts,$groupid) {
 global $rankcache;
 for($i=0;$i<count($rankcache[$groupid]);$i++) {
  if($rankcache[$groupid][$i][posts]==0) {
   return $rankcache[$groupid][$i];
   break;
  }
  elseif($posts/$rankcache[$groupid][$i][posts]>=1) {
   return $rankcache[$groupid][$i];
   break;
  } 
 }
}

$getpostids=$db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE bb".$n."_posts.threadparentid='$threadid' ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC")." LIMIT ".($eproseite*($page-1)).",".($eproseite));
while($row=$db_zugriff->fetch_array($getpostids)) $postids.=",".$row[postid];

$post_result = $db_zugriff->query("
	SELECT bb".$n."_posts.*, bb".$n."_avatars.extension as avatarextension, bb".$n."_user_table.*, bb".$n."_useronline.zeit FROM bb".$n."_posts
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_posts.userid)
	LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id = bb".$n."_user_table.avatarid)
	LEFT JOIN bb".$n."_useronline ON (bb".$n."_useronline.userid = bb".$n."_posts.userid AND bb".$n."_useronline.userid>0)
	WHERE bb".$n."_posts.postid IN (0$postids) ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC"));
$pages=ceil($anzahl/$eproseite); 
unset($j);

while($posts = $db_zugriff->fetch_array($post_result)){
	
	unset($posttopic);
	unset($lastedit);
	unset($user_pic);
	unset($signature);
	unset($email);
	unset($userhp);
	unset($quote_and_edit);
	unset($location);
	unset($usericq);
	unset($useraim);
	unset($useryim);
	unset($status);
	unset($stars);
	unset($user_on_off);
	unset($search);
	unset($profile);
	unset($homie);
	unset($pn);
	unset($regdate);
		
	if($posts[userid]) {
		if($pms && $userdata[canusepms]) eval ("\$pn = \"".gettemplate("thread_pm")."\";"); 	
		$regdate = formatdate($posts[regdate],$regdateformat);
		$location = htmlspecialchars(editDBdata($posts[location]));
		
		$rank = getRank($posts[userposts],$posts[groupid]);
		if($rank) {
		 for($i = 0; $i<$rank[mal]; $i++) $stars .= "<img src=\"$rank[grafik]\" border=\"0\">";
        	 $stars = "<a href=\"javascript:rank($rank[id])\" title=\"Informationen zum Rang $rank[rank]\">".$stars."</a>";
	
		 if($posts[statusextra]) $status = editDBdata($posts[statusextra]);
		 else $status = $rank[rank]; 
		}
		
		if($posts[avatarid] && !$hide_userpic && $avatars) $user_pic = "<br><img src=\"images/avatars/avatar-".$posts[avatarid].".".$posts[avatarextension]."\" border=0>";
		if($posts[signatur] && $posts[signature] && !$hide_signature) {
			$signatur = editSignatur($posts[signatur],$posts[disable_smilies]);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		if($posts[zeit]) eval ("\$user_on_off = \"".gettemplate("thread_useron")."\";");
		else eval ("\$user_on_off = \"".gettemplate("thread_useroff")."\";");
		if($posts[users_may_email]==1) eval ("\$email = \"".gettemplate("thread_email")."\";");
		if($posts[userhp]) eval ("\$userhp = \"".gettemplate("thread_userhp")."\";");
		if($posts[usericq]) {
			$usericq = editDBdata($posts[usericq]);
			eval ("\$usericq = \"".gettemplate("thread_usericq")."\";");
		}
		if($posts[aim]) {
			$aim = editDBdata($posts[aim]);
			eval ("\$useraim = \"".gettemplate("thread_useraim")."\";");
		}
		if($posts[yim]) {
			$yim = editDBdata($posts[yim]);
			eval ("\$useryim = \"".gettemplate("thread_useryim")."\";");
		}
		eval ("\$search = \"".gettemplate("thread_search")."\";");
		eval ("\$profile = \"".gettemplate("thread_profile")."\";");
		eval ("\$homie = \"".gettemplate("thread_homie")."\";");
		$authorname = $posts[username];
	}
	else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
		
	$a_name = (($page-1)*$eproseite)+$j+1;
	$backcolor = rowcolor($j);
		
	if($posts[posticon]) $posticon = "<img src=\"$posts[posticon]\">";
	else $posticon = "&nbsp;";
	
	$posttopic = prepare_topic($posts[posttopic]);
	$post = editPost($posts[message],$posts[disable_smilies]);
	
	if($old_time <= $posts[posttime]) $postsign = "<IMG SRC=\"images/posticonnew.gif\">";
	else $postsign = "<IMG SRC=\"images/posticon.gif\">";
	$posttime = formatdate($posts[posttime],$longdateformat,1);
		
	if($posts[edittime]) {
		if($posts[editorid]) $editorname = getUsername($posts[editorid]);
		else eval ("\$editorname = \"".gettemplate("lg_anonymous")."\";");
		$edittime = formatdate($posts[edittime],$longdateformat);
		eval ("\$lastedit = \"".gettemplate("thread_lastedit")."\";");
	}
	if($thread_info[flags]!=1) eval ("\$quote_and_edit = \"".gettemplate("thread_quote_edit")."\";");
		
	eval ("\$thread_postbit .= \"".gettemplate("thread_postbit")."\";");
	$j++;
}
$db_zugriff->free_result($post_result);
						
$navi_chain = makenavichain("thread",$boardid,$threadid);
$oldest = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE boardparentid='$boardid' ORDER BY timelastreply ASC LIMIT 1");
if($threadid != $oldest[threadid]) eval ("\$next_thread .= \"".gettemplate("thread_next_oldest")."\";");
$newest = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE boardparentid='$boardid' ORDER BY timelastreply DESC LIMIT 1");
if($threadid != $newest[threadid]) eval ("\$next_thread .= \"".gettemplate("thread_next_newest")."\";");

eval ("\$newthread_reply  .= \"".gettemplate("thread_newthread")."\";");
if(!getThreadflag($threadid)) eval ("\$newthread_reply  .= \"".gettemplate("thread_reply")."\";");
else eval ("\$newthread_reply  .= \"".gettemplate("thread_closed")."\";");

if($pages>1) $page_link = makepagelink("thread.php?threadid=$threadid&boardid=$boardid$session", $page, $pages);
if($thread_info[pquestion]) {
	
	$poll_check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_vote WHERE threadid='$threadid' AND userid = '$user_id'");
	$ptitle = prepare_topic($thread_info[pquestion]);
	if($poll_check[0] || $presult || ($thread_info[ptimeout] && time() >= ($thread_info[starttime]+$thread_info[ptimeout]*(24*3600)))) {
		$votes_total = $db_zugriff->query_first("SELECT SUM(votes) FROM bb".$n."_poll WHERE threadid='$threadid'");
		$total = $votes_total[0];
		$poll_result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid='$threadid'");
		while($row = $db_zugriff->fetch_array($poll_result)) {
			$field = prepare_topic($row[field]);
			$votes = $row[votes];
			
			if($total) {
				$percent_float = $votes*100/$total;
				$percent = number_format($percent_float, 2);
				$percent_int = floor($percent_float)*3;	
			}
			else $percent = $percent_int = 0; 
			
			eval ("\$thread_poll_resultbit .= \"".gettemplate("thread_poll_resultbit")."\";");
		}
		if(check_boardobject($boardid,$user_id,"mod") || $userdata[issupermod]) eval ("\$mod_poll_edit = \"".gettemplate("thread_polledit")."\";");
		eval ("\$poll = \"".gettemplate("thread_poll_result")."\";");
	}
	else {
		$poll_result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid='$threadid'");
		while($row = $db_zugriff->fetch_array($poll_result)) {
			$field = prepare_topic($row[field]);
			eval ("\$thread_pollbit .= \"".gettemplate("thread_pollbit")."\";");
		}
		if(check_boardobject($boardid,$user_id,"mod") || $userdata[issupermod]) eval ("\$mod_poll_edit = \"".gettemplate("thread_polledit")."\";");
		eval ("\$poll = \"".gettemplate("thread_poll")."\";");
	}
} 
if(check_boardobject($boardid,$user_id,"mod") || $userdata[issupermod] || ($thread_info[authorid] && $thread_info[authorid]==$user_id && ($userdata[cancloseowntopic] || $userdata[candelowntopic]))) eval ("\$quick_mod = \"".gettemplate("thread_quick_mod")."\";");
eval("dooutput(\"".gettemplate("thread")."\");");
?>
			
					