<?
						eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
						eval ("\$footer = \"".gettemplate("footer")."\";");
if($imageurl) 					$imageurl = "<img src=\"$imageurl\">";
if(!$user_id)	 				eval ("\$pro_reg = \"".gettemplate("header_reg")."\";");
else 						eval ("\$pro_reg = \"".gettemplate("header_profile")."\";");
if($userdata[canuseacp])			eval ("\$admin = \"".gettemplate("header_admin")."\";");
						eval ("\$header = \"".gettemplate("header")."\";");
if($user_id) 					eval ("\$navibar_hello = \"".gettemplate("header_logtin")."\";");
else 						eval ("\$navibar_hello = \"".gettemplate("header_unreg")."\";");

if($session) $session_post = "<INPUT TYPE=\"HIDDEN\" NAME=\"sid\" VALUE=\"$sid\">";
?>