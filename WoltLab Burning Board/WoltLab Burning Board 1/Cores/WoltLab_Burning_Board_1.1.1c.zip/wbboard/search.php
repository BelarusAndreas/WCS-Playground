<?
require("_functions.php");
require("_header.php");
if(!$userdata[canusesearch ]) {
	header("LOCATION: misc.php?action=access_error$session");
	exit;
}
if(!$send && $mode!="daily" && $mode!="user" && !$searchid) {

        function makeboardsearchbit($bid,$depth=1) {
  		global $boardcache, $permissioncache;

  		if ( !isset($boardcache[$bid]) ) {
    			return;
  		}

  		while ( list($key1,$val1)=each($boardcache[$bid]) ) {
    			while ( list($key2,$boards)=each($val1) ) {
				if($boards[invisible] && !$permissioncache[$boards[boardid]]) continue;
				$out .= "<OPTION value=\"+".$boards[boardid]."\"";
				if($depth>1) $out .= ">".str_repeat("--",$depth-1)." ".editDBdata($boards[boardname])."</option>";
				else $out .= ">".editDBdata($boards[boardname])."</option>";
				$out.=makeboardsearchbit($boards[boardid],$depth+1);
        		} 
  		} 
  		unset($boardcache[$bid]);
  		return $out;
	}

	$result = $db_zugriff->query("SELECT * FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
	while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row[boardparentid]][$row[sort]][$row[boardid]] = $row;
	$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
	while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row[boardid]] = 1;
	$board_links = makeboardsearchbit(0);
	$db_zugriff->free_result($result);
        eval("dooutput(\"".gettemplate("search_new")."\");");
}
elseif(!$searchid) {
	if($mode=="daily") {
		$before = 1;
		$searchdate = 1;
		$sortby = "posttime"; 
		$sortorder = "DESC";
	} 
	if($mode=="user") {
		$searchuser = getUsername($userid);
		$exactname = 1;
		$showposts = 1;
		$searchdate = -1;
		$sortby = "posttime"; 
		$sortorder = "DESC";
	}
		if($searchdate!=-1) {
			if($before) $before = ">";
			else $before = "<";
			$posttime = "posttime".$before."'".(time()-($searchdate*86400))."'";
		}
		$forum = $forumchoice;
		if($forumchoice) {
		 $tempforumchoice = substr($forumchoice,1);
		 $forumchoice="";
		}
			$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1".ifelse($tempforumchoice," AND boardid='$tempforumchoice'",""));
			while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row[boardid]] = 1;
			$board_result = $db_zugriff->query("SELECT boardid FROM bb".$n."_boards WHERE boardpassword = ''");
                        unset($forumchoice);
                        while($boards = $db_zugriff->fetch_array($board_result)) {
                        	if(!$permissioncache[$boards[boardid]]) continue;
		        	if($forumchoice) $forumchoice .= " OR "; 
				$forumchoice .= "boardparentid='$boards[boardid]'";
			}
	if($query) {	
		if($hack_query) {
			$query_array = explode(" ",$query); 
			if($hack_query==1) {
							
				for($i = 0; $i < count($query_array); $i++) {
					if($i) $searchwords .= "AND";
					$searchwords .= " (";
					if($posts) $searchwords .= "message like '%".$query_array[$i]."%'";
					if($posts && $title) $searchwords .= " OR ";
					if($title) $searchwords .= "posttopic like '%".$query_array[$i]."%'";
					$searchwords .= " )";				
				}
			}
			else {
				$searchwords .= "(";
				for($i = 0; $i < count($query_array); $i++) {
					
					if($i) $searchwords .= " OR ";
					if($posts) $searchwords .= "message like '%".$query_array[$i]."%'";
					if($posts && $title) $searchwords .= " OR ";
					if($title) $searchwords .= "posttopic like '%".$query_array[$i]."%'";
								
				}
				$searchwords .= " )";	
			}
		} 
		else {
			$searchwords .= "(";
			if($posts) $searchwords .= "message like '%".$query."%'";
			if($posts && $title) $searchwords .= " OR ";
			if($title) $searchwords .= "posttopic like '%".$query."%'";
			$searchwords .= " )";	
		}
	}
	elseif($searchuser) {
		if($exactname) {
			$user = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username='$searchuser'");
			$searchwords = "bb".$n."_posts.userid='$user[userid]'";
		}
		else {
			$user = $db_zugriff->query("SELECT userid FROM bb".$n."_user_table WHERE username like '%".$searchuser."%'");
			while($row = $db_zugriff->fetch_array($user)) {
				if(!$m) $searchwords = "(";
				if($m) 	$searchwords .= " OR ";
				$searchwords .= "bb".$n."_posts.userid='$row[userid]'";
				$m = 1;	
			}
			if(!$searchwords) $searchwords = "bb".$n."_posts.userid='0'";
			else $searchwords .= ")";
		}
	}
	if(!$forumchoice) {
		eval("dooutput(\"".gettemplate("search_no_result")."\");");
		exit;	
	}
	if($posttime && ($forumchoice || $searchwords)) $posttime .= " AND";
	if($searchwords) $searchwords = "AND ".$searchwords;
	$ssquery = "$posttime ($forumchoice) $searchwords ORDER by $sortby $sortorder";
	
	do {
		$countx++;
		$name = "ssquery".$countx;
	}
	while($$name); 
	$$name = $ssquery;
	session_register("$name");
	eval ("\$output = \"".gettemplate("note27")."\";");
	$ride = "search.php?boardid=$boardid&searchid=$countx&showposts=$showposts$session";
	eval("dooutput(\"".gettemplate("action_ride")."\");");
}
else {		
	$name = "ssquery".$searchid;
	if(!trim($$name)) {
	 eval("dooutput(\"".gettemplate("search_no_result")."\");");
	 exit();
	}
	$order=substr($$name, strpos($$name, "ORDER"));
	if($showposts) {
		$anzahl = $db_zugriff->query_first("SELECT COUNT(postid)as anzahl FROM bb".$n."_posts WHERE ".$$name);
		$anzahl = $anzahl[anzahl];
		if(!$page) $page=1;

		$getpostids=$db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE ".$$name." LIMIT ".($eproseite*($page-1)).",".$eproseite);
		while($row=$db_zugriff->fetch_array($getpostids)) $postids.=",".$row[postid];

		$post_result = $db_zugriff->query("
		SELECT bb".$n."_posts.*,
		bb".$n."_avatars.extension as avatarextension,
		bb".$n."_user_table.*,
		bb".$n."_useronline.zeit,
		bb".$n."_threads.flags
		FROM bb".$n."_posts
		LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_posts.userid)
		LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id = bb".$n."_user_table.avatarid)
		LEFT JOIN bb".$n."_useronline ON (bb".$n."_useronline.userid = bb".$n."_posts.userid)
		LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid = bb".$n."_posts.threadparentid)
		WHERE postid IN (0$postids) ".$order);

		$pages=ceil($anzahl/$eproseite);
		$l_hits = 1+($page-1)*$eproseite;
		$h_hits = $page*$eproseite;
		if($h_hits > $anzahl) $h_hits = $anzahl;
		$all_hits = $anzahl;
		
		if($pages>1) $page_link = makepagelink("search.php?boardid=$boardid&searchid=$searchid&showposts=$showposts$session", $page, $pages);
		while($posts = $db_zugriff->fetch_array($post_result)){
		
			unset($posttopic);
			unset($lastedit);
			unset($user_pic);
			unset($signature);
			unset($email);
			unset($userhp);
			unset($quote_and_edit);
			unset($location);
			unset($usericq);
			unset($useraim);
			unset($useryim);
			unset($status);
			unset($stars);
			unset($user_on_off);
			unset($search);
			unset($profile);
			unset($homie);
			unset($pn);
			unset($regdate);
			unset($out);
			
			if($posts[userid]) {
				if($pms && $userdata[canusepms]) eval ("\$pn = \"".gettemplate("thread_pm")."\";"); 	
				$regdate = formatdate($posts[regdate],$regdateformat);
				$location = htmlspecialchars(editDBdata($posts[location]));
				$rank = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE groupid = $posts[groupid] AND posts<='$posts[userposts]' ORDER by posts DESC LIMIT 1");
	        		if($posts[statusextra]) $status = editDBdata($posts[statusextra]);
				else $status = $rank[rank]; 
		
                		for($i = 0; $i<$rank[mal]; $i++) {
                			$out .= "<img src=\"$rank[grafik]\" border=\"0\">";
        			}
        			$stars = "<a href=\"javascript:rank($rank[id])\" title=\"Informationen zum Rang $rank[rank]\">".$out."</a>";
        			if($posts[avatarid] && !$hide_userpic && $avatars) $user_pic = "<br><img src=\"images/avatars/avatar-".$posts[avatarid].".".$posts[avatarextension]."\" border=0>";
				if($posts[signatur] && $posts[signature] && !$hide_signature) {
					$signatur = editSignatur($posts[signatur],$posts[disable_smilies]);
					eval ("\$signature = \"".gettemplate("thread_signature")."\";");
				}
				if($posts[zeit]) eval ("\$user_on_off = \"".gettemplate("thread_useron")."\";");
				else eval ("\$user_on_off = \"".gettemplate("thread_useroff")."\";");
				if($posts[users_may_email]==1) eval ("\$email = \"".gettemplate("thread_email")."\";");
				if($posts[userhp]) eval ("\$userhp = \"".gettemplate("thread_userhp")."\";");
				if($posts[usericq]) {
					$usericq = editDBdata($posts[usericq]);
					eval ("\$usericq = \"".gettemplate("thread_usericq")."\";");
				}
				if($posts[aim]) {
					$aim = editDBdata($posts[aim]);
					eval ("\$useraim = \"".gettemplate("thread_useraim")."\";");
				}
				if($posts[yim]) {
					$yim = editDBdata($posts[yim]);
					eval ("\$useryim = \"".gettemplate("thread_useryim")."\";");
				}
				eval ("\$search = \"".gettemplate("thread_search")."\";");
				eval ("\$profile = \"".gettemplate("thread_profile")."\";");
				eval ("\$homie = \"".gettemplate("thread_homie")."\";");
				$authorname = $posts[username];
			}
			else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
						
			$a_name = (($page-1)*$eproseite)+$j+1;
			$backcolor = rowcolor($j++);
		
			if($posts[posticon]) $posticon = "<img src=\"".$posts[posticon]."\">";
			else $posticon = "&nbsp;";
	
			$posttopic = prepare_topic($posts[posttopic]);
			$post = editPost($posts[message],$posts[disable_smilies]);
	
			if($old_time <= $posts[posttime]) $postsign = "<IMG SRC=\"images/posticonnew.gif\">";
			else $postsign = "<IMG SRC=\"images/posticon.gif\">";
			$posttime = formatdate($posts[posttime],$longdateformat,1);
		
			if($posts[edittime]) {
				if($posts[editorid]) $editorname = getUsername($posts[editorid]);
				else eval ("\$editorname = \"".gettemplate("lg_anonymous")."\";");
				$edittime = formatdate($posts[edittime],$longdateformat);
				eval ("\$lastedit = \"".gettemplate("thread_lastedit")."\";");
			}
			if($posts[flags]!=1) eval ("\$quote_and_edit = \"".gettemplate("thread_quote_edit")."\";");
			$boardparentid = $posts[boardparentid];
			eval ("\$quote_and_edit = \"".gettemplate("search_showthread")."\";");
			eval ("\$thread_postbit .= \"".gettemplate("thread_postbit")."\";");
		}
		$db_zugriff->free_result($post_result);
		require("_board_jump.php");
		if($thread_postbit) eval("dooutput(\"".gettemplate("search_posts")."\");");
		else eval("dooutput(\"".gettemplate("search_no_result")."\");");
	
	}
	else {
		$result = $db_zugriff->query("SELECT DISTINCT threadparentid FROM bb".$n."_posts WHERE ".$$name);
		$anzahl = $db_zugriff->num_rows($result);
		while($row=$db_zugriff->fetch_array($result)) $allthreadids.=",".$row[threadparentid];
		if(!$page) $page=1;
		
		$getthreadids=$db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE threadid IN (0$allthreadids) ORDER BY timelastreply DESC LIMIT ".($tproseite*($page-1)).",".$tproseite);
		while($row=$db_zugriff->fetch_array($getthreadids)) $threadids.=",".$row[threadid];
		

		$result = $db_zugriff->query("
		SELECT bb".$n."_threads.*,
		bb".$n."_boards.boardname,
		bb".$n."_user_table.username
		FROM bb".$n."_threads
		LEFT JOIN bb".$n."_boards ON (bb".$n."_boards.boardid=bb".$n."_threads.boardparentid)
		LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_threads.lastposterid)
		WHERE threadid IN (0$threadids) ORDER BY timelastreply DESC");
		
		$pages=ceil($anzahl/$tproseite);
		
		$l_hits = 1+($page-1)*$tproseite;
		$h_hits = $page*$tproseite;
		if($h_hits > $anzahl) $h_hits = $anzahl;
		$all_hits = $anzahl;
		
		if($pages>1) $page_link = makepagelink("search.php?boardid=$boardid&searchid=$searchid&showposts=$showposts$session", $page, $pages);
		while ($threads = $db_zugriff->fetch_array($result)) {
			
			unset($folder_image);
			unset($thread_link);
			unset($anonymous_lp);
			unset($anonymous);
			unset($thread_starter);
			unset($lastauthor);
			
			$sthreadname = "sthread_".$threads[threadid];	
			$boardname = $threads[boardname];		
			if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) $folder_image .= "new";		
			if($threads[replies] > "15" || $threads[views] > "150") $folder_image .= "hot";
			if($threads[flags]==1) $folder_image .= "lock";
			$folder_image = "<img src=\"images/".$folder_image."folder.gif\">";
			
			if($threads[topicicon]) $posticon = "<img src=\"$threads[topicicon]\">";
			else $posticon = "&nbsp;";
		
			if($old_time <= $threads[timelastreply] && $$sthreadname < $threads[timelastreply]) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
			$thread_link .= "<font size=2 face=\"$font\"><b>";
			if($threads[important]) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
			if($threads[pollid]) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
			$thread_link .= "<a href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]$session\">".prepare_topic($threads[threadname])."</a></b></font>";
			if(($threads[replies]+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"$font\"> ( <img src=\"images/multipage.gif\"> <a href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]$session&page=1\">1</a> <a href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]$session&page=2\">2</a> ";
			if(($threads[replies]+1)/$eproseite > 2) $thread_link .= "<a href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]$session&page=3\">3</a> ";
			if(($threads[replies]+1)/$eproseite > 3) $thread_link .= "<a href=\"thread.php?threadid=".$threads[threadid]."&boardid=$threads[boardparentid]$session&page=4\">4</a> ";
			if(($threads[replies]+1)/$eproseite > 4) {
				$pagesx=ceil(($threads[replies]+1)/$eproseite);
				eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
			}
			if(($threads[replies]+1)/$eproseite > 1) $thread_link .= ")</font>";
		
			$starttime = formatdate($threads[starttime],$longdateformat,1);
			if($threads[authorid]) $thread_starter = $threads[author];
			else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
			$lastposttime = formatdate($threads[timelastreply],$longdateformat,1);
			if($threads[lastposterid]) $lastauthor = $threads[username];
			else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
			eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");
					
		eval ("\$search_threadbit .= \"".gettemplate("search_threadbit")."\";");
		
		}
		$db_zugriff->free_result($result);
		require("_board_jump.php");
		if($search_threadbit) eval("dooutput(\"".gettemplate("search_threads")."\");");
		else eval("dooutput(\"".gettemplate("search_no_result")."\");");
	}
}
?>
