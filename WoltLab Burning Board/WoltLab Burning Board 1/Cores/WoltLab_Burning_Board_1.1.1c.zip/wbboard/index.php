<?
header ("Location: main.php");
exit;
?>