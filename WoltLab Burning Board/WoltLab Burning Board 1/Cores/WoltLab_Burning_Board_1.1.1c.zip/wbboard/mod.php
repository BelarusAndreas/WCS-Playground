<? 
require("_functions.php");
require("_header.php");

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info[boardparentid]) { 
	echo $boardid."--".$thread_info[boardparentid];
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
	if($action == -1) {
		eval ("\$output = \"".gettemplate("error2")."\";");	
		eval("dooutput(\"".gettemplate("action_error")."\");");
	}
	
if($action == "polledit") {
		
	if($userdata[issupermod] || check_boardobject($boardid, $userid, "mod")) {
		$ptitle = prepare_topic($thread_info[pquestion]);
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid = '$threadid'");
		$j=0;
		while($row = $db_zugriff->fetch_array($result)) {
			$j++;
			$row[field] = prepare_topic($row[field]);
			eval ("\$fields .= \"".gettemplate("mod_pollbit")."\";");
		}
		eval("dooutput(\"".gettemplate("mod_polledit")."\");");	
	}
	else header("LOCATION: misc.php?action=access_error$session");	
}
	
if($action == "polledit_write") {
	if($userdata[issupermod] || check_boardobject($boardid, $userid, "mod")) {
		if($delete) {
			$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '', ptimeout = 0 WHERE threadid = '$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid = '$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid = '$threadid'");
			header("LOCATION: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;
		}
		elseif($ptitle && count($pfield)>=2) {
			$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '".trim($ptitle)."', ptimeout = '$ptimeout' WHERE threadid = '$threadid'");
			while(list($key,$val) = each($pfield)) $db_zugriff->query("UPDATE bb".$n."_poll SET field = '$val' WHERE id = '$key'");
			header("LOCATION: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;	
		}
		else {
			eval ("\$output = \"".gettemplate("error3")."\";");
			eval("dooutput(\"".gettemplate("action_error")."\");");
			exit;
		}	
	}
	else header("LOCATION: misc.php?action=access_error$session");	
} 
	
if($action == "close") {
	if(check_boardobject($boardid,$user_id,"mod") || $userdata[issupermod] || ($thread_info[authorid] && $thread_info[authorid]==$user_id && $userdata[cancloseowntopic])) {
		if($thread_info[flags]) {
			$db_zugriff->query("UPDATE bb".$n."_threads SET flags='0' WHERE threadid='$threadid'");		
			eval ("\$output = \"".gettemplate("mod_note9")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		else {
			$db_zugriff->query("UPDATE bb".$n."_threads SET flags='1' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note10")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		eval("dooutput(\"".gettemplate("action_ride")."\");");	
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}

if($action == "move") {
	if((check_boardobject($boardid,$user_id,"mod") && $userdata[ismod]) || $userdata[issupermod]) {
		if($send == "send") {
			if($copy) $db_zugriff->query("UPDATE bb".$n."_threads SET boardparentid='$newboardid', putoffid='$putoffid' WHERE threadid='$threadid'");		
			else $db_zugriff->query("UPDATE bb".$n."_threads SET boardparentid='$newboardid', putoffid='0' WHERE threadid='$threadid'");
			$db_zugriff->query("UPDATE bb".$n."_posts SET boardparentid='$newboardid' WHERE threadparentid='$threadid'");	
			
			$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$putoffid' ORDER BY posttime DESC LIMIT 1");
                	$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads-1, posts=posts-".($thread_info[replies]+1).", lastposttime = '$pinfo[posttime]', lastpostid = '$pinfo[postid]' WHERE boardid = '$putoffid'");
                	
                	$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$newboardid' ORDER BY posttime DESC LIMIT 1");
                	$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads+1, posts=posts+".($thread_info[replies]+1).", lastposttime = '$pinfo[posttime]', lastpostid = '$pinfo[postid]' WHERE boardid = '$newboardid'");
                
                        eval ("\$output = \"".gettemplate("mod_note11")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$newboardid&styleid=$styleid$session";
			eval("dooutput(\"".gettemplate("action_ride")."\");");
			exit;
		}
		$board_result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE boardid<>$boardid AND isboard = 1 ORDER BY boardname ASC");
		while($boards = $db_zugriff->fetch_array($board_result)) {
			$select .= "<option value=\"$boards[boardid]\">$boards[boardname]</option>";
		}
		$db_zugriff->free_result($board_result);
		eval("dooutput(\"".gettemplate("mod_move")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}
	
if($action == "del") {
	if((check_boardobject($boardid,$user_id,"mod") && $userdata[ismod]) || $userdata[issupermod] || ($thread_info[authorid] && $thread_info[authorid]==$user_id && $userdata[candelowntopic])) {
		if($send == "send") {
			$post_result = $db_zugriff->query("SELECT userid FROM bb".$n."_posts WHERE threadparentid='$threadid'");
			while($row = $db_zugriff->fetch_array($post_result)) {
				delUserposts($row[userid]);
			}
			$db_zugriff->query("DELETE FROM bb".$n."_threads WHERE threadid='$threadid'");
                	$db_zugriff->query("DELETE FROM bb".$n."_posts WHERE threadparentid='$threadid'");
                	$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid='$threadid'");
                	$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid='$threadid'");
                	$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid='$threadid'");
                	$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid='$threadid' AND favthreads = 1");
		
			$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$boardid' ORDER BY posttime DESC LIMIT 1");
                	$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads-1, posts=posts-".($thread_info[replies]+1).", lastposttime = '$pinfo[posttime]', lastpostid = '$pinfo[postid]' WHERE boardid = '$boardid'");
                
                	eval ("\$output = \"".gettemplate("mod_note12")."\";");
			$ride = "board.php?boardid=$boardid&styleid=$styleid$session";
			eval("dooutput(\"".gettemplate("action_ride")."\");");
		}
		else eval("dooutput(\"".gettemplate("mod_del")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}

if($action == "top") {
	if($userdata[issupermod] || ($userdata[ismod] && check_boardobject($boardid,$user_id,"mod"))) {
		if($thread_info[important]) {
			$db_zugriff->query("UPDATE bb".$n."_threads SET important='0' WHERE threadid='$threadid'");		
			eval ("\$output = \"".gettemplate("mod_note14")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		else {
			$db_zugriff->query("UPDATE bb".$n."_threads SET important='1' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note13")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		eval("dooutput(\"".gettemplate("action_ride")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}

if($action == "threadedit") {
	if($userdata[issupermod] || ($userdata[ismod] && check_boardobject($boardid,$user_id,"mod"))) {
		if($send == "send" && $subject = trim($subject)) {
			$db_zugriff->query("UPDATE bb".$n."_threads SET threadname = '".editPostdata($subject)."', topicicon = '$posticon' WHERE threadid = '$threadid'");
			header("Location: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;
		}
		$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
		$subject = prepare_topic($thread_info[threadname]);
		
		include("templates/posticons.php");
		for($i = 0; $i < count($posticons); $i++) {
			if(is_int($i/6) && $i) $choice_posticons .= "<br>";
			elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
			$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
			if($thread_info[topicicon] == $posticons[$i]) $choice_posticons .= " CHECKED";
			$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
		}
		if(!$thread_info[topicicon]) $noicon[0] = "CHECKED"; 
		
		eval("dooutput(\"".gettemplate("mod_threadedit")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}
?>
