<?

$header = "<html>
<head>
<title>Woltlab Burning Board Update</title>
		<STYLE TYPE=\"TEXT/CSS\">
			BODY { SCROLLBAR-BASE-COLOR: #646464; SCROLLBAR-ARROW-COLOR: #FEC254; } 
			SELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } 
			TEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } 
			#bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; } #bg A:hover { COLOR: #000000; TEXT-DECORATION: none; } 
			#cat A:link, #cat A:visited, #cat A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #cat A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; } 
			#title A:link, #title A:visited, #title A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #title A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; }  
		</STYLE>
	
</head>

<body bgcolor=\"#808080\" text=\"#000000\" bgproperties=fixed id=\"bg\">
<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=2 color=\"#000000\">";


# - functions -
require "_data.inc.php";
require "class_db_zugriff.php";

$db_zugriff = new db_zugriff;

$db_zugriff->appname="WoltLab Burning Board";
$db_zugriff->database=$mysqldb;
$db_zugriff->server=$mysqlhost;
$db_zugriff->user=$mysqluser;
$db_zugriff->password=$mysqlpassword;

$db_zugriff->connect();

function gettemplate($template) {
        $file = file("templates/".$template.".htm");
        $template = implode("",$file);
        $template = str_replace("\"","\\\"",$template);
        return $template;
}

function dooutput($template) {
        echo $template;
}

# - steps -
if(!$step) {
echo $header;
?>
<p>
<font site=3><b>Willkommen bei dem Update von WoltLab Burning Board 1.0 Beta 4.5 auf 1.1.0!</b></font> 
</p>
<p>
<a href="update.php?step=1">Klicken Sie hier, um mit dem Update zu beginnen!</a> 
</p>
<?
}

if($step==1) {
	$db_zugriff->query("ALTER TABLE bb".$n."_config ADD forumid varchar(32) NOT NULL");
	$db_zugriff->query("ALTER TABLE bb".$n."_threads ADD lastposterid int(11) NOT NULL DEFAULT '-1' AFTER authorid");
	$db_zugriff->query("ALTER TABLE bb".$n."_threads ADD author varchar(30) NOT NULL AFTER authorid");
	$db_zugriff->query("UPDATE bb".$n."_config SET forumid = '".md5(uniqid(microtime()))."'");
	
	echo $header;
	?>
		<p>
		<b>Tabellen wurden erfolgreich ver�ndert.</b> 
		</p>
		<p>
		<a href="update.php?step=2">Klicken Sie hier, um mit dem Update fortzufahren!</a> 
		</p>
	<?
	
}

if($step==10) {
 $db_zugriff->query("UPDATE bb".$n."_threads SET lastposterid = '-1'");
 header("Location: update.php?step=2");
}

if($step==2) {
	$result = $db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE lastposterid = '-1' LIMIT 100");
	if($db_zugriff->num_rows()) {
	 while($row=$db_zugriff->fetch_array($result)) {
	  $dump = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE threadparentid = '$row[threadid]' ORDER BY posttime DESC LIMIT 1");
	  $db_zugriff->query("UPDATE bb".$n."_threads SET lastposterid = '$dump[userid]' WHERE threadid = '$row[threadid]'");
	 }
	 header("Location: update.php?step=2");
	}
	else {
	$db_zugriff->query("ALTER TABLE bb".$n."_threads CHANGE lastposterid lastposterid INT (11) DEFAULT '0' not null ");
	echo $header;
	?>
		<p>
		<b>"Letzter Beitrag" Konvertierung erfolgreich beendet.</b> 
		</p>
		<p>
		<a href="update.php?step=3">Klicken Sie hier, um mit dem Update fortzufahren!</a> 
		</p>
	<?
	}
}

if($step==3) {
	$result = $db_zugriff->query("SELECT username, userid FROM bb".$n."_user_table WHERE username LIKE '%<%' OR username LIKE '%>%' OR username LIKE '%\"%' OR username LIKE '%&%'");
	while($row=$db_zugriff->fetch_array($result)) {
	 $db_zugriff->query("UPDATE bb".$n."_user_table SET username = '".htmlspecialchars($row[username])."' WHERE userid = '$row[userid]'");
	} 
	echo $header;
	?>
		<p>
		<b>"Benutzernamen" Konvertierung erfolgreich beendet.</b> 
		</p>
		<p>
		<a href="update.php?step=4">Klicken Sie hier, um mit dem Update fortzufahren!</a> 
		</p>
	<?
	
}

if($step==4) {
	$result = $db_zugriff->query("SELECT authorid FROM bb".$n."_threads WHERE authorid > 0 AND author = '' LIMIT 100");
	if($db_zugriff->num_rows()) {
	 while($row=$db_zugriff->fetch_array($result)) $authorids.=",".$row[authorid];
	 $db_zugriff->free_result($result);
	 $result = $db_zugriff->query("SELECT username, userid FROM bb".$n."_user_table WHERE userid IN (0$authorids)");
	 while($row=$db_zugriff->fetch_array($result)) $db_zugriff->query("UPDATE bb".$n."_threads SET author = '$row[username]' WHERE authorid='$row[userid]'");
	 
	 header("Location: update.php?step=4");
	}
	else {
	echo $header;
	?>
		<p>
		<b>Update erfolgreich abgeschlossen.</b> 
		</p>
		<p>
		<b>L�schen Sie die update.php!</b> 
		</p>
		<p>
		<b>enjoy Burning Board 1.1.0</b> 
		</p>
	<?
	}
}
?>
</font></body>
</html>