<?
require("_functions.php");
require("_header.php");

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info[boardparentid]) { 
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}

if((($thread_info[authorid] && $thread_info[authorid] != $user_id && $userdata[canreplytopic]) || ($thread_info[authorid] && $thread_info[authorid] == $user_id && $userdata[canreplyowntopic]) || (!$thread_info[authorid] && $userdata[canreplytopic])) && check_boardobject($boardid,$user_group,"replypermission")) {

	if($action == "send" && !$preview) {
		if($message && !check_posts($message)) {
			if($user_id && !$userdata[avoidfc] && floodcontrol($user_id)) {
				require("_board_jump.php");
				eval("dooutput(\"".gettemplate("floodcontrol")."\");");
				exit;
			}	
			$result = newPost($boardid,$threadid,$user_id,$subject,$message,$posticon,$parseurl,$email,$disablesmilies,$signature,$close);
                        if($result==2) {
                                eval ("\$output = \"".gettemplate("note4")."\";");
                                $ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid";
                        }
                        if($result==4) {
                                $ride = getLastPost($user_id,4);
                                header("Location: $ride");
				exit;
                        }
                        eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
			eval("dooutput(\"".gettemplate("action_ride")."\");");
			exit;
		}
		else eval ("\$error = \"".gettemplate("newthread_error")."\";");
	}
	
	if($ch_parseurl) $checked[0] = "CHECKED";
	if($ch_email) $checked[1] = "CHECKED";
	if($ch_disablesmilies) $checked[2] = "CHECKED";
	if($ch_signature) $checked[3] = "CHECKED";
	
	if($action == "send") {
	 $subject=stripslashes($subject);	
	 $message=stripslashes($message);	
	}
				
	if($preview) {
		$subject = prepare_topic($subject);
                $user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE username='$user_name'");
                if($user_info[signatur] && $signature && !$hide_signature) {
                       	$signatur = editSignatur($user_info[signatur],$disablesmilies);
			eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
		}
                if($posticon) $pre_posticon = "<img src=\"".$posticon."\">";
                else $pre_posticon = "&nbsp;";
                $post = editPost($message,$disablesmilies);
                $message = stripslashes($message);             
                eval ("\$preview = \"".gettemplate("preview")."\";");
                        
                if($parseurl) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if($email) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if($disablesmilies) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if($signature) $checked[3] = "CHECKED";
		else $checked[3] = "";
		if($close) $checked[4] = "CHECKED";
		else $checked[4] = "";
        }
        else $subject=htmlspecialchars($subject);
	
	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);
	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

	include("templates/posticons.php");
	for($i = 0; $i < count($posticons); $i++) {
		if(is_int($i/6) && $i) $choice_posticons .= "<br>";
		elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
		$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
		if($posticon == $posticons[$i]) $choice_posticons .= " CHECKED";
		$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
	}
	if(!$posticon) $noicon[0] = "CHECKED"; 
		
	$navi_chain = makenavichain("reply",$boardid,$threadid);
	if($mode=="quote" && !$preview) {
		$message = $db_zugriff->query_first("SELECT threadparentid, userid, message FROM bb".$n."_posts WHERE postid='$postid'");
		if($message[threadparentid]==$threadid) {
			if($message[userid]) $username = getUsername($message[userid]);
			else eval ("\$username = \"".gettemplate("lg_anonymous")."\";");
			$quote = prepare_quote($message[message]);
			eval ("\$message = \"".gettemplate("reply_quote")."\";");
		}
	}

	if($thread_info[replies]+1 <= $eproseite) {
        	$post_result = $db_zugriff->query("SELECT bb".$n."_posts.*, bb".$n."_user_table.username FROM bb".$n."_posts LEFT JOIN bb".$n."_user_table USING (userid) WHERE threadparentid='$threadid' ORDER by posttime DESC LIMIT 0,".($eproseite));
        	while($posts = $db_zugriff->fetch_array($post_result)) {
        	       	unset($posttopic);
                	if($posts[userid]) $authorname = $posts[username];
                	else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
                	if($posts[posticon]) $posticon = "<img src=\"".$posts[posticon]."\">";
                	else $posticon = "&nbsp;";
                	$posttopic = prepare_topic($posts[posttopic]);
                	$post = editPost($posts[message],$posts[disable_smilies]);
               		$backcolor = rowcolor($j);
                	eval ("\$reply_threadview .= \"".gettemplate("reply_threadview")."\";");
                	$j++;
        	}
	} 
	else eval ("\$reply_threadview = \"".gettemplate("reply_to_many_posts")."\";");
	
	if(($thread_info[authorid] && $thread_info[authorid] == $user_id && $userdata[cancloseowntopic]) || ($userdata[ismod] && check_boardobject($boardid,$user_id,"mod"))|| $userdata[issupermod]) eval ("\$quick_close = \"".gettemplate("reply_quick_close")."\";");

	if($userid) eval ("\$quick_logout .= \"".gettemplate("newthread_logout")."\";");
	$message=htmlspecialchars($message);
	eval("dooutput(\"".gettemplate("reply")."\");");
}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>