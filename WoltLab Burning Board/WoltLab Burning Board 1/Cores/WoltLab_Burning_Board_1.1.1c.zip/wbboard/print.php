<? 
require("_functions.php");

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info[boardparentid]) { 
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
if($imageurl) $imageurl = "<img src=\"$imageurl\">";

$anzahl = $thread_info[replies]+1;
if(!$page) $page=1;
$post_result = $db_zugriff->query("SELECT bb".$n."_posts.*, bb".$n."_user_table.* FROM bb".$n."_posts LEFT JOIN bb".$n."_user_table USING (userid) WHERE bb".$n."_posts.threadparentid='$threadid' ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC")." LIMIT ".($eproseite*($page-1)).",".($eproseite));
$pages=ceil($anzahl/$eproseite);

while($posts = $db_zugriff->fetch_array($post_result)){
		
	unset($signature);
	if($posts[posticon]) $posticon = "<img src=\"".$posts[posticon]."\">";
	else $posticon = "&nbsp;";
	if($posts[posttopic]) $posttopic = prepare_topic($posts[posttopic]);
	else $posttopic = "";
	$post = editPost($posts[message],$posts[disable_smilies]);
	if($posts[signatur] && $posts[signature] && !$hide_signature) {
		$signatur = editSignatur($posts[signatur],$posts[disable_smilies]);
		eval ("\$signature = \"".gettemplate("thread_signature")."\";");
	}
	$posttime = formatdate($posts[posttime],$longdateformat);
		
	eval ("\$print_postbit .= \"".gettemplate("print_postbit")."\";");
}
$db_zugriff->free_result($post_result);

if($imageurl) $image = "<img src=\"$imageurl\">";						
$threadname = getThreadname($threadid);
$boardname = getBoardname($boardid);

eval("dooutput(\"".gettemplate("print")."\");");
?>
			
					