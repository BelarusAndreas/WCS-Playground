<? 
require("_functions.php");
require("_header.php");
require("_board_jump.php");

if($mode == "view") {
	$uproseite = 30;
	$anzahl = $db_zugriff->query_first("SELECT COUNT(userid)as anzahl FROM bb".$n."_user_table WHERE activation='1'");
	$anzahl = $anzahl[anzahl];
	$page=intval($page);
	if(!$page) $page=1;
	
switch($by) {
 case "username"; break;
 case "regdate": break;	
 default: $by = "userposts"; break; 	
}

switch($order) {
 case "ASC"; break;
 default: $order = "DESC"; break; 	
}
	
	
	$user_result = $db_zugriff->query("SELECT * FROM bb".$n."_user_table WHERE activation='1' ORDER by $by $order LIMIT ".($uproseite*($page-1)).",".$uproseite);
	$pages=ceil($anzahl/$uproseite);
	
	while($users = $db_zugriff->fetch_array($user_result)) {	
		if($users[users_may_email]) eval ("\$email = \"".gettemplate("members_view_email")."\";");
		else $email = "&nbsp;";
				
		if($users[userhp]) {
		 $users[userhp]=htmlspecialchars($users[userhp]);
		 eval ("\$userhp = \"".gettemplate("members_view_hp")."\";");
		}
		else $userhp = "&nbsp;";
		
		if($users[usericq]) {
		 $users[usericq]=htmlspecialchars($users[usericq]);
		 eval ("\$icq = \"".gettemplate("members_view_icq")."\";");
		}
		else $icq = "&nbsp;";
		
		if($users[aim]) {
		 $users[aim]=htmlspecialchars($users[aim]);
		 eval ("\$aim = \"".gettemplate("members_view_aim")."\";");
		}
		else $aim = "&nbsp;";
		
		if($users[yim]) {
		 $users[yim]=htmlspecialchars($users[yim]);
		 eval ("\$yim = \"".gettemplate("members_view_yim")."\";");
		}
		else $yim = "&nbsp;";
		
		$regdate = formatdate($users[regdate],$shortdateformat);
		eval ("\$members_view_memberbit .= \"".gettemplate("members_view_memberbit")."\";");
	}						

	if($pages>1) $page_link = makepagelink("members.php?mode=view&boardid=$boardid&styleid=$styleid&by=$by&order=$order$session", $page, $pages);
	eval("dooutput(\"".gettemplate("members_view")."\");");
}
if($mode=="profile") {
	$user_info = $db_zugriff->query_first("SELECT users.*, avatars.extension FROM bb".$n."_user_table users LEFT JOIN bb".$n."_avatars avatars ON (avatars.id=users.avatarid) WHERE users.userid='$userid'");
	$posts[username] = $user_info[username];
	$regdate = formatdate($user_info[regdate],$shortdateformat);
	$posts[userid] = $user_info[userid];
	
	$dabeiseit = (time() - $user_info[regdate]) / 86400;
	if ($dabeiseit < 1) $beitragprotag = "$user_info[userposts]";
	else $beitragprotag = sprintf("%.2f",($user_info[userposts] / $dabeiseit)); 
	
	if($user_info[usertext]) $user_text = prepare_topic($user_info[usertext]);
	if($user_info[gender]) {
		if($user_info[gender]==1) eval ("\$gender = \"".gettemplate("profile_male")."\";");
		else eval ("\$gender  = \"".gettemplate("profile_female")."\";");
	}
	else eval ("\$gender = \"".gettemplate("profile_nodeclaration")."\";");
		
	$rank = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE groupid = '$user_info[groupid]' AND posts<='$user_info[userposts]' ORDER by posts DESC");
        for($i = 0; $i<$rank[mal]; $i++) $stars .= "<img src=\"$rank[grafik]\" border=\"0\">";
        $stars = "<a href=\"javascript:rank($rank[id])\" title=\"Informationen zum Rang $rank[rank]\">".$stars."</a>";
	
	if($user_info[statusextra]) $user_rang = editDBdata($user_info[statusextra]);
	else $user_rang = editDBdata($rank[rank]);
	if($user_info[avatarid] && !$hide_userpic && $avatars) $userpic = "<br><img src=\"images/avatars/avatar-$user_info[avatarid].$user_info[extension]\" border=0>";
	
	if($user_info[show_email_global]) $useremail = "<a href=\"mailto:".editDBdata($user_info[useremail])."\" class=\"link\">".editDBdata($user_info[useremail])."</a>";
	else eval ("\$useremail = \"".gettemplate("profile_nodeclaration")."\";"); 
	
	if($user_info[users_may_email]) eval ("\$email = \"".gettemplate("thread_email")."\";"); 
	if($pms) eval ("\$pn = \"".gettemplate("thread_pm")."\";"); 
	
	if($user_info[userhp]) $userhp = "<a class=\"link\" href=\"".htmlspecialchars(editDBdata($user_info[userhp]))."\" target=\"_blank\">".htmlspecialchars(editDBdata($user_info[userhp]))."</a>";
	else eval ("\$userhp = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[usericq]) $usericq = htmlspecialchars(editDBdata($user_info[usericq]));
	else eval ("\$usericq = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[aim]) $aim = htmlspecialchars(editDBdata($user_info[aim]));
	else eval ("\$aim = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[yim]) $yim = htmlspecialchars(editDBdata($user_info[yim]));
	else eval ("\$yim = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[location]) $location = htmlspecialchars(editDBdata($user_info[location]));
	else  eval ("\$location = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[work]) $work = htmlspecialchars(editDBdata($user_info[work]));
	else  eval ("\$work = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[interests]) $interests = htmlspecialchars(editDBdata($user_info[interests]));
	else  eval ("\$interests = \"".gettemplate("profile_nodeclaration")."\";");
	
	if($user_info[age_m] && $user_info[age_d] && $user_info[age_y]) $birthday = $user_info[age_d].". ".$user_info[age_m]." ".$user_info[age_y];
	else eval ("\$birthday = \"".gettemplate("profile_nodeclaration")."\";");
	eval("dooutput(\"".gettemplate("members_profile")."\");");
}
?>
			
					