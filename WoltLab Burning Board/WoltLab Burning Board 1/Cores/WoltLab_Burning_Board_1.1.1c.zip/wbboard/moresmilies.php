<?
require("_functions.php");
eval ("\$headinclude = \"".gettemplate("headinclude")."\";");

$rightorleft = "left";
$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies");
while($row = $db_zugriff->fetch_array($result)) {
	if ($rightorleft == "left") {
		if (($j++ % 2) != 0) $backcolor="tableb";
		else $backcolor="tablec";
		eval ("\$popup_smiliesbits .= \"<tr>".gettemplate("popup_smiliesbits")."\";");
		$rightorleft = "right";
	}
	else {
		eval ("\$popup_smiliesbits .= \"".gettemplate("popup_smiliesbits")."</tr>\";");
		$rightorleft = "left";
	}
}

eval("dooutput(\"".gettemplate("popup_smilies")."\");");

?>