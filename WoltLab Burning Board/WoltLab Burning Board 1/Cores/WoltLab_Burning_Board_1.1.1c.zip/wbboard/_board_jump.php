<? 

if($user_id) {
	eval ("\$profile_link = \"".gettemplate("board_jump_profile")."\";");
	if($pms && $userdata[canusepms]) eval ("\$pm_link = \"".gettemplate("board_jump_pm")."\";");
}

function makeboardjumpbit2($bid,$depth=1) {
	global $boardcache, $boardid, $permissioncache;

	if(!isset($boardcache[$bid])) {
		return;
 	}

  	while (list($key1,$val1) = each($boardcache[$bid])) {
    		while(list($key2,$boards) = each($val1)) {
			if($boards[invisible] && !$permissioncache[$boards[boardid]]) continue;
			$out .= "<OPTION value=\"".$boards[boardid]."\"";
			if($boardid == $boards[boardid]) $out .= " selected";
			if($depth>1) $out .= ">".str_repeat("--",$depth-1)." ".editDBdata($boards[boardname])."</option>";
			else $out .= ">".editDBdata($boards[boardname])."</option>";
			$out.=makeboardjumpbit2($boards[boardid],$depth+1);
     		} 
  	} 
  	unset($boardcache[$bid]);
  	return $out;
}
$result = $db_zugriff->query("SELECT * FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row[boardparentid]][$row[sort]][$row[boardid]] = $row;
$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row[boardid]] = 1;
$board_links = makeboardjumpbit2(0);
$db_zugriff->free_result($result);
eval ("\$board_jump = \"".gettemplate("board_jump")."\";");
?>
