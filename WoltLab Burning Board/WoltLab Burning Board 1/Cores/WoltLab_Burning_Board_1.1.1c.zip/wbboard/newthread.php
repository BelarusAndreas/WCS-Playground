<? 
require("_functions.php");
require("_header.php");
				
if($userdata[canstarttopic] && check_boardobject($boardid,$user_group,"startpermission")) {
	if($action == "send" && !$preview && !$post_poll) {
		if(!$subject || !$message  || $p_fields != count($pfield) || ($p_fields && !$ptitle) || check_posts($message)) {
			if($p_fields) {
				$post_poll = 1;
				$poll_fields = $p_fields;
			}
			eval ("\$error = \"".gettemplate("newthread_error")."\";");
		}
		else {
			if($user_id && !$userdata[avoidfc] && floodcontrol($user_id)) {
				require("_board_jump.php");
				eval("dooutput(\"".gettemplate("floodcontrol")."\");");
				exit;
			}
			
			$time = time();
        		$subject = editPostdata($subject);
        		$message = editPostdata($message);
        		if($parseurl) $message = parseURL($message);

        		if($disablesmilies!=1) $disablesmilies=0;
        		if($signature!=1) $signature=0;
            		$db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts+1 WHERE userid='$user_id'");
            		
            		$db_zugriff->query("INSERT INTO bb".$n."_threads (boardparentid,threadname,starttime,authorid,author,lastposterid,timelastreply,topicicon) VALUES ('$boardid','$subject','$time','$user_id','$user_name','$user_id','$time','$posticon')");
        		$nr = $db_zugriff->insert_id();
        		if($email && $user_id) $db_zugriff->query("INSERT INTO bb".$n."_notify VALUES ($nr,$user_id)");
        		$db_zugriff->query("INSERT INTO bb".$n."_posts (boardparentid,threadparentid,userid,posttime,posttopic,message,posticon,disable_smilies,signature,ip) VALUES ('$boardid','$nr','$user_id','$time','$subject','$message','$posticon','$disablesmilies','$signature','".getenv("REMOTE_ADDR")."')");
			$postid = $db_zugriff->insert_id();
			$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads+1, posts=posts+1, lastposttime = '$time', lastpostid = '$postid' WHERE boardid = '$boardid'");	
						
			if($p_fields) {
				$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '".editPostdata($ptitle)."', ptimeout = '".(int)($poll_timeout)."' WHERE threadid = '$nr'");
				for($i = 0; $i < $p_fields; $i++) $db_zugriff->query("INSERT INTO bb".$n."_poll VALUES ('','$nr','".editPostdata($pfield[$i])."','0')");
			}
		
			$ride = getLastPost($user_id,4);
                	header("Location: $ride");
			exit; 
		}
	}	
	if($ch_parseurl) $checked[0] = "CHECKED";
	if($ch_email) $checked[1] = "CHECKED";
	if($ch_disablesmilies) $checked[2] = "CHECKED";
	if($ch_signature) $checked[3] = "CHECKED";
				
	if($post_poll) {
		$subject = prepare_topic($subject);
		$message = stripslashes($message);     
		
		if($parseurl) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if($email) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if($disablesmilies) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if($signature) $checked[3] = "CHECKED";
		else $checked[3] = "";
			
		for($i = 0; $i < $poll_fields; $i++) {
			$j = $i+1;
			$wert = prepare_topic($pfield[$i]);
			eval ("\$fields .= \"".gettemplate("newthread_pollbit")."\";");
		}
		eval ("\$poll .= \"".gettemplate("newthread_poll")."\";");
	}
	
	if($action == "send") {
	 $subject=stripslashes($subject);	
	 $message=stripslashes($message);	
	}
			
	if($preview) {
		$subject = prepare_topic($subject);
                $user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE username='$user_name'");
                if($user_info[signatur] && $signature && !$hide_signature) {
                      	$signatur = editPost($user_info[signatur],$disablesmilies);
			eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
		}
                if($posticon) $pre_posticon = "<img src=\"".$posticon."\">";
                else $pre_posticon = "&nbsp;";
                $post = editPost($message,$disablesmilies);
                $message = stripslashes($message);             
                eval ("\$preview = \"".gettemplate("preview")."\";");
                        
                if($parseurl) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if($email) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if($disablesmilies) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if($signature) $checked[3] = "CHECKED";
		else $checked[3] = "";
			
		if($p_fields) {
			$ptitle = prepare_topic($ptitle);
			for($i = 0; $i < $p_fields; $i++) {
				$j = $i+1;
				$wert = prepare_topic($pfield[$i]);
				eval ("\$fields .= \"".gettemplate("newthread_pollbit")."\";");
			}
			$poll_fields = $p_fields;	
			eval ("\$poll = \"".gettemplate("newthread_poll")."\";");
			eval ("\$poll_check = \"".gettemplate("newthread_pollcheck")."\";");
			$post_poll = 1;
		}
	}
	else $subject=htmlspecialchars($subject);
		
	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);

	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");
		
	include("templates/posticons.php");
	for($i = 0; $i < count($posticons); $i++) {
		if(is_int($i/6) && $i) $choice_posticons .= "<br>";
		elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
		$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
		if($posticon == $posticons[$i]) $choice_posticons .= " CHECKED";
		$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
	}
	if(!$posticon) $noicon[0] = "CHECKED"; 
		
	$navi_chain = makenavichain("newthread",$boardid);
	if(!$post_poll && $polls && $userdata[canpostpoll]) eval ("\$poll .= \"".gettemplate("newthread_startpoll")."\";");
	
	if($userid) eval ("\$quick_logout .= \"".gettemplate("newthread_logout")."\";");
	$message=htmlspecialchars($message);
	eval("dooutput(\"".gettemplate("newthread")."\");");
	
}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>
