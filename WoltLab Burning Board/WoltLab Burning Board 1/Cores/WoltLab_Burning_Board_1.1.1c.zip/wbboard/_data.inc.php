<?
// Hostname oder IP des MySQL-Servers
$mysqlhost = "localhost";
// Username und Passwort zum einloggen in den Datenbankserver
$mysqluser = "root";
$mysqlpassword = "";
// Name der Datenbank
$mysqldb = "";
// Nummer des Boards
$n = "1";
// Email des Admins
$adminmail = "";
?>