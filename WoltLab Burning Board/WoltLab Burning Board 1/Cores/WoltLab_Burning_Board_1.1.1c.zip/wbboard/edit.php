<? 
require("_functions.php");
require("_header.php");
require("_board_jump.php");

$post = $db_zugriff->query_first("SELECT boardparentid, threadparentid, userid, message, disable_smilies FROM bb".$n."_posts WHERE postid='$postid'");

if($boardid != $post[boardparentid] || $threadid != $post[threadparentid]) { 
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
if(($userdata[ismod] && check_boardobject($boardid,$user_id,"mod")) || $userdata[issupermod] || ($post[userid] && $userdata[caneditownpost] && $user_id == $post[userid])) {
	
	if($action == "send" && !$preview) {
		if(!$delete && (!$message || check_posts($message))) eval ("\$error = \"".gettemplate("newthread_error")."\";");
		else {
			if($delete && (($userdata[ismod] && check_boardobject($boardid,$user_id,"mod")) || $userdata[issupermod] || ($post[userid] && $userdata[candelownpost] && $user_id == $post[userid]))) {
                		$result = delPost($postid,$threadid,$boardid);
                		if($result==1) {
                       			eval ("\$output = \"".gettemplate("note15")."\";");
                        		$ride = "thread.php?boardid=$boardid&styleid=$styleid&threadid=$threadid$session";
                		}
                		if($result==2) {
                        		eval ("\$output = \"".gettemplate("note16")."\";");
                       			$ride = "board.php?boardid=$boardid&styleid=$styleid$session";
                		}
        		}
        		else {
                		$thread_info = $db_zugriff->query_first("SELECT flags FROM bb".$n."_threads WHERE threadid='$threadid'");
        			if($thread_info[flags]) eval ("\$output = \"".gettemplate("note17")."\";");
                		else {
                        		if($appendnote) {
                        			$time = time();
                        			$editorid = $user_id;
                        		}
                        		$message = editPostdata($message);
                                	if($parseurl) $message = parseURL($message);
                                	$db_zugriff->query("UPDATE bb".$n."_posts SET edittime='$time', editorid = '$editorid', message='$message', disable_smilies='$disablesmilies' WHERE postid='$postid'");
                        		if($appendnote) $db_zugriff->query("UPDATE bb".$n."_threads SET timelastreply='$time' WHERE threadid='$threadid'");
                        		eval ("\$output = \"".gettemplate("note8")."\";");
                        	}
                	}
        		
        		if(!$ride) {
        		
                		$post_result = $db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE threadparentid='$post[threadparentid]' ORDER by posttime ".ifelse($postorder,"DESC","ASC"));
                		$i=1;
                		while($row = $db_zugriff->fetch_array($post_result)) {
                			if($postid == $row[postid]) break;
                			$i++;
                		}
                		$db_zugriff->free_result($post_result);
                		$pages=(int)($i/$eproseite);
                		if(($i/$eproseite)-$pages>0) $pages++;

                		$ride = "thread.php?threadid=$post[threadparentid]&boardid=$post[boardparentid]&styleid=$styleid$session&page=".$pages."#".$i;
               		}
        		
        		header("Location: $ride");
			exit;
		}
	}

	if($preview || $error) {
		if($user_id) {
			$user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE userid='$user_id'");
                	if($user_info[signatur] && $signature && !$hide_signature) {
                      		$signatur = editSignatur($user_info[signatur],$disablesmilies);
				eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
			}
		}
                if($posticon) $pre_posticon = "<img src=\"".$posticon."\">";
                else $pre_posticon = "&nbsp;";
                $post = editPost($message,$disablesmilies);
                if($preview) eval ("\$preview = \"".gettemplate("preview")."\";");
                        
                if($parseurl) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if($disablesmilies) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if($delete) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if($appendnote) $checked[3] = "CHECKED";
		else $checked[3] = "";
	}
	else {
		if($ch_parseurl) $checked[0] = "CHECKED";
		if($post[disable_smilies]) $checked[1] = "CHECKED"; 
	}
	
	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);

	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

	$navi_chain = makenavichain("edit",$boardid,$threadid);
	if(!$preview) $edit = editDBdata($post[message]);
	else $edit = stripslashes($message);
	
	if(($userdata[ismod] && check_boardobject($boardid,$user_id,"mod")) || $userdata[issupermod] || ($post[userid] && $userdata[candelownpost] && $user_id == $post[userid])) eval ("\$edit_del = \"".gettemplate("edit_del")."\";");
	if(!$userdata[appendeditnote]) eval ("\$edit_appendnote = \"".gettemplate("edit_appendnote")."\";");
	else $edit_appendnote = "<input type=\"hidden\" value=\"1\" name=\"appendnote\">";
	$edit=htmlspecialchars($edit);
	eval("dooutput(\"".gettemplate("edit")."\");");
}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>
