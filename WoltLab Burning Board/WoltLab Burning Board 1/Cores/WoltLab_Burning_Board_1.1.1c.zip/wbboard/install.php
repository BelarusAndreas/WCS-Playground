<?

$header = "<html>
<head>
<title>Woltlab Burning Board Installation</title>
		<STYLE TYPE=\"TEXT/CSS\">
			BODY { SCROLLBAR-BASE-COLOR: #646464; SCROLLBAR-ARROW-COLOR: #FEC254; } 
			SELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } 
			TEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } 
			#bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; } #bg A:hover { COLOR: #000000; TEXT-DECORATION: none; } 
			#cat A:link, #cat A:visited, #cat A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #cat A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; } 
			#title A:link, #title A:visited, #title A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #title A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; }  
		</STYLE>
	
</head>

<body bgcolor=\"#808080\" text=\"#000000\" bgproperties=fixed id=\"bg\">
<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=2 color=\"#000000\">";


# - functions -
require "_data.inc.php";
require "class_db_zugriff.php";

$tables = array(
"bb".$n."_announcements",
"bb".$n."_avatars",
"bb".$n."_bbcode",
"bb".$n."_boards",
"bb".$n."_config",
"bb".$n."_folders",
"bb".$n."_groups",
"bb".$n."_notify",
"bb".$n."_object2board",
"bb".$n."_object2user",
"bb".$n."_pms",
"bb".$n."_pmsend",
"bb".$n."_poll",
"bb".$n."_posts",
"bb".$n."_ranks",
"bb".$n."_smilies",
"bb".$n."_style",
"bb".$n."_threads",
"bb".$n."_user_table",
"bb".$n."_useronline",
"bb".$n."_vote"
); 

$db_zugriff = new db_zugriff;

$db_zugriff->appname="WoltLab Burning Board";
$db_zugriff->database=$mysqldb;
$db_zugriff->server=$mysqlhost;
$db_zugriff->user=$mysqluser;
$db_zugriff->password=$mysqlpassword;

$db_zugriff->connect();

function gettemplate($template) {
        $file = file("templates/".$template.".htm");
        $template = implode("",$file);
        $template = str_replace("\"","\\\"",$template);
        return $template;
}

function dooutput($template) {
        echo $template;
}

# - steps -
if(!$step) {
echo $header;
?>
<p>
<font site=3><b>Willkommen bei der WoltLab Burning Board 1.1.1 Installation!</b></font> 
</p>
<p>
<a href="install.php?step=1">Klicken Sie hier, um mit der Installation zu beginnen!</a> 
</p>
<?
}

if($step==1) {
	$result = mysql_list_tables($mysqldb); 
	if(!$db_zugriff->num_rows($result)) header("Location: install.php?step=4");
	else { 
	echo $header;
	?>
		<p>
		<b>Die Datenbank <? echo "$mysqldb"; ?> ist nicht leer!</b> 
		</p>
		<p>
		<a href="install.php?step=3">Klicken Sie hier, um mit der Installation zu fortzufahren!</a> 
		</p>
		<p>
		<a href="install.php?step=2">Klicken Sie hier, um die Datenbank zu leeren!</a> (<b>Achtung: Dabei werden s�mtliche Inhalte der Datenbank gel�scht!</b>)
		</p>
	<?
	}
}

if($step==2) {
	$result = mysql_list_tables ($mysqldb);
	for($i = 0; $i < mysql_num_rows ($result); $i++) $db_zugriff->query("DROP TABLE ".mysql_tablename($result, $i));
	echo $header;
	?>
		<p>
		<b>Datenbank <? echo "$mysqldb"; ?> wurde erfolgreich geleert!</b> 
		</p>
		<p>
		<a href="install.php?step=4">Klicken Sie hier, um mit der Installation fortzufahren!</a> 
		</p>
	<?
}

if($step==3) {
	$result = mysql_list_tables ($mysqldb);
	for($i = 0; $i < mysql_num_rows ($result); $i++) {
		if(in_array(mysql_tablename($result, $i),$tables)) {
			$check = 1;
			break;
		}
	}
	if(!$check) header("Location: install.php?step=4");
	else {
	echo $header;
	?>
		<p>
		<b>Es gibt bereits Tabellen in der Datenbank mit dem selben Namen wie Tabellen die diese Installation erstellen will! Diese Tabelle werden beim fortfahren �berschrieben!</b> 
		</p>
		<p>
		<a href="install.php?step=4">Klicken Sie hier, um mit der Installation fortzufahren!</a> 
		</p>
	<?
	}
}

if($step==4) {
	$result = mysql_list_tables ($mysqldb);
	for($i = 0; $i < mysql_num_rows ($result); $i++) if(in_array(mysql_tablename($result, $i),$tables)) $db_zugriff->query("DROP TABLE ".mysql_tablename($result, $i));
	echo $header;
	echo "<p>\n";
	$db_zugriff->query("CREATE TABLE bb".$n."_announcements (
   	announcementid int(11) NOT NULL auto_increment,
   	boardid int(11) DEFAULT '0' NOT NULL,
   	userid int(11) DEFAULT '0' NOT NULL,
   	starttime int(11) DEFAULT '0' NOT NULL,
   	endtime int(11) DEFAULT '0' NOT NULL,
   	topic varchar(70) NOT NULL,
   	message text NOT NULL,
   	PRIMARY KEY (announcementid)
	)");
	echo "bb".$n."_announcements Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_avatars (
   	id int(11) NOT NULL auto_increment,
   	name varchar(250) NOT NULL,
   	extension varchar(7) NOT NULL,
   	groupid int(11) DEFAULT '0' NOT NULL,
   	posts int(7) DEFAULT '0' NOT NULL,
   	userid int(11) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_avatars Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_bbcode (
   	id int(11) NOT NULL auto_increment,
   	bbcodetag varchar(250) NOT NULL,
   	bbcodereplace varchar(250) NOT NULL,
   	params int(1) DEFAULT '1' NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_bbcode Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_boards (
   	boardid int(11) NOT NULL auto_increment,
   	boardparentid int(11) DEFAULT '0' NOT NULL,
   	boardname varchar(70) NOT NULL,
   	boardpassword varchar(25) NOT NULL,
   	descriptiontext text NOT NULL,
   	threads int(11) DEFAULT '0' NOT NULL,
   	posts int(11) DEFAULT '0' NOT NULL,
   	lastposttime int(11) DEFAULT '0' NOT NULL,
   	lastpostid int(11) DEFAULT '0' NOT NULL,
   	sort int(7) DEFAULT '0' NOT NULL,
   	isboard int(1) DEFAULT '0' NOT NULL,
   	invisible int(1) DEFAULT '0' NOT NULL,
   	style_set int(11) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (boardid)
	)");
	echo "bb".$n."_boards Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_config (
   	php_path varchar(200) NOT NULL,
   	master_board_name varchar(50) NOT NULL,
   	master_email varchar(70) NOT NULL,
   	html int(1) DEFAULT '0' NOT NULL,
   	smilies int(1) DEFAULT '0' NOT NULL,
   	bbcode int(1) DEFAULT '0' NOT NULL,
   	maximage int(2) DEFAULT '0' NOT NULL,
   	polls int(1) DEFAULT '0' NOT NULL,
   	image int(1) DEFAULT '0' NOT NULL,
   	image_ext text NOT NULL,
   	tproseite int(2) DEFAULT '0' NOT NULL,
   	eproseite int(2) DEFAULT '0' NOT NULL,
   	timeoffset int(3) DEFAULT '0' NOT NULL,
   	rekord int(7) DEFAULT '0' NOT NULL,
   	rekordtime int(11) DEFAULT '0' NOT NULL,
   	timeout int(2) DEFAULT '0' NOT NULL,
   	default_daysprune int(4) DEFAULT '0' NOT NULL,
   	hotthread_reply int(3) DEFAULT '0' NOT NULL,
   	hotthread_view int(5) DEFAULT '0' NOT NULL,
   	show_subboards int(1) DEFAULT '0' NOT NULL,
   	anzahl_smilies int(3) DEFAULT '0' NOT NULL,
   	cover char(1) NOT NULL,
   	badwords text NOT NULL,
   	ch_parseurl int(1) DEFAULT '0' NOT NULL,
   	ch_email int(1) DEFAULT '0' NOT NULL,
   	ch_disablesmilies int(1) DEFAULT '0' NOT NULL,
   	ch_signature int(1) DEFAULT '0' NOT NULL,
   	boardoff int(1) DEFAULT '0' NOT NULL,
   	boardoff_text text NOT NULL,
   	regdateformat varchar(30) NOT NULL,
   	shortdateformat varchar(30) NOT NULL,
   	longdateformat varchar(30) NOT NULL,
   	today varchar(30) NOT NULL,
   	timetype int(1) DEFAULT '0' NOT NULL,
   	postorder int(1) DEFAULT '0' NOT NULL,
   	register int(1) DEFAULT '0' NOT NULL,
   	act_code int(1) DEFAULT '0' NOT NULL,
   	act_permail int(1) DEFAULT '0' NOT NULL,
   	regnotify int(1) DEFAULT '0' NOT NULL,
   	multi_email int(1) DEFAULT '0' NOT NULL,
   	banname text NOT NULL,
   	banemail text NOT NULL,
   	sigsmilies int(1) DEFAULT '0' NOT NULL,
   	sigbbcode int(1) DEFAULT '0' NOT NULL,
   	sightml int(1) DEFAULT '0' NOT NULL,
   	sigimage int(1) DEFAULT '0' NOT NULL,
   	sigmaximage int(2) DEFAULT '0' NOT NULL,
   	sigimage_ext text NOT NULL,
   	siglength int(5) DEFAULT '0' NOT NULL,
   	avatars int(1) DEFAULT '0' NOT NULL,
   	avatarimage_ext text NOT NULL,
   	avatar_width int(3) DEFAULT '0' NOT NULL,
   	avatar_height int(3) DEFAULT '0' NOT NULL,
   	avatar_size int(6) DEFAULT '0' NOT NULL,
   	usertextlength int(4) DEFAULT '0' NOT NULL,
   	favboards int(2) DEFAULT '0' NOT NULL,
   	favthreads int(2) DEFAULT '0' NOT NULL,
   	pms int(1) DEFAULT '0' NOT NULL,
   	maxpms int(5) DEFAULT '0' NOT NULL,
   	maxfolder int(2) DEFAULT '0' NOT NULL,
   	forumid varchar(32) NOT NULL
	)");
	echo "bb".$n."_config Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_folders (
   	folderid int(11) NOT NULL auto_increment,
   	userid int(11) DEFAULT '0' NOT NULL,
   	foldername varchar(100) NOT NULL,
   	PRIMARY KEY (folderid)
	)");
	echo "bb".$n."_folders Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_groups (
   	id int(11) NOT NULL auto_increment,
   	title varchar(30) NOT NULL,
   	canviewboard int(1) DEFAULT '0' NOT NULL,
   	canviewoffboard int(1) DEFAULT '0' NOT NULL,
   	canusesearch int(1) DEFAULT '0' NOT NULL,
   	canusepms int(1) DEFAULT '0' NOT NULL,
   	canstarttopic int(1) DEFAULT '0' NOT NULL,
   	canreplyowntopic int(1) DEFAULT '0' NOT NULL,
   	canreplytopic int(1) DEFAULT '0' NOT NULL,
   	caneditownpost int(1) DEFAULT '0' NOT NULL,
   	candelownpost int(1) DEFAULT '0' NOT NULL,
   	cancloseowntopic int(1) DEFAULT '0' NOT NULL,
   	candelowntopic int(1) DEFAULT '0' NOT NULL,
   	canpostpoll int(1) DEFAULT '0' NOT NULL,
   	canvotepoll int(1) DEFAULT '0' NOT NULL,
   	canuploadavatar int(1) DEFAULT '0' NOT NULL,
   	appendeditnote int(1) DEFAULT '0' NOT NULL,
   	avoidfc int(1) DEFAULT '0' NOT NULL,
   	ismod int(1) DEFAULT '0' NOT NULL,
   	issupermod int(1) DEFAULT '0' NOT NULL,
   	canuseacp int(1) DEFAULT '0' NOT NULL,
   	default_group int(1) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_groups Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_notify (
   	threadid int(11) DEFAULT '0' NOT NULL,
  	userid int(11) DEFAULT '0' NOT NULL
	)");
	echo "bb".$n."_notify Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_object2board (
   	boardid int(11) DEFAULT '0' NOT NULL,
   	objectid int(11) DEFAULT '0' NOT NULL,
   	mod int(1) DEFAULT '0' NOT NULL,
   	boardpermission int(1) DEFAULT '0' NOT NULL,
  	startpermission int(1) DEFAULT '0' NOT NULL,
   	replypermission int(1) DEFAULT '0' NOT NULL
	)");
	echo "bb".$n."_object2board Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_object2user (
   	userid int(11) DEFAULT '0' NOT NULL,
   	objectid int(11) DEFAULT '0' NOT NULL,
   	favboards int(1) DEFAULT '0' NOT NULL,
   	favthreads int(1) DEFAULT '0' NOT NULL,
   	buddylist int(1) DEFAULT '0' NOT NULL,
   	ignorelist int(1) DEFAULT '0' NOT NULL,
   	pmsend int(1) DEFAULT '0' NOT NULL
	)");
	echo "bb".$n."_object2user Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_pms (
   	senderid int(11) DEFAULT '0' NOT NULL,
   	recipientid int(11) DEFAULT '0' NOT NULL,
   	pmid int(11) NOT NULL auto_increment,
  	folderid int(11) DEFAULT '0' NOT NULL,
   	view int(1) DEFAULT '0' NOT NULL,
   	reply int(1) DEFAULT '0' NOT NULL,
   	forward int(1) DEFAULT '0' NOT NULL,
   	sendtime int(11) DEFAULT '0' NOT NULL,
   	subject varchar(70) NOT NULL,
   	message text NOT NULL,
   	icon varchar(200) NOT NULL,
   	disable_smilies int(1) DEFAULT '0' NOT NULL,
   	signature int(1) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (pmid)
	)");
	echo "bb".$n."_pms Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_pmsend (
   	userid int(11) DEFAULT '0' NOT NULL,
   	recipientid int(11) DEFAULT '0' NOT NULL,
   	pmparentid int(11) DEFAULT '0' NOT NULL,
   	pmid int(11) NOT NULL auto_increment,
   	sendtime int(11) DEFAULT '0' NOT NULL,
   	subject varchar(70) NOT NULL,
   	message text NOT NULL,
   	icon varchar(200) NOT NULL,
   	disable_smilies int(1) DEFAULT '0' NOT NULL,
   	signature int(1) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (pmid)
	)");
	echo "bb".$n."_pmsend Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_poll (
   	id int(11) NOT NULL auto_increment,
   	threadid int(11) DEFAULT '0' NOT NULL,
   	field varchar(200) NOT NULL,
   	votes int(11) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_poll Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_posts (
   	boardparentid int(11) DEFAULT '0' NOT NULL,
   	threadparentid int(11) DEFAULT '0' NOT NULL,
   	postid int(11) NOT NULL auto_increment,
   	userid int(11) DEFAULT '0' NOT NULL,
   	posttime int(11) DEFAULT '0' NOT NULL,
   	edittime int(11) DEFAULT '0' NOT NULL,
   	editorid int(11) DEFAULT '0' NOT NULL,
   	posttopic varchar(70) NOT NULL,
   	message text NOT NULL,
   	posticon varchar(200) DEFAULT '0' NOT NULL,
   	disable_smilies int(1) DEFAULT '0' NOT NULL,
   	signature int(1) DEFAULT '0' NOT NULL,
   	ip varchar(15) NOT NULL,
   	PRIMARY KEY (postid)
	)");
	echo "bb".$n."_posts Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_ranks (
   	id int(11) NOT NULL auto_increment,
   	groupid int(11) DEFAULT '1' NOT NULL,
   	posts int(7) DEFAULT '0' NOT NULL,
   	rank varchar(30) NOT NULL,
   	grafik varchar(250) NOT NULL,
   	mal int(2) DEFAULT '1' NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_ranks Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_smilies (
   	id int(11) NOT NULL auto_increment,
   	smiliespath varchar(255) NOT NULL,
   	smiliestext varchar(50) NOT NULL,
   	smiliestitle varchar(50) NOT NULL,
   	PRIMARY KEY (id)
	)");
	echo "bb".$n."_smilies Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_style (
   	styleid int(11) NOT NULL auto_increment,
   	stylename varchar(50) NOT NULL,
   	templatefolder varchar(200) NOT NULL,
   	font varchar(100) NOT NULL,
   	fontcolor varchar(7) NOT NULL,
   	fontcolorsec varchar(7) NOT NULL,
   	fontcolorthi varchar(7) NOT NULL,
   	fontcolorfour varchar(7) NOT NULL,
   	bgcolor varchar(7) NOT NULL,
   	tablebg varchar(7) NOT NULL,
   	tablea varchar(7) NOT NULL,
   	tableb varchar(7) NOT NULL,
   	tablec varchar(7) NOT NULL,
   	tabled varchar(7) NOT NULL,
   	imageurl varchar(250) NOT NULL,
   	css text NOT NULL,
   	bgimage varchar(250) NOT NULL,
   	bgfixed int(1) DEFAULT '0' NOT NULL,
   	default_style int(1) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (styleid)
	)");
	echo "bb".$n."_style Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_threads (
   	boardparentid int(11) DEFAULT '0' NOT NULL,
   	starttime int(11) DEFAULT '0' NOT NULL,
   	threadid int(11) NOT NULL auto_increment,
   	threadname varchar(70) NOT NULL,
   	authorid int(11) DEFAULT '0' NOT NULL,
   	author varchar(30) NOT NULL,
   	lastposterid int(11) DEFAULT '0' NOT NULL,
   	replies int(11) DEFAULT '0' NOT NULL,
   	views int(11) DEFAULT '0' NOT NULL,
   	timelastreply int(11) DEFAULT '0' NOT NULL,
   	flags int(11) DEFAULT '0' NOT NULL,
   	topicicon varchar(200) NOT NULL,
   	rate_points int(15) DEFAULT '0' NOT NULL,
   	rated int(11) DEFAULT '0' NOT NULL,
   	putoffid int(11) DEFAULT '0' NOT NULL,
   	important int(1) DEFAULT '0' NOT NULL,
   	pquestion varchar(250) NOT NULL,
   	ptimeout int(11) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (threadid)
	)");
	echo "bb".$n."_threads Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_user_table (
  	userid int(11) NOT NULL auto_increment,
   	username varchar(30) NOT NULL,
   	userpassword varchar(50) NOT NULL,
   	useremail varchar(150) NOT NULL,
   	regemail varchar(150) NOT NULL,
   	userposts int(11) DEFAULT '0' NOT NULL,
   	groupid int(7) DEFAULT '0' NOT NULL,
   	statusextra varchar(25),
   	regdate int(11) DEFAULT '0' NOT NULL,
   	lastvisit int(11) DEFAULT '0' NOT NULL,
   	lastactivity int(11) DEFAULT '0' NOT NULL,
   	session_link int(1) DEFAULT '1' NOT NULL,
   	signatur text NOT NULL,
   	usericq varchar(30) NOT NULL,
   	aim varchar(30) NOT NULL,
   	yim varchar(30) NOT NULL,
   	userhp varchar(200) NOT NULL,
   	age_m varchar(10) NOT NULL,
   	age_d int(2) DEFAULT '0' NOT NULL,
   	age_y int(4) DEFAULT '0' NOT NULL,
   	avatarid int(11) DEFAULT '0' NOT NULL,
   	interests varchar(250) NOT NULL,
   	location varchar(250) NOT NULL,
   	work varchar(250) NOT NULL,
   	gender int(1) DEFAULT '0' NOT NULL,
   	usertext text NOT NULL,
   	show_email_global int(1) DEFAULT '0' NOT NULL,
   	mods_may_email int(1) DEFAULT '1' NOT NULL,
   	users_may_email int(1) DEFAULT '1' NOT NULL,
   	invisible int(1) DEFAULT '0' NOT NULL,
   	hide_signature int(1) DEFAULT '0' NOT NULL,
   	hide_userpic int(1) DEFAULT '0' NOT NULL,
   	prunedays int(4) DEFAULT '0' NOT NULL,
   	umaxposts int(2) DEFAULT '0' NOT NULL,
   	bbcode int(1) DEFAULT '1' NOT NULL,
   	style_set int(11) DEFAULT '0' NOT NULL,
   	activation int(10) DEFAULT '0' NOT NULL,
   	blocked int(1) DEFAULT '0' NOT NULL,
   	PRIMARY KEY (userid)
	)");
	echo "bb".$n."_user_table Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_useronline (
   	zeit int(11) DEFAULT '0' NOT NULL,
   	ip varchar(15) DEFAULT '0' NOT NULL,
   	userid int(11) DEFAULT '0' NOT NULL
	)");
	echo "bb".$n."_useronline Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_vote (
   	threadid int(11) DEFAULT '0' NOT NULL,
   	userid int(11) DEFAULT '0' NOT NULL
	)");
	echo "bb".$n."_vote Tabelle erstellt<br>";
	?>
		</p>
		<p>
		<b>Tabellen wurden erfolgreich erstellt!</b> 
		</p>
		<p>
		<a href="install.php?step=5">Klicken Sie hier, um mit der Installation fortzufahren!</a> 
		</p>
	<?
}

if($step==5) {
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '1', 'b', '<b>\\\\1</b>', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '2', 'i', '<i>\\\\1</i>', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '3', 'email', '<a href=\"mailto:\\\\1\">\\\\1</a>', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '4', 'email', '<a href=\"mailto:\\\\2\">\\\\3</a>', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '5', 'size', '<font size=\"\\\\2\">\\\\3</font>', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '6', 'quote', '<blockquote><font size=1>Zitat:</font><hr>\\\\1<hr></blockquote>', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '7', 'u', '<u>\\\\1</u>', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '8', 'color', '<font color=\"\\\\2\">\\\\3</font>', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '9', 'font', '<font face=\"\\\\2\">\\\\3</font>', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '10', 'align', '<div align=\"\\\\2\">\\\\3</div>', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '11', 'mark', '<span style=\"background-color: \\\\2\">\\\\3</span>', '2');");
	
	$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '1', 'Administratoren', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '0');");
	$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '2', 'Moderatoren', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '0', '0', '0');");
	$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '3', 'User', '1', '0', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '4', 'G�ste', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '5', 'Super Moderatoren', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '0', '0');");
	
	$db_zugriff->query("INSERT INTO bb".$n."_style VALUES ( '1', 'Standard', 'templates', 'Verdana, Arial, Helvetica, sans-serif', '#000000', '#FEC254', '#000000', '#444444', '#808080', '#000000', '#646464', '#EFEFEF', '#DEDEDE', '#646464', 'images/bblogo.gif', 'BODY { SCROLLBAR-BASE-COLOR: #646464; SCROLLBAR-ARROW-COLOR: #FEC254; } SELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } TEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } #bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; } #bg A:hover { COLOR: #000000; TEXT-DECORATION: none; } #cat A:link, #cat A:visited, #cat A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #cat A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; } #title A:link, #title A:visited, #title A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #title A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; }  ', '', '1', '1');");

	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '1', '1', '0', 'Administrator', 'images/star3.gif', '6');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '2', '2', '0', 'Moderator', 'images/star3.gif', '4');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '3', '3', '0', 'Gr�nschnabel', 'images/star.gif', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '4', '3', '10', 'Jungspunt', 'images/star.gif', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '5', '3', '25', 'Mitglied', 'images/star.gif', '3');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '6', '3', '50', 'Eroberer', 'images/star.gif', '4');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '7', '3', '75', 'Foren As', 'images/star.gif', '5');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '8', '3', '100', 'Doppel-As', 'images/star2.gif', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '9', '3', '150', 'Tripel-As', 'images/star2.gif', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '10', '3', '250', 'Routinier', 'images/star2.gif', '3');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '11', '3', '500', 'Haudegen', 'images/star2.gif', '4');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '12', '3', '750', 'K�nig', 'images/star2.gif', '5');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '13', '3', '1000', 'Kaiser', 'images/star3.gif', '1');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '14', '3', '1500', 'Lebende Foren Legende', 'images/star3.gif', '2');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '15', '3', '2000', 'Foren Gott', 'images/star3.gif', '3');");
	$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '16', '5', '0', 'Super Moderator', 'images/star3.gif', '5');");
	
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '2', 'images/smilies/biggrin.gif', ':D', 'gro�es Grinsen')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '3', 'images/smilies/redface.gif', ':O', 'rotes Gesicht')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '4', 'images/smilies/confused.gif', '?(', 'verwirrt')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '5', 'images/smilies/cool.gif', '8)', 'cool')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '6', 'images/smilies/crying.gif', ';(', 'traurig')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '7', 'images/smilies/eek.gif', '8o', 'geschockt')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '8', 'images/smilies/pleased.gif', ':]', 'Freude')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '9', 'images/smilies/frown.gif', ':(', 'ungl�cklich')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '10', 'images/smilies/happy.gif', ':))', 'fr�hlich')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '11', 'images/smilies/mad.gif', 'X(', 'b�se')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '12', 'images/smilies/smile.gif', ':)', 'smile')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '13', 'images/smilies/tongue.gif', ':P', 'Zunge raus')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '14', 'images/smilies/wink.gif', ';)', 'Augenzwinkern')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '15', 'images/smilies/rolleyes.gif', ':rolleyes:', 'Augen rollen')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '16', 'images/smilies/baby.gif', ':baby:', 'Baby')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '17', 'images/smilies/evil.gif', ':evil:', 'Teufel')");
	$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '18', 'images/smilies/tongue2.gif', ':tongue:', 'Zunge raus')");
	
	$db_zugriff->query("INSERT INTO bb".$n."_config VALUES ( 'http://www.ihredomain.de/wbboard', 'Burning Board', 'email@ihredomain.de', '0', '1', '1', '10', '1', '1', 'gif
jpeg
jpg
', '30', '20', '0', '0', '0', '5', '1000', '15', '150', '1', '15', '*', '{boeseswort=guteswort}', '1', '0', '0', '1', '0', '', 'MN YYYY', 'DD.MM.YYYY', 'DD.MM.YYYY, HH:II', 'DD.MM.YYYY=<b>Heute</b>', '0', '0', '1', '1', '1', '0', '0', '', '', '1', '1', '0', '1', '1', 'gif
jpeg
jpg', '300', '1', 'jpg
gif
jpeg', '90', '90', '10000', '50', '5', '20', '1', '100', '5','".md5(uniqid(microtime()))."')");
header("Location: install.php?step=6");	
}

if($step==6) {
	if($send == "send") {
		if(!$username || !$useremail || !$userpassword) $error = "Es wurden nicht alle Felder ausgef�llt.";
		else {
			$time = time();
			$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,lastvisit,lastactivity,activation) VALUES ('$username','".md5($userpassword)."','$useremail','$useremail','1','$time','$time','$time','1')");
			header("Location: install.php?step=7");
			exit;
		}
	}
echo $header;
?>
<p><form method=post action="install.php">
<input type="hidden" name="step" value="6">
<input type="hidden" name="send" value="send">
Registrierung der Admins:<br>
Name: <input class="input" name="username" value="<? echo $username; ?>" maxlength=30><br>
eMail: <input class="input" name="useremail" value="<? echo $useremail; ?>" maxlength=150><br>
Passwort: <input class="input" name="userpassword" value="<? echo $userpassword; ?>" maxlength=20><br>
<input type="submit" value="Senden"></form> 
</p>
<p><? echo $error; ?></p>
<?
}

if($step==7) {
echo $header;
?>
<p>
<b>Installation erfolgreich abgeschlossen!</b>
</p>
<p>
<b>L�schen Sie die install.php!</b>
</p>
<p>
<a href="admin/index.php">Klicken Sie hier, um ins Admin Control Panel zu gelangen!</a> 
</p>
<?
}

?>
</font></body>
</html>