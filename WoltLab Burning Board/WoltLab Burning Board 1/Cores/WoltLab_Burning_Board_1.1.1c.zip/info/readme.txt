++++++++++++ WoltLab Burning Board 1.1.1 ++++++++++++

I.	Installation
II.	Update von 1.0 Beta 4.5
III.	Copyright & Special Thanks

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++

++++++++++++++++ I. Installation +++++++++++++++

-- 1. entpacken des ZIP-Archivs wbboard.zip auf die lokalte Festplatte
-- 2. Datei "_data.inc.php" mit einem beliebigen Editor �ffnen
Folgende Daten sind einzutragen:
Hostname des MySQL Serves (falls externer Server, ansonsten meist localhost) -> $mysqlhost
Username f�r den MySQL Datenabank Server -> $mysqluser
Passwort des Users -> $mysqlpassword
Name der Datenbank in dem die Boarddaten liegen sollen -> $mysqldb
Nummer des Boards (falls man mehrere Boards, ansonsten 1) -> $n
eMail Adresse des Admins -> $adminmail
-- 3. Kopieren alle (mit Ausnahme der update.php) Dateien auf den Server
Beim Upload FTP Tool auf Auto Mode stellen
falls nicht vorhanden:
.php Dateien im ASCII Mode
.jpg/.gif Dateien im Bin�r Mode
-- 4. aufruf der install.php im Browser
-- 5. den Anweisungen folgen
-- 6. nach erfolgreicher Installation -> install.php l�schen
-- 7. im Admin Control Panel einloggen und Einstellungen vornehmen
Wichtig: Einstellungen -> Boardoptionen -> Url zum Board: http://www.deinedomain.de/wbboard
-- 8. Boards erstellen etc.
-- 9. Fertig!
Wichtig: Verzeichnis images/avatars mu� die Rechte 777 bekommen, wenn man Avatars hochladen m�chte


++++++++++++++++ II. Update von 1.0 Beta 4.5 +++++++++++++++

-- 1. Forum in Offline Modus schalten
-- 2. entpacken des ZIP-Archivs wbboard.zip auf die lokalte Festplatte
-- 3. Kopieren aller (mit Ausnahme von _data.inc.php und install.php) Dateien auf den Server
Beim Upload FTP Tool auf Auto Mode stellen
falls nicht vorhanden:
.php Dateien im ASCII Mode
.jpg/.gif Dateien im Bin�r Mode
-- 4. aufruf der update.php im Browser
-- 5. den Anweisungen folgen
-- 6. nach erfolgreichm Update -> update.php l�schen
-- 7. im Admin Control Panel einloggen und Einstellungen vornehmen/alten Einstellungen �berpr�fen
-- 8. Fertig!


++++++++++++++++ III. Copyright & Special Thanks +++++++++++++++

Copyright 2001 WoltLab GbR (www.woltlab.de) - Gesch�ftsf�hrer Marcel Werk
Special thanks to... PerfectPixel, Malick, OnkelDoc


  