<?php
require "global.php";


if(isset($_GET['action'])) $action=$_GET['action'];
elseif(isset($_POST['action'])) $action=$_POST['action'];
if(!isset($link)) $link = "";
if(!isset($ride)) $ride = "";


// ############## Login ###############
if($action=="login") {
$kennwort = md5($_POST['kennwort']);
$username = htmlspecialchars($_POST['username']);

$usercheck = checkUser($username,$kennwort);
if($usercheck==2) {
	if(!$link) $ride = urldecode($url_jump);
	else $ride = urldecode($link);
	
	$user_id = getUserid($username);
	$user_password = $kennwort;
	wbb_session_register("user_id");
	wbb_session_register("user_password");
	setcookie("user_id", "$user_id", time()+(3600*24*365));
	setcookie("user_password", "$user_password", time()+(3600*24*365));

	/* Session ID mitgeben, falls eingeschaltet.. */
	$sid_settings = $db_zugriff->query_first("SELECT session_link FROM bb".$n."_user_table WHERE userid='".$user_id."'");
	$session_link = $sid_settings['session_link'];
	if(!$session_link) { // SID muss angeh�ngt werden.
		$filename="";
		$querystring="";
		@list($filename,$querystring)=@explode("?",$ride);
		if(!$querystring) {
			$ride = $filename."?sid=".$sid;
		}
		else // querystring schon vorhanden => sid= ersetzen.
		{
			if(!stristr($querystring,"sid="))  // sid einfach anh�ngen
			{
				$querystring .= "&sid=".$sid;
			}
			else // sid= ersetzen
			{
				$querystring = preg_replace("/sid=[a-zA-Z0-9]*/","sid=",$querystring);
				$querystring = str_replace("sid=","sid=$sid",$querystring);
			}
			$ride = $filename."?".$querystring;
		}
	}
	// Boardcookies verwenden...
	else
	{
		#setcookie("user_id", "$user_id", time()+(3600*24*365));
		#setcookie("user_password", "$user_password", time()+(3600*24*365));
	}

	eval ("\$output = \"".gettemplate("note1")."\";");
}
if($usercheck==0) eval ("\$output = \"".gettemplate("error1")."\";");
if($usercheck==1) eval ("\$output = \"".gettemplate("error2")."\";");
}

// ############## Logout ###############
if($action=="logout") {
	$ride = urldecode($url_jump);
	if(!@session_destroy()) @session_unset();
	setcookie("user_id");
	setcookie("user_password");
	$db_zugriff->query("DELETE FROM bb".$n."_useronline WHERE userid='".$user_id."'");

	setcookie("cbpassword");
	setcookie("votepoll");
	setcookie("sthreads");

	eval ("\$output = \"".gettemplate("note2")."\";");
}
// ############## als gelesen markieren ###############
if($action=="makeallread") {

        $old_time = time();
        $new_time = time();

        if($user_id) $db_zugriff->query("UPDATE bb".$n."_user_table SET lastvisit = '$old_time', lastactivity = '$new_time' WHERE userid = '$user_id'");
        else {
        	#session_register("old_time");
        	#session_register("new_time");
			#$HTTP_SESSION_VARS['old_time'] = $old_time;
			#$HTTP_SESSION_VARS['new_time'] = $new_time;
			wbb_session_register("old_time");
			wbb_session_register("new_time");
        }
        $ride = urldecode($url_jump);
        eval ("\$output = \"".gettemplate("note7")."\";");
}

// ############## unsubscripe thread ###############
if($action=="delthread") {
        if($user_id) {
                unsubscripe($threadid,$user_id,"threads");
                $threadname = getThreadname($threadid);
                eval ("\$output = \"".gettemplate("note11")."\";");
                $ride = urldecode($url_jump);
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## unsubscripe board ###############
if($action=="delboard") {
        if($user_id) {
                unsubscripe($boardid,$user_id,"boards");
                $boardname = getBoardname($boardid);
                eval ("\$output = \"".gettemplate("note10")."\";");
                $ride = urldecode($url_jump);
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## noemail ###############
if($action=="noemail") {
        if($threadid && $userid) {
                $db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid = '$threadid' AND userid = '$userid'");
                eval ("\$output = \"".gettemplate("note12")."\";");
                $ride = "main.php?$session2";
        }
        else eval ("\$output = \"".gettemplate("error3")."\";");
}

// ############## Formmailer ###############
if($action=="formmail") {
        if($userid) {
                $useremail = getUserEmail($userid);
                $username = getUsername($userid);
        }
		if(isset($_POST['useremail'])) $useremail=$_POST['useremail'];
        if(trim($_POST['absender']) && trim($_POST['message']) && $useremail) {
                formmail($_POST['absender'],$_POST['message'],$_POST['betreff'],$useremail);
                $name = ($username ? $username : $useremail);
                eval ("\$output = \"".gettemplate("note13")."\";");
                $ride = urldecode($url_jump);
        } else eval ("\$output = \"".gettemplate("error17")."\";");
}

// ############## Report ###############
if($action=="report") {
        if($user_id) {
                if($_POST['reason']) {
                        report($user_id,$_POST['postid'],$boardid,$threadid);
                        eval ("\$output = \"".gettemplate("note14")."\";");
                        $ride = "thread.php?styleid=$styleid&boardid=$boardid&threadid=$threadid&page=".$_POST['page']."$session";
                } else eval ("\$output = \"".gettemplate("error17")."\";");
        }
        else eval ("\$output = \"".gettemplate("error4")."\";");
}

// ############## Activation ###############
if($action=="activation") {
        $result = activat($userid,$_GET['code']);
        if($result == 1) eval ("\$output = \"".gettemplate("error1")."\";");
        if($result == 2) eval ("\$output = \"".gettemplate("error22")."\";");
        if($result == 3) eval ("\$output = \"".gettemplate("error23")."\";");
        if(!$result) {
                $user_id = $userid;
                eval ("\$output = \"".gettemplate("note21")."\";");
                $user_password = getUserPW($userid);
                #session_register("user_id");
                #session_register("user_password");
				#$HTTP_SESSION_VARS['user_id'] = $user_id;
				#$HTTP_SESSION_VARS['user_password'] = $user_password;
                wbb_session_register("user_id");
                wbb_session_register("user_password");
                setcookie("user_id", "$user_id", time()+(3600*24*365));
				setcookie("user_password", "$user_password", time()+(3600*24*365));
		}
        $ride = "main.php?styleid=$styleid$session";
}
// ############## addfriend ###############
if($action=="addfriend") {
        if($user_id) {
                $ride = urldecode($url_jump);
                if($user_id != $userid) {
                	$check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2user WHERE userid='$user_id' AND objectid = '$userid' AND buddylist = 1");
			if(!$check[0]) $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,buddylist) VALUES ('$user_id','$userid','1')");
			$name = getUsername($userid);
                        eval ("\$output = \"".gettemplate("buddy_note5")."\";");
                }
                else eval ("\$output = \"".gettemplate("buddy_note2")."\";");
        }
        else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## addboard ###############
if($action=="addboard") {
        if($user_id) {
                $ride = urldecode($url_jump);
                $output = subscripe($user_id,$boardid,"boards");
                if(!$output) {
                        $boardname = getBoardname($boardid);
                        eval ("\$output = \"".gettemplate("note22")."\";");
                }
        } else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## addthread ###############
if($action=="addthread") {
        if($user_id) {
                $ride = urldecode($url_jump);
                $output = subscripe($user_id,$threadid,"threads");
                if(!$output) {
                        $threadname = getThreadname($threadid);
                        eval ("\$output = \"".gettemplate("note23")."\";");
                }
        } else {
                header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
                exit;
        }
}

// ############## getLastPost main ###############
if($action=="getlastmain") {
        header("LOCATION: ".getLastPost($boardid,1)."");
        exit;
}
// ############## getLastPost board ###############
if($action=="getlastboard") {
        header("LOCATION: ".getLastPost($threadid,2)."");
        exit;
}
// ############## getLastPost Autor ###############
if($action=="getlastautor") {
        $username = getUsername($userid);
        header("LOCATION: ".getLastPost($username,4)."");
        exit;
}

// ############## getLastPost main ###############
if($action=="firstnew") {
        header("LOCATION: ".firstnewPost($threadid,$old_time)."");
        exit;
}

// ############## vote ###############
if($action=="vote") {
        if(!$_POST['vote']) {
        	header("LOCATION: ".urldecode($url_jump)."");
        	exit;
        }
        if(!$userdata['canvotepoll']) {
        	header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
        	exit;
        }
        $thread_info = $db_zugriff->query_first("SELECT starttime,ptimeout FROM bb".$n."_threads WHERE threadid = '$threadid'");
	$poll_check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_vote WHERE threadid='$threadid' AND userid = '$user_id'");
	if($poll_check[0] || ($thread_info['ptimeout'] && time() >= ($thread_info['starttime']+$thread_info['ptimeout']*(24*3600)))) {
		eval ("\$output = \"".gettemplate("error25")."\";");
        	$ride = urldecode($url_jump)."&presult=1";
        }
        else {
        	$db_zugriff->query("UPDATE bb".$n."_poll set votes=votes+1 WHERE id=".intval($_POST['vote']));
        	if($user_id) $db_zugriff->query("INSERT INTO bb".$n."_vote (threadid,userid) VALUES ('$threadid','$user_id')");
        	eval ("\$output = \"".gettemplate("note24")."\";");
        	$ride = urldecode($url_jump)."&presult=1";
        	#setcookie("vote_poll[$pollid]", "1", time()+(3600*24*365));
			$votepoll[$threadid]=1;
			setcookie("votepoll",serialize($votepoll), time()+3600*24*365);
			#setcookie("vote_poll");
        }
}

// ############## rate thread ###############
if($action=="rate_thread") {
        if($_POST['rate']!=-1) {
                $db_zugriff->query("UPDATE bb".$n."_threads set rate_points=rate_points+".intval($_POST['rate']).", rated=rated+1 WHERE threadid='$threadid'");
                $output = "Bewertung erfolgreich durchgef�hrt!";
                $ride = urldecode($url_jump);

        }
        else eval ("\$output = \"".gettemplate("error3")."\";");
}

if($action=="thread_order") {
        header("LOCATION: board.php?boardid=".$boardid."&styleid=".$styleid.$session."&sortfield=".$_POST['sortfield']."&sortorder=".$_POST['sortorder']."&daysprune=".$_POST['daysprune']."&page=".$_POST['page']);
        exit;
}


// ############## boardpw ###############
if($action == "boardpw") {
	if(!$_POST['boardpassword']) eval ("\$output = \"".gettemplate("error3")."\";");
	else {
		if($db_zugriff->query_first("SELECT boardid FROM bb".$n."_boards WHERE boardid='$boardid' AND boardpassword='".addslashes($_POST['boardpassword'])."'"))
		{
			#setcookie("cbpassword[$boardid]",md5($_POST['boardpassword']), time()+3600*24*365);
			$cbpassword[$boardid]=md5($_POST['boardpassword']);
			setcookie("cbpassword",serialize($cbpassword), time()+3600*24*365);
			$ride = urldecode($url_jump);
			eval ("\$output = \"".gettemplate("note25")."\";");
		}
		else eval ("\$output = \"".gettemplate("error2")."\";");
	}
}

/*
* Passwort vergessen.
*/
if($action == "forgotpw") {
	$result = $db_zugriff->query_first("SELECT userid, username, useremail FROM bb".$n."_user_table WHERE userid = '".$_GET['userid']."' AND userpassword = '".$_GET['code']."'");
	if(!$result['userid']) eval ("\$output = \"".gettemplate("error3")."\";");
	else {
		$kette = "abcdefghijklmnopqrstuvwxyz";
		for($i = 0; $i < 6; $i++) {
			$datum = date("s", time()+$i*4567);
                	mt_srand($datum);
                        $zahl = mt_rand(0,25);
                        $newpw .= substr($kette, $zahl, 1);
		}
		eval ("\$betreff = \"".gettemplate("forgotpw_betreff2","txt")."\";");
		eval ("\$inhalt = \"".gettemplate("forgotpw_mail2","txt")."\";");
		mail($result['useremail'],$betreff,$inhalt,"From: $master_email");
		$db_zugriff->query("UPDATE bb".$n."_user_table SET userpassword = '".md5($newpw)."' WHERE userid = '$userid'");

		header("Location: main.php$session2");
		exit;
	}
}

eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
if($ride) eval("dooutput(\"".gettemplate("action_ride")."\");");
else eval("dooutput(\"".gettemplate("action_error")."\");");


?>
