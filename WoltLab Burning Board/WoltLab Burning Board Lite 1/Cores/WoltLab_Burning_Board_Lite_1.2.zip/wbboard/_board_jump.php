<?php

if($user_id) {
	eval ("\$profile_link = \"".gettemplate("board_jump_profile")."\";");
	if($pms && $userdata['canusepms']) eval ("\$pm_link = \"".gettemplate("board_jump_pm")."\";");
	else $pm_link="";
}
else
{
	$profile_link="";
	$pm_link="";
}

$result = $db_zugriff->query("SELECT * FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
$board_links = makeboardjumpbit2(0);
$db_zugriff->free_result($result);
eval ("\$board_jump = \"".gettemplate("board_jump")."\";");
?>
