<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

if($user_id) {
	eval ("\$output = \"".gettemplate("error26")."\";");
	eval("dooutput(\"".gettemplate("action_error")."\");");
	exit;

}
if(!$register) {
	eval("dooutput(\"".gettemplate("registration_disable")."\");");
	exit;
}

/*
* Disclaimer
*/
if(isset($_GET['action']) && $_GET['action'] == "disclaimer") eval("dooutput(\"".gettemplate("disclaimer")."\");");

/*
* Registrierungsvorgang
*/
elseif((isset($_GET['action']) && $_GET['action'] == "register") || (isset($_POST['action']) && $_POST['action'] == "register"))
{
	$error="";
	$name="";
	$email="";
	$emailconfirm="";
	$action="register";
	/*
	* Speichern der Registrierung
	*/
	if(isset($_POST['send']) && $_POST['send'] == "send")
	{
		$tempname=trim($_POST['name']);
		$name=addslashes(htmlspecialchars(trim($_POST['name'])));
		$email = ($_POST['email']);
		if(!$_POST['name'] || !$_POST['email'] || !$_POST['emailconfirm'] || !$_POST['password'] || !$_POST['passwordconfirm'] || $_POST['email'] != $_POST['emailconfirm'] || $_POST['password'] != $_POST['passwordconfirm']) eval ("\$error = \"".gettemplate("register_error1")."\";");
		elseif(checkname($name)) eval ("\$error = \"".gettemplate("register_error2")."\";");
		elseif(checkemail($_POST['email'])) eval ("\$error = \"".gettemplate("register_error3")."\";");
		
		/*
		* Daten in Ordnung
		*/
		else
		{
			$default_group = $db_zugriff->query_first("SELECT id FROM bb".$n."_groups WHERE default_group = 2");
			$default_group = $default_group[0];
			$time = time();
			$password = md5($_POST['password']);
			
			/*
			* Aktivierungscode vergeben: True
			*/
			if($act_code)
			{
				// schwache Zufallszahl entfernt.
				mt_srand((double)microtime()*1000000);
				$z = mt_rand();
				$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,lastvisit,lastactivity,activation) VALUES ('".$name."','".$password."','".addslashes($_POST['email'])."','".addslashes($_POST['email'])."','".$default_group."','".$time."','".$time."','".$time."',".$z.")");
				$userid = $db_zugriff->insert_id();
				if($act_permail)
				{
					eval ("\$inhalt = \"".gettemplate("reg_mail")."\";");
					eval ("\$betreff = \"".gettemplate("reg_mail_betreff")."\";");
					$email = trim($_POST['email']);
					mail($email,$betreff,$inhalt,"From: ".$master_email);
				}
			}
			
			/*
			* Aktivierungscode vergeben: false
			* Der Benutzer wird gleich freigeschaltet...
			*/
			else
			{
				$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,lastvisit,lastactivity,activation) VALUES ('".$name."','".$password."','".addslashes($_POST['email'])."','".addslashes($_POST['email'])."','".$default_group."','".$time."','".$time."','".$time."','1')");
				$userid = $db_zugriff->insert_id();
				$user_id = $userid;
				#$user_password = getUserPW($userid);
				$user_password = $password;
				#session_register("user_id");
				#session_register("user_password");
				wbb_session_register("user_id");
				wbb_session_register("user_password");
				setcookie("user_id", "$user_id", time()+(3600*24*365));
				setcookie("user_password", "$user_password", time()+(3600*24*365));
			}
			
			
			/*
			* Benachrichtigung bei Registrierung: true
			*/
			if($regnotify)
			{
				eval ("\$inhalt = \"".gettemplate("reg_notifymail")."\";");
				eval ("\$betreff = \"".gettemplate("reg_mail_notifybetreff")."\";");
				mail($master_email,$betreff,$inhalt,"From: ".$master_email);
			}

			if($act_code)
			{
				if($act_permail) eval ("\$output = \"".gettemplate("register_note1")."\";");
				else eval ("\$output = \"".gettemplate("register_note2")."\";");
			}
			else eval ("\$output = \"".gettemplate("register_note3")."\";");
			$ride = urldecode($url_jump);
			eval("dooutput(\"".gettemplate("action_ride")."\");");
			exit;
		}

	}
	eval("dooutput(\"".gettemplate("register")."\");");
}
?>

