<?php
@error_reporting(7);
require "./admin/_data.inc.php";
require "./admin/class_db_zugriff.php";
require "./_functions.php";
$fctime = 30;


session_name("sid");
session_start();

require "./admin/incomingdata.php"; // Einkommende Daten bearbeiten
if (extension_loaded("zlib") && ($phpversion >= 404)) {
	ob_start("@ob_gzhandler");
}


// Einstellung f�r Register Globals einlesen.
if(ini_get("register_globals")) $register_globals=true;
else $register_globals=false;




//get vars
//...
if(isset($_POST['boardid'])) $boardid=($_POST['boardid']);
elseif(isset($_GET['boardid'])) $boardid=($_GET['boardid']);
else $boardid=0;
if($boardid!="home" && $boardid!="pm" && $boardid!="search" && $boardid!="profil" && $boardid!=-1) $boardid=intval($boardid);

if(isset($_POST['styleid'])) $styleid=intval($_POST['styleid']);
elseif(isset($_GET['styleid'])) $styleid=intval($_GET['styleid']);
else $styleid=0;

if(isset($_POST['threadid'])) $threadid=intval($_POST['threadid']);
elseif(isset($_GET['threadid'])) $threadid=intval($_GET['threadid']);
else $threadid=0;

if(isset($_POST['userid'])) $userid=intval($_POST['userid']);
elseif(isset($_GET['userid'])) $userid=intval($_GET['userid']);
else $userid=0;

if(isset($_POST['id'])) $id=intval($_POST['id']);
elseif(isset($_GET['id'])) $id=intval($_GET['id']);
else $id=0;

if(isset($_POST['pmid'])) $pmid=intval($_POST['pmid']);
elseif(isset($_GET['pmid'])) $pmid=intval($_GET['pmid']);
else $pmid=0;

if(isset($_COOKIE['sid']) && $_COOKIE['sid']) $sid=$_COOKIE['sid'];
elseif(isset($_POST['sid']) && $_POST['sid']) $sid=$_POST['sid'];
elseif(isset($_GET['sid']) && $_GET['sid']) $sid=$_GET['sid'];
else $sid = "";

if(isset($_GET['styleid'])) $styleid=intval($_GET['styleid']);

$templatecache = array();

$db_zugriff = new db_zugriff;
$db_zugriff->appname="WoltLab Burning Board";
$db_zugriff->database=$mysqldb;
$db_zugriff->server=$mysqlhost;
$db_zugriff->user=$mysqluser;
$db_zugriff->password=$mysqlpassword;
$db_zugriff->connect();

if(!$sid) $sid = session_id();
session_id($sid);


if(!$_SERVER['REQUEST_URI']) {
 	if($_SERVER['PATH_INFO']) $REQUEST_URI = $_SERVER['PATH_INFO'];
 	else $REQUEST_URI = $_SERVER['PHP_SELF'];
 	if($_SERVER['QUERY_STRING']) $REQUEST_URI .= "?" . $_SERVER['QUERY_STRING'];
}
else $REQUEST_URI = $_SERVER['REQUEST_URI'];


$REMOTE_ADDR = getIpAddress();
if(!isset($_SESSION['ssip'])) {
	#$ssip = getenv("REMOTE_ADDR");
	$ssip = $REMOTE_ADDR;
	wbb_session_register("ssip");
}


// Die IP von Aol Benutzern wird NICHT �berpr�ft, da AOL rotierende IPs benutzt.
// siehe dazu: http://www.phpbb.com/phpBB/viewtopic.php?t=30004&highlight=aol
//elseif($_SESSION['ssip']!=getenv("REMOTE_ADDR") && !stristr(getenv("HTTP_USER_AGENT"),"AOL")) {
//elseif((!isset($_COOKIE['sid']) || !$_COOKIE['sid']) && $_SESSION['ssip']!=getenv("REMOTE_ADDR") && !stristr(getenv("HTTP_USER_AGENT"),"AOL")) {
//elseif($_SESSION['ssip']!=getenv("REMOTE_ADDR")) {
//elseif((!stristr(getenv("HTTP_USER_AGENT"),"AOL") && !strstr($REQUEST_URI,"action.php") && $_SESSION['ssip']!=getenv("REMOTE_ADDR")) || (isset($_COOKIE['user_id']) && $COOKIE['user_id'] && $_COOKIE['user_id']!=$_SESSION['user_id'])) {
elseif((!strstr($REQUEST_URI,"action.php") && $_SESSION['ssip']!=$REMOTE_ADDR)) {
	// Cookie vorhanden, wahrscheinlich schon eingeloggt => nicht weiterleiten, sondern nur eine neue session starten.
	if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0 && isset($_COOKIE['user_password']))
	{
		session_unset();
		session_destroy();
		#session_name("sid");
		#session_start();
		#$sid=session_id();
	}
	// Session vollkommen killen..
	else
	{
		session_unset();
		session_destroy();
		header("Location: ".basename($REQUEST_URI)."");
		exit;
	}
}


$user_id="";
$user_password="";
if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0) $user_id = intval($_COOKIE['user_id']);
elseif(isset($_SESSION['user_id']) && intval($_SESSION['user_id'])>0 && !$user_id) $user_id = intval($_SESSION['user_id']);
else $user_id=0;

if(isset($_COOKIE['user_password']) && $_COOKIE['user_password']) $user_password = ($_COOKIE['user_password']);
elseif(isset($_SESSION['user_password']) && $_SESSION['user_password'] && !$user_password) $user_password = ($_SESSION['user_password']);
else $user_password="";



// $user_id & $user_password verifizieren...
if($user_id && $user_password && check_userdata($user_id,$user_password)) {
        $userdata = $db_zugriff->query_first("SELECT bb".$n."_user_table.*, bb".$n."_groups.* FROM bb".$n."_user_table LEFT JOIN bb".$n."_groups ON (bb".$n."_groups.id=bb".$n."_user_table.groupid) WHERE userid='$user_id'");
        if($userdata['blocked']) $blocked = 1;
		else $blocked = 0;
        $user_name = $userdata['username'];
        $user_group = $userdata['groupid'];
        $old_time = $userdata['lastvisit'];
        $new_time = $userdata['lastactivity'];
        $session_link = $userdata['session_link'];
        $hide_signature = $userdata['hide_signature'];
        $hide_userpic = $userdata['hide_userpic'];
        $prunedays = $userdata['prunedays'];
        $umaxposts = $userdata['umaxposts'];
        $u_bbcode = $userdata['bbcode'];
        if($userdata['style_set']) $styleid = $userdata['style_set'];
        if($new_time < (time()-900)) {
         $old_time = $new_time;
         $new_time = time();
         $db_zugriff->query("UPDATE bb".$n."_user_table SET lastvisit = lastactivity, lastactivity = '$new_time' WHERE userid = '$user_id'");
        }
        else {
         $new_time = time();
         $db_zugriff->query("UPDATE bb".$n."_user_table SET lastactivity = '$new_time' WHERE userid = '$user_id'");
        }
}
else {
	$user_id=0;
	$userdata = $db_zugriff->query_first("SELECT * FROM bb".$n."_groups WHERE default_group = 1");
	$user_group = $userdata[0];

	if(isset($_SESSION['old_time'])) $old_time = intval($_SESSION['old_time']);
	else $old_time = "";
	if(!$old_time) $old_time = time();
	$new_time = time();

	wbb_session_register("old_time");
	wbb_session_register("new_time");
	$session_link = 0;
	$umaxposts = 0;
	$hide_signature = 0;
	$hide_userpic = 0;
	$prunedays = 0;
	$u_bbcode = 1;
	$blocked=0;
}


if(isset($_SESSION['url_ak'])) $url_jump = $_SESSION['url_ak'];
else $url_jump = "";
if(!$url_jump) $url_jump = urlencode(basename($REQUEST_URI));
if(!strstr($REQUEST_URI,"action.php") && !strstr($REQUEST_URI,"register.php") && !strstr($REQUEST_URI,"misc.php")) $url_ak = urlencode($REQUEST_URI);
else $url_ak = $_SESSION['url_ak'];
wbb_session_register("url_ak");
wbb_session_register("url_jump");

$session = "";
$session2 = "";
if(!$session_link) {
	$session = "&sid=".$sid;
	$session2 = "?sid=".$sid;
}


$result = $db_zugriff->query("SELECT * FROM bb".$n."_config");
$row = $db_zugriff->fetch_array($result);
$j = mysql_num_fields($result);
for($i = 0; $i < $j; $i++) {
	$k = mysql_field_name($result,$i);
	$$k = $row[$k];
}
$db_zugriff->free_result($result);
$badwords = explode("\n", $badwords);
if($umaxposts) $eproseite = $umaxposts;

if($styleid) $style_result = $db_zugriff->query("SELECT * FROM bb".$n."_style WHERE styleid = '$styleid'");
else {
	if($boardid) $board_style = $db_zugriff->query_first("SELECT style_set FROM bb".$n."_boards WHERE boardid = '$boardid'");
	if(isset($board_style[0]) && $board_style[0]) $style_result = $db_zugriff->query("SELECT * FROM bb".$n."_style WHERE styleid = '$board_style[0]'");
	else $style_result = $db_zugriff->query("SELECT * FROM bb".$n."_style WHERE default_style = 1");
}

$row = $db_zugriff->fetch_array($style_result);
$j = mysql_num_fields($style_result);
for($i = 0; $i < $j; $i++) {
	$k = mysql_field_name($style_result,$i);
	$$k = $row[$k];
}
$db_zugriff->free_result($style_result);


// nachtr�glich gastnamen einlesen, da jetzt erst der templatefolder initialisisert ist.
if(!$user_id) eval ("\$user_name = \"".gettemplate("lg_anonymous")."\";");

// polls aus cookies
if(isset($_COOKIE['votepoll'])) $votepoll = unserialize($_COOKIE['votepoll']);
else $votepoll=array();

// Searches & Threads aus Session
if(isset($_COOKIE['sthreads']) && $_COOKIE['sthreads']) $sthreads_array = unserialize($_COOKIE['sthreads']);
elseif(isset($_SESSION['sthreads']) && $_SESSION['sthreads']) $sthreads_array = unserialize($_SESSION['sthreads']);
else $sthreads_array=array();
if(isset($_SESSION['ssquery']) && $_SESSION['ssquery']) $ssquery_array = unserialize($_SESSION['ssquery']);
else $ssquery_array=array();

$showpmpopup=0;

// ####################### Wartungsmodus ###############################
if($boardoff && !$userdata['canviewoffboard'] && !(strstr($REQUEST_URI,"misc.php") && $action=="login") && !(strstr($REQUEST_URI,"action.php") && $action=="login")) {
	require("_header.php");
	require("_board_jump.php");
	eval("dooutput(\"".gettemplate("wartungsmodus")."\");");
	exit;
}
// ####################### user blocked ###############################
if(($blocked == 1 || !$userdata['canviewboard']) && !strstr($REQUEST_URI,"action.php") && !strstr($REQUEST_URI,"misc2.php") && !strstr($REQUEST_URI,"register.php")) {
	require("_header.php");
	require("_board_jump.php");
	if(!$user_id) eval ("\$login = \"".gettemplate("access_error_login")."\";");
	else eval ("\$login = \"".gettemplate("access_error_logout")."\";");
	eval("dooutput(\"".gettemplate("access_error")."\");");
	exit;
}

useronline($user_id);

// ######################## Boardpasswort ############################
if((strstr($REQUEST_URI,"print.php") || strstr($REQUEST_URI,"board.php") || strstr($REQUEST_URI,"thread.php") || strstr($REQUEST_URI,"newthread.php") || strstr($REQUEST_URI,"reply.php") || strstr($REQUEST_URI,"edit.php")) && $boardid != "home" && $boardid != "pm" && $boardid != "search" && $boardid != "profil") {
	$password = $db_zugriff->query_first("SELECT boardpassword FROM bb".$n."_boards WHERE boardid = '$boardid'");

	if(isset($_COOKIE['cbpassword'])) $cbpassword = unserialize($_COOKIE['cbpassword']);
	else $cbpassword=array();

	if($password[0] && md5($password[0]) != $cbpassword[$boardid])
	#if($password[0] && md5($password[0]) != $_COOKIE['cbpassword'][$boardid])
	#if($password[0] && (!isset($_COOKIE['cbpassword'][$boardid]) || md5($password[0]) != $_COOKIE['cbpassword'][$boardid]))
	{
		require("_header.php");
		require("_board_jump.php");
		eval("dooutput(\"".gettemplate("boardpw")."\");");
		exit;
	}
}

// ######################## Boardaccess ############################
if((strstr($REQUEST_URI,"print.php") || strstr($REQUEST_URI,"board.php") || strstr($REQUEST_URI,"thread.php") || strstr($REQUEST_URI,"newthread.php") || strstr($REQUEST_URI,"reply.php") || strstr($REQUEST_URI,"edit.php")) && $boardid != "home" && $boardid != "pm" && $boardid != "search" && $boardid != "profil" && $boardid != -1 && !check_boardobject($boardid,$user_group,"boardpermission")) {
	require("_header.php");
	require("_board_jump.php");
	if(!$user_id) {
		if($session) $session_post = "<input type=\"hidden\" name=\"sid\" value=\"$sid\">";
		eval ("\$login = \"".gettemplate("access_error_login")."\";");
	}
	else eval ("\$login = \"".gettemplate("access_error_logout")."\";");
	eval("dooutput(\"".gettemplate("access_error")."\");");
	exit;
}


// PN Popup
if($user_id && $pms && $userdata['canusepms'] && !stristr($REQUEST_URI, "pms.php") && !stristr($REQUEST_URI, "pmpopup.php") && !stristr($REQUEST_URI, "action.php"))
{
	if($userdata['lastpmpopup']) $lastpmpopup=$userdata['lastpmpopup'];
	else $lastpmpopup=0;
	$pms_result=$db_zugriff->query_first("SELECT count(pmid) FROM bb".$n."_pms 
	WHERE recipientid=$user_id AND view=0 AND sendtime>=$lastpmpopup AND sendtime>=$old_time");
	$showpmpopup = $pms_result[0];
}
?>