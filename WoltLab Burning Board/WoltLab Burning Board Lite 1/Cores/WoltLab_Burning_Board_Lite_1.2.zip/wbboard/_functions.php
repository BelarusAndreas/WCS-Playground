<?php




/**
* @return result bool
* @param varname string
* @desc Registriert die Variable ${$varname} in einer Session.
* Dank einem Bug in php4 sind wir gezwungen, je nach Konfiguration session_register()
* oder $HTTP_SESSION_VARS/$_SESSION zu verwenden.
*/
function wbb_session_register($varname)
{
    global $register_globals, $HTTP_SESSION_VARS, ${$varname};
    $done = false;
    if($register_globals)
    {
        $done = session_register("$varname"); 
    }
    else
    {
        if($HTTP_SESSION_VARS[$varname] = ${$varname}) $done=true;
		if($_SESSION[$varname] =${$varname}) $done=true;
    }
    return $done; 
}







/**
* @return result bool
* @param varname string
* @desc L�scht die Variable ${$varname} aus einer Session.
* Dank einem Bug in php4 sind wir gezwungen, je nach Konfiguration session_unregister()
* oder $HTTP_SESSION_VARS/$_SESSION zu verwenden.
*/
function wbb_session_unregister($varname)
{
	global $register_globals, $HTTP_SESSION_VARS, ${$varname};
	$done = false;
	if($register_globals)
	{
		$done = session_unregister("$varname");
	}
	else
	{
		unset($HTTP_SESSION_VARS[$varname]);
		unset($_SESSION[$varname]);
		$done=true;
	}
	return $done;
}




/**
* @return out string
* @param boardid int
* @param depth=1 int
* @desc Diese Funktion erstellt eine <option> Liste aller Boards.
* Die Struktur wird dabei rekursiv erstellt..
*/
function makeboardjumpbit2($bid,$depth=1) {
	global $boardcache, $boardid, $permissioncache;

	if(!isset($boardcache[$bid])) {
		return;
 	}
	$out = "";
  	while (list($key1,$val1) = each($boardcache[$bid])) {
    		while(list($key2,$boards) = each($val1)) {
			if($boards['invisible'] && !$permissioncache[$boards['boardid']]) continue;
			$out .= "<OPTION value=\"".$boards['boardid']."\"";
			if($boardid == $boards['boardid']) $out .= " selected";
			if($depth>1) $out .= ">".str_repeat("--",$depth-1)." ".$boards['boardname']."</option>";
			else $out .= ">".$boards['boardname']."</option>";
			$out.=makeboardjumpbit2($boards['boardid'],$depth+1);
     		} 
  	} 
  	unset($boardcache[$bid]);
  	return $out;
}


/**
* @return out string
* @param boardid int
* @param depth=1 int
* @desc Diese Funktion erstellt eine <option> Liste speziell f�r die Forenauswahl in der Suche.
* Die Stuktur wird auch hier rekursiv erstellt.
*/
function makeboardsearchbit($bid,$depth=1) {
	global $boardcache, $permissioncache;

	if ( !isset($boardcache[$bid]) ) {
		return;
	}

	if(!isset($out)) $out="";
	while ( list($key1,$val1)=each($boardcache[$bid]) ) {
		while ( list($key2,$boards)=each($val1) ) {
			if($boards['invisible'] && !$permissioncache[$boards['boardid']]) continue;
			$out .= "<OPTION value=\"+".$boards['boardid']."\"";
			if($depth>1) $out .= ">".str_repeat("--",$depth-1)." ".$boards['boardname']."</option>";
			else $out .= ">".$boards['boardname']."</option>";
			$out.=makeboardsearchbit($boards['boardid'],$depth+1);
		}
	}
	unset($boardcache[$bid]);
	return $out;
}





/**
 * @return void
 * @desc Diese Funktion f�llt die Arrays $_REQUEST $_POST $_GET $_COOKIE usw.
 * mit den Daten aus dem equivalenten Arrays aus PHP Versionen vor 4.10
 */
function get_vars_old()
{
	global $HTTP_COOKIE_VARS, $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_SERVER_VARS,$HTTP_ENV_VARS, $HTTP_SESSION_VARS, $_REQUEST, $_COOKIE, $_POST, $_GET, $_SERVER, $_FILES,$_ENV,$_SESSION;
	
	if(is_array($HTTP_COOKIE_VARS))
	{
		while(list($key,$val)=each($HTTP_COOKIE_VARS))
		{
			$_REQUEST[$key]=$val;
			$_COOKIE[$key]=$val;
		}
	}

	if(is_array($HTTP_POST_VARS))
	{
		while(list($key,$val)=each($HTTP_POST_VARS))
		{
			$_REQUEST[$key]=$val;
			$_POST[$key]=$val;
		}
	}

	if(is_array($HTTP_GET_VARS))
	{
		while(list($key,$val)=each($HTTP_GET_VARS))
		{
			$_REQUEST[$key]=$val;
			$_GET[$key]=$val;
		}
	}
	
	if(is_array($HTTP_POST_FILES))
	{
		while(list($key,$val)=each($HTTP_POST_FILES)){
			$_FILES[$key]=$val;
		}
	}
	
	if(is_array($HTTP_SERVER_VARS))
	{
		while(list($key,$val)=each($HTTP_SERVER_VARS))
		{
			$_SERVER[$key]=$val;
		}
	}
	
	if(is_array($HTTP_ENV_VARS))
	{
		while(list($key,$val)=each($HTTP_ENV_VARS))
		{
			$_ENV[$key]=$val;
		}
	}
	
	if(is_array($HTTP_SESSION_VARS))
	{
		while(list($key,$val)=each($HTTP_SESSION_VARS))
		{
			$_SESSION[$key]=$val;
		}
	}
}








/**
 * @return array array
 * @param array array
 * @desc Diese Funktion wendet die Funktion stripslashes()
 * auf alle Elemente eines Arrays (auch mehrdimensional) an.
 */
function stripslashes_array(&$array)
{
	reset($array);
	while(list($key,$val)=each($array))
	{
		if(is_string($val))
		{
			$array[$key]=stripslashes($val);
		}
		elseif(is_array($val))
		{
			/* rekursiver Aufruf bei mehrdimensionalem Array */
			$array[$key]=stripslashes_array($val);
		}
	}
	return $array;
}






/**
* @return array array
* @param array array
* @desc Diese Funktion wendet die Funktion htmlspecialchars() 
* auf alle Elemente eines Arrays (auch mehrdimensional) an.
*/
function htmlspecialchars_array(&$array)
{
	reset($array);
	while(list($key,$val)=each($array))
	{
		if(is_string($val))
		{
			$array[$key]=htmlspecialchars($val);
		}
		elseif(is_array($val))
		{
			/* rekursiver Aufruf bei mehrdimensionalem Array */
			$array[$key]=htmlspecialchars_array($val);
		}
	}
	return $array;
}




/**
* @return text string
* @param text string
* @desc rehtmlspecialchars() macht die Funktin htmlspecialchars() r�ckg�ngig.
*/
function rehtmlspecialchars($text) {
 $text = str_replace("&lt;","<",$text);
 $text = str_replace("&gt;",">",$text);	
 $text = str_replace("&quot;","\"",$text);
 $text = str_replace("&amp;","&",$text);
 return $text;
}


# -------- user funktionen

/**
* @return username string
* @param userid int
* @desc getUserid() ermittelt die Userid anhand des Benutzernamen
*/
function getUserid($usernick) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username='".addslashes($usernick)."'");
        return $result['userid'];
}




/**
* @return userid int
* @param username string
* @desc getUsername() ermittelt den usernamen anhand der userid
*/
function getUsername($userid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT username FROM bb".$n."_user_table WHERE userid='$userid'");
        return ($result['username']);
}



/**
* @return userid int
* @param email string
* @desc getUserEmail() ermittelt die eMail Adresse anhand der userid
*/
function getUserEmail($userid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT useremail FROM bb".$n."_user_table WHERE userid='$userid'");
        return $result['useremail'];
}



/**
* @return count int
* @param userid int
* @param password string
* @desc check_userdata() pr�ft, ob userid und passwort richtig sind.
* Der R�ckgabewert ist 0, wenn das passwort nicht stimmt und gr��er 0,
* wenn die Daten korrekt sind.
*/
function check_userdata($userid,$password) {
	global $n, $db_zugriff;
        $result = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE userid='$userid' AND userpassword = '".addslashes($password)."' AND activation = 1");
	return $result[0];        
}



/**
* @return check string
* @param username string
* @param password string
* @desc checkUser() pr�ft die kombination von benutzername und passwort.
* der R�ckgabewert ist 0, wenn der Benutzer nicht existiert und 2, wenn 
* die Daten korrekt sind und 1, wenn das Passwort falsch ist.
*/
function checkUser($username,$password) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT userpassword FROM bb".$n."_user_table WHERE username='".addslashes($username)."' && activation='1'");
        if(!$result['userpassword']) return 0;
        elseif($result['userpassword']==$password) return 2;
        else return 1;
}


/**
* @return password string
* @param userid int
* @desc getUserPW() gibt das verschl�sselte Passwort des Benutzers zur�ck.
*/
function getUserPW($userid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT userpassword FROM bb".$n."_user_table WHERE userid='$userid'");
        return $result['userpassword'];
}


/**
* @return rank string
* @param posts int
* @param groupid int
* @desc Diese Funktion ermittelt den Benutzerrang anhand der Beitragszahl und der Benutzergruppe.
*/
function getUserrang($posts,$groupid) {
        global $n,$db_zugriff;
        $rank = $db_zugriff->query_first("SELECT rank FROM bb".$n."_ranks WHERE groupid = $groupid AND posts<='$posts' ORDER by posts DESC");
        return $rank['rank'];
}








# -------- beitrags erstellung

/**
* @return valid int
* @param text string
* @desc Diese Funktion �berpr�ft die IMG Tags in einem Beitrag.
* Wird die maximale Zahl an Bildern �berschritten oder taucht eine
* unerlaubte Dateiendung auf oder kommt javascript:, vbscript: oder about:
* vor, so wird 1 (ung�ltig) zur�ckgegeben. Andernfalls 0 (g�ltig).
*/
function check_posts($text)
{
	global $image, $image_ext, $maximage;
	$extension_array = @explode("\r\n",trim(strtolower($image_ext)));
	$count=0;
	if(preg_match("/\[img].*(javascript:|vbscript:|about:).*\[\/img\]/siU",$text))
	{
		return 1;
	}
	else
	{
		do
		{
			$extension="";
			preg_match("/\[img]([^\"]*)\[\/img\]/siU",$text,$exp);
			if(!isset($exp[0])) $exp[0]="";
			if(!$exp[0]) break;
			$text = str_replace($exp[0],"",$text);
			$extension = strtolower(substr(strrchr($exp[1],"."),1));
			if(!in_array($extension, $extension_array))
			{
				return 1;
				break;
			}
			$count++;
		} while($exp[0]!="" && $count<=$maximage);

		if($count>$maximage) return 1;	
	}
}

/**
* @return valid int
* @param text string
* @desc Diese Funktion �berpr�ft die IMG Tags in einem Beitrag.
* Wird die maximale Zahl an Bildern �berschritten oder taucht eine
* unerlaubte Dateiendung auf oder kommt javascript:, vbscript: oder about:
* vor, so wird 1 (ung�ltig) zur�ckgegeben. Andernfalls 0 (g�ltig).
*/
function check_signature($text)
{
	global $image, $image_ext, $maximage;
	$extension_array = @explode("\r\n",trim(strtolower($image_ext)));
	$count=0;
	if(preg_match("/\[img].*(javascript:|vbscript:|about:).*\[\/img\]/siU",$text))
	{
		return 1;
	}
	else
	{
		do
		{
			$extension="";
			preg_match("/\[img]([^\"]*)\[\/img\]/siU",$text,$exp);
			if(!isset($exp[0])) $exp[0]="";
			if(!$exp[0]) break;
			$text = str_replace($exp[0],"",$text);
			$extension = strtolower(substr(strrchr($exp[1],"."),1));
			if(!in_array($extension, $extension_array))
			{
				return 1;
				break;
			}
			$count++;
		} while($exp[0]!="" && $count<=$maximage);

		if($count>$maximage) return 1;	
	}
}


// Kopie von check_signature //
function check_signature2($text) {
 global $sigimage, $sigimage_ext, $sigmaximage;
 $image_ext = explode("\r\n",trim($sigimage_ext));
 $count=0;
 
 if(preg_match("/\[img].*javascript.*\[\/img\]/siU",$text)) { 
 	return 1;
  }
 else {
  do {	
  $exp=array();
  preg_match("/\[img]([^\"]*)\[\/img\]/siU",$text,$exp);
  if(!isset($exp[0])) $exp[0]="";
  if(!$exp[0]) break;
  $text = str_replace($exp[0],"",$text);
  $extension = trim(strtolower(substr(strrchr($exp[1],"."),1)));
  if(!in_array($extension, $image_ext)) {
   return 1;
   break;
  }
  $count++;
 } while($exp[0]!="" && $count<=$sigmaximage);
 if($count>$sigmaximage) return 1;	}
}

/* wird nicht mehr ben�tig
* (durch das Auskommentieren finden wir auch  Fehler,
* wo diese Funktion noch benutzt wird.
*/
/*function editPostdata($data) {
 $data = str_replace("'","&acute;", $data);
 $data = str_replace("\"","&quot;", $data);
 return $data;
}*/





/**
* @return text string
* @param text string
* @desc Diese Funktion ersetzt Urls und email Adressen ohne BBCode durch die Adresse MIT bbcode.
* http://link wird zu [URL]http://link[/URL].. falls der URL Tag schon vorhanden ist, wird nichts ersetzt.
*/
function parseURL($out) {
 $urlsearch[]="/([^]_a-z0-9-=\"'\/])((https?|ftp):\/\/|www\.)([^ \r\n\(\)\*\^\$!`\"'\|\[\]\{\};<>]*)/si";
 $urlsearch[]="/^((https?|ftp):\/\/|www\.)([^ \r\n\(\)\*\^\$!`\"'\|\[\]\{\};<>]*)/si";
 $urlreplace[]="\\1[URL]\\2\\4[/URL]";
 $urlreplace[]="[URL]\\1\\3[/URL]";
 $emailsearch[]="/([\s])([_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,}))/si";
 $emailsearch[]="/^([_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,}))/si";
 $emailreplace[]="\\1[EMAIL]\\2[/EMAIL]";
 $emailreplace[]="[EMAIL]\\0[/EMAIL]";
 $out = preg_replace($urlsearch, $urlreplace, $out);
 if (strpos($out, "@")) $out = preg_replace($emailsearch, $emailreplace, $out);
 return $out;
}








# -------- beitrags anzeige

/* wird nicht mehr ben�tig
* (durch das Auskommentieren finden wir auch  Fehler,
* wo diese Funktion noch benutzt wird.
*/
/*function editDBdata($data) {
 $data = str_replace("&acute;","'", $data);
 $data = str_replace("&quot;","\"", $data); 
 return $data;
}*/



/**
* @return expression string
* @param expression string
* @desc escaped einen String f�r die Benutzung in einem regul�ren Ausdruck.
*/
function wbb_preg_quote($expression) { 
 $expression=preg_quote($expression); 
 $expression = str_replace("/","\/",$expression); 
 return $expression; 
} 


/**
* @return text string
* @param text string
* @desc Diese Funktion zensiert einen Beitrag.
*/
function censor($out) {
 global $cover,$badwords;
 reset($badwords);
 if(count($badwords)) {
  while (list($key, $val) = each($badwords)) {
   $val = trim($val);
   if(!$val) continue;
   if(preg_match("/\{(.+)\}/si", $val, $exp)) {
    $val = $exp[1];
    $position = strpos($val, "=");
    if($position===false) {
     $searcharray[] = "/([\s]{1})".wbb_preg_quote($val)."([\s]{1})/si"; 	                		
     $replacearray[] = "\\1".str_repeat($cover, strlen($val))."\\2";
     $searcharray[] = "/^".wbb_preg_quote($val)."([\s]{1})/si"; 	                		
     $replacearray[] = str_repeat($cover, strlen($val))."\\1";
     $searcharray[] = "/([\s]{1})".wbb_preg_quote($val)."$/si"; 	                		
     $replacearray[] = "\\1".str_repeat($cover, strlen($val));
    }
    else {
     $pcover = substr($val, $position+1);
     $val = substr($val, 0, $position);
     $searcharray[] = "/([\s]{1})".wbb_preg_quote($val)."([\s]{1})/si"; 	                		
     $replacearray[] = "\\1".$pcover."\\2";
     $searcharray[] = "/^".wbb_preg_quote($val)."([\s]{1})/si"; 	                		
     $replacearray[] = $pcover."\\1";
     $searcharray[] = "/([\s]{1})".wbb_preg_quote($val)."$/si"; 	                		
     $replacearray[] = "\\1".$pcover;
    }
   }
   else {
    $position = strpos($val, "=");
    if($position===false) {
     $out = eregi_replace("$val","".str_repeat($cover, strlen($val))."", $out);	                		
     $searcharray[] = "/".wbb_preg_quote($val)."/si"; 	                		
     $replacearray[] = str_repeat($cover, strlen($val));
    }
    else {
     $pcover = substr($val, $position+1);
     $val = substr($val, 0, $position);
     $searcharray[] = "/".wbb_preg_quote($val)."/si"; 	                		
     $replacearray[] = $pcover;
    }
   }
  }
 }
 // Bug: "Empty regular Expression" bei fehlender Zensurfunktion...
 if(!isset($searcharray)) $searcharray=array();
 if(!isset($replacearray)) $replacearray=array();
 return ifelse(count($searcharray) && count($replacearray),preg_replace($searcharray, $replacearray, $out),$out);
}




/**
* @return text string
* @param text string
* @desc Diese Funktion ersetzt Smiliecodes in einem Text durch die Smiliebilder.
*/
function smilies($out) {
	global $smiliecache;
	if(!count($smiliecache)) $smiliecache = getsmilies();
	for($i = 0; $i < count($smiliecache); $i++) $out=str_replace ($smiliecache[$i]['text'], "<img src=".$smiliecache[$i]['path']." border=0>", $out);
        return $out;
}





/**
* @return smiliecache array
* @desc Diese Funktion l�dt alle Smiliecodes und Pfade in einen Array (cache).
*/
function getsmilies() {
	global $db_zugriff, $n;
	$result = $db_zugriff->query("SELECT smiliespath as path, smiliestext as text FROM bb".$n."_smilies");
	$count = 0;
	while($row = $db_zugriff->fetch_array($result)) {
		$smiliecache[$count] = $row;
		$count++;
	}
	return $smiliecache;
}







/**
* @return text string
* @param text string
* @param disablesmilies=0 int
* @desc Diese Funktion ersetzt bearbeitet einen Beitrag zur Anzeige in einem Thema.
* HTML wird (wenn eingestellt) zensiert. Smilies werden (wenn eingestellt) ersetzt.
* Ferner wird die Zensur (wenn eingestellt) angewendet und BBCode (wenn eingestellt) wird ersetzt.
*/
function editPost($out,$disable_smilies=0) {
	global $bbcode,$html,$smilies,$badwords;
	$nlreplace=substr(md5(uniqid(microtime())),0,6);
	if(!$html) 
	{ 
		#$out = str_replace("&lt;","&amp;lt;",$out);
		#$out = str_replace("&gt;","&amp;gt;",$out);
		#$out = str_replace("<","&lt;",$out);
		#$out = str_replace(">","&gt;",$out);
		$out = htmlspecialchars($out);
  	}
	// <script> ist generell verboten...
	else $out = preg_replace("/<script[^>]*>/i","&lt;script\\1&gt;",$out);
	#$out = str_replace("\r\n",$nlreplace,$out);
	#$out = str_replace($nlreplace,"\r\n",$out);
	if($smilies && !$disable_smilies) $out = smilies($out);
	if($bbcode) $out = prepare_code($out);
	#$out = nl2br($out);
	$out = str_replace("\n","<br />",$out);
	$out = censor($out);
	$out = nt_wordwrap($out);
	return $out;
}







/**
* @return text string
* @param text string
* @param disablesmilies=0 int
* @desc Diese Funktion bearbeitet eine Signatur f�r die Anzeige in einem Thema.
* HTML wird ersetzt, Smilies und BBCode werden ersetzt und die Zensur angewendet.
*/
function editSignatur($out,$disable_smilies=0) {
        global $sigbbcode,$sightml,$sigsmilies,$badwords;
        #$out = editDBdata($out);
		$nlreplace=substr(md5(uniqid(microtime())),0,6);
        if(!$sightml)
		{
    		#$out = str_replace("&lt;","&amp;lt;",$out);
    		#$out = str_replace("&gt;","&amp;gt;",$out);
    		#$out = str_replace("<","&lt;",$out);
    		#$out = str_replace(">","&gt;",$out);
			$out = htmlspecialchars($out);
		}
		else $out = preg_replace("/<script[^>]*>/i","&lt;script\\1&gt;",$out);
		$out = str_replace("\r\n",$nlreplace,$out);
		$out = str_replace($nlreplace,"\n",$out);
		if($sigsmilies && !$disable_smilies) $out = smilies($out);
		if($sigbbcode) $out = prepare_code($out);
		#$out = nl2br($out);
		$out = str_replace("\n","<br />",$out);
        /*$out = nl2br($out);
        if($sigsmilies && !$disable_smilies) $out = smilies($out);
        if($sigbbcode) $out = prepare_code($out); */
        $out = censor($out);
        $out = nt_wordwrap($out);
        return $out;
}






/**
* @return return mixed
* @param expression boolean
* @param returntrue mixed
* @param returnfalse=null mixed
* @desc Diese Funktion gibt returntrue zur�ck, wenn expression true ergibt. Andernfalls wird returnfalse zur�ckgegeben.
*/
function ifelse($expression,$returntrue,$returnfalse="") {
	#if (!$expression) return $returnfalse;
	#else return $returntrue;
	return ($expression ? $returntrue : $returnfalse);
}






/**
* @return code string
* @param code string
* @desc Diese Funktion formatiert Code mit dem <pre> Tag
*/
function formatcodetag($code) {
	#$code = str_replace("<br>","",$code);
	#$code = str_replace("<br />","",$code);
	$code = str_replace("\\\"","\"",$code);
	return "<blockquote><pre><font size=1>code:</font><hr><p>".$code."</p><hr></pre></blockquote>";
}





/**
* @return link string
* @param url string
* @param title=null string
* @param maxwidth=60 int
* @param width1=40 int
* @param width2=-15 int
* @desc Diese Funktion gibt einen Link zu url mit dem Titel title zur�ck.
* Ist der Titel l�nger als maxwidth und kommt kein IMG Tag darin vor, wird er "abgeschnitten".
*/
function formaturl($url, $title="", $maxwidth=60, $width1=40, $width2=-15) {
 if(!trim($title)) $title=$url;
 if(!preg_match("/[a-z]:\/\//si", $url)) $url = "http://$url";
 if(strlen($title)>$maxwidth && !stristr($title,"[img]")) $title = substr($title,0,$width1)."...".substr($title,$width2);
 return "<a href=\"$url\" target=\"_blank\">".str_replace("\\\"", "\"", $title)."</a>";
}






/**
* @return list string
* @param list string
* @param listtype=null string
* @desc Diese Funktion formatiert eine Liste...
*/
function formatlist($list, $listtype="") {
 $listtype = ifelse(!trim($listtype), "",  " type=\"$listtype\"");
 $list = str_replace("\\\"","\"",$list);
 if ($listtype) return "<ol$listtype>".str_replace("[*]","<li>", $list)."</ol>";
 else return "<ul>".str_replace("[*]","<li>", $list)."</ul>";
}







/**
* @return highlighted_code string
* @param code string
* @desc Diese Funktion formatiert einen Code innerhalb eines PHP Tags mit highlight_string() 
*/
function phphighlite($code) {

 #$code = str_replace("\\\"","\"",$code);
 $code = rehtmlspecialchars($code);
 #$code = str_replace("&gt;", ">", $code);
 #$code = str_replace("&lt;", "<", $code);
 #$code = str_replace("&amp;", "&", $code);
 #$code = str_replace('$', '\$', $code);
 #$code = str_replace('\n', '\\\\n', $code);
 #$code = str_replace('\r', '\\\\r', $code);
 #$code = str_replace('\t', '\\\\t', $code);
 #$code = str_replace("<br>", "", $code);
 #$code = str_replace("<br />", "", $code);
 $code = stripslashes($code);
 if(!strpos($code,"<?") && substr($code,0,2)!="<?") $code="<?php\n".trim($code)."\n?>";
 $code = trim($code);
 ob_start();
 $oldlevel=error_reporting(0);
 highlight_string($code);
 error_reporting($oldlevel);
 $buffer = ob_get_contents();
 ob_end_clean();
 #$buffer = str_replace("<br />", "",$buffer);

 #$buffer = str_replace("&quot;", "\"", $buffer);
 #echo nl2br(htmlspecialchars($buffer))."<hr>";
 return "<blockquote><pre><font size=1>php:</font><hr><p>$buffer</p><hr></pre></blockquote>";
}







/**
* @return out string
* @param out string
* @desc ..
*/
function prepare_quote($out) {
        global $zensur;
        #$out = editDBdata($out);
        if($zensur == 1) $out = censor($out);
        return $out;
}








/**
* @return topic string
* @param topic string
* @desc Diese Funktion zensiert HTML in einem String..
*/
function prepare_topic($out) { 
	#return htmlspecialchars(nt_wordwrap(editDBdata($out),40)); 
	return htmlspecialchars(nt_wordwrap($out,45));
}
// Kopie von prepare_topic() //
function prepare_topic2($out) { 
	#return htmlspecialchars(nt_wordwrap(editDBdata($out),40)); 
	return htmlspecialchars(stripslashes(nt_wordwrap($out,40)));
}













# -------- sonstige

/**
* @return mods string
* @param boardid int
* @desc Gibt eine Liste mit den Moderatoren eines Forums zur�ck.
*/
function getMod($id) {
        global $boardid,$styleid,$session,$db_zugriff,$n;
        $result = $db_zugriff->query("SELECT objectid,username FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON bb".$n."_user_table.userid=bb".$n."_object2board.objectid WHERE boardid = '$id' AND mod = 1"); 
		$mods = "";
        while($row = $db_zugriff->fetch_array($result)) {
        	if($mods) $mods .= ", ";
        	$mods .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=".$boardid."&styleid=".$styleid.$session."\">".($row['username'])."</a>";
        }
        return $mods;
}
/*function getMod($id) {
        global $boardid,$styleid,$session,$db_zugriff,$n;
        $result = $db_zugriff->query("SELECT objectid FROM bb".$n."_object2board WHERE boardid = '$id' AND mod = 1"); 
		$mods = "";
        while($row = $db_zugriff->fetch_array($result)) {
        	if($mods) $mods .= ", ";
        	$mods .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=".$boardid."&styleid=".$styleid.$session."\">".getUsername($row['objectid'])."</a>";
        }
        return $mods;
}*/



/**
* @return lastauthor string
* @param threadid int
* @desc Gibt den letzten Autor in einem Thema zur�ck... (mit Link zum profil).
*/
function getLastAuthor($threadid) {
        global $boardid,$n,$db_zugriff,$session;
        $result = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE threadparentid='$threadid' ORDER by posttime DESC LIMIT 1");
        return "<a href=\"members.php?mode=profile&userid=$result[userid]&boardid=$boardid$session\">".getUsername($result['userid'])."</a>";
}



/**
* @return flag int
* @param threadid int
* @desc Gibt den/die/das (*gg*) Flag eines thread zur�ck. 1 entspricht geschlossen, 0 entspricht offen.
* Damit �berpr�ft man also, ob ein Thread geschlossen ist oder nicht.
*/
function getThreadflag($threadid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT flags FROM bb".$n."_threads WHERE threadid='$threadid'");
        return $result['flags'];
}



/**
* @return highlighted_code string
* @param code string
* @desc Diese Funktion formatiert einen Code innerhalb eines PHP Tags mit highlight_string() 
*/
function getBoardname($boardid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT boardname FROM bb".$n."_boards WHERE boardid='$boardid'");
        return prepare_topic($result['boardname']);
}




/**
* @return threadname string
* @param threadid int
* @desc Ermittelt den Namen eines Themas anhand der ID und gibt ihn zur�ck..
*/
function getThreadname($threadid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT threadname FROM bb".$n."_threads WHERE threadid='$threadid'");
        return prepare_topic($result['threadname']);
}


/**
* @return url string
* @param id int
* @param nr int
* @desc Ermittelt die URL zum letzten Beitrag 1) eines Themas 2) eines Forums 3) eines Benutzers
*/
function getLastPost($id,$nr) {
        global $eproseite, $n, $db_zugriff, $session, $longdateformat, $postorder, $sid, $styleid;
        if($nr==1) {
                $result = $db_zugriff->query_first("SELECT threadid,replies FROM bb".$n."_threads WHERE boardparentid='$id' ORDER by timelastreply DESC LIMIT 1");
                $threadid = $result['threadid'];
               	if($postorder) return "thread.php?threadid=".$threadid."&boardid=".$id."$session&page=1#1";
                else {
                	$posts = $result['replies']+1;
			$pages=(int)($posts/$eproseite);
                	if(($posts/$eproseite)-$pages>0) $pages++;
	                return "thread.php?threadid=".$threadid."&boardid=".$id."$session&page=".$pages."#".$posts;
        	}
        }
        if($nr==2) {
                $result = $db_zugriff->query_first("SELECT boardparentid,replies FROM bb".$n."_threads WHERE threadid='$id' LIMIT 1");
                $boardid = $result['boardparentid'];
                if($postorder) return "thread.php?threadid=".$id."&boardid=".$boardid."$session&page=1#1";
                else {
                	$posts = $result['replies']+1;
			$pages=(int)($posts/$eproseite);
                	if(($posts/$eproseite)-$pages>0) $pages++;
			return "thread.php?threadid=".$id."&boardid=".$boardid."$session&page=".$pages."#".$posts;
		}
        }
        if($nr==4) {
                $result = $db_zugriff->query_first("SELECT threadparentid, boardparentid FROM bb".$n."_posts WHERE userid='$id' ORDER by posttime DESC LIMIT 1");
               	$threadid = $result['threadparentid'];
                if($postorder) return "thread.php?threadid=".$threadid."&boardid=".$result['boardparentid']."$session&page=1#1";
        	else {
                	$result = $db_zugriff->query_first("SELECT boardparentid,replies FROM bb".$n."_threads WHERE threadid='$threadid'");
                	$posts = $result['replies']+1;
                	$pages=(int)($posts/$eproseite);
                	if(($posts/$eproseite)-$pages>0) $pages++;
                	return "thread.php?threadid=".$threadid."&boardid=".$result['boardparentid']."&styleid=$styleid$session&page=".$pages."#".$posts;
        	}
        }
        if($nr==5) {
                $result = $db_zugriff->query_first("SELECT threadparentid, boardparentid FROM bb".$n."_posts WHERE userid='$id' ORDER by posttime DESC LIMIT 1");
               	$threadid = $result['threadparentid'];
                if($postorder) return "thread.php?threadid=".$threadid."&boardid=".$result['boardparentid']."$session&page=1#1";
        	else {
                	$result = $db_zugriff->query_first("SELECT boardparentid,replies FROM bb".$n."_threads WHERE threadid='$threadid'");
                	$posts = $result['replies']+1;
                	$pages=(int)($posts/$eproseite);
                	if(($posts/$eproseite)-$pages>0) $pages++;
                	return "thread.php?threadid=".$threadid."&boardid=".$result['boardparentid']."&styleid=$styleid$session&page=".$pages."#".$posts;
        	}
        }
}





/**
* @return url string
* @param threadid int
* @param time int
* @desc Ermittelt die URL des ersten neuen Beitrags in einem Themas.
*/
function firstnewPost($threadid,$time) {
        global $eproseite,$n,$db_zugriff,$styleid,$session, $postorder;
        $sthreadname = "sthread_".$threadid;
	global $$sthreadname;
	if($$sthreadname > $time) $time = $$sthreadname+1;
        
        $thread = $db_zugriff->query_first("SELECT boardparentid, replies FROM bb".$n."_threads WHERE threadid='$threadid' ORDER by timelastreply DESC");
        $posts = $thread['replies']+1;

        $result = $db_zugriff->query("SELECT posttime FROM bb".$n."_posts WHERE threadparentid='$threadid' ORDER by posttime ".ifelse($postorder,"DESC","ASC"));
        $i=1;
        while($row = $db_zugriff->fetch_array($result)) {
                if($time<=$row['posttime']) break;
                $i++;
        }
        $db_zugriff->free_result($result);
        $j=(int)($i/$eproseite);
        if(($i/$eproseite)-$j>0) $j++;

        return "thread.php?threadid=".$threadid."&boardid=".$thread[boardparentid]."&styleid=$styleid$session&page=".$j."#".$i;
}






/**
* @return isonline int
* @param userid int
* @desc �berpr�ft, ob ein Benutzer online ist. Gibt 1 zur�ck, wenn er online ist, andernfalls 0.
*/
function checkuseronline($userid) {
        global $n,$db_zugriff, $timeout;
        $user = $db_zugriff->query_first("SELECT COUNT(userid) as anzahl FROM bb".$n."_user_table WHERE userid='$userid' AND invisible='0'");
        if($user['anzahl']) $anzahl = $db_zugriff->query_first("SELECT COUNT(zeit)as anzahl FROM bb".$n."_useronline WHERE userid='$userid' AND zeit>='".(time()-60*$timeout)."'");
        return $anzahl['anzahl'];
}



/**
* @return result int
* @param postid int
* @param threadid int
* @param boardid int
* @desc L�scht einen Beitrag in einem Thema. Sind keine Antworten mehr in einem Thema, wird auch das Thema gel�scht.
* Wird nur ein Beitrag gel�scht, wird 1 zur�ckgegeben. Wenn auch das Thema gel�scht wird, wird 2 zur�ckgegeben.
*/
function delPost($postid,$threadid,$boardid) {
        global $n,$db_zugriff;
        $threadinfo = $db_zugriff->query_first("SELECT replies FROM bb".$n."_threads WHERE threadid = '$threadid'");
        if(!$threadinfo['replies']) { // keine Antworten mehr => Thema auch l�schen.
                $author = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE postid = '$postid'");
                delUserposts($author[0]);
               	$db_zugriff->query("DELETE FROM bb".$n."_threads WHERE threadid='$threadid'");
                $db_zugriff->query("DELETE FROM bb".$n."_posts WHERE postid='$postid'");
               	
               	$pinfo = $db_zugriff->query_first("SELECT postid, posttime, userid FROM bb".$n."_posts WHERE boardparentid = '$boardid' ORDER BY posttime DESC LIMIT 1");
                $db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads-1, posts=posts-1, lastposttime = '$pinfo[posttime]', lastpostid = '$pinfo[postid]' WHERE boardid = '$boardid'");
                
                $db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid='$threadid'");
                $db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid='$threadid'");
                $db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid='$threadid'");
                $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid='$threadid' AND favthreads = 1");
                
                return 2;
        }
        else { // nur beitrag l�schen..
                $author = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE postid = '$postid'");
                delUserposts($author[0]);
                $db_zugriff->query("DELETE FROM bb".$n."_posts WHERE postid='$postid'");
                $tinfo=$db_zugriff->query_first("SELECT userid, posttime FROM bb".$n."_posts WHERE threadparentid='$threadid' ORDER BY posttime DESC");
                $db_zugriff->query("UPDATE bb".$n."_threads SET replies=replies-1, timelastreply='$tinfo[posttime]', lastposterid='$tinfo[userid]' WHERE threadid = '$threadid'");
                
                $pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$boardid' ORDER BY posttime DESC LIMIT 1");
                $db_zugriff->query("UPDATE bb".$n."_boards SET posts=posts-1, lastposttime = '$pinfo[posttime]', lastpostid = '$pinfo[postid]' WHERE boardid = '$boardid'");
                
                return 1;
        }
}



/**
* @return void
* @param userid int
* @desc Verringert die Beitragszahl des Benutzers um 1. (wenn ein Beitrag gel�scht wird).
*/
function delUserposts($userid) {
        global $n,$db_zugriff;
        $db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts-1 WHERE userid='$userid'");
}



/**
* @return date string
* @param time int
* @param format string
* @param replacetoday=0 int
* @desc Gibt die Zeit time formatiert nach format zur�ck.
* Ist replacetoday=1, wird das heutige Datum durch "heute" ersetzt.
*/
function formatdate($time,$format,$replacetoday=0) {
	global $db_zugriff, $n, $timetype, $timeoffset, $today;
	$time = $time+(3600*$timeoffset);
	if(date("dmY", time()+(3600*$timeoffset))==date("dmY", $time) && $replacetoday) { // heute ersetzen.
		$position = strpos($today, "=");
                if($position!==false) {	                		
                	$pcover = substr($today, $position+1);
                	$val = substr($today, 0, $position);
                	$format = str_replace($val,$pcover, $format);
                }
	}
	$out = str_replace("DD",date("d", $time), $format);
	$out = str_replace("MM",date("m", $time), $out);
	$out = str_replace("YYYY",date("Y", $time), $out);
	$out = str_replace("YY",date("y", $time), $out);
	$out = str_replace("MN",get_month_name(date("n", $time)), $out);
	if($timetype) { #12 Stunden
		$out = str_replace("II","II ".date("A", $time), $out);	
		$out = str_replace("HH",date("h", $time), $out);
	}
	else $out = str_replace("HH",date("H", $time), $out);
	$out = str_replace("II",date("i", $time), $out);
	return $out;
}





/**
* @return template string
* @param templatename string
* @param extension='htm' string
* @desc gibt den Inhalt der Template template zur�ck. Benutzt einen Cache..
*/
function gettemplate($template,$endung="htm") {
        global $templatefolder,$templatecache;
		// noch nicht im Cache
		if(!isset($templatecache[$template]))
		{
	        if(!$templatefolder) $templatefolder = "templates";
			$templatecache[$template] = implode("",file($templatefolder."/".$template.".".$endung));
		}
		return str_replace("\"","\\\"",$templatecache[$template]);
}




/**
* @return void
* @param template string
* @desc Ersetzt in template einige Codew�rter zur Formatierung und gibt template dann auf dem Bildschirm aus.
*/
function dooutput($template) {
        global $_SESSION, $_COOKIE, $db_zugriff,$bgcolor, $tablebg, $tableb, $tablec, $tabled, $tablea, $font, $fontcolor, $fontcolorsec, $fontcolorthi, $fontcolorfour, $bgfixed, $bgimage, $imagefolder;
        
        $template = str_replace("{pagebgcolor}","$bgcolor",$template);
        $template = str_replace("{tablebordercolor}","$tablebg",$template);
        $template = str_replace("{tablea}","$tablea",$template);
        $template = str_replace("{tableb}","$tableb",$template);
        $template = str_replace("{tablec}","$tablec",$template);
        $template = str_replace("{tabled}","$tabled",$template);
        $template = str_replace("{font}","$font",$template);
        $template = str_replace("{fontcolorfirst}","$fontcolor",$template);
        $template = str_replace("{fontcolorsecond}","$fontcolorsec",$template);
        $template = str_replace("{fontcolorthird}","$fontcolorthi",$template);
        $template = str_replace("{fontcolorfourth}","$fontcolorfour",$template);
        $template = str_replace("{imagefolder}","$imagefolder",$template);
		

        if($bgimage) $hgpicture = " background=\"$bgimage\"";
		if(isset($hgpicture)) $template = str_replace("{hgpicture}","$hgpicture",$template);
        if($bgfixed) $template = str_replace("{bgproperties}"," bgproperties=fixed",$template);
        else $template = str_replace("{bgproperties}","",$template);
        echo $template;

}




// ##########################  Neuen Post einf�gen * ########################################################

/**
* @return result int
* @param boardid int
* @param threadid int
* @param userid int
* @param subject string
* @param message string
* @param posticon int
* @param parseurl int
* @param email int
* @param disablesmilies int
* @param signature int
* @param close int
* @desc erstellt einen neuen Beitrag im Thema mit der id threadid und dem board mit der id boardid
* mit dem Inhalt subject und message. Ausserdem gibt es einige Parameter.
* Gibt 4 zur�ck, wenn der Beitrag erstellt wurde. Wenn der Beitrag nicht erstellt werden konnte, weil das Thema
* schon geschlossen ist, wird 2 zur�ckgegben.
*/
function newPost($boardid,$threadid,$userid,$subject,$message,$posticon,$parseurl,$email,$disablesmilies,$signature,$close)
{
	global $n,$db_zugriff,$REMOTE_ADDR;
	$thread_info = $db_zugriff->query_first("SELECT boardparentid,flags FROM bb".$n."_threads WHERE threadid='$threadid'");
	if($thread_info['flags']==1) return 2; // Thema schon geschlossen..
	else // Beitrag speichern.
	{
		$time = time();
		if($parseurl) $message = parseURL($message);

		if($disablesmilies!=1) $disablesmilies=0;
		if($signature!=1) $signature=0;

		$db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts+1 WHERE userid='$userid'");
		$db_zugriff->query("UPDATE bb".$n."_threads SET replies=replies+1, lastposterid='$userid', timelastreply='$time' WHERE threadid='$threadid'");
		$db_zugriff->query("INSERT INTO bb".$n."_posts (boardparentid,threadparentid,userid,posttime,posttopic,message,posticon,disable_smilies,signature,ip) VALUES ('$boardid','$threadid','$userid','$time','$subject','$message','$posticon','$disablesmilies','$signature','$REMOTE_ADDR')");

		$postid = $db_zugriff->insert_id();
		$db_zugriff->query("UPDATE bb".$n."_boards SET posts=posts+1, lastposttime = '$time', lastpostid = '$postid' WHERE boardid = '$boardid'");	

		sendEmail($userid,getLastPost($userid,5),$threadid,$boardid);
		if($email && $userid) // eMail Benachrichtigung einf�gen.
		{
			$check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_notify WHERE threadid = '$threadid' AND userid = '$userid'");
			if(!$check[0]) $db_zugriff->query("INSERT INTO bb".$n."_notify (threadid,userid) VALUES ($threadid,$userid)");
		}
		// Thema auch gleich schliessen
		if($close) $db_zugriff->query("UPDATE bb".$n."_threads SET flags = 1 WHERE threadid = '$threadid'");
		return 4;
	}
}






// ##########################  Useronline * ########################################################

/**
* @return void
* @param user_id int
* @desc diese Funktion wird bei jedem Seitenaufruf aufgerufen und tr�gt den Benutzer
* in die useronlineliste ein bzw. aktualisiert seinen Eintrag.
*/
function useronline($user_id)
{
	global $useronlinelastemptied,$timeout,$n,$db_zugriff,$rekord,$sid,$REMOTE_ADDR;
	$deltime = time()-($timeout*60);


	// Registrierter Benutzer .. keine ip
	if($user_id)
	{
		$db_zugriff->query("REPLACE INTO bb".$n."_useronline (sid,zeit,ip,userid) VALUES ('$sid','".time()."','','$user_id')");
		$db_zugriff->query("DELETE FROM bb".$n."_useronline WHERE userid=$user_id AND sid<>'$sid'");
	}
	
	// Gast, identifizierung anhand der ip..
	else
	{
		$db_zugriff->query("REPLACE INTO bb".$n."_useronline (sid,zeit,ip,userid) VALUES ('$sid','".time()."','$REMOTE_ADDR','')");
	}
	
	
	// Wenn die letzte "L�schung" mehr als timeout Minuten zur�ckliegt,
	// ist es Zeit f�r die n�chste ;)
	if((time()-$timeout*60)>$useronlinelastemptied)
	{
		$db_zugriff->query("DELETE FROM bb".$n."_useronline WHERE zeit<'$deltime'");
		$db_zugriff->query("UPDATE bb".$n."_config SET useronlinelastemptied='".time()."'");
	}
	
	// Useronline Rekord aktualisieren..
	$user = $db_zugriff->query_first("SELECT COUNT(zeit) as anzahl FROM bb".$n."_useronline");
	if($user['anzahl']>$rekord) $db_zugriff->query("UPDATE bb".$n."_config set rekord='".$user['anzahl']."', rekordtime='".time()."'");
}









/**
* @return void
* @param userid int
* @param link string
* @param threadid int
* @param boardid int
* @desc Wenn jemand die Email Benachrichtigung zum Thema mit der id threadid aktiviert hat,
* wird eine Benachrichtigung per email gesendet, dass der benutzer (mit der id userid) einen neuen
* Beitrag im Thema (mit der Id threadid - im Board mit der id boardid) geschrieben hat.
* link ist die direkte URL zu diesem Beitrag.
*/
function sendEmail($userid,$link,$threadid,$boardid) {
        global $boardid, $master_email, $php_path, $db_zugriff, $n;
        $result = $db_zugriff->query("SELECT * FROM bb".$n."_notify WHERE threadid = '$threadid'");
        if($db_zugriff->num_rows($result)) {
        	$boardname = getBoardname($boardid);
              	$threadname = getThreadname($threadid);
              	if($userid) $authorname = getUsername($userid);
              	else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
              	eval ("\$inhalt = \"".gettemplate("notify_inhalt")."\";");
                eval ("\$betreff = \"".gettemplate("notify_betreff")."\";");
                while($row = $db_zugriff->fetch_array($result)) {
                        if($row['userid']==$userid) continue;
                        $email = getUserEmail($row['userid']);
                        mail($email,$betreff,$inhalt.$row['userid'],"From: ".$master_email);
                }
        }
}





// ##########################  activation * ########################################################
/**
* @return result int
* @param userid int
* @param code int
* @desc Aktiviert den Benutzeraccount mit der id userid,
* wenn der code mit dem in der Datenbank �bereinstimmt (der bei der Registrierung versendet wurde).
* Gibt bei Erfolg 0 zur�ck; wenn der Benutzeraccount nicht exisiert, wird 1 zur�ckgegen.
* Ist der Benutzeraccount schon aktiviert, wird 2 zur�ckgegeben. Wenn der Code falsch ist, wird 3 zur�ckgegeben.
*/
function activat($userid,$code)
{
        global $n,$db_zugriff;
        $anzahluser = $db_zugriff->query_first("SELECT COUNT(userid)as anzahl FROM bb".$n."_user_table WHERE userid='$userid'");
        if($anzahluser['anzahl']==0) return 1; // kein Benutzer gefunden.
        else {
                $result = $db_zugriff->query("SELECT activation FROM bb".$n."_user_table WHERE userid='$userid' && activation!='1'");
                $anzahluser = $db_zugriff->num_rows($result);
                if($anzahluser==0) return 2; // Benutzeraccount ist schon aktiviert.
                else {
                        $result = $db_zugriff->fetch_array($result);
                        if($code==$result['activation']) $db_zugriff->query("UPDATE bb".$n."_user_table SET activation='1' WHERE userid='$userid'");
                        else return 3; // falscher Code
                }
        }
}



/**
* @return output string
* @param userid int
* @param id int
* @param b_or_t string
* @desc F�gt ein Board/Thema zu den Favoriten des Benutzers userid hinzu.
*/
function subscripe($userid,$id,$b_or_t) {
        global $n,$db_zugriff,$favboards,$favthreads;
		$output="";
        if($b_or_t == "b") $max = $favboards;
        else $max = $favthreads;
        $field = "fav".$b_or_t;
        if(!check_userobject($userid,$id,$field)) {
		$count = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2user WHERE userid = '$userid' AND $field = 1");
		if($count[0] >= $max) eval ("\$output = \"".gettemplate("error24")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,$field) VALUES ('$userid','$id','1')");
	}
        return $output;
}



/**
* @return color string
* @param zeilennr int
* @desc Gibt abwechselnd 'tableb'/'tablec' zur�ck.
*/
function rowcolor($zeile) {
        if (($zeile/2) != floor($zeile/2)) $color="tableb";
        else $color="tablec";
        return $color;
}





/**
* @return boardid int
* @param threadid int
* @desc gibt die id des Forums zur�ck.
*/
function getBoardparent($threadid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT boardparentid FROM bb".$n."_threads WHERE threadid='$threadid'");
        return $result['boardparentid'];
}




/**
* @return void
* @param id int
* @param userid int
* @param b_or_t string
* @desc Entfernt ein Board/Thema aus den Favoriten des Benutzers userid
*/
function unsubscripe($id,$userid,$b_or_t) {
        global $n,$db_zugriff;
        $field = "fav".$b_or_t;
        $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$userid' AND objectid = '$id' AND $field = 1");
}






/**
* @return userstars string
* @param posts int
* @param groupid int
* @desc gibt einen String mit den Bildern des Ranges zur�ck, der mit posts und groupid ermittelt wird.
*/
function getUserStars($posts,$groupid) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT id, rank, grafik, mal FROM bb".$n."_ranks WHERE groupid = $groupid AND posts<='$posts' ORDER by posts DESC");
              
       # for($i = 0; $i<$result[mal]; $i++) {
        #        $out .= "<img src=\"".$result['grafik']."\" border=\"0\">";
        #}
		$out = str_repeat("<img src=\"".$result['grafik']."\" border=\"0\">",$result['mal']);
        return "<a href=\"javascript:rank($result[id])\" title=\"Informationen zum Rang $result[rank]\">".$out."</a>";
}





/**
* @return void
* @param absender string
* @param message string
* @param betreff string
* @useremail string
* @desc Schickt �ber das Board eine email an useremail mit dem Absender absender und dem Inhalt betreff und message
*/
function formmail($absender,$message,$betreff,$useremail) {
        global $master_board_name, $php_path;
        $useremail = trim($useremail);
        #$message .= "\n\n_________________________________________________________________\nPowered by: ".$master_board_name." - ".$php_path;
		eval ("\$message = \"".gettemplate("formmail_message2")."\";");
        $absender = "From: ".$absender;
        mail($useremail,$betreff,$message,$absender);
}




/**
* @return void
* @param userid int
* @param postid int
* @param boardid int
* @param threadid int
* @desc Schickt eine eMail an den moderator des Forums boardid und meldet den Beitrag mit der id postid.
*/
function report($userid,$postid,$boardid,$threadid) {
        global $master_board_name, $php_path, $master_email, $db_zugriff, $n, $eproseite;
        $mod = $db_zugriff->query_first("SELECT bb".$n."_object2board.objectid, useremail FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid=bb".$n."_user_table.userid) WHERE boardid='$boardid' AND mod=1");
        if(!$mod['useremail']) $mod = $db_zugriff->query_first("SELECT bb".$n."_object2board.objectid, useremail FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid=bb".$n."_user_table.userid) WHERE mod=1");
        if(!$mod['useremail']) $mod = $db_zugriff->query_first("SELECT bb".$n."_groups.id, useremail FROM bb".$n."_groups LEFT JOIN bb".$n."_user_table ON (bb".$n."_groups.id=bb".$n."_user_table.groupid) WHERE ismod=1 OR issupermod=1 ORDER BY ismod DESC");      
		$posts = $db_zugriff->query("SELECT postid,userid FROM bb".$n."_posts WHERE threadparentid='".$threadid."' ORDER BY posttime ASC");
		$i=0;
		while($post=$db_zugriff->fetch_array($posts))
		{
			$i++;
			if($post['postid']==$postid) break;
		}
		$page=ceil($i/$eproseite);
	    $authorname = getUsername($post['userid']);
        $username = getUsername($userid);
        eval ("\$betreff = \"".gettemplate("report_betreff")."\";");
        eval ("\$message = \"".gettemplate("report_mail")."\";");
        mail(trim($mod['useremail']),$betreff,$message,"From: ".$master_email);
}




// ###################### Get Code Buttons #######################
/**
* @return bbcode_buttons string
* @desc l�dt die Templates f�r die bbcode buttons und gibt den inhalt zur�ck.
*/
function getcodebuttons() {
        $modechecked[0] = "CHECKED";
		$modechecked[1] = "";

        eval ("\$bbcode_sizebits = \"".gettemplate("bbcode_sizebits")."\";");
        eval ("\$bbcode_fontbits = \"".gettemplate("bbcode_fontbits")."\";");
        eval ("\$bbcode_colorbits = \"".gettemplate("bbcode_colorbits")."\";");
        eval ("\$bbcode_alignbits = \"".gettemplate("bbcode_alignbits")."\";");
        eval ("\$bbcode_buttons = \"".gettemplate("bbcode_buttons")."\";");
        return $bbcode_buttons;
}

// ###################### Get Clicky Smilies #######################
/**
* @return bbcodesmilies string
* @param tableColumns=3 int
* @param maxSmilies=-1 int
* @desc generiert eine HTML Tabelle mit allen Smilies (die man anklicken kann - zum einf�gen in beitr�ge).
* tableColumns Smilies pro Reihe.
*/
function getclickysmilies ($tableColumns=3,$maxSmilies=-1) {
        global $session,$boardid,$styleid, $db_zugriff, $n, $sid;

        $result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies");
	$totalSmilies = $db_zugriff->num_rows($result);

        if (($maxSmilies == -1) || ($maxSmilies >= $totalSmilies)) $maxSmilies = $totalSmilies;
        elseif ($maxSmilies < $totalSmilies) eval ("\$bbcode_smilies_getmore = \"".gettemplate("bbcode_smilies_getmore")."\";");

	$i=0;
        while($row = $db_zugriff->fetch_array($result)) {
        	eval ("\$smilieArray[\"".$i."\"] = \"".gettemplate("bbcode_smiliebit")."\";");
        	$i++;
        }
        $tableRows = ceil($maxSmilies/$tableColumns);
        $count = 0;
		$smiliebits = "";
        for ($i=0; $i<$tableRows; $i++) {
                $smiliebits .= "\t<tr bgcolor=\"{tableb}\">\n";
                for ($j=0; $j<$tableColumns; $j++) {
                        $smiliebits .= "\t<td align=\"center\">".$smilieArray[$count]."&nbsp;</td>\n";
                        $count++;
                }
                $smiliebits .= "\t</tr>\n";
        }

        eval ("\$bbcode_smilies = \"".gettemplate("bbcode_smilies")."\";");
        return $bbcode_smilies;
}



/**
* @return userposts int
* @param username string
* @desc ermittelt die Beitragszahl des Benutzers username und gibt sie zur�ck.
*/
function getUserposts($name) {
	global $db_zugriff, $n;
	// Ich bin nicht sicher, wie die Funktion aufgerufen wird (habs net gefunden).
	// also ob addslashes() und htmlspecialchars() schon auf den Benutzername angewendet wurden oder nicht.
	$result = $db_zugriff->query_first("SELECT userposts FROM bb".$n."_user_table WHERE username='".addslashes(htmlspecialchars($name))."'");
	#$result = $db_zugriff->query_first("SELECT userposts FROM bb".$n."_user_table WHERE username='".$name."'");
	return $result['userposts'];
}



/**
* @return result int
* @param boardid int
* @param objectid int
* @param field string
* @desc �berpr�ft, ob man Zugriff auf ein Forum hat, ob man moderator ist etc.
* R�ckgabewert: bei Erfolg 1, ansonsten 0.
*/
function check_boardobject($boardid,$objectid,$field) {
	global $n,$db_zugriff;
	$result = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$boardid' AND objectid = '$objectid' AND $field = 1");
	return $result[0];
}



/**
* @return result int
* @param userid int
* @param objectid in
* @param field string
* @desc �berpr�ft, ob man jemanden in der buddy- oder ignoreliste hat oder ob man ein board oder thread in den favoriten hat.
* R�ckgabewert: bei Erfolg 1, ansonsten 0.
*/
function check_userobject($userid,$objectid,$field) {
	global $n,$db_zugriff;
	$result = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2user WHERE userid = '$userid' AND objectid = '$objectid' AND $field = 1");
	return $result[0];
}





/**
* @return result int
* @param email string
* @param db=0 int
* @desc �berpr�ft, ob eine eMail Adresse g�ltig ist.
* R�ckgabewert: 1 wenn die Email Adresse ung�ltig ist. Wenn sie g�ltig ist, dann kein R�ckgabewert.
* Der Parameter db gibt an, ob �berpr�ft werden soll, ob die eMail Adresse schon in der Datenbank eingetragen ist.
*/
function checkemail($email, $db=0) {
	global $db_zugriff, $n, $multi_email, $banemail;
	if(!substr_count($email,"@") || substr_count($email,"@")>1) return 1;
	$position1 = strrpos($email,"@");
	if(!$position1) return 1;
	$position2 = strrpos($email,".");
	if(!$position2) return 1;
	if(strlen(substr($email, $position2)) < 3)return 1;
	if(strlen(substr($email, $position1,$position2-$position1-1))<2) return 1;
	if(!$multi_email && !$db) {
		$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE useremail = '$email'");
		if($check[0]) return 1;
	}
	$banemail = @explode("\n",$banemail);
	for($i = 0; $i < count($banemail); $i++) {
		if(!trim($banemail[$i])) continue;
		if(ereg("\*", $banemail[$i])) {
			$banemail[$i] = str_replace("*",".*", trim($banemail[$i]));
			if(eregi("$banemail[$i]", $email)) return 1;
			break;
		}
		elseif(strtolower($email)==strtolower(trim($banemail[$i]))) {
			return 1;
			break;
		}  
	}
}








/**
* @return result int
* @param name string
* @desc �berpr�ft einen Benutzernamen auf seine G�ltigkeit.
* Wenn der Benutzername verboten ist oder schon in Benutzun ist, wird 1 zur�ckgegeben.
* Ansonsten ist der R�ckgabewert 0
*/
function checkname($name) {
	
	global $db_zugriff, $n, $banname;
	$bannames = explode("\r\n", trim($banname));
	for($i=0;$i<count($bannames);$i++) {
	 $bannames[$i] = trim($bannames[$i]);
	 if(!$bannames[$i]) continue;
	 if($name==$bannames[$i]) return 1;
	}
	$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE username = '".addslashes(htmlspecialchars($name))."'");
	return $check[0];
}







/**
* @return result int
* @param userid int
* @param password string
* @desc �berpr�ft die g�ltigkeit einer userid-passwort kombination.
* Wenn die Daten korrekt sind, wird 1 zur�ckgegeben, ansonsten 0
*/
function checkpw($userid,$password) {

	global $db_zugriff, $n;
	$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE userid = '$userid' AND userpassword = '$password'");
	return $check[0];
}





/**
* @return avatar string
* @param avatarid int
* @desc Gibt den Pfad zu dem Avatar mit der Id id zur�ck.
*/
function getAvatar($id) {
	global $db_zugriff, $n;
	$result = $db_zugriff->query_first("SELECT extension FROM bb".$n."_avatars WHERE id = '$id'");
	return "images/avatars/avatar-".$id.".".$result['extension'];
}




/**
* @return text string
* @param text string
* @param width=75 int
* @desc f�gt nach width Zeichen einen Zeilenumbruch in text ein.
*/
function nt_wordwrap($text, $width = 75) {
         if($text) return preg_replace("/([^\n\r ?&\.\/<>\"\\-]{".$width."})/i"," \\1\n",$text);
}






/**
* @return page_link string
* @param link string
* @param page int
* @param pages int
* @desc Generiert Links zu weiteren Seiten eines Themas.
*/
function makepagelink($link, $page, $pages) {
	$page_link = "<b>[";
	if($page!=1) $page_link .= "&nbsp;&nbsp;<a href=\"$link&page=1\">&laquo;</a>&nbsp;&nbsp;<a href=\"$link&page=".($page-1)."\">�</a>";
	if($page>=6) $page_link .= "&nbsp;&nbsp;<a href=\"$link&page=".($page-5)."\">...</a>";
	if($page+4>=$pages) $pagex=$pages;
	else $pagex=$page+4;
	for($i=$page-4 ; $i<=$pagex ; $i++) { 	
		if($i<=0) $i=1;
		if($i==$page) $page_link .= "&nbsp;&nbsp;$i";
		else $page_link .= "&nbsp;&nbsp;<a href=\"$link&page=$i\">$i</a>";
	}
	if(($pages-$page)>=5) $page_link .= "&nbsp;&nbsp;<a href=\"$link&page=".($page+5)."\">...</a>";
	if($page!=$pages) $page_link .= "&nbsp;&nbsp;<a href=\"$link&page=".($page+1)."\">�</a>&nbsp;&nbsp;<a href=\"$link&page=".$pages."\">&raquo;</a>";
	$page_link .= "&nbsp;&nbsp;]</b>";

	return $page_link;
}





/**
* @return result int
* @param user_id int
* @desc �berpr�ft, ob ein Benutzer innerhalb der Floodcontrol Zeit schon einen Beitrag erstellt hat.
* Wenn ja ist der R�ckgabewert gr��er 0. Ansonsten 0.
*/
function floodcontrol($user_id) {
	global $fctime, $db_zugriff, $n;
	$check_time = time()-$fctime;
	$result = $db_zugriff->query_first("SELECT COUNT(postid) FROM bb".$n."_posts WHERE userid = '$user_id' AND posttime > '$check_time'");
	return $result[0];
}






/**
* @return out string
* @param boardid int
* @param depth=1 int
* @param subscripe=0 int
* @desc Generiert f�r die Startseite bzw. die unterforen in der board.php die Boardzeilen.
* ziemlich kompliziert das ganze ;)
*/
function makeforumbit($boardid,$depth=1,$subscripe=0) {
  global $db_zugriff, $n, $show_subboards, $boardcache, $permissioncache, $modcache, $forumhomedepth, $session, $old_time, $user_group, $longdateformat;

  if ( !isset($boardcache[$boardid]) ) {
    return;
  }
	$out = "";
  while ( list($key1,$val1)=each($boardcache[$boardid]) ) {
    while ( list($key2,$boards)=each($val1) ) {
	$delboard = "";
	if($subscripe) eval ("\$delboard = \"".gettemplate("profile_subscripe_delboard")."\";");
	if($boards['invisible'] && !$permissioncache[$boards['boardid']]) continue;
	if($boards['isboard']) { //board
		if($depth==2 && $show_subboards==1) {
			$subboards=getSubboards($boards['boardid']);
			if($subboards) $subboards=ifelse($boards['descriptiontext'],"<br>","")."Inklusive: ".substr($subboards, 0, -2);	
		}
		#$boards['descriptiontext'] = editDBdata($boards['descriptiontext']);
		#$boards[boardname] = editDBdata($boards[boardname]);
		if($old_time <= $boards['lastposttime']) eval ("\$on_or_off = \"".gettemplate("main_newposts")."\";");
		else eval ("\$on_or_off = \"".gettemplate("main_nonewposts")."\";");
	
		if($boards['lastpostid']) {
			$lastposttime = formatdate($boards['posttime'],$longdateformat,1);
			if($boards['userid']) $lastauthor = "<a href=\"members.php?mode=profile&userid=".$boards['userid'].$session."\">".($boards['username'])."</a>";
			else eval ("\$lastauthor = \"".gettemplate("lg_anonymous")."\";");
			$boards['threadname'] = prepare_topic($boards['threadname']);
			if (!$boards['topicicon']) $ViewPosticon = "<img src=\"images/icons/noicon.gif\">";
			else $ViewPosticon = "<img src=\"$boards[topicicon]\">";
			if (isset($permissioncache[$boards['boardid']]) && $permissioncache[$boards['boardid']]) $template="main_lastpost";
			else $template="main_lastpost2";
			if (strlen($boards['threadname']) > '30') $ViewThreadname = substr($boards['threadname'], 0, 27)."...";
        		else $ViewThreadname = $boards['threadname'];
        		eval ("\$last_post = \"".gettemplate("$template")."\";");
		}
		else $last_post = "&nbsp;";
		
		$moderators = "";
		if(isset($modcache[$boards['boardid']])) {
			while (list($mkey,$moderator)=each($modcache[$boards['boardid']])) {
            			if ($moderators) $moderators .= ", ";
            			$moderators .= "<a href=\"members.php?mode=profile&userid=".$moderator['userid'].$session."\">".($moderator['username'])."</a>";
			}
		}
		eval ("\$out .= \"".gettemplate("main_boardbit$depth")."\";");
		unset($moderators);
		
	}
	else { //cat
		if($depth==2 && $show_subboards==1) {
			$subboards=getSubboards($boards['boardid']);
			if($subboards) $subboards=ifelse($boards['descriptiontext'],"<br>","")."Inklusive: ".substr($subboards, 0, -2);	
		}
		#$boards['descriptiontext'] = editDBdata($boards['descriptiontext']);
		#$boards['boardname'] = editDBdata($boards['boardname']);
		eval ("\$out .= \"".gettemplate("main_catbit$depth")."\";");
	}
        if ($depth<2) {
          $out.=makeforumbit($boards['boardid'],$depth+1,$subscripe);
        }
    } 
  } 
  unset($boardcache[$boardid]);
  return $out;
}



/**
* @return navichain string
* @param template string
* @param boardid int
* @param threadid=0 int
* @desc Generiert die sog. "Navichain"...
*/
function makenavichain($template, $boardid, $threadid=0) {
	global $db_zugriff, $n, $session;
	if($template == "board") {
		$binfo = $db_zugriff->query_first("SELECT boardparentid, boardname FROM bb".$n."_boards WHERE boardid = '$boardid'");
		$result['boardparentid'] = $binfo['boardparentid'];
	}
	else $result['boardparentid'] = $boardid;
	eval ("\$split = \"".gettemplate("navi_split")."\";");
	$out = "";
	do {
		$result = $db_zugriff->query_first("SELECT boardid, boardparentid, boardname FROM bb".$n."_boards WHERE boardid = '$result[boardparentid]'");	
		if(!$result['boardid']) break;
		$out = $split."<a href=\"board.php?boardid=$result[boardid]$session\">".$result['boardname']."</a>".$out;	
	}
	while($result['boardparentid']!=0);
	
	if($threadid) {
		$tinfo = $db_zugriff->query_first("SELECT threadname FROM bb".$n."_threads WHERE threadid = '$threadid'");
		$tinfo['threadname'] = prepare_topic($tinfo['threadname']);
	}
	eval ("\$ende = \"".gettemplate("navi_".$template)."\";");
	return $out.$ende;
}





/**
* @return month_name string
* @param month_number int
* @desc Gibt den Monatsnamen zu einer Monatszahl zur�ck.
*/
function get_month_name($month_number) {
	$name_monat[1]    =  "Januar";  
	$name_monat[2]    =  "Februar";  
	$name_monat[3]    =  "M&auml;rz";  
	$name_monat[4]    =  "April";  
	$name_monat[5]    =  "Mai";  
	$name_monat[6]    =  "Juni";  
	$name_monat[7]    =  "Juli";  
	$name_monat[8]    =  "August";  
	$name_monat[9]    =  "September";  
	$name_monat[10]  =  "Oktober";  
	$name_monat[11]  =  "November";  
	$name_monat[12]  =  "Dezember";
	
	return $name_monat[$month_number];
}





/**
* @return url string
* @param url string
* @desc H�ngt http:// vor eine Url, wenn es noch nicht vorhanden ist.
*/
function editURL($url) {
        if(strtolower(substr($url,0,7))!="http://") $url="http://".$url;
        return $url;
}





/**
* @return out string
* @param out string
* @desc Ersetzt in out alle bbcodes..
*/
function prepare_code($out) { 
 global $db_zugriff,$n,$searcharray,$replacearray;
 $phpversionnum = phpversion();

 if(!isset($searcharray) && !isset($replacearray)) {
  $searcharray[]="/\[list=(['\"]?)([^\"']*)\\1](.*)\[\/list((=\\1[^\"']*\\1])|(\]))/esiU";
  $replacearray[]="formatlist('\\3', '\\2')"; 
  $searcharray[]="/\[list](.*)\[\/list\]/esiU";	
  $replacearray[]="formatlist('\\1')"; 
  $searcharray[]="/\[url=(['\"]?)([^\"']*)\\1](.*)\[\/url\]/esiU";
  $replacearray[]="formaturl('\\2','\\3')";
  $searcharray[]="/\[url]([^\"]*)\[\/url\]/esiU";	
  $replacearray[]="formaturl('\\1')";
  $searcharray[]="/\[code](.*)\[\/code\]/esiU";	
  $replacearray[]="formatcodetag('\\1')";
  $searcharray[]="/\[php](.*)\[\/php\]/esiU";	
  $replacearray[]="phphighlite('\\1')";
  $searcharray[]="/\[img]([^\"]*)\[\/img\]/siU";	
  $replacearray[]="<img src=\"\\1\" border=0>"; 
  
  $threeparams = "/\[%s=(['\"]?)([^\"']*),([^\"']*)\\1](.*)\[\/%s\]/siU";
  $twoparams = "/\[%s=(['\"]?)([^\"']*)\\1](.*)\[\/%s\]/siU";
  $oneparam = "/\[%s](.*)\[\/%s\]/siU"; 

  $result = $db_zugriff->query("SELECT bbcodetag,bbcodereplace,params FROM bb".$n."_bbcode");

  while($row = $db_zugriff->fetch_array($result)) {
   if($row['params']==0) continue;
   if($row['params']==1) $search = sprintf($oneparam, $row['bbcodetag'], $row['bbcodetag']);
   if($row['params']==2) $search = sprintf($twoparams, $row['bbcodetag'], $row['bbcodetag']);
   if($row['params']==3) $search = sprintf($threeparams, $row['bbcodetag'], $row['bbcodetag']);

	for($i=0;$i<7;$i++) { // Verschachtelungstiefe
   $searcharray[] = $search;
   $replacearray[] = $row['bbcodereplace']; }
  } 
 }
 
 if ($phpversionnum<"4.0.5") $bbcode=str_replace("'", "\'", $out);
 $out = preg_replace($searcharray, $replacearray, $out);
 $out = str_replace("\\'", "'", $out);
 return $out;
}







/**
* @return links string
* @param boardid int
* @desc Gibt Links (per , getrennt) zu den Unterforen eines Boards zur�ck.
*/
function getSubboards($boardid) {
	global $boardcache,$session;

	if (!isset($boardcache[$boardid])) return;
	if(!isset($subboards)) $subboards = "";
  
	while(list($key1,$val1)=each($boardcache[$boardid])) {
		while(list($key2,$boards)=each($val1)) {
			$subboards.="<a href=\"board.php?boardid=$boards[boardid]$session\">".($boards['boardname'])."</a>, ".getSubboards($boards['boardid'],$boards);
		}
	}
 	
 	return $subboards;
}






/**
* @return rank string
* @param posts int
* @param groupid int
* @desc Ermittelt aus dem rankcache den Rang anhand von posts und groupid.
*/
function getRank($posts,$groupid)
{
	global $rankcache;
	if(isset($rankcache[$groupid]) && count($rankcache[$groupid]))
	{
		for($i=0;$i<count($rankcache[$groupid]);$i++)
		{
			if($rankcache[$groupid][$i]['posts']==0)
			{
				return $rankcache[$groupid][$i];
				break;
			}
			elseif($posts/$rankcache[$groupid][$i]['posts']>=1)
			{
				return $rankcache[$groupid][$i];
				break;
			}
		}
	}
}




/**
* @return ipaddress string
* @desc Ermittelt die IP des Clienten und gibt sie zur�ck.
*/
function getIpAddress() {
 $REMOTE_ADDR=getenv("REMOTE_ADDR");
 $HTTP_X_FORWARDED_FOR=getenv("HTTP_X_FORWARDED_FOR");
	
 if($HTTP_X_FORWARDED_FOR!="") {
  if(preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $HTTP_X_FORWARDED_FOR, $ip_match)) {
   $private_ip_list = array("/^0\./", "/^127\.0\.0\.1/", "/^192\.168\..*/", "/^172\.16\..*/", "/^10..*/", "/^224..*/", "/^240..*/");	
   $REMOTE_ADDR = preg_replace($private_ip_list, $REMOTE_ADDR, $ip_match[1]);	
  }	
 }
 
 if(strlen($REMOTE_ADDR)>16) $REMOTE_ADDR=substr($REMOTE_ADDR, 0, 16);
 return $REMOTE_ADDR;
}
?>
