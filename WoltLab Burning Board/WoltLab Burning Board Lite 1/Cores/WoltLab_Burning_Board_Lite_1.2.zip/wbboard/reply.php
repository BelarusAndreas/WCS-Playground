<?php
require("global.php");
require("_header.php");
include("posticons.php");


if(!isset($_POST['action'])) $_POST['action']="";
if(!isset($_POST['preview'])) $_POST['preview']="";
if(!isset($_GET['mode'])) $_GET['mode']="";

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info['boardparentid'])
{
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}

if((($thread_info['authorid'] && $thread_info['authorid'] != $user_id && $userdata['canreplytopic']) || ($thread_info['authorid'] && $thread_info['authorid'] == $user_id && $userdata['canreplyowntopic']) || (!$thread_info['authorid'] && $userdata['canreplytopic'])) && check_boardobject($boardid,$user_group,"replypermission"))
{
	if($_POST['action'] == "send" && (!trim($_POST['message']) || check_posts($_POST['message']))) eval ("\$error = \"".gettemplate("newthread_error")."\";");
	if($_POST['action'] == "send" && !$_POST['preview'])
	{
		if(trim($_POST['message']) && !check_posts(trim($_POST['message'])))
		{
			if($user_id && !$userdata['avoidfc'] && floodcontrol($user_id))
			{
				require("_board_jump.php");
				eval("dooutput(\"".gettemplate("floodcontrol")."\");");
				exit;
			}
			$subject = trim($_POST['subject']);
			$message = trim($_POST['message']);
			if($_POST['previewed'])
			{
				$subject = rehtmlspecialchars($subject);
				$message = rehtmlspecialchars($message);
			}
			$subject = addslashes($subject);
			$message = addslashes($message);
			if(isset($_POST['posticon']))
			{
				$posticon = $_POST['posticon'];
				if(!in_array($posticon,$posticons)) $posticon="";
			}
			else $posticon="";
			$posticon=addslashes($posticon);
			if(isset($_POST['parseurl'])) $parseurl = intval($_POST['parseurl']);
			else $parseurl=0;
			if(isset($_POST['email'])) $email = addslashes($_POST['email']);
			else $email=0;
			if(isset($_POST['disablesmilies'])) $disablesmilies = intval($_POST['disablesmilies']);
			else $disablesmilies=0;
			if(isset($_POST['signature'])) $signature = intval($_POST['signature']);
			else $signature=0;
			if(isset($_POST['close'])) $close = intval($_POST['close']);
			else $close=0;
			
			$result = newPost($boardid,$threadid,$user_id,$subject,$message,$posticon,$parseurl,$email,$disablesmilies,$signature,$close);
			if($result==2)
			{
				eval ("\$output = \"".gettemplate("note4")."\";");
				$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid";
			}
			if($result==4)
			{
				$ride = getLastPost($user_id,4);
				header("Location: $ride");
				exit;
			}
			eval ("\$headinclude = \"".gettemplate("headinclude")."\";");
			eval("dooutput(\"".gettemplate("action_ride")."\");");
			exit;
		}
		else eval ("\$error = \"".gettemplate("newthread_error")."\";");
	}


	if(!isset($error)) $error="";
	if(!isset($preview)) $preview="";
	if(!isset($subject)) $subject="";
	if(!isset($message)) $message="";
	$checked=array("","","","","");
	if($ch_parseurl) $checked[0] = "CHECKED";
	if($ch_email) $checked[1] = "CHECKED";
	if($ch_disablesmilies) $checked[2] = "CHECKED";
	if($ch_signature) $checked[3] = "CHECKED";
	$previewed = 0;

	
	/*
	* Vorschau ...
	*/
	if($_POST['preview'] || $error)
	{
		// Subject und Message f�r Formular vorbereiten.
		$previewed = 1;
		$disablesmilies=1;
		if(!isset($_POST['disablesmilies'])) $disablesmilies=0;
		$subject = htmlspecialchars($_POST['subject']);
		$message = htmlspecialchars($_POST['message']);
		if($_POST['preview'] && !$error)
		{
			if(isset($_POST['posticon']) && $_POST['posticon']) $pre_posticon = "<img src=\"".$_POST['posticon']."\">";
			else $pre_posticon = "&nbsp;";
			if(($user_id && $userdata['signatur']) && (isset($_POST['signature']) && $_POST['signature']) && !$hide_signature)
			{
				$signatur = editSignatur($userdata['signatur'],$disablesmilies);
				eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
			}
			else $pre_signature="";
			$post = editPost($_POST['message'],$disablesmilies);
			eval ("\$preview = \"".gettemplate("preview")."\";");
		}

		    
        if(isset($_POST['parseurl']) && $_POST['parseurl']) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if(isset($_POST['email']) && $_POST['email']) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if(isset($_POST['signature']) && $_POST['signature']) $checked[3] = "CHECKED";
		else $checked[3] = "";
		if(isset($_POST['close']) && $_POST['close']) $checked[4] = "CHECKED";
		else $checked[4] = "";		

	}

	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);
	$note="";
	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

	$choice_posticons="";
	for($i = 0; $i < count($posticons); $i++)
	{
		if(is_int($i/6) && $i) $choice_posticons .= "<br>";
		elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
		$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
		if(isset($_POST['posticon']) && $_POST['posticon'] == $posticons[$i]) $choice_posticons .= " CHECKED";
		$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
	}
	if(!isset($_POST['posticon']) || !$_POST['posticon']) $noicon[0] = "CHECKED";
	else $noicon[0]="";

	$navi_chain = makenavichain("reply",$boardid,$threadid);
	if($_GET['mode']=="quote" && !$_POST['preview'])
	{
		$message = $db_zugriff->query_first("SELECT threadparentid, userid, message FROM bb".$n."_posts WHERE postid='".$_GET['postid']."'");
		if($message['threadparentid']==$threadid)
		{
			if($message['userid']) $username = getUsername($message['userid']);
			else eval ("\$username = \"".gettemplate("lg_anonymous")."\";");
			$quote = htmlspecialchars(prepare_quote($message['message']));
			eval ("\$message = \"".gettemplate("reply_quote")."\";");
			
		}
	}

	$post_result = $db_zugriff->query("SELECT bb".$n."_posts.*, bb".$n."_user_table.username FROM bb".$n."_posts LEFT JOIN bb".$n."_user_table USING (userid) WHERE threadparentid='$threadid' ORDER by posttime DESC LIMIT 0,".($eproseite));
	$reply_threadview="";
	while($posts = $db_zugriff->fetch_array($post_result))
	{
		unset($posttopic);
		if($posts['userid']) $authorname = $posts['username'];
		else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
		if($posts['posticon']) $posticon = "<img src=\"".$posts['posticon']."\">";
		else $posticon = "&nbsp;";
		$posttopic = prepare_topic($posts['posttopic']);
		$post = editPost($posts['message'],$posts['disable_smilies']);
		$backcolor = rowcolor($j);
		eval ("\$reply_threadview .= \"".gettemplate("reply_threadview")."\";");
		$j++;
	}

	if(($thread_info['authorid'] && $thread_info['authorid'] == $user_id && $userdata['cancloseowntopic']) || ($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod"))|| $userdata['issupermod']) eval ("\$quick_close = \"".gettemplate("reply_quick_close")."\";");
	else $quick_close="";
	
	if($user_id) eval ("\$quick_logout = \"".gettemplate("newthread_logout")."\";");
	else $quick_logout = "";
	
	eval("dooutput(\"".gettemplate("reply")."\");");
}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>