<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

$boardcache=array();
$permissioncache=array();
$modcache=array();

if($boardid == -1) {
	eval ("\$output = \"".gettemplate("error3")."\";");
	eval("dooutput(\"".gettemplate("action_error")."\");");
	exit;
}
elseif($boardid == "home") {
	header("LOCATION: main.php$session2");
	exit;
}
elseif($boardid == "pm") {
	header("LOCATION: pms.php$session2");
	exit;
}
elseif($boardid == "search") {
	header("LOCATION: search.php$session2");
	exit;
}
elseif($boardid == "profil") {
	header("LOCATION: profile.php$session2");
	exit;
}
else $boardid = intval($boardid);
$binfo = $db_zugriff->query_first("SELECT * FROM bb".$n."_boards WHERE boardid='$boardid'");

$board_boardbit="";
list($childrencount) = $db_zugriff->query_first("SELECT count(boardid) FROM bb".$n."_boards WHERE boardparentid='$boardid'");

if($childrencount>0)
{
	$result = $db_zugriff->query("
		SELECT
		bb".$n."_boards.*,
		bb".$n."_posts.threadparentid,
		bb".$n."_posts.userid,
		bb".$n."_posts.posttime,
		bb".$n."_threads.threadname,
		bb".$n."_threads.topicicon,
		bb".$n."_threads.boardparentid as parentid,
		bb".$n."_user_table.username
		FROM bb".$n."_boards
		LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid)
		LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid)
		LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid)
		WHERE bb".$n."_boards.boardparentid>0
		ORDER by boardparentid ASC, sort ASC");
	while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
	$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
	while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
	$result = $db_zugriff->query("SELECT userid, username, boardid FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid = bb".$n."_user_table.userid) WHERE mod = 1 ORDER BY username ASC");
	while ($row = $db_zugriff->fetch_array($result)) $modcache[$row['boardid']][] = $row;
	$board_boardbit = makeforumbit($boardid);
	$db_zugriff->free_result($result);
}

$subboards = "";
if($board_boardbit) eval ("\$subboards .= \"".gettemplate("board_subboards")."\";");
$navi_chain = makenavichain("board",$boardid);
if(!isset($mods)) $mods = "";
if(!$binfo['isboard']) // Kategorie
{
	eval("dooutput(\"".gettemplate("board_cat")."\");");
	exit;
}

$time = time()+$timeoffset*3600;
$result = $db_zugriff->query("SELECT announcementid, topic, bb".$n."_announcements.userid, username FROM bb".$n."_announcements LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_announcements.userid) WHERE ($time BETWEEN starttime AND endtime) AND (boardid=0 OR boardid='$boardid') ORDER BY starttime DESC");

$board_threadbit = "";
while($row = $db_zugriff->fetch_array($result)) {
	$row['topic'] = prepare_topic($row['topic']);
	eval ("\$board_threadbit .= \"".gettemplate("announcementbit")."\";");
}
$db_zugriff->free_result($result);

if(!isset($_GET['sortfield'])) $_GET['sortfield'] = "timelastreply";
if(!isset($_GET['sortorder'])) $_GET['sortorder'] = "DESC";
if(!isset($_GET['daysprune'])) $_GET['daysprune'] = "";

switch($_GET['sortfield'])
{
	case "threadname"; break;
	case "starttime": break;
	case "replies": break;
	case "views": break;
	case "authorid": break;
	default: $_GET['sortfield'] = "timelastreply"; break;
}


switch($_GET['sortorder'])
{
	case "ASC"; break;
	default: $_GET['sortorder'] = "DESC"; break;
}

$daysprune="";
if(isset($_GET['daysprune'])) $daysprune = $_GET['daysprune'];
if(!$daysprune && !$prunedays) $daysprune = $default_daysprune;
if(!$daysprune && $prunedays) $daysprune = $prunedays;
if($daysprune!=1000) $date = time()-(86400*intval($daysprune));
else $date="";

$anzahl = $db_zugriff->query_first("SELECT COUNT(threadid)as anzahl FROM bb".$n."_threads WHERE (boardparentid='$boardid' OR putoffid='$boardid') AND (timelastreply>='$date' OR important='1')");
$anzahl = $anzahl['anzahl'];
if(isset($_GET['page'])) $page=intval($_GET['page']);
else $page=1;

$threadids = "";
$getthreadids=$db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE (boardparentid='$boardid' OR putoffid='$boardid') AND (timelastreply>='$date' OR important='1') ORDER BY important DESC, ".$_GET['sortfield']." ".$_GET['sortorder']." LIMIT ".($tproseite*($page-1)).",".($tproseite));
while($row=$db_zugriff->fetch_array($getthreadids)) $threadids.=",".$row['threadid'];

$thread_result = $db_zugriff->query("SELECT bb".$n."_threads.*, bb".$n."_user_table.username AS lastpostername FROM bb".$n."_threads
 LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_threads.lastposterid)
 WHERE threadid IN (0$threadids)
 ORDER by important DESC, ".$_GET['sortfield']." ".$_GET['sortorder']);
$pages=ceil($anzahl/$tproseite);

while($threads = $db_zugriff->fetch_array($thread_result)) {

	$folder_image="";
	$thread_link="";
	$rate="";
	$anonymous_lp="";
	$anonymous="";
	$thread_starter="";
	$lastauthor="";

	$folder_image = "";
	$thread_link = "";
	$anonymous_lp = "";
	$anonymous = "";
	$thread_autor = "";
	#$sthreadname = "sthread_".$threads['threadid'];
	$sthreadname = $threads['threadid'];
	if($boardid == $threads['putoffid']) $folder_image = "<img src=\"$imagefolder/movedfolder.gif\">"; // Thread verschoben
	else
	{
		if($old_time <= $threads['timelastreply'] && ((isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) || !isset($sthreads_array[$sthreadname]))) $folder_image .= "new";
		#if($old_time <= $threads['timelastreply'] && isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) $folder_image .= "new";
		if($threads['replies'] > $hotthread_reply || $threads['views'] > $hotthread_view) $folder_image .= "hot";
		if($threads['flags']==1) $folder_image .= "lock";
		$folder_image = "<img src=\"$imagefolder/".$folder_image."folder.gif\">";
	}
	if($threads['topicicon']) $posticon = "<img src=\"".$threads['topicicon']."\">";
	else $posticon = "&nbsp;";

	if($old_time <= $threads['timelastreply'] && ((isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) || !isset($sthreads_array[$sthreadname]))) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
	#if($old_time <= $threads['timelastreply'] && isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
	$thread_link .= "<font size=2 face=\"{font}\"><b>";
	if($boardid == $threads['putoffid']) eval ("\$thread_link .= \"".gettemplate("board_moved")."\";"); // Verschoben
	elseif($threads['important']) eval ("\$thread_link .= \"".gettemplate("board_important")."\";"); // Wichtig
 	if($threads['pquestion']) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";"); // Umfrage
	$thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."\">".prepare_topic($threads['threadname'])."</a></b></font>";
	if(($threads['replies']+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"".$font."\"> ( <img src=\"$imagefolder/multipage.gif\"> <a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=1\">1</a> <a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session&page=2\">2</a> ";
	if(($threads['replies']+1)/$eproseite > 2) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=3\">3</a> ";
	if(($threads['replies']+1)/$eproseite > 3) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=4\">4</a> ";
	if(($threads['replies']+1)/$eproseite > 4)
	{
		$pagesx=ceil(($threads['replies']+1)/$eproseite);
		eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
	}
	if(($threads['replies']+1)/$eproseite > 1) $thread_link .= ")</font>";

	$starttime = formatdate($threads['starttime'],$longdateformat,1);
	if($threads['authorid']) $thread_starter = ($threads['author']);
	else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
	$lastposttime = formatdate($threads['timelastreply'],$longdateformat,1);
	$lastauthorid = $threads['lastposterid'];
	if($lastauthorid) $lastauthor = ($threads['lastpostername']);
	else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
	eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");

	if($threads['rated'] && $threads['rate_points']) $rate = str_repeat("<img src=\"$imagefolder/star.gif\" border=0>",round($threads['rate_points']/$threads['rated']));
	else $rate = "&nbsp;";

	eval ("\$board_threadbit .= \"".gettemplate("board_threadbit")."\";");
}
$db_zugriff->free_result($thread_result);
if($pages>1) $page_link = makepagelink("board.php?boardid=".$boardid."&sortfield=".$_GET['sortfield']."&sortorder=".$_GET['sortorder']."&daysprune=".$_GET['daysprune'].$session, $page, $pages);
else $page_link = "";
if($mods = getMod($boardid)) eval ("\$mods = \"".gettemplate("board_moderate")."\";");

$l_threads = 1+($page-1)*$tproseite;
$h_threads = $page*$tproseite;
if($h_threads > $anzahl) $h_threads = $anzahl;
$all_threads = $anzahl;

$f_select[0] = "";
$f_select[1] = "";
$f_select[2] = "";
$f_select[3] = "";
$f_select[4] = "";
$f_select[5] = "";
switch($_GET['sortfield'])
{
	case "threadname": $f_select[0] = "selected"; break;
	case "timelastreply": $f_select[1] = "selected"; break;
	case "replies": $f_select[2] = "selected"; break;
	case "views": $f_select[3] = "selected"; break;
	case "author": $f_select[4] = "selected"; break;
	case "starttime": $f_select[5] = "selected"; break;
}

$o_select[0] = "";
$o_select[1] = "";
switch($_GET['sortorder'])
{
	case "ASC": $o_select[0] = "selected"; break;
	case "DESC": $o_select[1] = "selected"; break;
}

$d_select[0] = "";
$d_select[1] = "";
$d_select[2] = "";
$d_select[3] = "";
$d_select[4] = "";
$d_select[5] = "";
$d_select[6] = "";
$d_select[7] = "";
$d_select[8] = "";
$d_select[9] = "";
$d_select[10] = "";
$d_select[11] = "";
switch($daysprune)
{
	case "1": $d_select[0] = "selected"; break;
	case "2": $d_select[1] = "selected"; break;
	case "5": $d_select[2] = "selected"; break;
	case "10": $d_select[3] = "selected"; break;
	case "20": $d_select[4] = "selected"; break;
	case "30": $d_select[5] = "selected"; break;
	case "45": $d_select[6] = "selected"; break;
	case "60": $d_select[7] = "selected"; break;
	case "75": $d_select[8] = "selected"; break;
	case "100": $d_select[9] = "selected"; break;
	case "365": $d_select[10] = "selected"; break;
	case "1000": $d_select[11] = "selected"; break;
}
if($board_threadbit)
{
	if(!isset($threads_order)) $threads_order = "";
	eval ("\$threads_order  = \"".gettemplate("board_threads_order")."\";");
	eval("dooutput(\"".gettemplate("board")."\");");
}
else eval("dooutput(\"".gettemplate("board_no_threads")."\");");
?>