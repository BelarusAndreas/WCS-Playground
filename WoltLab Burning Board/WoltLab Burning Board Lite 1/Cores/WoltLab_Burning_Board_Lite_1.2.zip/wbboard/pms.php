<?php
require("global.php");
require("_header.php");
require("_board_jump.php");
require("posticons.php");

if(isset($_POST['box'])) $box = $_POST['box'];
elseif(isset($_GET['box'])) $box = $_GET['box'];
else $box = "";
if(!isset($_POST['action'])) $_POST['action']="";
if(!isset($_GET['action'])) $_GET['action']="";

if($user_id && $pms && $userdata['canusepms'])
{
	if(!$box) $box = "inbox";
	if($_POST['action'] == "send" || $_GET['action'] == "new" || $_GET['action'] == "reply" || $_GET['action'] == "forward")
	{

		if(!isset($_POST['preview'])) $_POST['preview']="";
		
		/*
		* PN versenden
		*/
		if($_POST['action'] && (!trim($_POST['message']) || !trim($_POST['subject']) || check_posts($_POST['message'])))  eval ("\$error = \"".gettemplate("newthread_error")."\";");
		if($_POST['action'] == "send" && !$_POST['preview'])
		{
			if(trim($_POST['message']) && trim($_POST['subject']) && !check_posts($_POST['message']))
			{
				$userid = getUserid(htmlspecialchars($_POST['recipient']));
				$count_pm = $db_zugriff->query_first("SELECT COUNT(pmid) FROM bb".$n."_pms WHERE recipientid = '$userid'");
				if(!$userid || $userid == $user_id || check_userobject($userid,$user_id,"ignorelist")) eval ("\$error = \"".gettemplate("pm_error1")."\";");
				elseif($count_pm[0] >= $maxpms)
				{
					eval("\$error = \"".gettemplate("pm_error2")."\";");
				}
				else
				{
					if(isset($_POST['posticon']))
					{
						$posticon = $_POST['posticon'];
						if(!in_array($posticon,$posticons)) $posticon="";
						$posticon=addslashes($posticon);
					}
					else $posticon="";
					if(isset($_POST['parseurl'])) $parseurl = intval($_POST['parseurl']);
					else $parseurl=0;
					if(isset($_POST['disablesmilies'])) $disablesmilies = intval($_POST['disablesmilies']);
					else $disablesmilies=0;
					if(isset($_POST['signature'])) $signature = intval($_POST['signature']);
					else $signature=0;

					$subject = $_POST['subject'];
					$message = $_POST['message'];
					if(isset($_POST['previewed']) && $_POST['previewed'])
					{
						$subject = rehtmlspecialchars($subject);
						$message = rehtmlspecialchars($message);
					}
					if($parseurl) $message = parseURL($message);
					$subject = addslashes($subject);
					$message = nt_wordwrap($message);
					$message = addslashes($message);
					
					$db_zugriff->query("INSERT INTO bb".$n."_pms (senderid,recipientid,sendtime,subject,message,icon,disable_smilies,signature)VALUES ('$user_id','$userid','".time()."','".$subject."','".$message."','".$posticon."','".$disablesmilies."','".$signature."')");
					if(isset($_POST['copy']) && $_POST['copy'])
					{
						$nr = $db_zugriff->insert_id();
						$db_zugriff->query("INSERT INTO bb".$n."_pmsend VALUES ('$user_id','$userid','$nr','','".time()."','".$subject."','".$message."','".$posticon."','".$disablesmilies."','".$signature."')");
					}
					if(isset($_POST['replyid']) && $_POST['replyid']) $db_zugriff->query("UPDATE bb".$n."_pms SET reply = 1 WHERE pmid = '".intval($_POST['replyid'])."'");
					if(isset($_POST['forwardid']) && $_POST['forwardid']) $db_zugriff->query("UPDATE bb".$n."_pms SET forward = 1 WHERE pmid = '".intval($_POST['forwardid'])."'");
					header("LOCATION: pms.php?box=inbox$session");
				}
			}
			else eval ("\$error = \"".gettemplate("newthread_error")."\";");
		}
		
		
		/*
		* Auf PN antworten => zititat
		*/
		if($_GET['action'] == "reply")
		{
			$pmdata = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '".$_GET['pmid']."' AND recipientid = '$user_id'");
			$subject = prepare_topic($pmdata['subject']);
			$message = prepare_quote(htmlspecialchars($pmdata['message']));
			$sendername = $recipient = getUsername($pmdata['senderid']);
			$sendtime = formatdate($pmdata['sendtime'],$longdateformat,0);
			eval ("\$message = \"".gettemplate("pm_reply_message")."\";");
			eval ("\$subject = \"".gettemplate("pm_reply_subject")."\";");
			$subject = preg_replace("/^(AW: )+/","AW: ", $subject);
			$replyid = $_GET['pmid'];
		}
		else $replyid=0;
		
		/*
		* PN weiterleiten => alte message einlesen
		*/
		if($_GET['action'] == "forward")
		{
			$pmdata = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '".$_GET['pmid']."' AND recipientid = '$user_id'");
			$subject = prepare_topic($pmdata['subject']);
			$message = prepare_quote(htmlspecialchars($pmdata['message']));
			$sendername = getUsername($pmdata['senderid']);
			$sendtime = formatdate($pmdata['sendtime'],$longdateformat,0);
			eval ("\$message = \"".gettemplate("pm_forward_message")."\";");
			eval ("\$subject = \"".gettemplate("pm_forward_subject")."\";");
			$subject = preg_replace("/^(WG: )+/","WG: ", $subject);
			$forwardid = $_GET['pmid'];
		}
		else $forwardid=0;
	

		if(!isset($previewed)) $previewed = 0;
		if(!isset($preview)) $preview="";
		if(!isset($recipient)) $recipient="";
		if(!isset($subject)) $subject="";
		if(!isset($message)) $message="";
		if(!isset($error)) $error="";
		if(!isset($note)) $note="";
		$checked=array("","","","");
		if($ch_parseurl) $checked[0] = "CHECKED";
		if($ch_disablesmilies) $checked[2] = "CHECKED";
		if($ch_signature) $checked[3] = "CHECKED";

		if($userid) $recipient = getUsername($userid);
		/*
		* Vorschau..
		*/
		if($_POST['preview'] || $error)
		{
			$previewed = 1;
			$recipient = $_POST['recipient'];
			$subject = prepare_topic($_POST['subject']);
			$disablesmilies=1;
			if(!isset($_POST['disablesmilies'])) $disablesmilies=0;
			if($_POST['preview'] && !$error)
			{
				if(isset($_POST['posticon']) && $_POST['posticon']) $pre_posticon = "<img src=\"".$_POST['posticon']."\">";
				else $pre_posticon = "&nbsp;";
				$user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE username='$user_name'");
				if(($user_id && $userdata['signatur']) && (isset($_POST['signature']) && $_POST['signature']) && !$hide_signature)
				{
					$signatur = editSignatur($userdata['signatur'],$disablesmilies);
					eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
				}
				else $pre_signature="";
				$post = editPost($_POST['message'],$disablesmilies);
				eval ("\$preview = \"".gettemplate("preview")."\";");
			}
			$message = htmlspecialchars(stripslashes($_POST['message']));
	
	        if(isset($_POST['parseurl']) && $_POST['parseurl']) $checked[0] = "CHECKED";
			else $checked[0] = "";
			if(isset($_POST['copy']) && $_POST['copy']) $checked[1] = "CHECKED";
			else $checked[1] = "";
			if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $checked[2] = "CHECKED";
			else $checked[2] = "";
			if(isset($_POST['signature']) && $_POST['signature']) $checked[3] = "CHECKED";
			else $checked[3] = "";
		}
	
		if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
		if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);
		if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
		else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
		if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
		if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");
		$choice_posticons="";
		for($i = 0; $i < count($posticons); $i++)
		{
			if(is_int($i/6) && $i) $choice_posticons .= "<br>";
			elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
			$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
			if(isset($_POST['posticon']) && $_POST['posticon'] == $posticons[$i]) $choice_posticons .= " CHECKED";
			$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
		}
		if(!isset($_POST['posticon']) || !$_POST['posticon']) $noicon[0] = "CHECKED";
		if($session) $session_post = "<INPUT TYPE=\"HIDDEN\" NAME=\"sid\" VALUE=\"$sid\">";
	
		eval("dooutput(\"".gettemplate("pm_new")."\");");
		exit;
	}




	/*
	* Druckansicht. ..
	*/
	elseif($_GET['action'] == "print")
	{
		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
		if(!$row['pmid'])
		{
			header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
			exit;
		}
	
		$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
		$sendername = $user_info['username'];
		$subject = prepare_topic($row['subject']);
		$message = editPost($row['message'],$row['disable_smilies']);
		if($user_info['signatur'] && $row['signature'] && !$hide_signature)
		{
			$signatur = editSignatur($user_info['signatur'],$row['disable_smilies']);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		else $signature="";
		$sendtime = formatdate($row['sendtime'],$longdateformat,0);
	
		eval("dooutput(\"".gettemplate("pm_print")."\");");
		exit;
	}
	
	
	/*
	* Download ...
	*/
	elseif($_GET['action'] == "download")
	{
		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
		if(!$row['pmid'])
		{
			header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
			exit;
		}
	
		$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
		$sendername = $user_info['username'];
		$subject = prepare_topic($row['subject']);
		$message = prepare_topic($row['message']);
		if($user_info['signatur'] && $row['signature'] && !$hide_signature) {
			$signatur = prepare_topic($user_info['signatur']);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		$sendtime = formatdate($row['sendtime'],$longdateformat,0);
	
		header("Content-disposition: filename=message-".$pmid.".txt");
		header("Content-type: application/octet-stream");
		header("Pragma: no-cache");
		header("Expires: 0");
	
		eval("dooutput(\"".gettemplate("pm_download")."\");");
		exit;
	}

	
	/*
	* L�schen ...
	*/
	elseif($_GET['action'] == "delete" || $_POST['action'] == "delete")
	{
		if(!isset($_POST['save'])) $_POST['save']="";
		$check = $db_zugriff->query_first("SELECT pmid FROM bb".$n."_pms WHERE pmid = '$pmid' AND recipientid = '$user_id'");
		if(!$check['pmid'])
		{
			header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
			exit;
		}
		if(!$_POST['save']) eval("dooutput(\"".gettemplate("pm_delete_check")."\");");
		else
		{
			$db_zugriff->query("DELETE FROM bb".$n."_pms WHERE pmid = '$pmid'");
			header("LOCATION: pms.php?boardid=$boardid&styleid=$styleid$session");
		}
		exit;
	}


	/*
	* L�schen aus Ordneransicht.. 
	*/
	elseif($_POST['action'] == "massdel")
	{
		$where = "";
		if(isset($_POST['select']) && is_array($_POST['select']))
		{
			$where = "pmid IN ('0','".implode("','",$_POST['select'])."')";
		}
		if($where) $db_zugriff->query("DELETE FROM bb".$n."_pms WHERE $where");
		header("LOCATION: pms.php$session2");
		exit;
	}


	/*
	* PN verschieben ... 
	*/
	elseif(substr($_POST['action'], 0 , 2) == "->")
	{
		$folderid = substr($_POST['action'], 2);
		$where = "";
		if(isset($_POST['select']) && is_array($_POST['select']))
		{
			$where = "pmid IN ('0','".implode("','",$_POST['select'])."')";
		}
		if($where) $db_zugriff->query("UPDATE bb".$n."_pms SET folderid = '$folderid' WHERE $where");
		header("LOCATION: pms.php?box=$folderid$session");
		exit;
	}


	/*
	* L�schen aus postausgang ... 
	*/
	elseif($_POST['action'] == "massdel_send")
	{
		$where = "";
		if(isset($_POST['select']) && is_array($_POST['select']))
		{
			$where = "pmid IN ('0','".implode("','",$_POST['select'])."')";
		}
		if($where) $db_zugriff->query("DELETE FROM bb".$n."_pmsend WHERE $where");
		header("LOCATION: pms.php?box=outbox$session");
		exit;
	}

	
	/*
	* Ordner erstellen ... 
	*/
	elseif($_POST['action'] == "createfolder" && $_POST['foldername'] = trim($_POST['foldername']))
	{
		$check = $db_zugriff->query_first("SELECT folderid FROM bb".$n."_folders WHERE userid = '$user_id' AND foldername = '".addslashes($_POST['foldername'])."'");
		$count = $db_zugriff->query_first("SELECT COUNT(folderid) FROM bb".$n."_folders WHERE userid = '$user_id'");
		if($check[0] || $count[0] >= $maxfolder)
		{
			eval ("\$output = \"".gettemplate("error28")."\";");
			eval("dooutput(\"".gettemplate("action_error")."\");");
			exit;
		}
		$db_zugriff->query("INSERT INTO bb".$n."_folders (userid,foldername) VALUES ('$user_id','".addslashes($_POST['foldername'])."')");
		header("LOCATION: pms.php?box=".$db_zugriff->insert_id()."$session");
		exit;
	}

	
	/*
	* Ordner l�schen, PNs in diesem Ordner werden in die Inbox verschoben...
	*/
	elseif($_POST['action'] == "delfolder" && $_POST['folderid'])
	{
		$check = $db_zugriff->query_first("SELECT folderid FROM bb".$n."_folders WHERE userid = '$user_id' AND folderid = '".$_POST['folderid']."'");
		if($check[0])
		{
			$db_zugriff->query("UPDATE bb".$n."_pms SET folderid = 0 WHERE folderid = '".$_POST['folderid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_folders WHERE folderid = '".$_POST['folderid']."'");
			header("LOCATION: pms.php?box=inbox$session");
			exit;
		}
		exit;
	}



	/*
	* Ordner: Inbox ..
	*/
	elseif($box == "inbox" && !$pmid)
	{
		// PNs auslesen
		$result = $db_zugriff->query("SELECT bb".$n."_pms.*, bb".$n."_user_table.username AS sendername FROM bb".$n."_pms LEFT JOIN bb".$n."_user_table ON (bb".$n."_pms.senderid=bb".$n."_user_table.userid) WHERE recipientid = '$user_id' AND folderid = 0 ORDER BY sendtime DESC");
		$pm_pmbit="";
		while ($row = $db_zugriff->fetch_array($result))
		{
			if($row['icon']) $icon = "<img src=\"$row[icon]\">";
			else $icon = "&nbsp;";
			$subject = prepare_topic($row['subject']);
			$sendername = ($row['sendername']);
			$sendtime = formatdate($row['sendtime'],$longdateformat,1);

			if($row['sendtime'] >= $old_time) $folder_image = "<img src=\"$imagefolder/pmnew.gif\">";
			elseif(!$row['view']) $folder_image = "<img src=\"$imagefolder/pmunread.gif\">";
			else
			{
				if($row['reply'] && $row['forward']) $folder_image = "<img src=\"$imagefolder/pmreward.gif\">";
				elseif($row['reply']) $folder_image = "<img src=\"$imagefolder/pmreply.gif\">";
				elseif($row['forward']) $folder_image = "<img src=\"$imagefolder/pmforward.gif\">";
				else  $folder_image = "<img src=\"$imagefolder/pmnormal.gif\">";
			}

			eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit")."\";");
		}
		
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id' ORDER BY foldername ASC");
		$folderdel_options="";
		$change_options="";
		$move_options="";
		while($folder = $db_zugriff->fetch_array($result))
		{
			$folderdel_options .= "<option value=\"".$folder['folderid']."\">".htmlspecialchars($folder['foldername'])."</option>\n";
			$change_options .= "<option value=\"".$folder['folderid']."\">".htmlspecialchars($folder['foldername'])."</option>\n";
			$move_options .= "<option value=\"->".$folder['folderid']."\">Verschieben nach: ".htmlspecialchars($folder['foldername'])."</option>\n";
		}
		$foldername = "Inbox";

		if($folderdel_options) eval ("\$del_folder = \"".gettemplate("pm_delfolder")."\";");
		else $del_folder="";
		if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
		eval("dooutput(\"".gettemplate("pm_inbox")."\");");
	}
	
	

	/*
	* Eigener Ordner 
	*/
	elseif($box != "inbox" && $box != "outbox" && !$pmid)
	{
		$result = $db_zugriff->query("
				SELECT bb".$n."_pms.*, username, foldername FROM bb".$n."_pms
				LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_pms.senderid)
				LEFT JOIN bb".$n."_folders ON (bb".$n."_folders.folderid=bb".$n."_pms.folderid)
				WHERE recipientid = '$user_id' AND bb".$n."_pms.folderid = '$box' ORDER BY sendtime DESC");
		$pm_pmbit="";
		while ($row = $db_zugriff->fetch_array($result))
		{
			if($row['icon']) $icon = "<img src=\"$row[icon]\">";
			else $icon = "&nbsp;";
			$subject = prepare_topic($row['subject']);
			$sendername = ($row['username']);
			$sendtime = formatdate($row['sendtime'],$longdateformat,1);

			if($row['sendtime'] >= $old_time) $folder_image = "<img src=\"$imagefolder/pmnew.gif\">";
			elseif(!$row['view']) $folder_image = "<img src=\"$imagefolder/pmunread.gif\">";
			else {
				if($row['reply'] && $row['forward']) $folder_image = "<img src=\"$imagefolder/pmreward.gif\">";
				elseif($row['reply']) $folder_image = "<img src=\"$imagefolder/pmreply.gif\">";
				elseif($row['forward']) $folder_image = "<img src=\"$imagefolder/pmforward.gif\">";
				else  $folder_image = "<img src=\"$imagefolder/pmnormal.gif\">";
			}
			eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit")."\";");
		}
		$move_options = "<option value=\"->inbox\">Verschieben nach: Inbox</option>\n";
		$change_options="";
		$folderdel_options="";
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id' ORDER BY foldername ASC");
		while($folder = $db_zugriff->fetch_array($result)) {
			if($box==$folder['folderid']) $foldername = htmlspecialchars($folder['foldername']);
			$folderdel_options .= "<option value=\"".$folder['folderid']."\">".htmlspecialchars($folder['foldername'])."</option>\n";
			$change_options .= "<option value=\"".$folder['folderid']."\">".htmlspecialchars($folder['foldername'])."</option>\n";
			if($folder['folderid']!=$box) $move_options .= "<option value=\"->".$folder['folderid']."\">Verschieben nach: ".htmlspecialchars($folder['foldername'])."</option>\n";
		}
		if($folderdel_options) eval ("\$del_folder = \"".gettemplate("pm_delfolder")."\";");
		else $del_folder="";
		if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
		eval("dooutput(\"".gettemplate("pm_inbox")."\");");
	}
	
	
	/*
	* Outbox 
	*/
	elseif($box == "outbox" && !$pmid)
	{

		$result = $db_zugriff->query("SELECT bb".$n."_pmsend.*, bb".$n."_user_table.username FROM bb".$n."_pmsend LEFT JOIN bb".$n."_user_table ON (bb".$n."_pmsend.recipientid=bb".$n."_user_table.userid) WHERE bb".$n."_pmsend.userid = '$user_id' ORDER BY sendtime DESC");
		$pm_pmbit="";
		while ($row = $db_zugriff->fetch_array($result))
		{
			if($row['icon']) $icon = "<img src=\"".$row['icon']."\">";
			else $icon = "&nbsp;";
			$subject = prepare_topic($row['subject']);
			$recipientname = ($row['username']);
			$sendtime = formatdate($row['sendtime'],$longdateformat,1);
			$folder_image = "<img src=\"$imagefolder/pmnormal.gif\">";
			eval ("\$pm_pmbit .= \"".gettemplate("pm_pmbit2")."\";");
		}
	
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_folders WHERE userid = '$user_id'");
		$change_options="";
		while($folder = $db_zugriff->fetch_array($result)) $change_options .= "<option value=\"".$folder['folderid']."\">".htmlspecialchars($folder['foldername'])."</option>\n";
		if(!$pm_pmbit) eval ("\$pm_pmbit = \"".gettemplate("pm_nopm")."\";");
		eval("dooutput(\"".gettemplate("pm_outbox")."\");");
	}
	
	/*
	* empfangene PN ansehen
	*/
	elseif($pmid && $box != "outbox")
	{
		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pms WHERE pmid = '$pmid'");
		if($row['senderid']==$user_id) $links = "&nbsp;";
		elseif($row['recipientid']==$user_id)
		{
			$db_zugriff->query("UPDATE bb".$n."_pms SET view=1 WHERE pmid = '$pmid'");
			eval ("\$links = \"".gettemplate("pm_links")."\";");
		}
		else 
		{
			header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
			exit;
		}
		$user_info = $db_zugriff->query_first("SELECT username, signatur FROM bb".$n."_user_table WHERE userid = '$row[senderid]'");
		$sendername = ($user_info['username']);
		$recipientname = $db_zugriff->query_first("SELECT username FROM bb".$n."_user_table WHERE userid = '$row[recipientid]'");
		$recipientname = ($recipientname['username']);

		if($row['icon']) $icon = "<img src=\"".$row['icon']."\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row['subject']);
		$message = editPost($row['message'],$row['disable_smilies']);
		if($user_info['signatur'] && $row['signature'] && !$hide_signature)
		{
			$signatur = editSignatur($user_info['signatur'],$row['disable_smilies']);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		else $signature="";
		$sendtime = formatdate($row['sendtime'],$longdateformat,0);
		eval("dooutput(\"".gettemplate("pm_view")."\");");
	}

	/*
	* gesendete PN ansehen..
	*/
	elseif($pmid)
	{
		$links="";
		$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_pmsend WHERE pmid = '$pmid' AND userid = '$user_id'");
		$sendername = $user_name;
		$recipientname = getUsername($row['recipientid']);

		if($row['icon']) $icon = "<img src=\"".$row['icon']."\">";
		else $icon = "&nbsp;";
		$subject = prepare_topic($row['subject']);
		$message = editPost($row['message'],$row['disable_smilies']);
		if($userdata['signatur'] && $row['signature'] && !$hide_signature)
		{
			$signatur = editSignatur($userdata['signatur'],$row['disable_smilies']);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		else $signature="";
		$sendtime = formatdate($row['sendtime'],$longdateformat,0);

		eval("dooutput(\"".gettemplate("pm_view")."\");");
	}
}
else header("LOCATION: misc.php?action=access_error$session");
?>
