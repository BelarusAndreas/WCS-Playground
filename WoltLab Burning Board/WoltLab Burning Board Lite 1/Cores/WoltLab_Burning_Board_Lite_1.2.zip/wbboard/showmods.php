<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

function douserinfo() {
	global $userdata, $user, $avatar, $avatars, $hide_userpic, $sendpmlink, $pms, $user_group, $sendpmlink, $boardid, $session, $user_on_off;
	if($user['avatarid'] && !$hide_userpic && $avatars) $avatar = "<img src=\"images/avatars/avatar-".$user['avatarid'].".".$user['extension']."\" border=0>";
	else $avatar="";
	$user['location'] = htmlspecialchars($user['location']);
	$posts['userid'] = $user['userid'];
	$posts['username'] = $user['username'];
	if($pms && $userdata['canusepms']) eval ("\$sendpmlink = \"".gettemplate("thread_pm")."\";");
	if($user['zeit'] && !$user['invisible']) eval ("\$user_on_off = \"".gettemplate("thread_useron")."\";");
	else eval ("\$user_on_off = \"".gettemplate("thread_useroff")."\";");
}

$users = $db_zugriff->query("SELECT bb".$n."_user_table.*, extension, bb".$n."_groups.canuseacp, bb".$n."_useronline.zeit
FROM bb".$n."_groups, bb".$n."_user_table
LEFT JOIN bb".$n."_useronline USING (userid)
LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id=avatarid)
WHERE bb".$n."_user_table.groupid = bb".$n."_groups.id AND (bb".$n."_groups.canuseacp = 1 OR bb".$n."_groups.issupermod = 1) order by bb".$n."_groups.canuseacp DESC, bb".$n."_user_table.username ASC");
$acount = 0;
$scount = 0;
$adminbits = "";
$supermodbits = "";
while ($user = $db_zugriff->fetch_array($users)) {
	if ($user['canuseacp']) {
		$backcolor = rowcolor($acount++);
		douserinfo();
		eval("\$adminbits .= \"".gettemplate("showmods_adminbit")."\";");
	}
	else {
		$backcolor = rowcolor($scount++);
		douserinfo();
		eval("\$supermodbits .= \"".gettemplate("showmods_adminbit")."\";");
	}
}

// mods
$mcount = 0;
$result = $db_zugriff->query("SELECT bb".$n."_boards.boardid, boardname, invisible, boardpermission FROM bb".$n."_boards LEFT JOIN bb".$n."_object2board ON (bb".$n."_object2board.boardid=bb".$n."_boards.boardid AND objectid = '$user_group' AND boardpermission = 1)");
while($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardid']] = $row;
$result = $db_zugriff->query("SELECT objectid, boardid FROM bb".$n."_object2board WHERE mod = 1 ORDER BY objectid ASC");
while ($row = $db_zugriff->fetch_array($result)) $modcache[$row['objectid']][] = $row['boardid'];

$users = $db_zugriff->query("SELECT DISTINCT bb".$n."_user_table.userid, bb".$n."_user_table.*, extension, bb".$n."_useronline.zeit
FROM bb".$n."_object2board, bb".$n."_user_table
LEFT JOIN bb".$n."_useronline USING (userid)
LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id=avatarid)
WHERE bb".$n."_user_table.userid = bb".$n."_object2board.objectid AND bb".$n."_object2board.mod = 1 order by bb".$n."_user_table.username ASC");
$moderatorbits = "";
while ($user = $db_zugriff->fetch_array($users)) {
	$forumbits="";
	$backcolor = rowcolor($mcount++);
	douserinfo();
	for($i=0;$i<count($modcache[$user['userid']]);$i++) {
		if(!$boardcache[$modcache[$user['userid']][$i]]['boardpermission'] && $boardcache[$modcache[$user['userid']][$i]]['invisible']) continue;
		$forumbits .= "<a href=\"board.php?boardid=".$modcache[$user['userid']][$i]."$session\">".$boardcache[$modcache[$user['userid']][$i]]['boardname']."</a><br>";
	}
	eval("\$moderatorbits .= \"".gettemplate("showmods_bit")."\";");
}

eval("dooutput(\"".gettemplate("showmods")."\");");
?>
