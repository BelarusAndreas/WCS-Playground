<?php
require("global.php");


if($user_id)
{
	require("_header.php");
	require("_board_jump.php");
	if(isset($_POST['mode'])) $mode = $_POST['mode'];
	elseif(isset($_GET['mode'])) $mode = $_GET['mode'];
	else $mode = "";
	if(!isset($_POST['send'])) $_POST['send'] = "";
	if(!isset($error)) $error="";
	
	/*
	* Startseite
	*/
	if(!$mode)
	{
		$online = "";
		$offline = "";
		$buddylist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND buddylist = 1");
		while($row = $db_zugriff->fetch_array($buddylist))
		{
			if(checkuseronline($row['objectid']))
			{
				if($online) $online .= ", ";
				$online .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=$boardid$session\">".$row['username']."</a>";
			}
			else
			{
				if($offline) $offline .= ", ";
				$offline .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=$boardid$session\">".$row['username']."</a>";
			}
		}
		if($pms && $userdata['canusepms']) eval ("\$profile_pmlink= \"".gettemplate("profile_pmlink")."\";");
		eval("dooutput(\"".gettemplate("profile_main")."\");");
	}




	/*
	* Avatar bearbeiten
	*/
	elseif($mode == "avatars")
	{
		if($_POST['send'] == "send")
		{
			if($_POST['avatarid']!="useown") // vordefinierten Avatar aus der Liste verwenden.
			{
				$oldavatar = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
				if($oldavatar['id'])
				{
					@unlink("images/avatars/avatar-".$oldavatar['id'].".".$oldavatar['extension']);
					$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '$oldavatar[id]'");
				}
				$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = '".intval($_POST['avatarid'])."' WHERE userid = '$user_id'");
			}
			else // Avatar hochladen
			{
				if($_FILES['uploadfile']['tmp_name'])
				{
					$oldavatar = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
					if($oldavatar['id'])
					{
						@unlink("images/avatars/avatar-".$oldavatar['id'].".".$oldavatar['extension']);
						$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '".$oldavatar['id']."'");
					}
					$conf['avatar_size'] = $avatar_size;
					$conf['avatar_width'] = $avatar_width;
					$conf['avatar_height'] = $avatar_height;
					$setuserid = $user_id;

					$mimetype = explode("\n", $avatarimage_ext);
					for($i = 0; $i < count($mimetype); $i++) $mimetype[$i] = trim($mimetype[$i]);

					require_once("./admin/Upload.class.php");
					$upload = new Upload();

					$upload->setAllowedMimeTypes($mimetype);
					$upload->setUploadPath("images/avatars");

					if ($upload->doUpload()) $db_zugriff->query("UPDATE bb".$n."_user_table set avatarid = '$insertid' WHERE userid = '$user_id'");
					elseif(in_array("noFileException", $upload->uploadErrors[$upload->HTTP_POST_FILES[$upload->uploadFieldName]['name']])) eval ("\$error = \"".gettemplate("error7")."\";");
					elseif(in_array("mimeException", $upload->uploadErrors[$upload->HTTP_POST_FILES[$upload->uploadFieldName]['name']])) eval ("\$error = \"".gettemplate("error7")."\";");
					elseif(in_array("fileTooBigException", $upload->uploadErrors[$upload->HTTP_POST_FILES[$upload->uploadFieldName]['name']])) eval ("\$error = \"".gettemplate("error8")."\";");
					else eval ("\$error = \"".gettemplate("error3")."\";");
				}
				elseif(!isset($_POST['havatarid']) || !$_POST['havatarid']) eval ("\$error = \"".gettemplate("error3")."\";");
			}
		}
		
		/*
		* Avatarformular...
		*/
		$info = $db_zugriff->query_first("SELECT userposts, avatarid FROM bb".$n."_user_table WHERE userid = '$user_id'");
		if(!$info['avatarid'] || !$avatars) $checked = " CHECKED";
		else $checked = "";
		if($avatars)
		{
			$anzahl = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_avatars WHERE (groupid = '$user_group' OR groupid = 0) AND posts <= '$info[userposts]' AND userid = 0");
			if($anzahl[0])
			{
				if(isset($_GET['page'])) $page = intval($_GET['page']);
				else $page=1;
				$pages=ceil($anzahl[0]/25);
				$result = $db_zugriff->query("SELECT * FROM bb".$n."_avatars WHERE (groupid = '$user_group' OR groupid = 0) AND posts <= '$info[userposts]' AND userid = 0 ORDER BY name ASC LIMIT ".(25*($page-1)).", 25");
				while($row = $db_zugriff->fetch_array($result))
				{
					if($row['id']==$info['avatarid']) $avatarArray[] = "<input type=\"RADIO\" name=\"avatarid\" value=\"$row[id]\" CHECKED><img src=\"images/avatars/avatar-".$row['id'].".".$row['extension']."\">";
					else $avatarArray[] = "<input type=\"RADIO\" name=\"avatarid\" value=\"$row[id]\"><img src=\"images/avatars/avatar-".$row['id'].".".$row['extension']."\">";
				}
				$tableRows = ceil(count($avatarArray)/5);
				$count = 0;
				$avatarbit="";
				for ($i=0; $i<$tableRows; $i++)
				{
					$avatarbit .= "\t<tr bgcolor=\"{tableb}\" id=\"tableb\">\n";
					for ($j=0; $j<5; $j++)
					{
						if(!isset($avatarArray[$count])) $avatarArray[$count] = "";
						$avatarbit .= "\t<td align=\"center\">".$avatarArray[$count]."&nbsp;</td>\n";
						$count++;
					}
					$avatarbit .= "\t</tr>\n";
				}
				$countall = $anzahl[0];
				$countvon = 1+25*($page-1);
				$countbis = 25*$page;
				if($countbis > $countall) $countbis = $countall;

				if($pages>1)
				{
					$page_link .= "<br>[ ";
					if($page!=1) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=1\">&laquo;</a> <a href=\"profile.php?mode=$mode$session&page=".($page-1)."\">�</a> ";
					if($page>=6) $page_link .= "<a href=\"profile.php?mode=$mode$sessionpage=".($page-5)."\">...</a> ";
					if($page+4>=$pages) $pagex=$pages;
					else $pagex=$page+4;
					for($i=$page-4 ; $i<=$pagex ; $i++)
					{
						if($i<=0) $i=1;
						if($i==$page) $page_link .= $i." ";
						else $page_link .= "<a href=\"profile.php?mode=$mode$session&page=$i\">$i</a> ";
					}
					if(($pages-$page)>=5) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=".($page+5)."\">...</a> ";
					if($page!=$pages) $page_link .= "<a href=\"profile.php?mode=$mode$session&page=".($page+1)."\">�</a> <a href=\"profile.php?mode=$mode$session&page=".$pages."\">&raquo;</a>";
					$page_link .= " ]";
				}
				else $page_link = "";
				eval ("\$avatar_choice = \"".gettemplate("profile_avatar_choice")."\";");
			}
			else $avatar_choice = "";
			if($userdata['canuploadavatar'])
			{
				$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE userid = '$user_id'");
				if($info['id'])
				{
					$ownavatar = "<img src=\"images/avatars/avatar-".$info['id'].".".$info['extension']."\">";
					$havatar = "<input type=\"hidden\" name=\"havatarid\" value=\"".$info['id']."\">";
					$checked2= " CHECKED";
				}
				else
				{
					$ownavatar = "";
					$havatar = "";
					$checked2 = "";
				}
				eval ("\$avatar_choice .= \"".gettemplate("profile_avatar_useown")."\";");
			}
		}
		eval("dooutput(\"".gettemplate("profile_avatars")."\");");
	}



	/*
	* Profil bearbeiten
	*/
	elseif($mode=="editprofile")
	{
		$error = "";
		if($_POST['send'] == "send") // Speichern
		{
			if(!$_POST['email'] || !$_POST['emailconfirm'] || $_POST['email'] != $_POST['emailconfirm'] || strlen(trim($_POST['usertext'])) > $usertextlength || (getUserEmail($user_id) != $_POST['email'] && checkemail($_POST['email'])) || checkemail($_POST['email'],1)) eval ("\$error = \"".gettemplate("errorn1")."\";");
			else
			{
				if($_POST['homepage']) $_POST['homepage'] = editURL($_POST['homepage']);
				$db_zugriff->query("UPDATE bb".$n."_user_table SET useremail='".addslashes($_POST['email'])."', userhp='".addslashes($_POST['homepage'])."', usericq='".intval($_POST['icq'])."', aim='".addslashes($_POST['aim'])."', yim='".addslashes($_POST['yim'])."', age_m='".addslashes($_POST['month'])."', age_d='".addslashes($_POST['day'])."', age_y='".addslashes($_POST['year'])."', location='".addslashes($_POST['location'])."', interests='".addslashes(nt_wordwrap($_POST['interests'],20))."', work='".addslashes($_POST['work'])."', gender = '".intval($_POST['gender'])."', usertext = '".addslashes(nt_wordwrap($_POST['usertext'],25))."' WHERE userid='$user_id'");
			}
		}

		$user_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid='$user_id'");
		if(!$user_info['age_d']) $day_select = "<option value=\"\" selected></option>";
		else $day_select = "<option value=\"\"></option>";

		if($user_info['usertext']) $usertext = htmlspecialchars($user_info['usertext']);
		else $usertext = "";

		$gender_sel[1] = "";
		$gender_sel[2] = "";
		if($user_info['gender']==1) $gender_sel[1] = " selected";
		elseif($user_info['gender']==2) $gender_sel[2] = " selected";

		for($i = 1; $i <= 31; $i++)
		{
			$day_select .= "<option value=\"$i\"";
			if($user_info['age_d']=="$i") $day_select .= " selected";
			$day_select .= ">$i</option>";
		}

		$month_sel[0]="";
		$month_sel[1]="";
		$month_sel[2]="";
		$month_sel[3]="";
		$month_sel[4]="";
		$month_sel[5]="";
		$month_sel[6]="";
		$month_sel[7]="";
		$month_sel[8]="";
		$month_sel[9]="";
		$month_sel[10]="";
		$month_sel[11]="";
		$month_sel[12]="";
		if(!$user_info['age_m']) $month_sel[0] = " selected";
		elseif($user_info['age_m']=="Januar") $month_sel[1] = " selected";
		elseif($user_info['age_m']=="Februar") $month_sel[2] = " selected";
		elseif($user_info['age_m']=="M�rz") $month_sel[3] = " selected";
		elseif($user_info['age_m']=="April") $month_sel[4] = " selected";
		elseif($user_info['age_m']=="Mai") $month_sel[5] = " selected";
		elseif($user_info['age_m']=="Juni") $month_sel[6] = " selected";
		elseif($user_info['age_m']=="Juli") $month_sel[7] = " selected";
		elseif($user_info['age_m']=="August") $month_sel[8] = " selected";
		elseif($user_info['age_m']=="September") $month_sel[9] = " selected";
		elseif($user_info['age_m']=="Oktober") $month_sel[10] = " selected";
		elseif($user_info['age_m']=="November") $month_sel[11] = " selected";
		elseif($user_info['age_m']=="Dezember") $month_sel[12] = " selected";

		$usericq = $user_info['usericq'];
		$aim = htmlspecialchars($user_info['aim']);
		$yim = htmlspecialchars($user_info['yim']);
		$age_y = $user_info['age_y'];
		$location = htmlspecialchars($user_info['location']);
		$interests = htmlspecialchars($user_info['interests']);
		$work = htmlspecialchars($user_info['work']);

		eval("dooutput(\"".gettemplate("profile_editprofile")."\");");
	}



	/*
	* Signatur bearbeiten
	*/
	elseif($mode=="editsignature")
	{
		$error = "";
		if(!isset($_POST['preview'])) $_POST['preview']=0;
		if($_POST['send'] && !$_POST['preview'])
		{
			if(strlen(trim($_POST['message'])) > $siglength || check_signature($_POST['message'])) eval ("\$error = \"".gettemplate("errorn1")."\";");
			else $db_zugriff->query("UPDATE bb".$n."_user_table set signatur = '".addslashes(parseURL(nt_wordwrap($_POST['message'])))."' WHERE userid = '$user_id'");
		}
		elseif($_POST['send'] && (strlen(trim($_POST['message']))>$siglength || check_signature($_POST['message']))) eval ("\$error = \"".gettemplate("errorn1")."\";");
		if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
		if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);

		$note = "";
		if($sightml) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
		else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
		if(!$sigsmilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
		if(!$sigbbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

		$user_info = $db_zugriff->query_first("SELECT signatur FROM bb".$n."_user_table WHERE userid='$user_id'");
		if($user_info['signatur'])
		{
			$old_signature = editSignatur($user_info['signatur'],0);
			eval ("\$old_signatur = \"".gettemplate("profile_old_signature")."\";");
			if(!$_POST['preview']) $signature = htmlspecialchars($user_info['signatur']);
		}
		else
		{
			$old_signatur="";
			$signature="";
		}
		
		if($_POST['preview'] || $error)
		{
			if($_POST['preview'] && !$error)
			{
				$preview_signature = editSignatur($_POST['message'],0);
				eval ("\$preview = \"".gettemplate("profile_preview_signature")."\";");
			}
			$signature = htmlspecialchars($_POST['message']);
		}
		else $preview="";
		eval("dooutput(\"".gettemplate("profile_editsignature")."\");");
	}





	/*
	* Passwort �ndern
	*/
	elseif($mode=="changepw")
	{
		if(!isset($error)) $error="";
		if($_POST['send'] == "send")
		{
			if(!$_POST['password'] || !$_POST['confirmpassword'] || !$_POST['old_password'] || $_POST['password']!=$_POST['confirmpassword'] || !checkpw($user_id,md5($_POST['old_password']))) eval ("\$error = \"".gettemplate("errorn1")."\";");
			else
			{
				$user_password = md5($_POST['password']);
				$db_zugriff->query("UPDATE bb".$n."_user_table SET userpassword='".addslashes($user_password)."' WHERE userid='$user_id'");
				wbb_session_register("user_password");
				if($session_link) setcookie("user_password", "$user_password", time()+(3600*24*365));
				header("Location: profile.php?boardid=$boardid$session");
				exit;
			}
		}
		eval("dooutput(\"".gettemplate("profile_changepw")."\");");
	}




	/*
	* Optionen/Einstellungen bearbeiten
	*/
	elseif($mode=="editoptions")
	{
		if($_POST['send'] == "send")
		{
			$db_zugriff->query("UPDATE bb".$n."_user_table SET invisible='".intval($_POST['ghost'])."', session_link='".intval($_POST['slink'])."', mods_may_email='".intval($_POST['mod_email'])."', users_may_email='".intval($_POST['form_email'])."', show_email_global='".intval($_POST['hide_email'])."', hide_signature='".intval($_POST['show_signature'])."', hide_userpic='".intval($_POST['show_userpic'])."', prunedays='".intval($_POST['s_prunedays'])."', umaxposts='".intval($_POST['s_umaxposts'])."', bbcode='".intval($_POST['use_bbcode'])."', style_set='".intval($_POST['ustyleset'])."' WHERE userid='$user_id'");
			header("Location: profile.php?boardid=$boardid$session");
			exit;
		}
		$user = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid='$user_id'");


		$ghost=array("","");
		$slink=array("","");
		$mod_email=array("","");
		$hide_email=array("","");
		$form_email=array("","");
		$show_signature=array("","");
		$show_userpic=array("","");
		if($user['invisible']) $ghost[1] = "Checked";
		else $ghost[0] = "Checked";
		if($user['session_link']) $slink[1] = "Checked";
		else $slink[0] = "Checked";
		if($user['mods_may_email']) $mod_email[1] = "Checked";
		else $mod_email[0] = "Checked";
		if($user['show_email_global']) $hide_email[1] = "Checked";
		else $hide_email[0] = "Checked";
		if($user['users_may_email']) $form_email[1] = "Checked";
		else $form_email[0] = "Checked";
		if($user['hide_signature']) $show_signature[1] = "Checked";
		else $show_signature[0] = "Checked";
		if($user['hide_userpic']) $show_userpic[1] = "Checked";
		else $show_userpic[0] = "Checked";

		$s_prunedays = array("","","","","","","","","","","","","");
		if(!$user['prunedays']) $s_prunedays[0] = "selected";
		elseif($user['prunedays']==1) $s_prunedays[1] = "selected";
		elseif($user['prunedays']==2) $s_prunedays[2] = "selected";
		elseif($user['prunedays']==5) $s_prunedays[3] = "selected";
		elseif($user['prunedays']==10) $s_prunedays[4] = "selected";
		elseif($user['prunedays']==20) $s_prunedays[5] = "selected";
		elseif($user['prunedays']==30) $s_prunedays[6] = "selected";
		elseif($user['prunedays']==45) $s_prunedays[7] = "selected";
		elseif($user['prunedays']==60) $s_prunedays[8] = "selected";
		elseif($user['prunedays']==75) $s_prunedays[9] = "selected";
		elseif($user['prunedays']==100) $s_prunedays[10] = "selected";
		elseif($user['prunedays']==365) $s_prunedays[11] = "selected";
		elseif($user['prunedays']==1000) $s_prunedays[12] = "selected";

		$s_umaxposts=array("","","","","","");
		if(!$user['umaxposts']) $s_umaxposts[0] = "selected";
		elseif($user['umaxposts']==5) $s_umaxposts[1] = "selected";
		elseif($user['umaxposts']==10) $s_umaxposts[2] = "selected";
		elseif($user['umaxposts']==20) $s_umaxposts[3] = "selected";
		elseif($user['umaxposts']==30) $s_umaxposts[4] = "selected";
		elseif($user['umaxposts']==40) $s_umaxposts[5] = "selected";

		$use_bbcode=array("","");
		if($user['bbcode']) $use_bbcode[1] = "Checked";
		else $use_bbcode[0] = "Checked";

		$style_result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style = 0 ORDER by stylename ASC");
		$u_style="";
		while($row = $db_zugriff->fetch_array($style_result))
		{
			$u_style .= "<option value=\"".$row['styleid']."\"".ifelse(($user['style_set']==$row['styleid'])," selected").">".$row['stylename']."</option>";
		}
		$db_zugriff->free_result($style_result);
		eval("dooutput(\"".gettemplate("profile_editoptions")."\");");
	}






	/*
	* Buddyliste
	*/
	elseif($mode=="buddy")
	{
		if($_POST['send'] == "send" && $_POST['buddylist'])
		{
			$buddylist = explode(",",$_POST['buddylist']);
			for($i = 0; $i < count($buddylist); $i++)
			{
				$buddylist[$i] = getUserid(htmlspecialchars(trim($buddylist[$i])));
				if(!$buddylist[$i] || $buddylist[$i]==$user_id) continue;
				if(check_userobject($user_id,$buddylist[$i],"buddylist")) $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$user_id' AND objectid = '$buddylist[$i]' AND buddylist = 1");
				else $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,buddylist) VALUES ('$user_id','$buddylist[$i]','1')");
			}
		}

		$buddylist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND buddylist = 1");
		$online = "";
		$offline = "";
		while($row = $db_zugriff->fetch_array($buddylist))
		{
			if(checkuseronline($row['objectid']))
			{
				if($online) $online .= ", ";
				$online .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=$boardid$session\">".$row['username']."</a>";
			}
			else
			{
				if($offline) $offline .= ", ";
				$offline .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=$boardid$session\">".$row['username']."</a>";
			}
		}
		eval("dooutput(\"".gettemplate("profile_buddy")."\");");
	}






	/*
	* Ignorierliste
	*/
	elseif($mode=="ignore")
	{
		if($_POST['send'] == "send" && $_POST['ignorelist'])
		{
			$ignorelist = explode(",",$_POST['ignorelist']);
			for($i = 0; $i < count($ignorelist); $i++)
			{
				$ignorelist[$i] = getUserid(htmlspecialchars(trim($ignorelist[$i])));
				if(!$ignorelist[$i] || $ignorelist[$i]==$user_id) continue;
				if(check_userobject($user_id,$ignorelist[$i],"ignorelist")) $db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '$user_id' AND objectid = '$ignorelist[$i]' AND ignorelist = 1");
				else $db_zugriff->query("INSERT INTO bb".$n."_object2user (userid,objectid,ignorelist) VALUES ('$user_id','$ignorelist[$i]','1')");
			}
		}

		$ignoreusers = "";
		$ignorelist = $db_zugriff->query("SELECT objectid, username FROM bb".$n."_object2user LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_object2user.objectid) WHERE bb".$n."_object2user.userid='$user_id' AND ignorelist = 1");
		while($row = $db_zugriff->fetch_array($ignorelist))
		{
			if($ignoreusers) $ignoreusers .= "<br>";
			$ignoreusers .= "<a href=\"members.php?mode=profile&userid=".$row['objectid']."&boardid=$boardid$session\">".$row['username']."</a>";
		}
		eval("dooutput(\"".gettemplate("profile_ignore")."\");");
	}






	/*
	* Favoriten
	*/
	elseif($mode=="subscripe")
	{
	
		$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
		while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
		$result = $db_zugriff->query("SELECT userid, username, boardid FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid = bb".$n."_user_table.userid) WHERE mod = 1 ORDER BY username ASC");
		while ($row = $db_zugriff->fetch_array($result)) $modcache[$row['boardid']][] = $row;

		$result = $db_zugriff->query("
			SELECT
			bb".$n."_object2user.objectid as boardid,
			bb".$n."_boards.*,
			bb".$n."_posts.threadparentid,
			bb".$n."_posts.userid,
			bb".$n."_posts.posttime,
			bb".$n."_threads.threadname,
			bb".$n."_threads.topicicon,
			bb".$n."_threads.boardparentid as parentid,
			bb".$n."_user_table.username
			FROM bb".$n."_object2user
			LEFT JOIN bb".$n."_boards ON (bb".$n."_object2user.objectid = bb".$n."_boards.boardid)
			LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid)
			LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid)
			LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid)
			WHERE bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favboards = 1
			ORDER by boardname ASC");

		$boardbit="";
		while ($boards = $db_zugriff->fetch_array($result))
		{
			if($boards['invisible'] && !check_boardobject($boards['boardid'],$user_group,"boardpermission")) continue;

			eval ("\$delboard = \"".gettemplate("profile_subscripe_delboard")."\";");
			$subboards = "";
			if($old_time <= $boards['lastposttime']) eval ("\$on_or_off = \"".gettemplate("main_newposts")."\";");
			else eval ("\$on_or_off = \"".gettemplate("main_nonewposts")."\";");
	
			if($boards['lastpostid'])
			{
				$lastposttime = formatdate($boards['posttime'],$longdateformat,1);
				if($boards['userid']) $lastauthor = "<a href=\"members.php?mode=profile&userid=".$boards['userid'].$session."\">".($boards['username'])."</a>";
				else eval ("\$lastauthor = \"".gettemplate("lg_anonymous")."\";");
			
				$boards['threadname'] = prepare_topic($boards['threadname']);
				if (!$boards['topicicon']) $ViewPosticon = "<img src=\"images/icons/noicon.gif\">";
				else $ViewPosticon = "<img src=\"$boards[topicicon]\">";
				if(isset($permissioncache[$boards['boardid']]) && $permissioncache[$boards['boardid']]) $template="main_lastpost";
				else $template="main_lastpost2";
				if (strlen($boards['threadname']) > '30') $ViewThreadname = substr($boards['threadname'], 0, 27)."...";
        		else $ViewThreadname = $boards['threadname'];
        		eval ("\$last_post = \"".gettemplate("$template")."\";");
			}
			else $last_post = "&nbsp;";
			
			$moderators = "";
			if(isset($modcache[$boards['boardid']]))
			{
				while (list($mkey,$moderator)=each($modcache[$boards['boardid']]))
				{
    	        	if ($moderators) $moderators .= ", ";
            		$moderators .= "<a href=\"members.php?mode=profile&userid=".$moderator['userid'].$session."\">".($moderator['username'])."</a>";
				}
			}
			eval ("\$boardbit .= \"".gettemplate("main_boardbit2")."\";");
			unset($moderators);
	
		}
		$db_zugriff->free_result($result);
		
		if($boardbit) eval ("\$subscripe_boards = \"".gettemplate("profile_subscripe_board")."\";");
		else $subscripe_boards = "";
		
		
		

		$thread_result = $db_zugriff->query("SELECT DISTINCT bb".$n."_threads.threadid, bb".$n."_threads.* FROM bb".$n."_threads, bb".$n."_object2user WHERE bb".$n."_object2user.objectid = bb".$n."_threads.threadid AND bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favthreads = 1 ORDER by important DESC, timelastreply DESC");
		$threadbit = "";
		$subscripe_threads = "";
		if($db_zugriff->num_rows($thread_result))
		{
			while($threads = $db_zugriff->fetch_array($thread_result))
			{
				unset($folder_image);
				unset($thread_link);
				unset($rate);
				unset($anonymous_lp);
				unset($anonymous);
				unset($thread_starter);
				unset($lastauthor);

				#$sthreadname = "sthread_".$threads['threadid'];
				$sthreadname = $threads['threadid'];
				$folder_image = "";
				if($old_time <= $threads['timelastreply'] && ((isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) || !isset($sthreads_array[$sthreadname]))) $folder_image .= "new";				
				if($threads['replies'] > "15" || $threads['views'] > "150") $folder_image .= "hot";
				if($threads['flags']==1) $folder_image .= "lock";
				$folder_image = "<img src=\"$imagefolder/".$folder_image."folder.gif\">";

				if($threads['topicicon']) $posticon = "<img src=\"$threads[topicicon]\">";
				else $posticon = "&nbsp;";

				$thread_link = "";
				if($old_time <= $threads['timelastreply'] && isset($_SESSION[$sthreadname]) && $_SESSION[$sthreadname] < $threads['timelastreply']) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
				$thread_link .= "<font size=2 face=\"{font}\"><b>";
				if($threads['important']) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
				if($threads['pquestion']) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
				$thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session\">".prepare_topic($threads['threadname'])."</a></b></font>";
				if(($threads['replies']+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"$font\"> ( <img src=\"$imagefolder/multipage.gif\"> <a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=1\">1</a> <a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=2\">2</a> ";
				if(($threads['replies']+1)/$eproseite > 2) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=3\">3</a> ";
				if(($threads['replies']+1)/$eproseite > 3) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=4\">4</a> ";
				if(($threads['replies']+1)/$eproseite > 4)
				{
					$pagesx=ceil(($threads['replies']+1)/$eproseite);
					eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
					$pages = 0;
				}
				if(($threads['replies']+1)/$eproseite > 1) $thread_link .= ")";
				eval ("\$thread_link .= \"".gettemplate("profile_subscripe_delthread")."\";");

				$starttime = formatdate($threads['starttime'],$longdateformat,1);
				$anonymous = "";
				if($threads['authorid']) $thread_starter = getUsername($threads['authorid']);
				else
				{
					$thread_starter = "";
					eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
				}
				$lastposttime = formatdate($threads['timelastreply'],$longdateformat,1);
				$lastauthorid = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE threadparentid='".$threads['threadid']."' ORDER by posttime DESC LIMIT 1");
				$lastauthorid = $lastauthorid['userid'];
				$anonymous_lp="";
				if($lastauthorid) $lastauthor = getUsername($lastauthorid);
				else
				{
					$lastauthor = "";
					eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
				}

				eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");

				if($threads['rated'] && $threads['rate_points'])
				{
					$rate = str_repeat("<img src=\"$imagefolder/star.gif\" border=0>",round($threads['rate_points']/$threads['rated']));
				}
				else $rate = "&nbsp;";

				eval ("\$threadbit .= \"".gettemplate("board_threadbit")."\";");
			}
			$db_zugriff->free_result($thread_result);
			eval ("\$subscripe_threads .= \"".gettemplate("profile_subscripe_thread")."\";");
		}
		eval("dooutput(\"".gettemplate("profile_subscripe")."\");");
	}
	
	
	
	elseif($mode=="subscripe2")
	{
		$result = $db_zugriff->query("
			SELECT
			bb".$n."_object2user.objectid as boardid,
			bb".$n."_boards.*,
			bb".$n."_posts.threadparentid,
			bb".$n."_posts.userid,
			bb".$n."_posts.posttime,
			bb".$n."_threads.threadname,
			bb".$n."_threads.topicicon,
			bb".$n."_threads.boardparentid as parentid,
			bb".$n."_user_table.username
			FROM bb".$n."_object2user
			LEFT JOIN bb".$n."_boards ON (bb".$n."_object2user.objectid = bb".$n."_boards.boardid)
			LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid)
			LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid)
			LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid)
			WHERE bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favboards = 1
			ORDER by boardparentid ASC, sort ASC");

		$firstid = "";
		while ($row = $db_zugriff->fetch_array($result))
		{
			if($row['invisible'] && !check_boardobject($row['boardid'],$user_group,"boardpermission")) continue;
			if(!$firstid) $firstid = $row['boardparentid'];
			$boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
		}
		$boardbit = makeforumbit($firstid,1,1);
		$db_zugriff->free_result($result);
		if($boardbit) eval ("\$subscripe_boards = \"".gettemplate("profile_subscripe_board")."\";");
		else $subscripe_boards = "";

		$thread_result = $db_zugriff->query("SELECT DISTINCT bb".$n."_threads.threadid, bb".$n."_threads.* FROM bb".$n."_threads, bb".$n."_object2user WHERE bb".$n."_object2user.objectid = bb".$n."_threads.threadid AND bb".$n."_object2user.userid = '$user_id' AND bb".$n."_object2user.favthreads = 1 ORDER by important DESC, timelastreply DESC");
		$threadbit = "";
		$subscripe_threads = "";
		if($db_zugriff->num_rows($thread_result))
		{
			while($threads = $db_zugriff->fetch_array($thread_result))
			{
				unset($folder_image);
				unset($thread_link);
				unset($rate);
				unset($anonymous_lp);
				unset($anonymous);
				unset($thread_starter);
				unset($lastauthor);

				$sthreadname = "sthread_".$threads['threadid'];
				$folder_image = "";
				if($old_time <= $threads['timelastreply'] && isset($_SESSION[$sthreadname]) &&$_SESSION[$sthreadname] < $threads['timelastreply']) $folder_image .= "new";
				if($threads['replies'] > "15" || $threads['views'] > "150") $folder_image .= "hot";
				if($threads['flags']==1) $folder_image .= "lock";
				$folder_image = "<img src=\"images/".$folder_image."folder.gif\">";

				if($threads['topicicon']) $posticon = "<img src=\"$threads[topicicon]\">";
				else $posticon = "&nbsp;";

				$thread_link = "";
				if($old_time <= $threads['timelastreply'] && isset($_SESSION[$sthreadname]) && $_SESSION[$sthreadname] < $threads['timelastreply']) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
				$thread_link .= "<font size=2 face=\"{font}\"><b>";
				if($threads['important']) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
				if($threads['pquestion']) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
				$thread_link .= "<a class=\"link\" href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]&styleid=$styleid$session\">".prepare_topic($threads['threadname'])."</a></b></font>";
				if(($threads['replies']+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"$font\"> ( <img src=\"images/multipage.gif\"> <a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=1\">1</a> <a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=2\">2</a> ";
				if(($threads['replies']+1)/$eproseite > 2) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=3\">3</a> ";
				if(($threads['replies']+1)/$eproseite > 3) $thread_link .= "<a class=\"link\" href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid']."&styleid=".$styleid.$session."&page=4\">4</a> ";
				if(($threads['replies']+1)/$eproseite > 4)
				{
					$pagesx=ceil(($threads['replies']+1)/$eproseite);
					eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
					$pages = 0;
				}
				if(($threads['replies']+1)/$eproseite > 1) $thread_link .= ")";
				eval ("\$thread_link .= \"".gettemplate("profile_subscripe_delthread")."\";");

				$starttime = formatdate($threads['starttime'],$longdateformat,1);
				$anonymous = "";
				if($threads['authorid']) $thread_starter = getUsername($threads['authorid']);
				else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
				$lastposttime = formatdate($threads['timelastreply'],$longdateformat,1);
				$lastauthorid = $db_zugriff->query_first("SELECT userid FROM bb".$n."_posts WHERE threadparentid='".$threads['threadid']."' ORDER by posttime DESC LIMIT 1");
				$lastauthorid = $lastauthorid['userid'];
				$anonymous_lp="";
				if($lastauthorid) $lastauthor = getUsername($lastauthorid);
				else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");

				eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");

				if($threads['rated'] && $threads['rate_points'])
				{
					$rate = str_repeat("<img src=\"images/star.gif\" border=0>",round($threads['rate_points']/$threads['rated']));
					#$j = round($threads['rate_points']/$threads['rated']);
					#for ($j; $j > 0; $j--) $rate .= "<img src=\"images/star.gif\" border=0>";
				}
				else $rate = "&nbsp;";

				eval ("\$threadbit .= \"".gettemplate("board_threadbit")."\";");
			}
			$db_zugriff->free_result($thread_result);
			eval ("\$subscripe_threads .= \"".gettemplate("profile_subscripe_thread")."\";");
		}
		eval("dooutput(\"".gettemplate("profile_subscripe")."\");");
	}
	
}

else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>

