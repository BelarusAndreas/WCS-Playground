b_text = "fetten Text einf�gen";
i_text = "kursiven Text einf�gen";
u_text = "unterstrichenen Text einf�gen";

size_text = "Textgr��e �ndern";
font_text = "Schriftart �ndern";
color_text = "Schriftfarbe �ndern";
align_text = "Text-Ausrichtung �ndern";

url_text = "Hyperlink einf�gen";
email_text = "Email Adresse einf�gen";
img_text = "Grafik einf�gen";

code_text = "monospace Text einf�gen";
php_text = "PHP Code einf�gen";
list_text = "Liste einf�gen";
quote_text = "Zitat einf�gen";

norm_text = "einfacher Modus";
enha_text = "erweiterter Modus";

closecurrent_text = "aktuellen tag schlie�en";
closeall_text = "alle tags schlie�en";

enhanced_only_text = "<< nur im erweiterten Modus verf�gbar >>";
no_tags_text = "<< keine offenen tags vorhanden >>";
already_open_text = "<< es ist bereit der selbe tag offen >>";

HELPTEXT = "Einfaches Einf�gen von BBCode und Smilies.\n\nDiese Kontrollen erlauben das schnelle und einfache Einf�gen von BBcode in Nachrichten.\n\nEs gibt 2 Moden bei der Benutzung: einfacher and erweiterter Modus.\n\nBeim einfachen Modus �ffnet sich beim dr�cken eines Buttons ein Pop-up Fenster,\nwo man den zu formatierenden Text eingeben kann\nDer Text wird dann automatisch an der aktuellen Position des Nachricht angehangen.\n\nBeim erweiterten Modus wird ein BBCode tag sofort in die Nachricht eingef�gt.\nUm den entsprechenden tag dann wieder zu schlie�en,\nmu� man auf den 'aktuellen tag schlie�en' Button (alt+c) dr�cken.\nMan kann allerdings auch alle offenen tags auf einmal schlie�en,\nindem man den 'alle tags schlie�en' Button (alt+x) benutzt.\n\nUm einen Smilie in die Nachricht einzuf�gen, mu� man einfach auf den Gew�nschten klicken.\nAu�erdem hat man mit einem Klick auf den Button 'mehr' alle Smilies zur Auswahl.";

tag_prompt = "Gebe einen Text ein:";

font_formatter_prompt = "Gebe einen Text ein - ";

link_text_prompt = "Gebe einen Linknamen ein (optional)";
link_url_prompt = "Gebe die volle Adresse des Links ein";
link_email_prompt = "Gebe eine Email Adesse ein";

list_type_prompt = "was f�r eine Liste m�chtest du? Gebe '1' ein f�r eine nummerierte Liste, 'a' f�r ein alphabetische, oder gar nichts f�r eine einfache Punktliste.";
list_item_prompt = "Gebe eine Listepunkt ein.\nGebe nichts ein oder dr�cke 'Cancel' um die Liste fertigzustellen.";
