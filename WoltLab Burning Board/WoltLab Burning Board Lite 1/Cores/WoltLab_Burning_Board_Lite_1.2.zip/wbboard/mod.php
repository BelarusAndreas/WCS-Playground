<?php
require("global.php");
require("_header.php");

if(isset($_POST['action'])) $action = $_POST['action'];
elseif(isset($_GET['action'])) $action = $_GET['action'];
else $action = "";
if(!isset($_POST['action'])) $_POST['action']="";
if(!isset($_POST['send'])) $_POST['send']="";
if(!isset($_GET['action'])) $_GET['action']="";

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info['boardparentid']) {
	echo $boardid."--".$thread_info['boardparentid'];
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}

if($action==-1)
{
	eval ("\$output = \"".gettemplate("error2")."\";");
	eval("dooutput(\"".gettemplate("action_error")."\");");
	exit;
}








/*
* Umfrage bearbeiten
*/
if($_GET['action'] == "polledit")
{
	if($userdata['issupermod'] || check_boardobject($boardid, $userid, "mod"))
	{
		$ptitle = prepare_topic($thread_info['pquestion']);
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid = '$threadid' ORDER BY id ASC");
		$j=0;
		$fields="";
		while($row = $db_zugriff->fetch_array($result))
		{
			$j++;
			$row['field'] = prepare_topic($row['field']);
			eval ("\$fields .= \"".gettemplate("mod_pollbit")."\";");
		}
		eval("dooutput(\"".gettemplate("mod_polledit")."\");");
	}
	else header("LOCATION: misc.php?action=access_error$session");
}


/*
* Umfrage speichern .. 
*/
if($_POST['action'] == "polledit_write") {
	if($userdata['issupermod'] || check_boardobject($boardid, $userid, "mod"))
	{
		/*
		* Umfrage l�schen
		*/
		if(isset($_POST['delete']) && $_POST['delete'])
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '', ptimeout = 0 WHERE threadid = '$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid = '$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid = '$threadid'");
			header("LOCATION: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;
		}
		/*
		* Umfrage speichern
		*/
		elseif($_POST['ptitle'] && count($_POST['pfield'])>=2)
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '".addslashes(trim($_POST['ptitle']))."', ptimeout = '".addslashes($_POST['ptimeout'])."' WHERE threadid = '$threadid'");
			while(list($key,$val) = each($_POST['pfield'])) $db_zugriff->query("UPDATE bb".$n."_poll SET field = '".addslashes($val)."' WHERE id = '".intval($key)."'");
			header("LOCATION: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;
		}
		/*
		* Eingabefehler.
		*/
		else {
			eval ("\$output = \"".gettemplate("error3")."\";");
			eval("dooutput(\"".gettemplate("action_error")."\");");
			exit;
		}
	}
	else header("LOCATION: misc.php?action=access_error$session");
}


/*
* Thema schliessen/�ffnen.
*/
if($_POST['action'] == "close")
{
	if(check_boardobject($boardid,$user_id,"mod") || $userdata['issupermod'] || ($thread_info['authorid'] && $thread_info['authorid']==$user_id && $userdata['cancloseowntopic']))
	{
		/*
		* �ffnen
		*/
		if($thread_info['flags'])
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET flags='0' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note9")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		
		/*
		* Schliessen
		*/
		else
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET flags='1' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note10")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		eval("dooutput(\"".gettemplate("action_ride")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}


/*
* Thema verschieben ..
*/
if($_POST['action'] == "move") {
	if((check_boardobject($boardid,$user_id,"mod") && $userdata['ismod']) || $userdata['issupermod'])
	{
		/*
		* Speichern - in dem Fall verschieben...
		*/
		if($_POST['send'] == "send")
		{
			$check=$db_zugriff->query_first("SELECT boardid,isboard FROM bb".$n."_boards WHERE boardid='".intval($_POST['newboardid'])."'");
			if($check['boardid'] && $check['isboard']==1 && $check['boardid']!=$_POST['putoffid'])
			{
				if(isset($_POST['copy']) && $_POST['copy']) $db_zugriff->query("UPDATE bb".$n."_threads SET boardparentid='".intval($_POST['newboardid'])."', putoffid='".intval($_POST['putoffid'])."' WHERE threadid='$threadid'");
				else $db_zugriff->query("UPDATE bb".$n."_threads SET boardparentid='".intval($_POST['newboardid'])."', putoffid='0' WHERE threadid='$threadid'");
				$db_zugriff->query("UPDATE bb".$n."_posts SET boardparentid='".intval($_POST['newboardid'])."' WHERE threadparentid='$threadid'");
	
				/*
				* Boardinfos updaten
				*/
				$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '".intval($_POST['putoffid'])."' ORDER BY posttime DESC LIMIT 1");
				$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads-1, posts=posts-".($thread_info['replies']+1).", lastposttime = '".$pinfo['posttime']."', lastpostid = '".$pinfo['postid']."' WHERE boardid = '".intval($_POST['putoffid'])."'");
				$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '".intval($_POST['newboardid'])."' ORDER BY posttime DESC LIMIT 1");
				$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads+1, posts=posts+".($thread_info['replies']+1).", lastposttime = '".$pinfo['posttime']."', lastpostid = '".$pinfo['postid']."' WHERE boardid = '".intval($_POST['newboardid'])."'");
	
				eval ("\$output = \"".gettemplate("mod_note11")."\";");
				$ride = "thread.php?threadid=$threadid&boardid=".$_POST['newboardid']."&styleid=$styleid$session";
				eval("dooutput(\"".gettemplate("action_ride")."\");");
				exit;
			}
		}
		
		$result = $db_zugriff->query("SELECT * FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
		while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
		$board_result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE boardid<>$boardid AND isboard = 1 ORDER BY boardname ASC");
		$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
		while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
		$select = makeboardjumpbit2(0);

		/*$select="";
		while($boards = $db_zugriff->fetch_array($board_result)) {
			$select .= "<option value=\"".$boards['boardid']."\">".$boards['boardname']."</option>";
		}
		$db_zugriff->free_result($board_result);*/
		eval("dooutput(\"".gettemplate("mod_move")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}



/*
* Thema l�schen
*/
if($_POST['action'] == "del")
{
	if((check_boardobject($boardid,$user_id,"mod") && $userdata['ismod']) || $userdata['issupermod'] || ($thread_info['authorid'] && $thread_info['authorid']==$user_id && $userdata['candelowntopic']))
	{
		/*
		* l�schen
		*/
		if($_POST['send'] == "send")
		{
			$post_result = $db_zugriff->query("SELECT userid FROM bb".$n."_posts WHERE threadparentid='$threadid'");
			while($row = $db_zugriff->fetch_array($post_result))
			{
				delUserposts($row['userid']);
			}
			$db_zugriff->query("DELETE FROM bb".$n."_threads WHERE threadid='$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_posts WHERE threadparentid='$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid='$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid='$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid='$threadid'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid='$threadid' AND favthreads = 1");

			/*
			* Boardinfos updaten
			*/
			$pinfo = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '$boardid' ORDER BY posttime DESC LIMIT 1");
			$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads-1, posts=posts-".($thread_info['replies']+1).", lastposttime = '".$pinfo['posttime']."', lastpostid = '".$pinfo['postid']."' WHERE boardid = '$boardid'");

			eval ("\$output = \"".gettemplate("mod_note12")."\";");
			$ride = "board.php?boardid=$boardid&styleid=$styleid$session";
			eval("dooutput(\"".gettemplate("action_ride")."\");");
		}
		else eval("dooutput(\"".gettemplate("mod_del")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}









/*
* Thema festhalten/l�sen
*/
if($_POST['action'] == "top") {
	if($userdata['issupermod'] || ($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod")))
	{
		if($thread_info['important']) // l�sen
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET important='0' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note14")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		else // festhalten
		{
			$db_zugriff->query("UPDATE bb".$n."_threads SET important='1' WHERE threadid='$threadid'");
			eval ("\$output = \"".gettemplate("mod_note13")."\";");
			$ride = "thread.php?threadid=$threadid&boardid=$boardid&styleid=$styleid$session";
		}
		eval("dooutput(\"".gettemplate("action_ride")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}





/*
* Thema bearbeiten ..
*/

if($_POST['action'] == "threadedit") {
	if($userdata['issupermod'] || ($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod")))
	{
		include("./posticons.php");
		/*
		* Daten abspeichern.
		*/
		if($_POST['send'] == "send" && $_POST['subject'] = trim($_POST['subject'])) 
		{
			if(isset($_POST['posticon']))
			{
				$posticon=$_POST['posticon'];
				if(!in_array($posticon,$posticons)) $posticon="";
			}
			else $posticon="";
			$db_zugriff->query("UPDATE bb".$n."_threads SET threadname = '".addslashes($_POST['subject'])."', topicicon = '".addslashes($posticon)."' WHERE threadid = '$threadid'");
			header("Location: thread.php?threadid=$threadid&boardid=$boardid$session");
			exit;
		}
		
		$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
		$subject = prepare_topic($thread_info['threadname']);

		$choice_posticons="";
		for($i = 0; $i < count($posticons); $i++) {
			if(is_int($i/6) && $i) $choice_posticons .= "<br>";
			elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
			$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
			if($thread_info['topicicon'] == $posticons[$i]) $choice_posticons .= " CHECKED";
			$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
		}
		if(!$thread_info['topicicon']) $noicon[0] = "CHECKED";

		eval("dooutput(\"".gettemplate("mod_threadedit")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}
?>
