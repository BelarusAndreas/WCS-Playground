<?php
require("global.php");
require("_header.php");

$boardcache=array();
$permissioncache=array();
$modcache=array();

$result = $db_zugriff->query("
	SELECT
	bb".$n."_boards.*,
	bb".$n."_posts.threadparentid,
	bb".$n."_posts.userid,
	bb".$n."_posts.posttime,
	bb".$n."_threads.threadname,
	bb".$n."_threads.topicicon,
	bb".$n."_threads.boardparentid as parentid,
	bb".$n."_user_table.username
	FROM bb".$n."_boards
	LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid)
	LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid)
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid)
	ORDER by boardparentid ASC, sort ASC");
	/*
	die("
	SELECT
	bb".$n."_boards.*,
	bb".$n."_posts.threadparentid,
	bb".$n."_posts.userid,
	bb".$n."_posts.posttime,
	bb".$n."_threads.threadname,
	bb".$n."_threads.topicicon,
	bb".$n."_threads.boardparentid as parentid,
	bb".$n."_user_table.username
	FROM bb".$n."_boards
	LEFT JOIN bb".$n."_posts ON (bb".$n."_posts.postid=bb".$n."_boards.lastpostid)
	LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid=bb".$n."_posts.threadparentid)
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_posts.userid)
	ORDER by boardparentid ASC, sort ASC");
	*/
while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
$result = $db_zugriff->query("SELECT userid, username, boardid FROM bb".$n."_object2board LEFT JOIN bb".$n."_user_table ON (bb".$n."_object2board.objectid = bb".$n."_user_table.userid) WHERE mod = 1 ORDER BY username ASC");
while ($row = $db_zugriff->fetch_array($result)) $modcache[$row['boardid']][] = $row;
$main_boardbit = makeforumbit(0);
$db_zugriff->free_result($result);

$last_visited = formatdate($old_time,$longdateformat);
$newestuser = $db_zugriff->query_first("SELECT userid,username FROM bb".$n."_user_table WHERE activation='1' ORDER by regdate DESC LIMIT 1");
$newestuser = "<a href=\"members.php?mode=profile&userid=".$newestuser['userid'].$session."\">".$newestuser['username']."</a>";
$anzahluser = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE activation='1'");
$anzahlthreads = $db_zugriff->query_first("SELECT COUNT(threadid) FROM bb".$n."_threads");
$anzahlposts = $db_zugriff->query_first("SELECT COUNT(postid) FROM bb".$n."_posts");
$anzahluser = $anzahluser[0];
$anzahlthreads = $anzahlthreads[0];
$anzahlposts = $anzahlposts[0];

$rekordtime = formatdate($rekordtime,$longdateformat);

$guests = $db_zugriff->query_first("SELECT COUNT(zeit)as anzahl FROM bb".$n."_useronline WHERE userid='' AND zeit>=".(time()-60*$timeout)."");
$user = $db_zugriff->query_first("SELECT COUNT(zeit)as anzahl FROM bb".$n."_useronline WHERE ip='' AND zeit>=".(time()-60*$timeout)."");
$useronline = $guests['anzahl'] + $user['anzahl'];
/* ############## user online ############## */
$result = $db_zugriff->query("select distinct bb".$n."_useronline.userid, username, invisible from bb".$n."_useronline LEFT JOIN bb".$n."_user_table ON (bb".$n."_useronline.userid = bb".$n."_user_table.userid) WHERE bb".$n."_useronline.userid>0 AND zeit>=".(time()-60*$timeout)." ORDER BY username ASC");
$user_on = "";
while($row = $db_zugriff->fetch_array($result)) {
	if($row['invisible']) continue;
	if($user_on) $user_on .= ", ";
	$user_on .= "<a href=\"members.php?mode=profile&userid=$row[0]$session\">".$row[1]."</a>";
}
$db_zugriff->free_result($result);

/* ############## pms ############## */
if($user_id)
{
	$totalpm = $db_zugriff->query_first("SELECT COUNT(pmid) FROM bb".$n."_pms WHERE recipientid = '$user_id'");
	$newpm = $db_zugriff->query_first("SELECT COUNT(pmid) FROM bb".$n."_pms WHERE recipientid = '$user_id' AND sendtime >= '$old_time' AND view = 0");
	$unreadpm = $db_zugriff->query_first("SELECT COUNT(pmid) FROM bb".$n."_pms WHERE recipientid = '$user_id' AND view = 0");
	$totalpm = $totalpm[0];
	$newpm = $newpm[0];
	$unreadpm = $unreadpm[0];
}

if(!$user_id) eval ("\$quick_login = \"".gettemplate("main_unreg")."\";");
else eval ("\$quick_login = \"".gettemplate("main_logtin")."\";");

eval("dooutput(\"".gettemplate("main")."\");");
?>