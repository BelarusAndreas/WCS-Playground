<?php
require("global.php");
require("_header.php");
require("_board_jump.php");


/*
* $_GET['goto'] kann "nextoldest" oder "nextnewest" sein.
* Es wird dann der vorherige oder der n�chste Thread geladen.
*/
if(isset($_GET['goto']) && $_GET['goto'])
{
	$time = $db_zugriff->query_first("SELECT timelastreply as time FROM bb".$n."_threads WHERE threadid='$threadid'");
	if($_GET['goto'] == "nextoldest") $nextthread = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE timelastreply < '".$time['time']."' AND boardparentid='$boardid' ORDER by timelastreply DESC LIMIT 1");
	if($_GET['goto'] == "nextnewest") $nextthread = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE timelastreply > '".$time['time']."' AND boardparentid='$boardid' ORDER by timelastreply ASC LIMIT 1");
	$threadid = $nextthread['threadid'];
}
$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");

/*
* �bergebene Boardid stimmt nicht mit der Boardid des Thread �berein => Abbruch
*/
if($boardid != $thread_info['boardparentid'])
{
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
$threadname = prepare_topic($thread_info['threadname']); // Threadnamen vorbeiten (html, etc.)

$db_zugriff->query("UPDATE bb".$n."_threads SET views=views+1 WHERE threadid='$threadid'");
/*
$sthreadname = "sthread_".$threadid;
$$sthreadname = $thread_info['timelastreply'];
#session_register("$sthreadname");
#$HTTP_SESSION_VARS[$sthreadname] = $$sthreadname;
wbb_session_register("$sthreadname");
*/
// neu...
$sthreads_array[$threadid] = $thread_info['timelastreply'];
$sthreads = serialize($sthreads_array);
setcookie("sthreads", "$sthreads", time()+(3600*24*365));
wbb_session_register("sthreads");



$anzahl = $thread_info['replies']+1;
if(isset($_GET['page'])) $page = intval($_GET['page']);
else $page = 1;


$result = $db_zugriff->query("SELECT * FROM bb".$n."_ranks ORDER BY posts DESC");
while($row=$db_zugriff->fetch_array($result)) $rankcache[$row['groupid']][]=$row;


/*
* Postids des Threads auslesen ... 
*/
$getpostids=$db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE bb".$n."_posts.threadparentid='$threadid' ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC")." LIMIT ".($eproseite*($page-1)).",".($eproseite));
$postids = "";
while($row=$db_zugriff->fetch_array($getpostids)) $postids.=",".$row['postid'];

/*
* Postdaten auslesen ...
*/
$post_result = $db_zugriff->query("
	SELECT bb".$n."_posts.*, bb".$n."_avatars.extension as avatarextension, bb".$n."_user_table.*, bb".$n."_useronline.zeit FROM bb".$n."_posts
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_posts.userid)
	LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id = bb".$n."_user_table.avatarid)
	LEFT JOIN bb".$n."_useronline ON (bb".$n."_useronline.userid = bb".$n."_posts.userid AND bb".$n."_useronline.userid>0)
	WHERE bb".$n."_posts.postid IN (0$postids) ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC"));
$pages=ceil($anzahl/$eproseite);
$j=0;
$thread_postbit = "";
while($posts = $db_zugriff->fetch_array($post_result))
{
	$posttopic="";
	$lastedit="";
	$user_pic="";
	$signature="";
	$email="";
	$userhp="";
	$quote_and_edit="";
	$location="";
	$usericq="";
	$useraim="";
	$useryim="";
	$status="";
	$stars="";
	$user_on_off="";
	$search="";
	$profile="";
	$homie="";
	$pn="";
	$regdate="";

	if($posts['userid'])
	{
		if($pms && $userdata['canusepms']) eval ("\$pn = \"".gettemplate("thread_pm")."\";");
		$regdate = formatdate($posts['regdate'],$regdateformat);
		$location = htmlspecialchars($posts['location']);

		$rank = getRank($posts['userposts'],$posts['groupid']);
		if($rank)
		{
			$stars = "<a href=\"javascript:rank(".$rank['id'].")\" title=\"Informationen zum Rang ".$rank['rank']."\">".str_repeat("<img src=\"".$rank['grafik']."\" border=\"0\">",$rank['mal'])."</a>";
			if($posts['statusextra']) $status = htmlspecialchars($posts['statusextra']);
			else $status = $rank['rank'];
		}
		
		if($posts['avatarid'] && !$hide_userpic && $avatars) $user_pic = "<br><img src=\"images/avatars/avatar-".$posts['avatarid'].".".$posts['avatarextension']."\" border=0>";
		if($posts['signatur'] && $posts['signature'] && !$hide_signature)
		{
			$signatur = editSignatur($posts['signatur'],$posts['disable_smilies']);
			eval ("\$signature = \"".gettemplate("thread_signature")."\";");
		}
		
		// Unsichtbar Bug beseitigt.
		if($posts['zeit'] && !$posts['invisible']) eval ("\$user_on_off = \"".gettemplate("thread_useron")."\";");
		else eval ("\$user_on_off = \"".gettemplate("thread_useroff")."\";");
		if($posts['users_may_email']==1) eval ("\$email = \"".gettemplate("thread_email")."\";");
		if($posts['userhp']) eval ("\$userhp = \"".gettemplate("thread_userhp")."\";");
		if($posts['usericq']) 
		{
			$usericq = intval($posts['usericq']);
			eval ("\$usericq = \"".gettemplate("thread_usericq")."\";");
		}
		if($posts['aim'])
		{
			$aim = htmlspecialchars($posts['aim']);
			eval ("\$useraim = \"".gettemplate("thread_useraim")."\";");
		}
		if($posts['yim'])
		{
			$yim = htmlspecialchars($posts['yim']);
			eval ("\$useryim = \"".gettemplate("thread_useryim")."\";");
		}
		eval ("\$search = \"".gettemplate("thread_search")."\";");
		eval ("\$profile = \"".gettemplate("thread_profile")."\";");
		eval ("\$homie = \"".gettemplate("thread_homie")."\";");
		$authorname = $posts['username'];
	}
	else
	{
		eval ("\$status = \"".gettemplate("thread_anonymous_status")."\";");
		eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");
	}

	$a_name = (($page-1)*$eproseite)+$j+1;
	$backcolor = rowcolor($j);

	if($posts['posticon']) $posticon = "<img src=\"".$posts['posticon']."\">";
	else $posticon = "&nbsp;";

	$posttopic = prepare_topic($posts['posttopic']);
	$post = editPost($posts['message'],$posts['disable_smilies']);

	if($old_time <= $posts['posttime']) $postsign = "<IMG SRC=\"$imagefolder/posticonnew.gif\" border=\"0\">";
	else $postsign = "<IMG SRC=\"$imagefolder/posticon.gif\" border=\"0\">";
	$posttime = formatdate($posts['posttime'],$longdateformat,1);

	if($posts['edittime'])
	{
		if($posts['editorid']) $editorname = getUsername($posts['editorid']);
		else eval ("\$editorname = \"".gettemplate("lg_anonymous")."\";");
		$edittime = formatdate($posts['edittime'],$longdateformat);
		eval ("\$lastedit = \"".gettemplate("thread_lastedit")."\";");
	}
	else $lastedit="";
	if($thread_info['flags']!=1) eval ("\$quote_and_edit = \"".gettemplate("thread_quote_edit")."\";");

	eval ("\$thread_postbit .= \"".gettemplate("thread_postbit")."\";");
	$j++;
}
$db_zugriff->free_result($post_result);

$navi_chain = makenavichain("thread",$boardid,$threadid);




/*
* Es wird nicht mehr �berpr�ft, ob es wirklich einen n�chsten Thread gibt,
* dadurch werden 2 Queries eingespart. Besser als nichts.
*/

#$oldest = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE boardparentid='$boardid' ORDER BY timelastreply ASC LIMIT 1");
#if($threadid != $oldest['threadid']) eval ("\$next_thread .= \"".gettemplate("thread_next_oldest")."\";");
#$newest = $db_zugriff->query_first("SELECT threadid FROM bb".$n."_threads WHERE boardparentid='$boardid' ORDER BY timelastreply DESC LIMIT 1");
#if($threadid != $newest['threadid']) eval ("\$next_thread .= \"".gettemplate("thread_next_newest")."\";");
$next_thread="";
eval ("\$next_thread .= \"".gettemplate("thread_next_oldest")."\";");
eval ("\$next_thread .= \"".gettemplate("thread_next_newest")."\";");

$newthread_reply="";
eval ("\$newthread_reply  .= \"".gettemplate("thread_newthread")."\";");
#if(!getThreadflag($threadid)) eval ("\$newthread_reply  .= \"".gettemplate("thread_reply")."\";");
if(!$thread_info['flags']) eval ("\$newthread_reply  .= \"".gettemplate("thread_reply")."\";");
else eval ("\$newthread_reply  .= \"".gettemplate("thread_closed")."\";");



if($pages>1) $page_link = makepagelink("thread.php?threadid=$threadid&boardid=$boardid$session", $page, $pages);
else $page_link="";

/*
* Umfrage vorhanden
*/
if($thread_info['pquestion'])
{
	if($user_id) $poll_check = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_vote WHERE threadid='$threadid' AND userid = '$user_id'");
	else $poll_check[0]=0;
	$ptitle = prepare_topic($thread_info['pquestion']);

	/*
	* Ergebnis anzeigen ...
	*/
	if((isset($votepoll[$threadid]) && $votepoll[$threadid]) || $poll_check[0] || (isset($_GET['presult']) && $_GET['presult']) || ($thread_info['ptimeout'] && time() >= ($thread_info['starttime']+$thread_info['ptimeout']*(24*3600))))
	{
		$votes_total = $db_zugriff->query_first("SELECT SUM(votes) FROM bb".$n."_poll WHERE threadid='$threadid'");
		$total = $votes_total[0];
		$poll_result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid='$threadid' ORDER BY id ASC");
		$thread_poll_resultbit="";
		while($row = $db_zugriff->fetch_array($poll_result))
		{
			$field = prepare_topic($row['field']);
			$votes = intval($row['votes']);

			if($total)
			{
				$percent_float = $votes*100/$total;
				$percent = number_format($percent_float, 2);
				$percent_int = floor($percent_float)*3;
			}
			else $percent = $percent_int = 0;

			eval ("\$thread_poll_resultbit .= \"".gettemplate("thread_poll_resultbit")."\";");
		}
		if(check_boardobject($boardid,$user_id,"mod") || $userdata['issupermod']) eval ("\$mod_poll_edit = \"".gettemplate("thread_polledit")."\";");
		else $mod_poll_edit="";
		eval ("\$poll = \"".gettemplate("thread_poll_result")."\";");
	}
	
	/*
	* Formular zum Abstimmen aussuchen ...
	*/
	else
	{
		$poll_result = $db_zugriff->query("SELECT * FROM bb".$n."_poll WHERE threadid='$threadid'");
		$thread_pollbit="";
		while($row = $db_zugriff->fetch_array($poll_result))
		{
			$field = prepare_topic($row['field']);
			eval ("\$thread_pollbit .= \"".gettemplate("thread_pollbit")."\";");
		}
		if(check_boardobject($boardid,$user_id,"mod") || $userdata['issupermod']) eval ("\$mod_poll_edit = \"".gettemplate("thread_polledit")."\";");
		else $mod_poll_edit="";
		eval ("\$poll = \"".gettemplate("thread_poll")."\";");
	}
}
else $poll="";

if(check_boardobject($boardid,$user_id,"mod") || $userdata['issupermod'] || ($thread_info['authorid'] && $thread_info['authorid']==$user_id && ($userdata['cancloseowntopic'] || $userdata['candelowntopic']))) eval ("\$quick_mod = \"".gettemplate("thread_quick_mod")."\";");
else $quick_mod = "";

eval("dooutput(\"".gettemplate("thread")."\");");
?>