<?php
require("global.php");

$thread_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_threads WHERE threadid = '$threadid'");
if($boardid != $thread_info['boardparentid']) {
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}
if($imageurl) $imageurl = "<a href=\"main.php\"><img src=\"".$imageurl."\" border=0></a>";
else $imageurl="";

$anzahl = $thread_info['replies']+1;
if(isset($_GET['page'])) $page=intval($_GET['page']);
else $page = 1;
$post_result = $db_zugriff->query("SELECT bb".$n."_posts.*, bb".$n."_user_table.* FROM bb".$n."_posts LEFT JOIN bb".$n."_user_table USING (userid) WHERE bb".$n."_posts.threadparentid='$threadid' ORDER by bb".$n."_posts.posttime ".ifelse($postorder,"DESC","ASC")." LIMIT ".($eproseite*($page-1)).",".($eproseite));
$pages=ceil($anzahl/$eproseite);
$print_postbit="";
while($posts = $db_zugriff->fetch_array($post_result)){

	unset($signature);
	if($posts['posticon']) $posticon = "<img src=\"".$posts['posticon']."\">";
	else $posticon = "&nbsp;";
	if($posts['posttopic']) $posttopic = prepare_topic($posts['posttopic']);
	else $posttopic = "";
	$post = editPost($posts['message'],$posts['disable_smilies']);
	if($posts['signatur'] && $posts['signature'] && !$hide_signature) {
		$signatur = editSignatur($posts['signatur'],$posts['disable_smilies']);
		eval ("\$signature = \"".gettemplate("thread_signature")."\";");
	}
	else $signature="";
	$posttime = formatdate($posts['posttime'],$longdateformat);

	eval ("\$print_postbit .= \"".gettemplate("print_postbit")."\";");
}
$db_zugriff->free_result($post_result);

$threadname = getThreadname($threadid);
$boardname = getBoardname($boardid);

eval("dooutput(\"".gettemplate("print")."\");");
?>

