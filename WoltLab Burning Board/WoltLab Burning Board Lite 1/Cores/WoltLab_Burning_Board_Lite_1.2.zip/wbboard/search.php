<?php
require("global.php");
require("_header.php");

/*
* Benutzer darf Suche nicht benutzen => Access Error
*/
if(!$userdata['canusesearch'])
{
	header("LOCATION: misc.php?action=access_error$session");
	exit;
}



if(!isset($_POST['send'])) $_POST['send']="";
if(!isset($_GET['mode'])) $_GET['mode']="";
if(!isset($_GET['searchid'])) $_GET['searchid']="";


/*
* Suchformular anzeigen
*/
if(!$_POST['send'] && $_GET['mode']!="daily" && $_GET['mode']!="user" && !$_GET['searchid'])
{

	$result = $db_zugriff->query("SELECT * FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
	while ($row = $db_zugriff->fetch_array($result)) $boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
	$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1");
	while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
	$board_links = makeboardsearchbit(0);
	$db_zugriff->free_result($result);
	eval("dooutput(\"".gettemplate("search_new")."\");");
}



/*
* Suche ausf�hren.
*/
elseif(!$_GET['searchid'])
{
	if(isset($_POST['sortby'])) $sortby = $_POST['sortby'];
	elseif(isset($_GET['sortby'])) $sortby = $_GET['sortby'];
	else $sortby = "posttime";
	if(isset($_POST['sortorder'])) $sortorder = $_POST['sortorder'];
	elseif(isset($_GET['sortorder'])) $sortorder = $_GET['sortorder'];
	else $sortorder = "DESC";
	if(isset($_POST['before'])) $before = $_POST['before'];
	elseif(isset($_GET['before'])) $before = $_GET['before'];
	else $before = "";
	if(isset($_POST['searchdate'])) $searchdate = $_POST['searchdate'];
	elseif(isset($_GET['searchdate'])) $searchdate = $_GET['searchdate'];
	else $searchdate = "";
	
	/*
	* Suche: Daily
	*/
	if($_GET['mode']=="daily")
	{
		$before = 1;
		$searchdate = 1;
		$sortby = "posttime";
		$sortorder = "DESC";
	}
	
	
	/*
	* Suche: User
	*/
	if($_GET['mode']=="user")
	{
		$searchuser = getUsername($userid);
		$exactname = 1;
		$showposts = 1;
		$searchdate = -1;
		$sortby = "posttime";
		$sortorder = "DESC";
	}



	if($searchdate!=-1)
	{
		if($before) $before = ">";
		else $before = "<";
		$posttime = "posttime".$before."'".(time()-($searchdate*86400))."'";
	}
	else $posttime="";
	if(isset($_POST['forumchoice'])) $forumchoice=$_POST['forumchoice'];
	else $forumchoice="";
	$forum = $forumchoice;
	if($forumchoice) {
		$tempforumchoice = substr($forumchoice,1);
		$forumchoice="";
	}
	else $tempforumchoice="";
	
	$result = $db_zugriff->query("SELECT boardid FROM bb".$n."_object2board WHERE objectid = '$user_group' AND boardpermission = 1".ifelse($tempforumchoice," AND boardid='$tempforumchoice'",""));
	while ($row = $db_zugriff->fetch_array($result)) $permissioncache[$row['boardid']] = 1;
	$board_result = $db_zugriff->query("SELECT boardid FROM bb".$n."_boards WHERE boardpassword = ''");
	$forumchoice = "";
	$tempboardids="";
	while($boards = $db_zugriff->fetch_array($board_result))
	{
		if(!isset($permissioncache[$boards['boardid']]) || !$permissioncache[$boards['boardid']]) continue;
		#if($forumchoice) $forumchoice .= " OR ";
		#$forumchoice .= "boardparentid='$boards[boardid]'";
		if($tempboardids) $tempboardids .= ",";
		$tempboardids .= $boards['boardid'];
	}
	$forumchoice = "boardparentid IN (".$tempboardids.")";
	
	if(isset($_POST['query'])) $query = $_POST['query'];
	else $query="";
	$searchwords="";
	
	if($query)
	{
		if(!isset($_POST['posts'])) $_POST['posts']="";
		if(!isset($_POST['title'])) $_POST['title']="";
		if(!isset($searchwords)) $searchwords = "";
		if(isset($_POST['hack_query']) && $_POST['hack_query'])
		{
			$query_array = explode(" ",$query);
			/* AND */
			if($_POST['hack_query']==1)
			{
				for($i = 0; $i < count($query_array); $i++)
				{
					if($i) $searchwords .= "AND";
					$searchwords .= " (";
					if($_POST['posts']) $searchwords .= "message like '%".addslashes($query_array[$i])."%'";
					if($_POST['posts'] && $_POST['title']) $searchwords .= " OR ";
					if($_POST['title']) $searchwords .= "posttopic like '%".addslashes($query_array[$i])."%'";
					$searchwords .= " )";
				}
			}
			/* OR */
			else
			{
				$searchwords .= "(";
				for($i = 0; $i < count($query_array); $i++)
				{
					if($i) $searchwords .= " OR ";
					if($_POST['posts']) $searchwords .= "message like '%".addslashes($query_array[$i])."%'";
					if($_POST['posts'] && $_POST['title']) $searchwords .= " OR ";
					if($_POST['title']) $searchwords .= "posttopic like '%".addslashes($query_array[$i])."%'";
				}
				$searchwords .= " )";
			}
		}
		/* Suiche nach komplettem String */
		else
		{
			$searchwords .= "(";
			if($_POST['posts']) $searchwords .= "message like '%".addslashes($query)."%'";
			if($_POST['posts'] && $_POST['title']) $searchwords .= " OR ";
			if($_POST['title']) $searchwords .= "posttopic like '%".addslashes($query)."%'";
			$searchwords .= " )";
		}
	}
	
	/* Suche nach User.. */
	if(!isset($searchuser)) $searchuser="";
	if(isset($_POST['searchuser'])) $searchuser = $_POST['searchuser'];
	if(!isset($exactname)) $exactname="";
	if(isset($_POST['exactname'])) $exactname = $_POST['exactname'];

	elseif(isset($searchuser) && $searchuser)
	{
		/* genaue Suche */
		if(isset($exactname) && $exactname)
		{
			$user = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username='".addslashes(htmlspecialchars($searchuser))."'");
			$searchwords = "bb".$n."_posts.userid='".intval($user['userid'])."'";
		}
		/* ungenaue Suche */
		else
		{
			$user = $db_zugriff->query("SELECT userid FROM bb".$n."_user_table WHERE username like '%".addslashes(htmlspecialchars($searchuser))."%'");
			$m = 0;
			while($row = $db_zugriff->fetch_array($user))
			{
				if(!$m) $searchwords = "(";
				if($m) 	$searchwords .= " OR ";
				$searchwords .= "bb".$n."_posts.userid='".intval($row['userid'])."'";
				$m = 1;
			}
			if(!$searchwords) $searchwords = "bb".$n."_posts.userid='0'";
			else $searchwords .= ")";
		}
	}
	

	if(!$forumchoice) {
		eval("dooutput(\"".gettemplate("search_no_result")."\");");
		exit;
	}
	if($posttime && ($forumchoice || $searchwords)) $posttime .= " AND";
	if($searchwords) $searchwords = "AND ".$searchwords;
	$ssquery_temp = "$posttime ($forumchoice) $searchwords ORDER by ".$sortby." ".$sortorder;
	$countx=1;
	do {
		$countx++;
	}
	while(isset($ssquery_array[$countx]) && $ssquery_array[$countx]);
	$ssquery_array[$countx] = $ssquery_temp;
	$ssquery = serialize($ssquery_array);
	#session_register("$name");
	#$HTTP_SESSION_VARS[$name] = $$name;
	wbb_session_register("ssquery");


/* ALT ALT ALT ALT
	$ssquery = "$posttime ($forumchoice) $searchwords ORDER by ".$sortby." ".$sortorder;
	$countx=1;
	do {
		$countx++;
		$name = "ssquery".$countx;
	}
	while(isset($_SESSION[$name]) && $_SESSION[$name]);
	$$name = $ssquery;
	#session_register("$name");
	#$HTTP_SESSION_VARS[$name] = $$name;
	wbb_session_register("$name");
*/




	if(isset($_POST['showposts'])) $showposts=intval($_POST['showposts']);
	elseif(isset($_GET['showposts'])) $showposts=intval($_GET['showposts']);
	elseif(!$showposts) $showposts=0;
	eval ("\$output = \"".gettemplate("note27")."\";");
	$ride = "search.php?boardid=$boardid&searchid=$countx&showposts=".$showposts.$session;
	eval("dooutput(\"".gettemplate("action_ride")."\");");
}











/*
* Ergebnisse anzeigen..
*/
else
{
	$searchid = $_GET['searchid'];
	#$name = "ssquery".$_GET['searchid'];
	$name = $_GET['searchid'];
	
	if(!isset($ssquery_array[$searchid]) || !trim($ssquery_array[$searchid])) {
	 eval("dooutput(\"".gettemplate("search_no_result")."\");");
	 exit();
	}
	$order=substr($ssquery_array[$name], strpos($ssquery_array[$name], "ORDER"));
	
	/* Beitr�ge zeigen */
	if($_GET['showposts'])
	{
		$anzahl = $db_zugriff->query_first("SELECT COUNT(postid)as anzahl FROM bb".$n."_posts WHERE ".$ssquery_array[$name]);
		$anzahl = $anzahl['anzahl'];
		if(isset($_GET['page'])) $page = intval($_GET['page']);
		else $page = 1;

		$getpostids=$db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE ".$ssquery_array[$name]." LIMIT ".($eproseite*($page-1)).",".$eproseite);
		$postids = "";
		while($row=$db_zugriff->fetch_array($getpostids)) $postids.=",".$row['postid'];

		$post_result = $db_zugriff->query("
		SELECT bb".$n."_posts.*,
		bb".$n."_avatars.extension as avatarextension,
		bb".$n."_user_table.*,
		bb".$n."_useronline.zeit,
		bb".$n."_threads.flags
		FROM bb".$n."_posts
		LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid = bb".$n."_posts.userid)
		LEFT JOIN bb".$n."_avatars ON (bb".$n."_avatars.id = bb".$n."_user_table.avatarid)
		LEFT JOIN bb".$n."_useronline ON (bb".$n."_useronline.userid = bb".$n."_posts.userid)
		LEFT JOIN bb".$n."_threads ON (bb".$n."_threads.threadid = bb".$n."_posts.threadparentid)
		WHERE postid IN (0$postids) ".$order);

		$pages=ceil($anzahl/$eproseite);
		$l_hits = 1+($page-1)*$eproseite;
		$h_hits = $page*$eproseite;
		if($h_hits > $anzahl) $h_hits = $anzahl;
		$all_hits = $anzahl;

		if($pages>1) $page_link = makepagelink("search.php?boardid=$boardid&searchid=".$_GET['searchid']."&showposts=".$_GET['showposts'].$session, $page, $pages);
		else $page_link="";
		$thread_postbit="";
		while($posts = $db_zugriff->fetch_array($post_result)){

			$posttopic="";
			$lastedit="";
			$user_pic="";
			$signature="";
			$email="";
			$userhp="";
			$quote_and_edit="";
			$location="";
			$usericq="";
			$useraim="";
			$useryim="";
			$status="";
			$stars="";
			$user_on_off="";
			$search="";
			$profile="";
			$homie="";
			$pn="";
			$regdate="";
			$out="";

			if($posts['userid'])
			{
				if($pms && $userdata['canusepms']) eval ("\$pn = \"".gettemplate("thread_pm")."\";");
				$regdate = formatdate($posts['regdate'],$regdateformat);
				$location = htmlspecialchars($posts['location']);
				$rank = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE groupid = $posts[groupid] AND posts<='$posts[userposts]' ORDER by posts DESC LIMIT 1");
	        	if($posts['statusextra']) $status = htmlspecialchars($posts['statusextra']);
				else $status = $rank['rank'];
       			$stars = "<a href=\"javascript:rank($rank[id])\" title=\"Informationen zum Rang ".$rank['rank']."\">".str_repeat("<img src=\"".$rank['grafik']."\" border=\"0\">",$rank['mal'])."</a>";
        		if($posts['avatarid'] && !$hide_userpic && $avatars) $user_pic = "<br><img src=\"images/avatars/avatar-".$posts['avatarid'].".".$posts['avatarextension']."\" border=0>";
				if($posts['signatur'] && $posts['signature'] && !$hide_signature)
				{
					$signatur = editSignatur($posts['signatur'],$posts['disable_smilies']);
					eval ("\$signature = \"".gettemplate("thread_signature")."\";");
				}
				if($posts['zeit'] && !$posts['invisible']) eval ("\$user_on_off = \"".gettemplate("thread_useron")."\";");
				else eval ("\$user_on_off = \"".gettemplate("thread_useroff")."\";");
				if($posts['users_may_email']==1) eval ("\$email = \"".gettemplate("thread_email")."\";");
				if($posts['userhp']) eval ("\$userhp = \"".gettemplate("thread_userhp")."\";");
				if($posts['usericq']) {
					$usericq = intval($posts['usericq']);
					eval ("\$usericq = \"".gettemplate("thread_usericq")."\";");
				}
				if($posts['aim']) {
					$aim = htmlspecialchars($posts['aim']);
					eval ("\$useraim = \"".gettemplate("thread_useraim")."\";");
				}
				if($posts['yim']) {
					$yim = htmlspecialchars($posts['yim']);
					eval ("\$useryim = \"".gettemplate("thread_useryim")."\";");
				}
				eval ("\$search = \"".gettemplate("thread_search")."\";");
				eval ("\$profile = \"".gettemplate("thread_profile")."\";");
				eval ("\$homie = \"".gettemplate("thread_homie")."\";");
				$authorname = $posts['username'];
			}
			else eval ("\$authorname = \"".gettemplate("lg_anonymous")."\";");

			$a_name = (($page-1)*$eproseite)+$j+1;
			$backcolor = rowcolor($j++);

			if($posts['posticon']) $posticon = "<img src=\"".$posts['posticon']."\">";
			else $posticon = "&nbsp;";

			$posttopic = prepare_topic($posts['posttopic']);
			$post = editPost($posts['message'],$posts['disable_smilies']);

			if($old_time <= $posts['posttime']) $postsign = "<IMG SRC=\"$imagefolder/posticonnew.gif\" border=\"0\">";
			else $postsign = "<IMG SRC=\"$imagefolder/posticon.gif\" border=\"0\">";
			$posttime = formatdate($posts['posttime'],$longdateformat,1);

			if($posts['edittime']) {
				if($posts['editorid']) $editorname = getUsername($posts['editorid']);
				else eval ("\$editorname = \"".gettemplate("lg_anonymous")."\";");
				$edittime = formatdate($posts['edittime'],$longdateformat);
				eval ("\$lastedit = \"".gettemplate("thread_lastedit")."\";");
			}
			if($posts['flags']!=1) eval ("\$quote_and_edit = \"".gettemplate("thread_quote_edit")."\";");
			$boardparentid = $posts['boardparentid'];
			eval ("\$quote_and_edit = \"".gettemplate("search_showthread")."\";");
			eval ("\$thread_postbit .= \"".gettemplate("thread_postbit")."\";");
		}
		$db_zugriff->free_result($post_result);
		require("_board_jump.php");
		if($thread_postbit) eval("dooutput(\"".gettemplate("search_posts")."\");");
		else eval("dooutput(\"".gettemplate("search_no_result")."\");");

	}
	
	/*
	* Themen anzeigen.
	*/
	else {
		$result = $db_zugriff->query("SELECT DISTINCT threadparentid FROM bb".$n."_posts WHERE ".$ssquery_array[$name]);
		$anzahl = $db_zugriff->num_rows($result);
		$allthreadids="";
		while($row=$db_zugriff->fetch_array($result)) $allthreadids.=",".$row['threadparentid'];
		if(isset($_GET['page'])) $page = intval($_GET['page']);
		else $page = 1;

		$getthreadids=$db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE threadid IN (0$allthreadids) ORDER BY timelastreply DESC LIMIT ".($tproseite*($page-1)).",".$tproseite);
		$threadids="";
		while($row=$db_zugriff->fetch_array($getthreadids)) $threadids.=",".$row['threadid'];


		$result = $db_zugriff->query("
		SELECT bb".$n."_threads.*,
		bb".$n."_boards.boardname,
		bb".$n."_user_table.username
		FROM bb".$n."_threads
		LEFT JOIN bb".$n."_boards ON (bb".$n."_boards.boardid=bb".$n."_threads.boardparentid)
		LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_threads.lastposterid)
		WHERE threadid IN (0$threadids) ORDER BY timelastreply DESC");

		$pages=ceil($anzahl/$tproseite);

		$l_hits = 1+($page-1)*$tproseite;
		$h_hits = $page*$tproseite;
		if($h_hits > $anzahl) $h_hits = $anzahl;
		$all_hits = $anzahl;

		if($pages>1) $page_link = makepagelink("search.php?boardid=$boardid&searchid=".$_GET['searchid']."&showposts=".$_GET['showposts'].$session, $page, $pages);
		else $page_link="";
		$search_threadbit="";
		while ($threads = $db_zugriff->fetch_array($result))
		{
			$folder_image="";
			$thread_link="";
			$anonymous_lp="";
			$anonymous="";
			$thread_starter="";
			$lastauthor="";
			$lastauthorid="";

			#$sthreadname = "sthread_".$threads['threadid'];
			$sthreadname = $threads['threadid'];
			$boardname = $threads['boardname'];
			#if($old_time <= $threads['timelastreply'] && $$sthreadname < $threads['timelastreply']) $folder_image .= "new";
			if($old_time <= $threads['timelastreply'] && ((isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) || !isset($sthreads_array[$sthreadname]))) $folder_image .= "new";
			if($threads['replies'] > "15" || $threads['views'] > "150") $folder_image .= "hot";
			if($threads['flags']==1) $folder_image .= "lock";
			$folder_image = "<img src=\"$imagefolder/".$folder_image."folder.gif\">";

			if($threads['topicicon']) $posticon = "<img src=\"$threads[topicicon]\">";
			else $posticon = "&nbsp;";

			if($old_time <= $threads['timelastreply'] && ((isset($sthreads_array[$sthreadname]) && $sthreads_array[$sthreadname] < $threads['timelastreply']) || !isset($sthreads_array[$sthreadname]))) eval ("\$thread_link .= \"".gettemplate("board_gofirstnew")."\";");
			$thread_link .= "<font size=2 face=\"$font\"><b>";
			if($threads['important']) eval ("\$thread_link .= \"".gettemplate("board_important")."\";");
			if($threads['pquestion']) eval ("\$thread_link .= \"".gettemplate("board_poll")."\";");
			$thread_link .= "<a href=\"thread.php?threadid=$threads[threadid]&boardid=".$threads['boardparentid'].$session."\">".prepare_topic($threads['threadname'])."</a></b></font>";
			if(($threads['replies']+1)/$eproseite > 1) $thread_link .= "<font size=1 face=\"".$font."\"> ( <img src=\"$imagefolder/multipage.gif\"> <a href=\"thread.php?threadid=$threads[threadid]&boardid=$threads[boardparentid]$session&page=1\">1</a> <a href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid'].$session."&page=2\">2</a> ";
			if(($threads['replies']+1)/$eproseite > 2) $thread_link .= "<a href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid'].$session."&page=3\">3</a> ";
			if(($threads['replies']+1)/$eproseite > 3) $thread_link .= "<a href=\"thread.php?threadid=".$threads['threadid']."&boardid=".$threads['boardparentid'].$session."&page=4\">4</a> ";
			if(($threads['replies']+1)/$eproseite > 4) {
				$pagesx=ceil(($threads['replies']+1)/$eproseite);
				eval ("\$thread_link .= \"".gettemplate("board_lastpage")."\";");
			}
			if(($threads['replies']+1)/$eproseite > 1) $thread_link .= ")</font>";

			$starttime = formatdate($threads['starttime'],$longdateformat,1);
			if($threads['authorid']) $thread_starter = $threads['author'];
			else eval ("\$anonymous = \"".gettemplate("lg_anonymous")."\";");
			$lastposttime = formatdate($threads['timelastreply'],$longdateformat,1);
			if($threads['lastposterid'])
			{
				$lastauthor = $threads['username'];
				$lastauthorid = $threads['lastposterid'];
			}
			else eval ("\$anonymous_lp = \"".gettemplate("lg_anonymous")."\";");
			eval ("\$last_post = \"".gettemplate("board_lastpost")."\";");

		eval ("\$search_threadbit .= \"".gettemplate("search_threadbit")."\";");

		}
		$db_zugriff->free_result($result);
		require("_board_jump.php");
		if($search_threadbit) eval("dooutput(\"".gettemplate("search_threads")."\");");
		else eval("dooutput(\"".gettemplate("search_no_result")."\");");
	}
}



?>
