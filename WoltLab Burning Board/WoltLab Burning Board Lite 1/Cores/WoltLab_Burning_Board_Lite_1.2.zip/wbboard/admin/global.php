<?php
require "./_data.inc.php";
require "./class_db_zugriff.php";

$db_zugriff = new db_zugriff;

$db_zugriff->appname="WoltLab Burning Board";
$db_zugriff->database=$mysqldb;
$db_zugriff->server=$mysqlhost;
$db_zugriff->user=$mysqluser;
$db_zugriff->password=$mysqlpassword;

$db_zugriff->connect();


session_name("sid");
session_start();

// Einstellung f�r Register Globals einlesen.
if(ini_get("register_globals")) $register_globals=true;
else $register_globals=false;

require "./incomingdata.php";







// ######################### Session ###########################
#if(!isset($sid)) $sid = "";
if(isset($_COOKIE['sid']) && $_COOKIE['sid']) $sid=$_COOKIE['sid'];
elseif(isset($_POST['sid']) && $_POST['sid']) $sid=$_POST['sid'];
elseif(isset($_GET['sid']) && $_GET['sid']) $sid=$_GET['sid'];
else $sid = "";

// ####################### Define variables ######################
if(!isset($user_id)) $user_id = "";
if(!isset($user_password)) $user_password = "";
if(!isset($error)) $error="";
if(!isset($username)) $username="";
if(!isset($userpassword)) $userpassword = "";
if(!isset($member_search_resultbit)) $member_search_resultbit = "";



// ####################### Sessions ##############################
if(!$sid) $sid = session_id();
session_id($sid);


$user_id="";
$user_password="";

if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0) $user_id = intval($_COOKIE['user_id']);
elseif(isset($_SESSION['user_id']) && intval($_SESSION['user_id'])>0 && !$user_id) $user_id = intval($_SESSION['user_id']);
else $user_id=0;

if(isset($_COOKIE['user_password']) && $_COOKIE['user_password']) $user_password = ($_COOKIE['user_password']);
elseif(isset($_SESSION['user_password']) && $_SESSION['user_password'] && !$user_password) $user_password = ($_SESSION['user_password']);
else $user_password="";

$session = "&sid=".$sid;
$session2 = "?sid=".$sid;




function get_vars_old()
{
	global $HTTP_COOKIE_VARS, $HTTP_POST_FILES, $HTTP_POST_VARS, $HTTP_GET_VARS, $HTTP_SERVER_VARS,$HTTP_ENV_VARS, $HTTP_SESSION_VARS, $_REQUEST, $_COOKIE, $_POST, $_GET, $_SERVER, $_FILES,$_ENV,$_SESSION;
	
	if(is_array($HTTP_COOKIE_VARS))
	{
		while(list($key,$val)=each($HTTP_COOKIE_VARS))
		{
			$_REQUEST[$key]=$val;
			$_COOKIE[$key]=$val;
		}
	}

	if(is_array($HTTP_POST_VARS))
	{
		while(list($key,$val)=each($HTTP_POST_VARS))
		{
			$_REQUEST[$key]=$val;
			$_POST[$key]=$val;
		}
	}

	if(is_array($HTTP_GET_VARS))
	{
		while(list($key,$val)=each($HTTP_GET_VARS))
		{
			$_REQUEST[$key]=$val;
			$_GET[$key]=$val;
		}
	}
	
	if(is_array($HTTP_POST_FILES))
	{
		while(list($key,$val)=each($HTTP_POST_FILES)){
			$_FILES[$key]=$val;
		}
	}
	
	if(is_array($HTTP_SERVER_VARS))
	{
		while(list($key,$val)=each($HTTP_SERVER_VARS))
		{
			$_SERVER[$key]=$val;
		}
	}
	
	if(is_array($HTTP_ENV_VARS))
	{
		while(list($key,$val)=each($HTTP_ENV_VARS))
		{
			$_ENV[$key]=$val;
		}
	}
	
	if(is_array($HTTP_SESSION_VARS))
	{
		while(list($key,$val)=each($HTTP_SESSION_VARS))
		{
			$_SESSION[$key]=$val;
		}
	}
}

/*
	Funktion: array stripslashes_array(array array)
	Diese Funktion wendet die Funktion stripslashes() 
	auf alle Elemente eines Arrays (auch mehrdimensional) an.
*/
function stripslashes_array(&$array)
{
	reset($array);
	while(list($key,$val)=each($array))
	{
		if(is_string($val))
		{
			$array[$key]=stripslashes($val);
		}
		elseif(is_array($val))
		{
			/* rekursiver Aufruf bei mehrdimensionalem Array */
			$array[$key]=stripslashes_array($val);
		}
	}
	return $array;
}

/*
	Funktion: array htmlentities_array(array array)
	Diese Funktion wendet die Funktion htmlentities() 
	auf alle Elemente eines Arrays (auch mehrdimensional) an.
*/
function htmlentities_array(&$array)
{
	reset($array);
	while(list($key,$val)=each($array))
	{
		if(is_string($val))
		{
			$array[$key]=htmlentities($val);
		}
		elseif(is_array($val))
		{
			/* rekursiver Aufruf bei mehrdimensionalem Array */
			$array[$key]=htmlentities_array($val);
		}
	}
	return $array;
}





/**
* @return result bool
* @param varname string
* @desc Registriert die Variable ${$varname} in einer Session.
* Dank einem Bug in php4 sind wir gezwungen, je nach Konfiguration session_register()
* oder $HTTP_SESSION_VARS/$_SESSION zu verwenden.
*/
function wbb_session_register($varname)
{
    global $register_globals, $HTTP_SESSION_VARS, ${$varname};
    $done = false;
    if($register_globals)
    {
        $done = session_register("$varname"); 
    }
    else
    {
        if($HTTP_SESSION_VARS[$varname] = ${$varname}) $done=true;
		if($_SESSION[$varname] =${$varname}) $done=true;
    }
    return $done; 
}







/**
* @return result bool
* @param varname string
* @desc L�scht die Variable ${$varname} aus einer Session.
* Dank einem Bug in php4 sind wir gezwungen, je nach Konfiguration session_unregister()
* oder $HTTP_SESSION_VARS/$_SESSION zu verwenden.
*/
function wbb_session_unregister($varname)
{
	global $register_globals, $HTTP_SESSION_VARS, ${$varname};
	$done = false;
	if($register_globals)
	{
		$done = session_unregister("$varname");
	}
	else
	{
		unset($HTTP_SESSION_VARS[$varname]);
		unset($_SESSION[$varname]);
		$done=true;
	}
	return $done;
}




function gettemplate($template) {

        $file = file("templates/".$template.".htm");
        $template = implode("",$file);
        $template = str_replace("\"","\\\"",$template);
        return $template;
}

function dooutput($template) {

        echo $template;
}

function getUserid($usernick) {
        global $n,$db_zugriff;
        $result = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username='".addslashes($usernick)."'");
        return $result['userid'];
}

function getUser_stat($userid,$password)  {
	global $n,$db_zugriff;
	$result = $db_zugriff->query_first("SELECT groupid, blocked FROM bb".$n."_user_table WHERE userid='$userid' AND userpassword='".addslashes($password)."' AND activation='1'");
        $result = $db_zugriff->query_first("SELECT canuseacp FROM bb".$n."_groups WHERE id = '".$result['groupid']."'");
        return $result['0'];
}

#function editDBdata($data) {
#	$data = str_replace("&acute;","'", $data);
#	$data = str_replace("&quot;","\"", $data);
#	return $data;
#}

#function editPostdata($data) {
#	$data = str_replace("'","&acute;", $data);
#	$data = str_replace("\"","&quot;", $data);
#	return $data;
#}

function check_boardobject($boardid,$objectid,$field) {
	global $db_zugriff, $n;
	$result = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '$boardid' AND objectid = '$objectid' AND $field = 1");
	return $result['0'];
}

function checkemail($email) {
	
	global $db_zugriff, $n;
	if(!substr_count($email,"@") || substr_count($email,"@")>1) return 1;
	$position1 = strrpos($email,"@");
	if(!$position1) return 1;
	$position2 = strrpos($email,".");
	if(!$position2) return 1;
	if(strlen(substr($email, $position2)) < 3)return 1;
	if(strlen(substr($email, $position1,$position2-$position1-1))<2) return 1;

	$result = $db_zugriff->query_first("SELECT multi_email, banemail FROM bb".$n."_config");
	if(!$result['0']) {
		$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE useremail = '$email'");
		if($check['0']) return 1;
	}
	$banemail = explode("\n",$result['banemail']);
	for($i = 0; $i < count($banemail); $i++) {
		if(!trim($banemail[$i])) continue;
		if(ereg("\*", $banemail[$i])) {
			$banemail[$i] = str_replace("*",".*", trim($banemail[$i]));
			if(eregi("".$banemail[$i]."", $email)) return 1;
			break;
		}
		elseif(strtolower($email)==strtolower(trim($banemail[$i]))) {
			return 1;
			break;
		}  
	}
	
}

function checkname($name) {
	global $db_zugriff, $n;
	$check = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE username = '".addslashes($name)."'");
	return $check['0'];
}

function Hackdate($time) {
	global $db_zugriff, $n;
	$config = $db_zugriff->query_first("SELECT timeoffset, shortdateformat, timetype  FROM bb".$n."_config");
	$out = str_replace("DD",date("d", $time+(3600*$config['timeoffset'])), $config['shortdateformat']);
	$out = str_replace("MM",date("m", $time+(3600*$config['timeoffset'])), $out);
	$out = str_replace("YYYY",date("Y", $time+(3600*$config['timeoffset'])), $out);
	$out = str_replace("YY",date("y", $time+(3600*$config['timeoffset'])), $out);
	$out = str_replace("MN",get_month_name(date("n", $time+(3600*$config['timeoffset']))), $out);
	if($config['timetype']) { #12 Stunden
		$out = str_replace("II","II ".date("A", $time+(3600*$config['timeoffset'])), $out);	
		$out = str_replace("HH",date("h", $time+(3600*$config['timeoffset'])), $out);
	}
	else $out = str_replace("HH",date("H", $time+(3600*$config['timeoffset'])), $out);
	$out = str_replace("II",date("i", $time+(3600*$config['timeoffset'])), $out);
	return $out;
}

function get_month_name($month_number) {
	if(!isset($name_monat['$month_number'])) $name_monat['$month_number'] = "";

	$name_monat['1']    =  "Januar";  
	$name_monat['2']    =  "Februar";  
	$name_monat['3']    =  "M&auml;rz";  
	$name_monat['4']    =  "April";  
	$name_monat['5']    =  "Mai";  
	$name_monat['6']    =  "Juni";  
	$name_monat['7']    =  "Juli";  
	$name_monat['8']    =  "August";  
	$name_monat['9']    =  "September";  
	$name_monat['10']  =  "Oktober";  
	$name_monat['11']  =  "November";  
	$name_monat['12']  =  "Dezember";
	
	return $name_monat['$month_number'];
}

function bb_order() {
	global $db_zugriff, $n;
	
	$board_result = $db_zugriff->query("SELECT boardid FROM bb".$n."_boards");
	while($boards = $db_zugriff->fetch_array($board_result)) {
		$countp = $db_zugriff->query_first("SELECT COUNT(postid) FROM bb".$n."_posts WHERE boardparentid = '".$boards['boardid']."'");
               	$countt = $db_zugriff->query_first("SELECT COUNT(threadid) FROM bb".$n."_threads WHERE boardparentid = '".$boards['boardid']."'");
                $lastpost = $db_zugriff->query_first("SELECT postid, posttime FROM bb".$n."_posts WHERE boardparentid = '".$boards['boardid']."' ORDER BY posttime DESC LIMIT 1");
                $db_zugriff->query("UPDATE bb".$n."_boards SET posts = '".$countp['0']."', threads = '".$countt['0']."', lastposttime = '".$lastpost['posttime']."', lastpostid = '".$lastpost['postid']."' WHERE boardid = '".$boards['boardid']."'");	
	}
}

function ifelse ($expression,$returntrue,$returnfalse="") {
	if (!$expression) return $returnfalse;
	else return $returntrue;
}

function checkfiles(){
$first = "";
$second = "";

if(file_exists("./../install.php")) $first = "install.php";
if(file_exists("./../update.php")) $second = "update.php";
if($first AND $second){
	die("Please delete install.php and update.php");
}elseif($first OR $second){
	die("Please delete ".$first."".$second.".");
}else{
return TRUE;
}
}
?>