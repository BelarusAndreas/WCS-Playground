<?php
@set_time_limit(0);
require "./global.php"; 

if(!getUser_stat($user_id,$user_password)) {
	header("LOCATION: index.php?sid=$sid");
	exit;
} 

eval ("\$headinclude = \"".gettemplate("headinclude")."\";");	



// ####################### Define variables (Error free programming) ######################
if(isset($_POST['action'])) $action=$_POST['action'];
elseif(isset($_GET['action'])) $action=$_GET['action'];
else $action="";
if(!isset($send)) $send = "";
if(!isset($_GET['action'])) $_GET['action'] = "";
if(!isset($_POST['action'])) $_POST['action'] = "";
if(!isset($_POST['send'])) $_POST['send'] = "";
if(!isset($error)) $error = "";


if($_GET['action'] == "welcome") {

	$inaktiv = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE activation <> 1");
	$blocked = $db_zugriff->query_first("SELECT COUNT(userid) FROM bb".$n."_user_table WHERE blocked <> 0");
	$pms_count = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_pms");
	$inaktiv = $inaktiv['0'];
	$blocked = $blocked['0'];
	$pms_count = $pms_count['0'];
	eval("dooutput(\"".gettemplate("welcome")."\");");
}

if($_REQUEST['action'] == "switch_onoff") {
	if($_POST['send'] == "send") $db_zugriff->query("UPDATE bb".$n."_config SET boardoff = '".intval($_POST['onoff'])."', boardoff_text = '".addslashes($_POST['offlinemessage'])."'");
	$info = $db_zugriff->query_first("SELECT boardoff, boardoff_text FROM bb".$n."_config");
	$selected=array("","");
	if(!$info['0']) $selected['0'] = " selected";
	else $selected['1'] = " selected";
	$offlinemessage = htmlspecialchars($info['1']);
	eval("dooutput(\"".gettemplate("switch_onoff")."\");");
}

if($_REQUEST['action'] == "board_options") {
	if($_POST['send'] == "send") {
	
		if(!$_POST['boardname'] || !$_POST['masteremail'] || !$_POST['php_path'] || !$_POST['regdateformat'] || !$_POST['shortdateformat'] || !$_POST['longdateformat']) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET php_path = '".addslashes($_POST['php_path'])."', master_board_name = '".addslashes($_POST['boardname'])."', master_email = '".addslashes($_POST['masteremail'])."', regdateformat = '".addslashes($_POST['regdateformat'])."', shortdateformat = '".addslashes($_POST['shortdateformat'])."', longdateformat = '".addslashes($_POST['longdateformat'])."', today = '".addslashes($_POST['today'])."', timetype = '".intval($_POST['timetype'])."', timeoffset = '".intval($_POST['timeoffset'])."'");
	}
	$info = $db_zugriff->query_first("SELECT php_path, master_board_name, master_email, regdateformat, shortdateformat, longdateformat, today, timetype, timeoffset FROM bb".$n."_config");
	
	$boardname = ($info['master_board_name']);
	$php_path = ($info['php_path']);
	$masteremail = ($info['master_email']);
	$regdateformat = ($info['regdateformat']);
	$shortdateformat = ($info['shortdateformat']);
	$longdateformat = ($info['longdateformat']);
	$today = ($info['today']);
	
	$selected=array("","");
	if(!$info['timetype']) $selected['0'] = " selected";
	else $selected['1'] = " selected";
	
	$timeoffset_select="";
	for($i = -24; $i <= 24; $i++) {
		$timeoffset_select .= "<option value=\"$i\"";
		if($i == $info['timeoffset']) $timeoffset_select .= " selected";
		$timeoffset_select .= ">$i</option>\n";
	}	
	eval("dooutput(\"".gettemplate("board_options")."\");");
}

if($_REQUEST['action'] == "foren_options") {
	if($_POST['send'] == "send") {
	
		$tproseite = (int)($_POST['tproseite']);
		if(!$tproseite) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET tproseite = '$tproseite', default_daysprune = '".intval($_POST['default_daysprune'])."', show_subboards = '".intval($_POST['show_subboards'])."'");
	}
	$info = $db_zugriff->query_first("SELECT tproseite, default_daysprune, show_subboards FROM bb".$n."_config");
	
	$tproseite = $info['tproseite'];
	$selected=array("","");
	if(!$info['show_subboards']) $selected['0'] = " selected";
	else $selected['1'] = " selected";
	
	$s_prunedays=array("","","","","","","","","","","","");
	switch($info['default_daysprune']) {
		case 1: $s_prunedays['1'] = " selected"; break;
		case 2: $s_prunedays['2'] = " selected"; break; 
		case 5: $s_prunedays['3'] = " selected"; break;
		case 10: $s_prunedays['4'] = " selected"; break;
		case 20: $s_prunedays['5'] = " selected"; break;
		case 30: $s_prunedays['6'] = " selected"; break;
		case 45: $s_prunedays['7'] = " selected"; break;
		case 60: $s_prunedays['8'] = " selected"; break;
		case 75: $s_prunedays['9'] = " selected"; break;
		case 100: $s_prunedays['10'] = " selected"; break;
		case 365: $s_prunedays['11'] = " selected"; break;
		case 1000: $s_prunedays['12'] = " selected"; break;
	}	
	eval("dooutput(\"".gettemplate("foren_options")."\");");
}

if($_REQUEST['action'] == "thread_options") {
	if($_POST['send'] == "send") {
		$_POST['eproseite'] = (int)($_POST['eproseite']);
		$_POST['hotthread_view'] = (int)($_POST['hotthread_view']);
		$_POST['hotthread_reply'] = (int)($_POST['hotthread_reply']);
		#if(!$_POST['eproseite'] || !$_POST['hotthread_view'] || !$_POST['hotthread_reply']) eval ("\$error = \"".gettemplate("error")."\";");
		if(!$_POST['eproseite']) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET eproseite = '".$_POST['eproseite']."', postorder = '".intval($_POST['postorder'])."', hotthread_reply = '".$_POST['hotthread_reply']."', hotthread_view = '".$_POST['hotthread_view']."'");
	}
	$info = $db_zugriff->query_first("SELECT eproseite, postorder, hotthread_view, hotthread_reply FROM bb".$n."_config");
	$eproseite = $info['eproseite'];
	$hotthread_view = $info['hotthread_view'];
	$hotthread_reply = $info['hotthread_reply'];
	
	$selected=array("","");
	if(!$info['postorder']) $selected['0'] = " selected";
	else $selected['1'] = " selected";
	
	eval("dooutput(\"".gettemplate("thread_options")."\");");
}

if($_REQUEST['action'] == "post_options") {
	if($_POST['send'] == "send") {
		$_POST['anzahl_smilies'] = (int)($_POST['anzahl_smilies']);
		if(!$_POST['anzahl_smilies'] || !$_POST['cover'] || ($_POST['anzahl_smilies'] && round($_POST['anzahl_smilies']/3)-($_POST['anzahl_smilies']/3)!=0)) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET html = '".intval($_POST['html'])."', smilies = '".intval($_POST['smilies'])."', bbcode = '".intval($_POST['bbcode'])."', maximage = '".intval($_POST['maximage'])."', polls = '".intval($_POST['polls'])."', image = '".intval($_POST['image'])."', image_ext = '".addslashes($_POST['image_ext'])."', ch_parseurl = '".intval($_POST['ch_parseurl'])."', ch_email = '".intval($_POST['ch_email'])."', ch_disablesmilies = '".intval($_POST['ch_disablesmilies'])."', ch_signature = '".intval($_POST['ch_signature'])."', anzahl_smilies = '".intval($_POST['anzahl_smilies'])."', badwords = '".addslashes($_POST['badwords'])."', cover = '".addslashes($_POST['cover'])."'");
	}
	$info = $db_zugriff->query_first("SELECT html, smilies, bbcode, maximage, polls, image, image_ext, ch_parseurl, ch_email, ch_disablesmilies, ch_signature, anzahl_smilies, badwords, cover FROM bb".$n."_config");
	
	$html_selected=array("","");
	$smilies_selected=array("","");
	$bbcode_selected=array("","");
	$polls_selected=array("","");
	$image_selected=array("","");
	$ch_parseurl_selected=array("","");
	$ch_email_selected=array("","");
	$ch_disablesmilies_selected=array("","");
	$ch_signature_selected=array("","");
	if(!$info['html']) $html_selected['0'] = " selected";
	else $html_selected['1'] = " selected";
	if(!$info['smilies']) $smilies_selected['0'] = " selected";
	else $smilies_selected['1'] = " selected";
	if(!$info['bbcode']) $bbcode_selected['0'] = " selected";
	else $bbcode_selected['1'] = " selected";
	if(!$info['polls']) $polls_selected['0'] = " selected";
	else $polls_selected['1'] = " selected";
	if(!$info['image']) $image_selected['0'] = " selected";
	else $image_selected['1'] = " selected";
	if(!$info['ch_parseurl']) $ch_parseurl_selected['0'] = " selected";
	else $ch_parseurl_selected['1'] = " selected";
	if(!$info['ch_email']) $ch_email_selected['0'] = " selected";
	else $ch_email_selected['1'] = " selected";
	if(!$info['ch_disablesmilies']) $ch_disablesmilies_selected['0'] = " selected";
	else $ch_disablesmilies_selected['1'] = " selected";
	if(!$info['ch_signature']) $ch_signature_selected['0'] = " selected";
	else $ch_signature_selected['1'] = " selected";
	
	$image_ext = ($info['image_ext']);
	$badwords = ($info['badwords']);
	$cover = ($info['cover']);
	$maximage = $info['maximage'];
	$anzahl_smilies = $info['anzahl_smilies'];
	
	eval("dooutput(\"".gettemplate("post_options")."\");");
}

if($_REQUEST['action'] == "register_options") {
	if($_POST['send'] == "send") $db_zugriff->query("UPDATE bb".$n."_config SET register = '".intval($_POST['register'])."', act_code = '".intval($_POST['act_code'])."', act_permail = '".intval($_POST['act_permail'])."', regnotify = '".intval($_POST['regnotify'])."', multi_email = '".intval($_POST['multi_email'])."', banname = '".addslashes($_POST['banname'])."', banemail = '".addslashes($_POST['banemail'])."'");
	$info = $db_zugriff->query_first("SELECT register, act_code, act_permail, regnotify, multi_email, banname, banemail FROM bb".$n."_config");
	
	
	$register_selected=array("","");
	$act_code_selected=array("","");
	$act_permail_selected=array("","");
	$regnotify_selected=array("","");
	$multi_email_selected=array("","");
	if(!$info['register']) $register_selected['0'] = " selected";
	else $register_selected['1'] = " selected";
	if(!$info['act_code']) $act_code_selected['0'] = " selected";
	else $act_code_selected['1'] = " selected";
	if(!$info['act_permail']) $act_permail_selected['0'] = " selected";
	else $act_permail_selected['1'] = " selected";
	if(!$info['regnotify']) $regnotify_selected['0'] = " selected";
	else $regnotify_selected['1'] = " selected";
	if(!$info['multi_email']) $multi_email_selected['0'] = " selected";
	else $multi_email_selected['1'] = " selected";
	
	$banname = ($info['banname']);
	$banemail = ($info['banemail']);
	
	eval("dooutput(\"".gettemplate("register_options")."\");");
}

if($_REQUEST['action'] == "member_options") {
	if($_POST['send'] == "send") {
		$_POST['avatar_width'] = (int)($_POST['avatar_width']);
		$_POST['avatar_height'] = (int)($_POST['avatar_height']);
		$_POST['avatar_size'] = (int)($_POST['avatar_size']);
		if(!$_POST['avatar_size'] || !$_POST['avatar_width'] || !$_POST['avatar_height']) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_config SET sigsmilies = '".intval($_POST['sigsmilies'])."', sigbbcode = '".intval($_POST['sigbbcode'])."', sightml = '".intval($_POST['sightml'])."', sigimage = '".intval($_POST['sigimage'])."', sigmaximage = '".(int)($_POST['sigmaximage'])."', sigimage_ext = '".addslashes($_POST['sigimage_ext'])."', siglength = '".(int)($_POST['siglength'])."', avatars = '".intval($_POST['avatars'])."', avatarimage_ext = '".addslashes($_POST['avatarimage_ext'])."', avatar_width = '".(int)($_POST['avatar_width'])."', avatar_height = '".(int)($_POST['avatar_height'])."', avatar_size = '".(int)($_POST['avatar_size'])."', usertextlength = '".(int)($_POST['usertextlength'])."', favboards = '".(int)($_POST['favboards'])."', favthreads = '".(int)($_POST['favthreads'])."'");
	}
	$info = $db_zugriff->query_first("SELECT sigsmilies, sigbbcode, sightml, sigimage, sigmaximage, sigimage_ext, siglength, avatars, avatarimage_ext, avatar_width, avatar_height, avatar_size, usertextlength, favboards, favthreads FROM bb".$n."_config");
	
	
	$sigsmilies_selected=array("","");
	$sigbbcode_selected=array("","");
	$sightml_selected=array("","");
	$sigimage_selected=array("","");
	$avatars_selected=array("","");
	if(!$info['sigsmilies']) $sigsmilies_selected['0'] = " selected";
	else $sigsmilies_selected['1'] = " selected";
	if(!$info['sigbbcode']) $sigbbcode_selected['0'] = " selected";
	else $sigbbcode_selected['1'] = " selected";
	if(!$info['sightml']) $sightml_selected['0'] = " selected";
	else $sightml_selected['1'] = " selected";
	if(!$info['sigimage']) $sigimage_selected['0'] = " selected";
	else $sigimage_selected['1'] = " selected";
	if(!$info['avatars']) $avatars_selected['0'] = " selected";
	else $avatars_selected['1'] = " selected";
		
	$sigmaximage = $info['sigmaximage'];
	$siglength = $info['siglength'];
	$avatar_width = $info['avatar_width'];
	$avatar_height = $info['avatar_height'];
	$avatar_size = $info['avatar_size'];
	$usertextlength = $info['usertextlength'];
	$favboards = $info['favboards'];
	$favthreads = $info['favthreads'];
	
	$sigimage_ext = ($info['sigimage_ext']);
	$avatarimage_ext = ($info['avatarimage_ext']);
		
	eval("dooutput(\"".gettemplate("member_options")."\");");
}

if($_REQUEST['action'] == "pms_options") {
	if($_POST['send'] == "send") $db_zugriff->query("UPDATE bb".$n."_config SET pms = '".$_POST['pms']."', maxpms = '".(int)($_POST['maxpms'])."', maxfolder = '".(int)($_POST['maxfolder'])."'");
	$info = $db_zugriff->query_first("SELECT pms, maxpms, maxfolder FROM bb".$n."_config");
	
	$pms_selected=array("","");
	if(!$info['pms']) $pms_selected['0'] = " selected";
	else $pms_selected['1'] = " selected";
	
	$maxpms = $info['maxpms'];
	$maxfolder = $info['maxfolder'];
	
	eval("dooutput(\"".gettemplate("pms_options")."\");");
}

function makeboardlist($boardid) {
 global $boardcache;
if(!isset($out)) $out = "";
if(!isset($options)) $options = "";

 if(!isset($boardcache[$boardid])) return;
 
 $out.="<ul>";
 while (list($key1,$val1) = each($boardcache[$boardid])) {
  while(list($key2,$boards) = each($val1)) {
   $count = countboards($boardcache[$boardid]);
   unset($options);
   if(!isset($options)) $options = "";
   for($i = 1; $i <= $count; $i++) $options .= " <option value=\"$i\"".ifelse($boards['sort']==$i," selected","").">$i</option>";
   eval ("\$out .= \"".gettemplate("board_viewbit")."\";");
   $out .= makeboardlist($boards['boardid']);
  } 
 } 
 unset($boardcache['$boardid']);
 return $out."</ul>";
}

function countboards($array) {
 $count=0;
 reset($array);
 while(list($key,$val)=each($array)) $count+=count($val);
 return $count;
}

if($_REQUEST['action'] == "board_view") {
 if($_POST['send'] == "send") while(list($key,$val)=each($_POST['boardorder'])) $db_zugriff->query("UPDATE bb".$n."_boards SET sort='$val' WHERE boardid = '$key'");
 	
 $result = $db_zugriff->query("SELECT boardid, boardparentid, sort, boardname FROM bb".$n."_boards ORDER by boardparentid ASC, sort ASC");
 while ($row = $db_zugriff->fetch_array($result))$boardcache[$row['boardparentid']][$row['sort']][$row['boardid']] = $row;
 $boardlist = makeboardlist(0);
	
 eval("dooutput(\"".gettemplate("board_view")."\");");	
}

if($_REQUEST['action'] == "board_del") {
	if($_POST['send'] == "send" && $_POST['boardid']) {
		$threadids="";
		$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE boardid = ".$_POST['boardid']." AND (mod = 1 OR boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
		$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid = ".$_POST['boardid']." AND favboards = 1");
		$db_zugriff->query("UPDATE bb".$n."_boards SET boardparentid = 0 WHERE boardparentid = ".$_POST['boardid']."");
		$db_zugriff->query("DELETE FROM bb".$n."_boards WHERE boardid = ".$_POST['boardid']."");
		$result = $db_zugriff->query("SELECT threadid FROM bb".$n."_threads WHERE boardparentid = ".$_POST['boardid']."");
		while($row=$db_zugriff->fetch_array($result)) $threadids .= ",".$row['threadid']."";
		$db_zugriff->query("DELETE FROM bb".$n."_threads WHERE boardparentid = ".$_POST['boardid']."");
		$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_poll WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE threadid IN (0$threadids)");
		$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid IN (0$threadids) AND favthreads = 1");
		
		$result = $db_zugriff->query("SELECT COUNT(postid) AS posts, userid FROM bb".$n."_posts WHERE boardparentid = ".$_POST['boardid']." GROUP BY userid");
		while($row=$db_zugriff->fetch_array($result)) $db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts-'".$row['posts']."' WHERE userid=".$row['userid']."");
		
		$db_zugriff->query("DELETE FROM bb".$n."_posts WHERE boardparentid = ".$_POST['boardid']."");
		header("Location: admin.php?action=board_view$session");
		exit();
	}

	$board = $db_zugriff->query_first("SELECT boardname FROM bb".$n."_boards WHERE boardid='".$_GET['boardid']."'");
	eval("dooutput(\"".gettemplate("board_del")."\");");
}

if($_REQUEST['action'] == "board_add") {
	if($_POST['send'] == "send") {
		$_POST['boardname'] = trim($_POST['boardname']);
		if(!$_POST['boardname']) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			list($sort)=$db_zugriff->query_first("SELECT COUNT(*)+1 FROM bb".$n."_boards WHERE boardparentid='".intval($_POST['boardparentid'])."'");
			$db_zugriff->query("INSERT INTO bb".$n."_boards (boardid, boardparentid, boardname, boardpassword, descriptiontext, threads, posts, lastposttime, lastpostid, sort, isboard, invisible, style_set) VALUES ('','".intval($_POST['boardparentid'])."','".addslashes($_POST['boardname'])."','".trim(addslashes($_POST['boardpassword']))."','".addslashes($_POST['descriptiontext'])."','0','0','0','0','$sort','".$_POST['isboard']."','".$_POST['invisible']."','".$_POST['style_set']."')");
			$insertid = $db_zugriff->insert_id();
			if(isset($_POST['boardmods'])) for($i = 0; $i < count($_POST['boardmods']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,mod) VALUES ('$insertid','".$_POST['boardmods'][$i]."','1')");
			if(isset($_POST['boardpermission']))
			{
				if($_POST['boardpermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$insertid','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['boardpermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('$insertid','".$_POST['boardpermission'][$i]."','1')");
			}
			if(isset($_POST['startpermission']))
			{
				if($_POST['startpermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$insertid','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['startpermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('$insertid','".$_POST['startpermission'][$i]."','1')");
			}
			if(isset($_POST['replypermission']))
			{
				if($_POST['replypermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$insertid','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['replypermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('$insertid','".$_POST['replypermission'][$i]."','1')");
			}
			header("Location: admin.php?action=board_view$session");
			exit();
		}
	}
	
	$boardparentid_options="";
	$options="";
	$style_options="";
	$mod_options="";
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) $boardparentid_options .= "<option value=\"".$row['boardid']."\">".($row['boardname'])."</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"".$row['id']."\">".$row['title']."</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style <> 1 ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) $style_options .= "<option value=\"".$row['styleid']."\">".$row['stylename']."</option>\n";
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT userid, username FROM bb".$n."_groups LEFT JOIN bb".$n."_user_table ON (bb".$n."_groups.id = bb".$n."_user_table.groupid) WHERE ismod = 1 OR issupermod = 1");
	while($row = $db_zugriff->fetch_array($result)) $mod_options .= "<option value=\"".$row['userid']."\">".$row['username']."</option>\n";
	$db_zugriff->free_result($result);
		
	eval("dooutput(\"".gettemplate("board_add")."\");");
}

if($_REQUEST['action'] == "board_edit") {
	if($_POST['send'] == "send") {
		$_POST['boardname'] = trim($_POST['boardname']);
		if(!$_POST['boardname']) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("UPDATE bb".$n."_boards set boardparentid = '".$_POST['boardparentid']."', boardname = '".addslashes($_POST['boardname'])."', boardpassword = '".trim(addslashes($_POST['boardpassword']))."', descriptiontext = '".addslashes($_POST['descriptiontext'])."', isboard = '".$_POST['isboard']."', invisible = '".$_POST['invisible']."', style_set = '".$_POST['style_set']."' WHERE boardid = '".$_POST['boardid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE boardid = '".$_POST['boardid']."' AND (mod = 1 OR boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
			if(isset($_POST['boardmods']) && count($_POST['boardmods'])) for($i = 0; $i < count($_POST['boardmods']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,mod) VALUES ('".$_POST['boardid']."','".$_POST['boardmods'][$i]."','1')");
			if(isset($_POST['boardpermission']))
			{
				if($_POST['boardpermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('".$_POST['boardid']."','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['boardpermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES ('".$_POST['boardid']."','".$_POST['boardpermission'][$i]."','1')");
			}
			if(isset($_POST['startpermission']))
			{		
				if($_POST['startpermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('".$_POST['boardid']."','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['startpermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES ('".$_POST['boardid']."','".$_POST['startpermission'][$i]."','1')");
			}
			if(isset($_POST['replypermission']))
			{
				if($_POST['replypermission']['0']=="*") {
					$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups");
					while($row = $db_zugriff->fetch_array($result)) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('".$_POST['boardid']."','".$row['id']."','1')");
				}
				else for($i = 0; $i < count($_POST['replypermission']); $i++) $db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES ('".$_POST['boardid']."','".$_POST['replypermission'][$i]."','1')");
			}
		}
	} 
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_boards WHERE boardid = '".($_REQUEST['boardid'])."'");
	
	
	$invisible_selected=array("","");
	$isboard_select=array("","");
	$bp_selected="";
	$sp_selected="";
	$rp_selected="";
	$boardparentid_options="";
	$options="";
	$style_options="";
	$mod_options="";
	$bp_options="";
	$sp_options="";
	$rp_options="";
	
	$boardname = ($info['boardname']);
	$descriptiontext = ($info['descriptiontext']);
	$boardpassword = $info['boardpassword'];
	
	if($info['invisible']) $invisible_selected['1'] = " selected";
	else $invisible_selected['0'] = " selected";
	
	if(!$info['isboard']) $isboard_select = " selected";
	else $isboard_select = "";
	
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE boardid <> '".$info['boardid']."' ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$boardparentid_options .= "<option value=\"".$row['boardid']."\"";
		if($row['boardid'] == $info['boardparentid']) $boardparentid_options .= " selected";
		$boardparentid_options .= ">".$row['boardname']."</option>\n";
	}
	$db_zugriff->free_result($result);
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style WHERE default_style <> 1 ORDER BY stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$style_options .= "<option value=\"".$row['styleid']."\"";
		if($row['styleid']==$info['style_set']) $style_options .= " selected";
		$style_options .= ">".$row['stylename']."</option>\n";
	}
	$db_zugriff->free_result($result);
	
	
	$check1 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_groups");
	$check2 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '".$info['boardid']."' AND boardpermission = 1");
	$check3 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '".$info['boardid']."' AND startpermission = 1");
	$check4 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_object2board WHERE boardid = '".$info['boardid']."' AND replypermission = 1");
	
	if($check1['0'] == $check2['0']) $bp_selected = " selected";
	if($check1['0'] == $check3['0']) $sp_selected = " selected";
	if($check1['0'] == $check4['0']) $rp_selected = " selected";
	
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY id ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$bp_options .= "<option value=\"".$row['id']."\"";
		$sp_options .= "<option value=\"".$row['id']."\"";
		$rp_options .= "<option value=\"".$row['id']."\"";
		
		if(!$bp_selected && check_boardobject($info['boardid'],$row['id'],"boardpermission")) $bp_options .= " selected";
		if(!$sp_selected && check_boardobject($info['boardid'],$row['id'],"startpermission")) $sp_options .= " selected";
		if(!$rp_selected && check_boardobject($info['boardid'],$row['id'],"replypermission")) $rp_options .= " selected";
		
		$bp_options .= ">".$row['title']."</option>\n";
		$sp_options .= ">".$row['title']."</option>\n";
		$rp_options .= ">".$row['title']."</option>\n";		
	}
	$db_zugriff->free_result($result);
	
	$where="";
	$result = $db_zugriff->query("SELECT id FROM bb".$n."_groups WHERE ismod = 1 OR issupermod = 1");
	while($row = $db_zugriff->fetch_array($result)) {
		if($where) $where .= " OR ";
		$where .= "groupid = '".$row['id']."'";
	}
	$db_zugriff->free_result($result);
	if($where) {
		$result = $db_zugriff->query("SELECT userid, username FROM bb".$n."_user_table WHERE $where");
		while($row = $db_zugriff->fetch_array($result)) {
			$mod_options .= "<option value=\"".$row['userid']."\"";
			if(check_boardobject($info['boardid'],$row['userid'],"mod")) $mod_options .= " selected";
			$mod_options .= ">".$row['username']."</option>\n";
		}
		$db_zugriff->free_result($result);
	}
	
	eval("dooutput(\"".gettemplate("board_edit")."\");");
}

if($_REQUEST['action'] == "member_add") {
	if($_POST['send'] == "send") {
		if(!$_POST['username'] || !trim($_POST['userpassword']) || !$_POST['useremail'] || checkname($_POST['username']) || checkemail($_POST['useremail'])){
			eval ("\$error = \"".gettemplate("error")."\";");
		}else{
			$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,session_link,activation) VALUES ('".trim(addslashes(htmlspecialchars($_POST['username'])))."','".md5(trim($_POST['userpassword']))."','".trim(addslashes(htmlspecialchars($_POST['useremail'])))."','".trim(addslashes(htmlspecialchars($_POST['useremail'])))."','".intval($_POST['groupid'])."','".time()."','".intval($_POST['session_link'])."','1')");
			header("Location: admin.php?action=welcome$session");
		}
	}
	$options="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY default_group DESC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"".$row['id']."\">".$row['title']."</option>\n";
	eval("dooutput(\"".gettemplate("member_add")."\");");
}

if($_REQUEST['action'] == "member_view_inactiv") {
	if($_POST['send'] == "send" && isset($_POST['userid']) && count($_POST['userid'])) {
		if(isset($_POST['delete']) && $_POST['delete']) for($i = 0; $i < count($_POST['userid']); $i++) $db_zugriff->query("DELETE FROM bb".$n."_user_table WHERE userid = '".$_POST['userid'][$i]."'");
		else for($i = 0; $i < count($_POST['userid']); $i++) $db_zugriff->query("UPDATE bb".$n."_user_table SET activation = 1 WHERE userid = '".$_POST['userid'][$i]."'");
	}
	$result = $db_zugriff->query("SELECT userid, username, useremail, regdate FROM bb".$n."_user_table WHERE activation <> 1 ORDER BY regdate DESC");
	$member_view_inactivbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		$regdate = Hackdate($row['regdate']);		
		eval ("\$member_view_inactivbit .= \"".gettemplate("member_view_inactivbit")."\";");
	}
	eval("dooutput(\"".gettemplate("member_view_inactiv")."\");");
}

if($_REQUEST['action'] == "member_search") {
	if(isset($_POST['search']) && trim($_POST['search'])) {
		$_POST['search'] = htmlspecialchars($_POST['search']);
		if($_POST['mode'] == 1) $result = $db_zugriff->query("SELECT userid, username, useremail, regemail, regdate FROM bb".$n."_user_table WHERE activation = 1 AND username LIKE '%".addslashes(trim($_POST['search']))."%' ORDER BY username ASC");
		else $result = $db_zugriff->query("SELECT userid, useremail, username, regemail, regdate FROM bb".$n."_user_table WHERE activation = 1 AND userid = '".intval($_POST['search'])."' ORDER BY username ASC");
		while ($row = $db_zugriff->fetch_array($result)) {
			$regdate = Hackdate($row['regdate']);		
			eval ("\$member_search_resultbit .= \"".gettemplate("member_search_resultbit")."\";");
		}
		eval("dooutput(\"".gettemplate("member_search_result")."\");");
		exit;
	}
	eval("dooutput(\"".gettemplate("member_search")."\");");
}

if($_REQUEST['action'] == "member_edit") {
	if($_POST['send'] == "send") {
		if($_POST['delete'] == "1") {
			$db_zugriff->query("UPDATE bb".$n."_posts SET userid = 0 WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("UPDATE bb".$n."_threads SET authorid = 0 WHERE authorid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_folders WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_notify WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE objectid = '".$_POST['userid']."' AND mod = 1");
			$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2user WHERE objectid = '".$_POST['userid']."' AND (buddylist = 1 OR ignorelist = 1)");
			$db_zugriff->query("DELETE FROM bb".$n."_pms WHERE recipientid = '".$_POST['userid']."' OR senderid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_pmsend WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_useronline WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_user_table WHERE userid = '".$_POST['userid']."'");
			$db_zugriff->query("DELETE FROM bb".$n."_vote WHERE userid = '".$_POST['userid']."'");
					
			header("Location: admin.php?action=member_search$session");
			exit;
		}

		$username = trim($_POST['username']);
		$useremail = trim($_POST['useremail']);
		
		$check = $db_zugriff->query_first("SELECT username, useremail, groupid FROM bb".$n."_user_table WHERE userid = '".$_POST['userid']."'");
		if($username!=$check['username']) $check_username = checkname($username);
		if($useremail!=$check['useremail']) $check_useremail = checkname($useremail);
		if(!$username || !$useremail || (isset($check_useremail) && $check_useremail) || (isset($check_username) && $check_username)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
		 $db_zugriff->query("UPDATE bb".$n."_user_table SET username = '".addslashes(htmlspecialchars($username))."', useremail = '".addslashes(htmlspecialchars($useremail))."', userhp = '".addslashes($_POST['userhp'])."', usericq = '".intval($_POST['usericq'])."', aim = '".addslashes($_POST['aim'])."', yim = '".addslashes($_POST['yim'])."', interests = '".addslashes($_POST['interests'])."', location = '".addslashes($_POST['location'])."', work = '".addslashes($_POST['work'])."', signatur = '".addslashes($_POST['signatur'])."', usertext = '".addslashes($_POST['usertext'])."', statusextra = '".addslashes($_POST['statusextra'])."', groupid = '".intval($_POST['groupid'])."', blocked = '".intval($_POST['blocked'])."' WHERE userid = '".intval($_POST['userid'])."'");
		 $db_zugriff->query("UPDATE bb".$n."_threads SET author = '".addslashes(htmlspecialchars($username))."' WHERE authorid = '".$_POST['userid']."'");
		 // Benutzer aus der Moderatorenliste l�schen, falls seine Gruppe nicht Mod ist.
		 if($check['groupid']!=$_POST['groupid'])
		 {
		 	$check=$db_zugriff->query_first("SELECT ismod+issupermod as moderator FROM bb".$n."_groups WHERE id='".$_POST['groupid']."'");
			if(!$check['moderator']) $db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE objectid='".$_POST['userid']."' AND mod='1'");
		 }
	  }
	}
			
	if(!isset($_POST['userid'])) header("Location: admin.php?action=member_search$session");

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_user_table WHERE userid = '".$_POST['userid']."'");
	
	$userhp = ($info['userhp']);
	$usericq = ($info['usericq']);
	$aim = ($info['aim']);
	$yim = ($info['yim']);
	$interests = ($info['interests']);
	$location = ($info['location']);
	$signatur = ($info['signatur']);
	$usertext = ($info['usertext']);
	$work = ($info['work']);
	$statusextra = ($info['statusextra']);

	$options="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY default_group DESC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"".$row['id']."\"";
		if($row['id']==$info['groupid']) $options .= " selected";
		$options .= ">".$row['title']."</option>\n";
	}
	
	
	if($info['blocked']) $selected = " selected";
	else $selected="";
	eval("dooutput(\"".gettemplate("member_edit")."\");");

}


// Beim Erstellen einer neuen Gruppe werden die Zugriffsrechte der Foren aktualisiert, wenn "#ALLE GRUPPEN" ausgew�hlt wurde.
if($_REQUEST['action'] == "group_add") {
	if($_POST['send'] == "send") {
		if(!$_POST['title']) eval ("\$error = \"".gettemplate("error")."\";");
		else
		{
			$db_zugriff->query("INSERT INTO bb".$n."_groups (id, title, canviewboard, canviewoffboard, canusesearch, canusepms, canstarttopic, canreplyowntopic, canreplytopic, caneditownpost, candelownpost, cancloseowntopic, candelowntopic, canpostpoll, canvotepoll, canuploadavatar, appendeditnote, avoidfc, ismod, issupermod, canuseacp, default_group) VALUES ('','".addslashes($_POST['title'])."','".$_POST['canviewboard']."','".$_POST['canviewoffboard']."','".$_POST['canusesearch']."','".$_POST['canusepms']."','".$_POST['canstarttopic']."','".$_POST['canreplyowntopic']."','".$_POST['canreplytopic']."','".$_POST['caneditownpost']."','".$_POST['candelownpost']."','".$_POST['cancloseowntopic']."','".$_POST['candelowntopic']."','".$_POST['canpostpoll']."','".$_POST['canvotepoll']."','".$_POST['canuploadavatar']."','".$_POST['appendeditnote']."','".$_POST['avoidfc']."','".$_POST['ismod']."','".$_POST['issupermod']."','".$_POST['canuseacp']."','')");
			$newgroupid = $db_zugriff->insert_id();
			
			$check1 = $db_zugriff->query_first("SELECT COUNT(*) FROM bb".$n."_groups");
			$result1 = $db_zugriff->query("SELECT boardid,count(objectid) countgroups FROM bb".$n."_object2board WHERE boardpermission=1 GROUP BY boardid ORDER BY countgroups DESC");
			$result2 = $db_zugriff->query("SELECT boardid,count(objectid) countgroups FROM bb".$n."_object2board WHERE startpermission=1 GROUP BY boardid ORDER BY countgroups DESC");
			$result3 = $db_zugriff->query("SELECT boardid,count(objectid) countgroups FROM bb".$n."_object2board WHERE replypermission=1 GROUP BY boardid ORDER BY countgroups DESC");
			while($row=$db_zugriff->fetch_array($result1))
			{
				if($row['countgroups']+1<$check1[0]) break;
				$db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,boardpermission) VALUES('".$row['boardid']."','".$newgroupid."','1')");
			}
			while($row=$db_zugriff->fetch_array($result2))
			{
				if($row['countgroups']+1<$check1[0]) break;
				$db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,startpermission) VALUES('".$row['boardid']."','".$newgroupid."','1')");
			}
			while($row=$db_zugriff->fetch_array($result3))
			{
				if($row['countgroups']+1<$check1[0]) break;
				$db_zugriff->query("INSERT INTO bb".$n."_object2board (boardid,objectid,replypermission) VALUES('".$row['boardid']."','".$newgroupid."','1')");
			}
			header("Location: admin.php?action=group_view_edit$session");
		}
	}
	eval("dooutput(\"".gettemplate("group_add")."\");");
}


if($_GET['action'] == "group_view_edit") {
	$group_view_editbit="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) eval ("\$group_view_editbit .= \"".gettemplate("group_view_editbit")."\";");
	eval("dooutput(\"".gettemplate("group_view_edit")."\");");
}

if($_REQUEST['action'] == "group_edit") {
	if($_POST['send'] == "send") {
		if(!$_POST['title']) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_groups SET title = '".addslashes($_POST['title'])."', canviewboard = '".$_POST['canviewboard']."', canviewoffboard = '".$_POST['canviewoffboard']."', canusesearch = '".$_POST['canusesearch']."', canusepms = '".$_POST['canusepms']."', canstarttopic = '".$_POST['canstarttopic']."', canreplyowntopic = '".$_POST['canreplyowntopic']."', canreplytopic = '".$_POST['canreplytopic']."', caneditownpost = '".$_POST['caneditownpost']."', candelownpost = '".$_POST['candelownpost']."', cancloseowntopic = '".$_POST['cancloseowntopic']."', candelowntopic = '".$_POST['candelowntopic']."', canpostpoll = '".$_POST['canpostpoll']."', canvotepoll = '".$_POST['canvotepoll']."', canuploadavatar = '".$_POST['canuploadavatar']."', appendeditnote = '".$_POST['appendeditnote']."', avoidfc = '".$_POST['avoidfc']."', ismod = '".$_POST['ismod']."', issupermod = '".$_POST['issupermod']."', canuseacp = '".$_POST['canuseacp']."' WHERE id = '".$_POST['groupid']."'");
	}
	if(!isset($_POST['groupid'])) header("LOCATION: admin.php?action=group_view_edit$session");

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_groups WHERE id = '".$_POST['groupid']."'");


	$s_canviewboard=array("","",);
	$s_canusesearch=array("","",);
	$s_canusepms=array("","",);
	$s_canstarttopic=array("","",);
	$s_canreplyowntopic=array("","",);
	$s_canreplytopic=array("","",);
	$s_caneditownpost=array("","",);
	$s_candelownpost=array("","",);
	$s_cancloseowntopic=array("","",);
	$s_candelowntopic=array("","",);
	$s_canpostpoll=array("","",);
	$s_canvotepoll=array("","",);
	$s_canuploadavatar=array("","",);
	$s_appendeditnote=array("","",);
	$s_avoidfc=array("","",);
	$s_canviewoffboard=array("","");
	$s_ismod=array("","",);
	$s_issupermod=array("","",);
	$s_canuseacp=array("","",);
	if($info['canviewboard']) $s_canviewboard['1'] = " selected";
	else $s_canviewboard['0'] = " selected";
	if($info['canusesearch']) $s_canusesearch['1'] = " selected";
	else $s_canusesearch['0'] = " selected";
	if($info['canusepms']) $s_canusepms['1'] = " selected";
	else $s_canusepms['0'] = " selected";
	if($info['canstarttopic']) $s_canstarttopic['1'] = " selected";
	else $s_canstarttopic['0'] = " selected";
	if($info['canreplyowntopic']) $s_canreplyowntopic['1'] = " selected";
	else $s_canreplyowntopic['0'] = " selected";
	if($info['canreplytopic']) $s_canreplytopic['1'] = " selected";
	else $s_canreplytopic['0'] = " selected";
	if($info['caneditownpost']) $s_caneditownpost['1'] = " selected";
	else $s_caneditownpost['0'] = " selected";
	if($info['candelownpost']) $s_candelownpost['1'] = " selected";
	else $s_candelownpost['0'] = " selected";
	if($info['cancloseowntopic']) $s_cancloseowntopic['1'] = " selected";
	else $s_cancloseowntopic['0'] = " selected";
	if($info['candelowntopic']) $s_candelowntopic['1'] = " selected";
	else $s_candelowntopic['0'] = " selected";
	if($info['canpostpoll']) $s_canpostpoll['1'] = " selected";
	else $s_canpostpoll['0'] = " selected";
	if($info['canvotepoll']) $s_canvotepoll['1'] = " selected";
	else $s_canvotepoll['0'] = " selected";
	if($info['canuploadavatar']) $s_canuploadavatar['1'] = " selected";
	else $s_canuploadavatar['0'] = " selected";
	if($info['appendeditnote']) $s_appendeditnote['1'] = " selected";
	else $s_appendeditnote['0'] = " selected";
	if($info['avoidfc']) $s_avoidfc['1'] = " selected";
	else $s_avoidfc['0'] = " selected";
	if($info['canviewoffboard']) $s_canviewoffboard['1'] = " selected";
	else $s_canviewoffboard['0'] = " selected";
	if($info['ismod']) $s_ismod['1'] = " selected";
	else $s_ismod['0'] = " selected";
	if($info['issupermod']) $s_issupermod['1'] = " selected";
	else $s_issupermod['0'] = " selected";
	if($info['canuseacp']) $s_canuseacp['1'] = " selected";
	else $s_canuseacp['0'] = " selected";
	
	eval("dooutput(\"".gettemplate("group_edit")."\");");
}

if($_REQUEST['action'] == "group_del") {
	if($_POST['send'] == "send" && isset($_POST['groupid']) && count($_POST['groupid'])) {
		for($i = 0; $i < count($_POST['groupid']); $i++) {
			$check = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_groups WHERE id = '".$_POST['groupid'][$i]."' AND default_group <> 0");
			if($check['0']) continue;
			$default = $db_zugriff->query_first("SELECT id FROM bb".$n."_groups WHERE default_group = 2");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET groupid = '".$default['id']."' WHERE groupid = '".$_POST['groupid'][$i]."'");
			$db_zugriff->query("UPDATE bb".$n."_ranks SET groupid = '".$default['id']."' WHERE groupid = '".$_POST['groupid'][$i]."'");
			$db_zugriff->query("DELETE FROM bb".$n."_object2board WHERE objectid = '".$_POST['groupid'][$i]."' AND (boardpermission = 1 OR startpermission = 1 OR replypermission = 1)");
			$db_zugriff->query("DELETE FROM bb".$n."_groups WHERE id = '".$_POST['groupid'][$i]."'");
		}
	} 

	$group_delbit="";
	$result = $db_zugriff->query("SELECT id, title, default_group FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		if($row['default_group']) $disabled = " disabled";
		else $disabled = "";
		eval ("\$group_delbit .= \"".gettemplate("group_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("group_del")."\");");
}

if($_GET['action'] == "menue") eval("dooutput(\"".gettemplate("menue")."\");"); 
if($_GET['action'] == "top") eval("dooutput(\"".gettemplate("oben")."\");");


if($_REQUEST['action'] == "group_default") {
	if($_POST['send'] == "send") {
		if($_POST['default1'] == $_POST['default2']) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 0");
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 1 WHERE id = '".$_POST['default1']."'");
			$db_zugriff->query("UPDATE bb".$n."_groups SET default_group = 2 WHERE id = '".$_POST['default2']."'");
		}
	}
	
	$options1="";
	$options2="";
	$result = $db_zugriff->query("SELECT id, title, default_group FROM bb".$n."_groups ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options1 .= "<option value=\"".$row['id']."\"";
		if($row['default_group']==1) $options1 .= " selected";
		$options1 .= ">".$row['title']."</option>\n";
		
		$options2 .= "<option value=\"".$row['id']."\"";
		if($row['default_group']==2) $options2 .= " selected";
		$options2 .= ">".$row['title']."</option>\n";
	}
	eval("dooutput(\"".gettemplate("group_default")."\");");
}

if($_REQUEST['action'] == "rank_add") {
	if($_POST['send'] == "send") {
		#if(!isset($_POST['rank']) || !$_POST['rank']) eval ("\$error = \"".gettemplate("error")."\";");
		if(isset($_POST['rank']) && $_POST['rank']) $db_zugriff->query("INSERT INTO bb".$n."_ranks (groupid,posts,rank,grafik,mal) VALUES ('".intval($_POST['groupid'])."', '".(int)($_POST['posts'])."', '".addslashes($_POST['rank'])."', '".addslashes($_POST['grafik'])."', '".(int)($_POST['mal'])."')");
		header("Location: admin.php?action=rank_view_edit$session");
	}

	$options="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>";
	
	eval("dooutput(\"".gettemplate("rank_add")."\");");
}

if($_REQUEST['action'] == "rank_view_edit") {
	if($_POST['send'] == "send" && $_POST['rankid']) header("Location: admin.php?action=rank_edit&rankid=".$_POST['rankid'].$session);
	
	$result = $db_zugriff->query("SELECT bb".$n."_ranks.id, groupid, posts, rank,title FROM bb".$n."_ranks LEFT JOIN bb".$n."_groups ON bb".$n."_groups.id=bb".$n."_ranks.groupid ORDER BY groupid ASC, posts ASC");
	$rank_view_editbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		$rank = ($row['rank']);
		#$groupname = $db_zugriff->query_first("SELECT title FROM bb".$n."_groups WHERE id = '$row[groupid]'");
		#$groupname = $groupname[0];
		$groupname = $row['title'];
		eval ("\$rank_view_editbit .= \"".gettemplate("rank_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("rank_view_edit")."\");");
}

if($_REQUEST['action'] == "rank_edit") {
	if($_POST['send'] == "send") {
		if(!isset($_POST['rank']) || !$_POST['rank']) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_ranks SET groupid = '".intval($_POST['groupid'])."', posts = '".(int)($_POST['posts'])."', rank = '".addslashes($_POST['rank'])."', grafik = '".addslashes($_POST['grafik'])."', mal = '".(int)($_POST['mal'])."' WHERE id = '".intval($_POST['rankid'])."'");
	}
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE id = '".intval($_REQUEST['rankid'])."'");
	$rank = ($info['rank']);
	$rankid=$info['id'];
	$options="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"$row[id]\"";
		if($row['id']==$info['groupid']) $options .= " selected";
		$options .= ">$row[title]</option>";
	}
	eval("dooutput(\"".gettemplate("rank_edit")."\");");
}

if($_REQUEST['action'] == "rank_del") {
	if($_POST['send'] == "send" && isset($_POST['rankid']) && count($_POST['rankid'])) {
		for($i = 0; $i < count($_POST['rankid']); $i++) $db_zugriff->query("DELETE FROM bb".$n."_ranks WHERE id = '".$_POST['rankid'][$i]."'");
	}
	
	$result = $db_zugriff->query("SELECT bb".$n."_ranks.id, groupid, posts, rank,title FROM bb".$n."_ranks LEFT JOIN bb".$n."_groups ON bb".$n."_groups.id=bb".$n."_ranks.groupid ORDER BY groupid ASC, posts ASC");
	$rank_delbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		$rank = ($row['rank']);
		$groupname = $row['title'];
		eval ("\$rank_delbit .= \"".gettemplate("rank_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("rank_del")."\");");
}

if($_REQUEST['action'] == "style_add") {
	if($_POST['send'] == "send") {
		if(!$_POST['stylename'] || !$_POST['templatefolder'] || !$_POST['imagefolder'] || !file_exists("../".$_POST['templatefolder']."/main.htm")) eval ("\$error = \"".gettemplate("error")."\";");
		else 
		{
			$db_zugriff->query("INSERT INTO bb".$n."_style (stylename,templatefolder,imagefolder,font,fontcolor,fontcolorsec,fontcolorthi,fontcolorfour,bgcolor,tablebg,tablea,tableb,tablec,tabled,imageurl,css,bgimage,bgfixed) VALUES ('".addslashes($_POST['stylename'])."','".addslashes($_POST['templatefolder'])."','".addslashes($_POST['imagefolder'])."','".addslashes($_POST['font'])."','".addslashes($_POST['fontcolor'])."','".addslashes($_POST['fontcolorsec'])."','".addslashes($_POST['fontcolorthi'])."','".addslashes($_POST['fontcolorfour'])."','".addslashes($_POST['bgcolor'])."','".addslashes($_POST['tablebg'])."','".addslashes($_POST['tablea'])."','".addslashes($_POST['tableb'])."','".addslashes($_POST['tablec'])."','".addslashes($_POST['tabled'])."','".addslashes($_POST['imageurl'])."','".addslashes($_POST['css'])."','".addslashes($_POST['bgimage'])."','".intval($_POST['bgfixed'])."')");
			header("Location: admin.php?action=style_view_edit$session");
		}
	}
	eval("dooutput(\"".gettemplate("style_add")."\");");
}

if($_REQUEST['action'] == "style_view_edit") {
	if($_POST['send'] == "send" && isset($_POST['styleid']) && $_POST['styleid']) header("Location: admin.php?action=style_edit&styleid=".$_POST['styleid'].$session);
	
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style ORDER BY stylename ASC");
	$style_view_editbit = "";
	while($row = $db_zugriff->fetch_array($result)) {
		$stylename = ($row['stylename']);
		eval ("\$style_view_editbit .= \"".gettemplate("style_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("style_view_edit")."\");");
}

if($_REQUEST['action'] == "style_edit") {
	if($_POST['send'] == "send") {
		if(!$_POST['stylename'] || !$_POST['templatefolder'] || !file_exists("../".$_POST['templatefolder']."/main.htm")) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_style SET stylename = '".addslashes($_POST['stylename'])."', templatefolder = '".addslashes($_POST['templatefolder'])."', imagefolder='".addslashes($_POST['imagefolder'])."', font = '".addslashes($_POST['font'])."', fontcolor = '".addslashes($_POST['fontcolor'])."', fontcolorsec = '".addslashes($_POST['fontcolorsec'])."', fontcolorthi = '".addslashes($_POST['fontcolorthi'])."', fontcolorfour = '".addslashes($_POST['fontcolorfour'])."', bgcolor = '".addslashes($_POST['bgcolor'])."', tablebg = '".addslashes($_POST['tablebg'])."', tablea = '".addslashes($_POST['tablea'])."', tableb = '".addslashes($_POST['tableb'])."', tablec = '".addslashes($_POST['tablec'])."', tabled = '".addslashes($_POST['tabled'])."', imageurl = '".addslashes($_POST['imageurl'])."', css = '".addslashes($_POST['css'])."', bgimage = '".addslashes($_POST['bgimage'])."', bgfixed = '".addslashes($_POST['bgfixed'])."' WHERE styleid = '".intval($_POST['styleid'])."'");
	}
	
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_style WHERE styleid = '".$_REQUEST['styleid']."'");
	$styleid = $info['styleid'];
	$stylename = ($info['stylename']);
	$css = ($info['css']);
	if(!$info['bgfixed']) $selected = " selected";
	else $selected = "";
	eval("dooutput(\"".gettemplate("style_edit")."\");");
}

if($_REQUEST['action'] == "style_del") {
	if($_POST['send'] == "send" && isset($_POST['styleid']) && count($_POST['styleid'])) {
		for($i = 0; $i < count($_POST['styleid']); $i++) {
			$check = $db_zugriff->query_first("SELECT COUNT(styleid) FROM bb".$n."_style WHERE styleid = '".$_POST['styleid'][$i]."' AND default_style = 1");
			if($check[0]) continue;
			$db_zugriff->query("UPDATE bb".$n."_boards SET style_set = '0' WHERE style_set = '".$_POST['styleid'][$i]."'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET style_set = '0' WHERE style_set = '".$_POST['styleid'][$i]."'");
			$db_zugriff->query("DELETE FROM bb".$n."_style WHERE styleid = '".$_POST['styleid'][$i]."'");
		}
	}
	$result = $db_zugriff->query("SELECT styleid, stylename, default_style FROM bb".$n."_style ORDER BY stylename ASC");
	$style_delbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		$stylename = ($row['stylename']);
		if($row['default_style']) $disabled = " disabled";
		else $disabled = "";
		eval ("\$style_delbit .= \"".gettemplate("style_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("style_del")."\");");
}






if($_REQUEST['action'] == "style_default") {
	if($_POST['send'] == "send") {
		$db_zugriff->query("UPDATE bb".$n."_style SET default_style = '0'");
		$db_zugriff->query("UPDATE bb".$n."_style SET default_style = '1' WHERE styleid = '".intval($_POST['styleid'])."'");
	}
	
	$options="";
	$result = $db_zugriff->query("SELECT styleid, stylename FROM bb".$n."_style ORDER BY default_style DESC, stylename ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[styleid]\">".($row['stylename'])."</option>";
	
	eval("dooutput(\"".gettemplate("style_default")."\");");
}


if($_GET['action'] == "style_importexport")
{
	$result = $db_zugriff->query("SELECT styleid,stylename FROM bb".$n."_style");
	$style_options="";
	while($row=$db_zugriff->fetch_array($result)) $style_options .= "<option value=\"".$row['styleid']."\">".htmlspecialchars($row['stylename'])."</option>\n";
	eval("dooutput(\"".gettemplate("style_importexport")."\");");
}


if($_POST['action']=="style_import")
{

	//if(!$_FILES['stylefile']['name'] || !$_FILES['stylefile']['tmp_name'] || !$_POST['templatefolder'] || !$_POST['imagefolder'] || !is_writeable("../".$_POST['templatefolder']) || !is_writeable("../".$_POST['imagefolder']))
	if(!$_FILES['stylefile']['name'] || !$_FILES['stylefile']['tmp_name'])
	{
		header("Location: admin.php?action=style_importexport&sid=$sid");
		exit;
	}

	$savedstylefile = uniqid("style").".style";
	// speichern in ../images/avatars (nur tempor�r)
	move_uploaded_file($_FILES['stylefile']['tmp_name'],"../images/avatars/$savedstylefile");

	$file_content = implode("",file("../images/avatars/$savedstylefile"));
	$style_import = unserialize(base64_decode($file_content));
	
	if((count($style_import['templates']) && (!$_POST['templatefolder'] || !is_writeable("../".$_POST['templatefolder']))) || ((count($style_import['images']) || $style_import['logo']['filename'] || $style_import['bgimage']['filename']) && (!$_POST['imagefolder'] || !is_writeable("../".$_POST['imagefolder']))))
	{
		@unlink("../images/avatars/$savedstylefile");
		header("Location: admin.php?action=style_importexport&sid=$sid");
		exit;
	}
	
	$db_zugriff->query("INSERT INTO bb".$n."_style (stylename,templatefolder,imagefolder,font,fontcolor,fontcolorsec,fontcolorthi,fontcolorfour,bgcolor,tablebg,tablea,tableb,tablec,tabled,imageurl,css,bgimage,bgfixed) 
	VALUES ('".addslashes($style_import['style_data']['stylename'])."', '".addslashes($_POST['templatefolder'])."', '".addslashes($_POST['imagefolder'])."', 
	'".addslashes($style_import['style_data']['font'])."', '".addslashes($style_import['style_data']['fontcolor'])."', 
	'".addslashes($style_import['style_data']['fontcolorsec'])."', '".addslashes($style_import['style_data']['fontcolorthi'])."', '".addslashes($style_import['style_data']['fontcolorfour'])."', 
	'".addslashes($style_import['style_data']['bgcolor'])."', '".addslashes($style_import['style_data']['tablebg'])."', '".addslashes($style_import['style_data']['tablea'])."', 
	'".addslashes($style_import['style_data']['tableb'])."', '".addslashes($style_import['style_data']['tablec'])."', '".addslashes($style_import['style_data']['tabled'])."', 
	'".ifelse($style_import['logo']['filename'],addslashes($_POST['imagefolder'])."/".addslashes($style_import['logo']['filename']))."', 
	'".addslashes($style_import['style_data']['css'])."', '".ifelse($style_import['bgimage']['filename'],$_POST['imagefolder']."/".addslashes($style_import['bgimage']['filename']))."', 
	'".intval($style_import['style_data']['bgfixed'])."')");
	$newstyleid = $db_zugriff->insert_id();
	
	#$db_zugriff->query("UPDATE bb".$n."_style SET templatefolder='styles/style".$newstyleid."_templates',imagefolder='styles/style".$newstyleid."_images',imageurl='".ifelse($style_import['logo']['filename'],"styles/style_$newstyleid/images/".addslashes($style_import['logo']['filename']))."',bgimage='".ifelse($style_import['bgimage']['filename'],"styles/style_$newstyleid/images/".addslashes($style_import['bgimage']['filename']))."' WHERE styleid=$newstyleid");
	
	foreach($style_import['templates'] as $currenttemplate)
	{
		$filename = $currenttemplate['filename'];
		$content = $currenttemplate['content'];
		$fh = @fopen("../".$_POST['templatefolder']."/$filename","w");
		fwrite($fh,$content);
		fclose($fh);
		@chmod("../".$_POST['templatefolder']."/$filename",0777);
	}
	foreach($style_import['images'] as $currentimage)
	{
		$filename = $currentimage['filename'];
		$content = $currentimage['content'];
		$fh = @fopen("../".$_POST['imagefolder']."/$filename","wb");
		fwrite($fh,$content);
		fclose($fh);
		@chmod("../".$_POST['imagefolder']."/$filename",0777);
	}
	
	if($style_import['logo']['filename'])
	{
		$fh = @fopen("../".$_POST['imagefolder']."/".$style_import['logo']['filename'],"wb");
		fwrite($fh,$style_import['logo']['content']);
		fclose($fh);
		@chmod("../".$_POST['imagefolder']."/".$style_import['logo']['filename'],0777);
	}
	if($style_import['bgimage']['filename'])
	{
		$fh = @fopen("../".$_POST['imagefolder']."/".$style_import['bgimage']['filename'],"wb");
		fwrite($fh,$style_import['bgimage']['content']);
		fclose($fh);
		@chmod("../".$_POST['imagefolder']."/".$style_import['bgimage']['filename'],0777);
	}
	
	@unlink("../images/avatars/$savedstylefile");
	header("Location: admin.php?action=style_importexport&sid=$sid");
}



if($_POST['action']=="style_export")
{
	$style_info = $db_zugriff->query_first("SELECT * FROM bb".$n."_style WHERE styleid=".intval($_POST['styleid']));
	$style_data = array("stylename" => ("Export: ".$style_info['stylename']), 
										"font" => ($style_info['font']),
										"fontcolor" => ($style_info['fontcolor']),
										"fontcolorsec" => ($style_info['fontcolorsec']),
										"fontcolorthi" => ($style_info['fontcolorthi']),
										"fontcolorfour" => ($style_info['fontcolorfour']),
										"bgcolor" => ($style_info['bgcolor']),
										"tablebg" => ($style_info['tablebg']),
										"tablea" => ($style_info['tablea']),
										"tableb" => ($style_info['tableb']),
										"tablec" => ($style_info['tablec']),
										"tabled" => ($style_info['tabled']),
										"imageurl" => ($style_info['imageurl']),
										"css" => ($style_info['css']),
										"bgimage" => ($style_info['bgimage']),
										"bgfixed" => ($style_info['bgfixed']));

	$templates = array();
	if($_POST['exporttemplates']==1)
	{
		$dirh = opendir("../".$style_info['templatefolder']);
		while($templatename = readdir($dirh))
		{
			if($templatename != ".." && $templatename != "." && preg_match("/(txt|htm)$/i",$templatename))
			{
				$templates[] = array("filename" => $templatename, "content" => implode("",file("../".$style_info['templatefolder']."/".$templatename)));
			}
		}
		closedir($dirh);
	}

	$logo=array();
	$bgimage=array();
	$images = array();
	if($_POST['exportimages']==1)
	{
		if($style_info['imageurl'])
		{
			$fh = fopen ("../".$style_info['imageurl'], "rb");
			$logo = fread ($fh, filesize("../".$style_info['imageurl']));
			fclose ($fh);
			$logo = array("filename"=>basename($style_info['imageurl']), "content" => $logo);
		}
		else $logo = array("filename" => "", "content" => "");
	
		if($style_info['bgimage'])
		{
			$fh = fopen ("../".$style_info['bgimage'], "rb");
			$bgimage = fread ($fh, filesize("../".$style_info['bgimage']));
			fclose ($fh);
			$bgimage = array("filename"=>basename($style_info['bgimage']), "content" => $bgimage);
		}
		else $bgimage = array("filename" => "", "content" => "");
	
	
		$dirh = opendir("../".$style_info['imagefolder']);
		while($filename = readdir($dirh))
		{
			if($filename != ".." && $filename != ".")
			{
				$content = "";
				$fh = fopen ("../".$style_info['imagefolder']."/".$filename, "rb");
				$content = fread ($fh, filesize("../".$style_info['imagefolder']."/".$filename));
				fclose ($fh);
				$images[] = array("filename" => $filename, "content" => $content);
			}
		}
		closedir($dirh);
	}

	$style = array("style_data"=>$style_data, "logo" => $logo, "bgimage" => $bgimage, "templates"=>$templates,"images"=>$images);
	$output = base64_encode(serialize($style));

	$mime_type = "application/octet-stream";
	$content_disp = "attachment; ";
	#$mime_type = (USR_BROWSER_AGENT == 'IE' || USR_BROWSER_AGENT == 'OPERA') ? 'application/octetstream' : 'application/octet-stream';
	#$content_disp = (USR_BROWSER_AGENT == 'IE') ? 'inline; ' : 'attachment; ';
	$filename = "wbbstyle_".$_POST['styleid'].".style";

	header('Content-Type: '.$mime_type);
	header('Content-disposition: '.$content_disp.'filename='.$filename.'');
	header('Pragma: no-cache');
	header('Expires: 0');
	echo $output;
}



























if($_REQUEST['action'] == "avatar_add") {
	if($_POST['send'] == "send") {
		$conf = $db_zugriff->query_first("SELECT avatarimage_ext, avatar_width, avatar_height, avatar_size FROM bb".$n."_config");
		$mimetype = explode("\n", $conf['avatarimage_ext']);
		for($i = 0; $i < count($mimetype); $i++) $mimetype[$i] = trim($mimetype[$i]);
		$groupid = $_POST['groupid'];
		$posts = $_POST['posts'];
		$setuserid=0;
		
		require_once("Upload.class.php");
		$upload = new Upload();
		
		$upload->setAllowedMimeTypes($mimetype);	
		$upload->setUploadPath("../images/avatars");
	
		if ($upload->doUpload()) header("Location: admin.php?action=avatar_view_edit$session");
		else eval ("\$error = \"".gettemplate("error")."\";");
	}
	
	$options="";
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	while($row = $db_zugriff->fetch_array($result)) $options .= "<option value=\"$row[id]\">$row[title]</option>";
	eval("dooutput(\"".gettemplate("avatar_add")."\");");
}

if($_REQUEST['action'] == "avatar_view_edit") {
	if($_POST['send'] == "send" && $_POST['avatarid']) header("Location: admin.php?action=avatar_edit&avatarid=".$_POST['avatarid'].$session);

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid = 0");
	$anzahl = $anzahl[0];
	if(isset($_GET['page'])) $page = intval($_GET['page']);
	else $page = 1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, bb".$n."_groups.title FROM bb".$n."_avatars LEFT JOIN bb".$n."_groups ON (bb".$n."_groups.id=groupid) WHERE userid = 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	$avatar_view_editbit = "";
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row['id'].".".$row['extension'];
		$oriname = $row['name'].".".$row['extension'];
		if($row['groupid']) $groupname = $row['title'];
		else eval ("\$groupname = \"".gettemplate("lg_all")."\";");
				
		eval ("\$avatar_view_editbit .= \"".gettemplate("avatar_view_editbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_view_edit$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_view_edit$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_view_edit$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}
	else $page_link = "";

	eval("dooutput(\"".gettemplate("avatar_view_edit")."\");");
}

if($_REQUEST['action'] == "avatar_edit") {
	if($_POST['send'] == "send") $db_zugriff->query("UPDATE bb".$n."_avatars SET groupid = '".$_POST['groupid']."', posts = '".$_POST['posts']."' WHERE id = '".$_POST['avatarid']."'");
	
	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_avatars WHERE id = '".$_REQUEST['avatarid']."'");
	$avatarid=$info['id'];
	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1 ORDER BY title ASC");
	$options="";
	while($row = $db_zugriff->fetch_array($result)) {
		$options .= "<option value=\"$row[id]\"";
		if($row['id']==$info['groupid']) $options .= " selected";
		$options .= ">$row[title]</option>";
		
	}
	$imgfile = "../images/avatars/avatar-".$info['id'].".".$info['extension'];
	$oriname = $info['name'].".".$info['extension'];

	eval("dooutput(\"".gettemplate("avatar_edit")."\");");
}

if($_REQUEST['action'] == "avatar_del") {
	if($_POST['send'] == "send" && isset($_POST['avatarid']) && count($_POST['avatarid'])) {
		for($i = 0; $i < count($_POST['avatarid']); $i++) {
			$ext = $db_zugriff->query_first("SELECT extension FROM bb".$n."_avatars WHERE id = '".$_POST['avatarid'][$i]."'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = 0 WHERE avatarid = '".$_POST['avatarid'][$i]."'");
			$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '".$_POST['avatarid'][$i]."'");
			@unlink("../images/avatars/avatar-".$_POST['avatarid'][$i].".".$ext[0]);
		}
	}

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid = 0");
	$anzahl = $anzahl[0];
	if(isset($_GET['page'])) $page = intval($_GET['page']);
	else $page = 1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, bb".$n."_groups.title FROM bb".$n."_avatars LEFT JOIN bb".$n."_groups ON (bb".$n."_groups.id=groupid) WHERE userid = 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	$avatar_delbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row['id'].".".$row['extension'];
		$oriname = $row['name'].".".$row['extension'];
		if($row['groupid']) $groupname = $row['title'];
		else eval ("\$groupname = \"".gettemplate("lg_all")."\";");
				
		eval ("\$avatar_delbit .= \"".gettemplate("avatar_delbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_del$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_del$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_del$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}
	else $page_link="";

	eval("dooutput(\"".gettemplate("avatar_del")."\");");
}

if($_REQUEST['action'] == "avatar_user_del") {
	if($_POST['send'] == "send" && isset($_POST['avatarid']) && count($_POST['avatarid'])) {
		for($i = 0; $i < count($_POST['avatarid']); $i++) {
			$ext = $db_zugriff->query_first("SELECT extension FROM bb".$n."_avatars WHERE id = '".$_POST['avatarid'][$i]."'");
			$db_zugriff->query("UPDATE bb".$n."_user_table SET avatarid = 0 WHERE avatarid = '".$_POST['avatarid'][$i]."'");
			$db_zugriff->query("DELETE FROM bb".$n."_avatars WHERE id = '".$_POST['avatarid'][$i]."'");
			@unlink("../images/avatars/avatar-".$avatarid[$i].".".$ext[0]);
		}
	}

	$anzahl = $db_zugriff->query_first("SELECT COUNT(id) FROM bb".$n."_avatars WHERE userid > 0");
	$anzahl = $anzahl[0];
	if(isset($_GET['page'])) $page=intval($_GET['page']);
	else $page=1;
	
	$result = $db_zugriff->query("SELECT bb".$n."_avatars.*, username FROM bb".$n."_avatars LEFT JOIN bb".$n."_user_table ON (bb".$n."_avatars.userid=bb".$n."_user_table.userid) WHERE bb".$n."_avatars.userid > 0 ORDER BY bb".$n."_avatars.id ASC LIMIT ".(10*($page-1)).", 10");
	$pages=(int)($anzahl/10);
	if(($anzahl/10)-$pages>0) $pages++;
	$avatar_delbit="";
	while($row = $db_zugriff->fetch_array($result)) {
		
		$imgfile = "../images/avatars/avatar-".$row['id'].".".$row['extension'];
		$oriname = $row['name'].".".$row['extension'];
		eval ("\$avatar_delbit .= \"".gettemplate("avatar_user_delbit")."\";");
	}

	if($pages>1) {
		$page_link .= "[ ";
		if($page!=1) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=1\">&laquo;</a> <a href=\"admin.php?action=avatar_user_del$session&page=".($page-1)."\">�</a> ";
		if($page>=6) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page-5)."\">...</a> ";
		if($page+4>=$pages) $pagex=$pages;
		else $pagex=$page+4;
		for($i=$page-4 ; $i<=$pagex ; $i++) { 	
			if($i<=0) $i=1;
			if($i==$page) $page_link .= "<b>$i</b> ";
			else $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=$i\">$i</a> ";
		}
		if(($pages-$page)>=5) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page+5)."\">...</a> ";
		if($page!=$pages) $page_link .= "<a href=\"admin.php?action=avatar_user_del$session&page=".($page+1)."\">�</a> <a href=\"admin.php?action=avatar_user_del$session&page=".$pages."\">&raquo;</a>";
		$page_link .= " ]";
	}
	else $page_link ="";

	eval("dooutput(\"".gettemplate("avatar_user_del")."\");");
}

if($_REQUEST['action'] == "announcements_add") {
	if($_POST['send'] == "send") {
		if(!$_POST['topic'] || !$_POST['message'] || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$_POST['starttime'], $st_exp) || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$_POST['endtime'], $et_exp)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$starttime = mktime($st_exp['4'], $st_exp['5'], 0, $st_exp['2'], $st_exp['1'], $st_exp['3']);
			$endtime = mktime($et_exp['4'], $et_exp['5'], 0, $et_exp['2'], $et_exp['1'], $et_exp['3']);
			$db_zugriff->query("INSERT INTO bb".$n."_announcements (announcementid, boardid, userid, starttime,  endtime, topic, message) VALUES ('', '".$_POST['boardid']."', '$user_id', '".$starttime."', '".$endtime."', '".addslashes($_POST['topic'])."', '".addslashes($_POST['message'])."')");
			header("Location: admin.php?action=announcements_view_edit$session");
		}
	}
	$starttime = date("d-m-Y H:i");
	$endtime = date("d-m-Y H:i", time()+24*3600);
	
	$board_options="";
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE isboard = 1 ORDER BY boardname ASC");
	while($row = $db_zugriff->fetch_array($result)) $board_options .= "<option value=\"".$row['boardid']."\">".$row['boardname']."</option>\n";
	eval("dooutput(\"".gettemplate("announcements_add")."\");");
}

if($_REQUEST['action'] == "announcements_view_edit") {
	if($_POST['send'] == "send" && isset($_POST['announcementid']) && $_POST['announcementid']) header("Location: admin.php?action=announcements_edit&announcementid=".$_POST['announcementid']."$session");
	
	$announcements_view_editbit="";
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_announcements");
	while($row = $db_zugriff->fetch_array($result)) {
		$row['topic'] = ($row['topic']);
		$row['starttime'] = date("d-m-Y H:i", $row['starttime']);
		$row['endtime'] = date("d-m-Y H:i", $row['endtime']);
		eval ("\$announcements_view_editbit .= \"".gettemplate("announcements_view_editbit")."\";");
	}
	eval("dooutput(\"".gettemplate("announcements_view_edit")."\");");
}

if($_REQUEST['action'] == "announcements_edit") {
	if($_POST['send'] == "send") {
		if(!$_POST['topic'] || !$_POST['message'] || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$_POST['starttime'], $st_exp) || !ereg("^([0-9]{2})[-]([0-9]{2})[-]([0-9]{4})[[:space:]]+([0-9]{2})[:]([0-9]{2})$",$_POST['endtime'], $et_exp)) eval ("\$error = \"".gettemplate("error")."\";");
		else {
			$starttime = mktime($st_exp['4'], $st_exp['5'], 0, $st_exp['2'], $st_exp['1'], $st_exp['3']);
			$endtime = mktime($et_exp['4'], $et_exp['5'], 0, $et_exp['2'], $et_exp['1'], $et_exp['3']);
			$db_zugriff->query("UPDATE bb".$n."_announcements SET topic = '".addslashes($_POST['topic'])."', message = '".addslashes($_POST['message'])."', starttime = '$starttime', endtime = '$endtime', boardid = '".$_POST['boardid']."' WHERE announcementid = '".$_POST['announcementid']."'");
			header("Location: admin.php?action=announcements_view_edit$session");
		}
	}

	$row = $db_zugriff->query_first("SELECT * FROM bb".$n."_announcements WHERE announcementid = '".$_REQUEST['announcementid']."'");
	$starttime = date("d-m-Y H:i", $row['starttime']);
	$endtime = date("d-m-Y H:i", $row['endtime']);
	$row['topic'] = ($row['topic']);
	$row['message'] = ($row['message']);
	
	$board_options="";
	$result = $db_zugriff->query("SELECT boardid, boardname FROM bb".$n."_boards WHERE isboard = 1 ORDER BY boardname ASC");
	while($brow = $db_zugriff->fetch_array($result)) {
		if($brow['boardid']==$row['boardid']) $board_options .= "<option value=\"".$brow['boardid']."\" selected>".$brow['boardname']."</option>\n";
		else $board_options .= "<option value=\"".$brow['boardid']."\">".$brow['boardname']."</option>\n";
	}
	eval("dooutput(\"".gettemplate("announcements_edit")."\");");
}

if($_REQUEST['action'] == "announcements_del") {
	if($_POST['send'] == "send" && isset($_POST['announcementid']) && count($_POST['announcementid'])){
		for($i = 0; $i < count($_POST['announcementid']); $i++){
		$db_zugriff->query("DELETE FROM bb".$n."_announcements WHERE announcementid = '".$_POST['announcementid'][$i]."'");
		}
	}
	
	$announcements_delbit="";
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_announcements");
	while($row = $db_zugriff->fetch_array($result)) {
		$row['topic'] = ($row['topic']);
		$row['starttime'] = date("d-m-Y H:i", $row['starttime']);
		$row['endtime'] = date("d-m-Y H:i", $row['endtime']);
		eval ("\$announcements_delbit .= \"".gettemplate("announcements_delbit")."\";");
	}
	eval("dooutput(\"".gettemplate("announcements_del")."\");");
}

/*
if($_REQUEST['action'] == "smilies_add") {
	if($_POST['send'] == "send") {
		if(!$_POST['smiliespath'] || !$_POST['smiliestext'] || !@file_exists("../".$_POST['smiliespath'])) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("INSERT INTO bb".$n."_smilies (smiliespath,smiliestext,smiliestitle) VALUES ('".addslashes($_POST['smiliespath'])."', '".addslashes($_POST['smiliestext'])."', '".addslashes($_POST['smiliestitle'])."')");
		header("Location: admin.php?action=smilies_view_edit$session");
	}

	eval("dooutput(\"".gettemplate("smilies_add")."\");");
}*/
if($_REQUEST['action'] == "smilies_add")
{
	if(isset($_POST['send']) && $_POST['send'] == "send")
	{
		if(!$_POST['smiliestext'] || ($_POST['smiliessource']=="upload" && (!$_FILES['smiliesfile']['name'] || !$_FILES['smiliesfile']['tmp_name'])) || ($_POST['smiliessource']=="local" && (!$_POST['smiliespath'] || !@file_exists("../".$_POST['smiliespath'])))) die("error");
		else
		{
			if($_POST['smiliessource']=="upload")
			{
				$db_zugriff->query("INSERT INTO bb".$n."_smilies (smiliestext,smiliestitle) VALUES ('".addslashes($_POST['smiliestext'])."', '".addslashes($_POST['smiliestitle'])."')");
				$newsmiliesid = $db_zugriff->insert_id();
				move_uploaded_file($_FILES['smiliesfile']['tmp_name'],"../images/smilies/$newsmiliesid".strrchr($_FILES['smiliesfile']['name'],"."));
				$db_zugriff->query("UPDATE bb".$n."_smilies SET smiliespath='images/smilies/$newsmiliesid".strrchr($_FILES['smiliesfile']['name'],".")."' WHERE id=$newsmiliesid");
			}
			elseif($_POST['smiliessource']=="local")
			{
				$db_zugriff->query("INSERT INTO bb".$n."_smilies (smiliespath,smiliestext,smiliestitle) VALUES ('".addslashes($_POST['smiliespath'])."', '".addslashes($_POST['smiliestext'])."', '".addslashes($_POST['smiliestitle'])."')");
			}
		}
		header("Location: admin.php?action=smilies_view_edit$session");
	}
	eval("dooutput(\"".gettemplate("smilies_add")."\");");
}


if($_REQUEST['action'] == "smilies_view_edit") {
	if($_POST['send'] == "send" && isset($_POST['smilieid']) && $_POST['smilieid']) header("Location: admin.php?action=smilies_edit&smilieid=".$_POST['smilieid'].$session);
	
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies ORDER BY id ASC");
	$smilies_view_editbit="";
	while($row = $db_zugriff->fetch_array($result)) eval ("\$smilies_view_editbit .= \"".gettemplate("smilies_view_editbit")."\";");
	eval("dooutput(\"".gettemplate("smilies_view_edit")."\");");
}

if($_REQUEST['action'] == "smilies_edit") {
	if($_POST['send'] == "send") {
		if(!$_POST['smiliespath'] || !$_POST['smiliestext'] || !@file_exists("../".$_POST['smiliespath'])) eval ("\$error = \"".gettemplate("error")."\";");
		else $db_zugriff->query("UPDATE bb".$n."_smilies SET smiliespath = '".addslashes($_POST['smiliespath'])."', smiliestext = '".addslashes($_POST['smiliestext'])."', smiliestitle = '".addslashes($_POST['smiliestitle'])."' WHERE id = '".intval($_POST['smilieid'])."'");
	}

	$info = $db_zugriff->query_first("SELECT * FROM bb".$n."_smilies WHERE id = '".$_REQUEST['smilieid']."'");
	$smilieid=$info['id'];
	
	eval("dooutput(\"".gettemplate("smilies_edit")."\");");
}

if($_REQUEST['action'] == "smilies_del") {
	if($_POST['send'] == "send" && isset($_POST['smilieid']) && count($_POST['smilieid'])) {
		for($i = 0; $i < count($_POST['smilieid']); $i++) $db_zugriff->query("DELETE FROM bb".$n."_smilies WHERE id = '".$_POST['smilieid'][$i]."'");
	}
	
	$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies ORDER BY id ASC");
	$smilies_delbit="";
	while($row = $db_zugriff->fetch_array($result)) eval ("\$smilies_delbit .= \"".gettemplate("smilies_delbit")."\";");
	eval("dooutput(\"".gettemplate("smilies_del")."\");");
}

/*
if($_REQUEST['action'] == "newsletter") {
	if($_POST['send'] == "send") {
		if(!$_POST['subject'] || !$_POST['message']) eval ("\$error = \"".gettemplate("error")."\";");
		if(isset($_POST['groupid']) && $_POST['groupid'][0]) {
			for($i = 0; $i < count($_POST['groupid']); $i++) {
				if($where) $where.=" OR ";
				$where.="groupid='".$_POST['groupid'][$i]."'";
			}
		}
		$conf = $db_zugriff->query_first("SELECT master_email FROM bb".$n."_config");
		$result = $db_zugriff->query("SELECT useremail, username FROM bb".$n."_user_table WHERE mods_may_email = 1".ifelse($where," AND ($where)",""));
		while($row = $db_zugriff->fetch_array($result)) {
			$inhalt = str_replace("{username}","$row[username]", stripslashes($message));
			mail($row['useremail'],stripslashes($subject),$inhalt,"From: $conf[0]");
		}
	}

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1");
	$group_options="";
	while($row = $db_zugriff->fetch_array($result)) $group_options .= "<option value=\"$row[id]\">$row[title]</option>\n";
	eval("dooutput(\"".gettemplate("newsletter")."\");");
}
*/



if($_REQUEST['action'] == "newsletter") {
	if($_POST['send'] == "send") {
		if(!$_POST['subject'] || !$_POST['message']) eval ("\$error = \"".gettemplate("error")."\";");
		if(isset($_POST['groupid']) && $_POST['groupid'][0]) {
			for($i = 0; $i < count($_POST['groupid']); $i++) {
				if($where) $where.=" OR ";
				$where.="groupid='".$_POST['groupid'][$i]."'";
			}
		}
		header("Location: admin.php?action=newsletter_send&subject=".urlencode($_POST['subject'])."&message=".urlencode($_POST['message'])."&where=".urlencode($where)."&page=1");
	}

	$result = $db_zugriff->query("SELECT id, title FROM bb".$n."_groups WHERE default_group <> 1");
	$group_options="";
	while($row = $db_zugriff->fetch_array($result)) $group_options .= "<option value=\"$row[id]\">$row[title]</option>\n";
	eval("dooutput(\"".gettemplate("newsletter")."\");");
}

if($_GET['action']=="newsletter_send")
{
	$subject = urldecode($_GET['subject']);
	$message = urldecode($_GET['message']);
	$where = urldecode($_GET['where']);
	if(isset($_GET['page'])) $page = intval($_GET['page']);
	else $page = 1;
	$percycle = 50;
	
	eval("dooutput(\"".gettemplate("newsletter_send1")."\");");
	flush();
	
	$conf = $db_zugriff->query_first("SELECT master_email FROM bb".$n."_config");
	$result = $db_zugriff->query("SELECT useremail, username FROM bb".$n."_user_table WHERE mods_may_email = 1".ifelse($where," AND ($where)","")." LIMIT ".(($page-1)*$percycle).",$percycle");
	if($db_zugriff->num_rows($result))
	{
		while($row = $db_zugriff->fetch_array($result)) {
			$inhalt = str_replace("{username}","$row[username]", ($message));
			mail($row['useremail'],($subject),$inhalt,"From: $conf[0]");
		}
		$page++;
		$subject = urlencode($subject);
		$message = urlencode($message);
		$where = urlencode($where);
		eval("dooutput(\"".gettemplate("newsletter_send3")."\");");
		flush();
		exit;
	}
	else
	{
		eval("dooutput(\"".gettemplate("newsletter_send2")."\");");
		flush();
		exit;
	}
}

?>
