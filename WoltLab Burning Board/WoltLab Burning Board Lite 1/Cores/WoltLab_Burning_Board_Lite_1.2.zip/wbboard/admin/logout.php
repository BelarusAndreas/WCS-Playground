<?php
require "global.php"; 

$user_id = "";
$user_password = "";
wbb_session_register("user_id");
wbb_session_register("user_password");
setcookie("user_id", "");
setcookie("user_password", "");
header("LOCATION: index.php?sid=$sid");
exit;
?>