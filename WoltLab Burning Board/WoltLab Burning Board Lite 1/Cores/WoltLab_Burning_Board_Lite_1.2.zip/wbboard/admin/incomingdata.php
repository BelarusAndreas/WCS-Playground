<?php
$phpversion=(int)(str_replace(".","",phpversion())); // ge�ndert
/* Bei PHP Versionen unter 4.10 stehen die neuen Superglobals (REQUEST, POST, GET) noch nicht
zur Verf�gung und m�ssen mit den Daten aus den alten Arrays gef�llt werden. */
if($phpversion<410)
{
	$_REQUEST=array();
	$_COOKIE=array();
	$_POST=array();
	$_GET=array();
	$_SERVER=array();
	$_FILES=array();
	$_ENV=array();
	$_SESSION=array();
	get_vars_old();
}
if (get_magic_quotes_gpc()) {
  if(is_array($_REQUEST)) $_REQUEST=stripslashes_array($_REQUEST);
  if(is_array($_POST)) $_POST=stripslashes_array($_POST);
  if(is_array($_GET)) $_GET=stripslashes_array($_GET);
  if(is_array($_COOKIE)) $_COOKIE=stripslashes_array($_COOKIE);
  if(isset($_SESSION) && is_array($_SESSION)) stripslashes_array($_SESSION);
  #if(is_array($_SESSION)) $_SESSION=stripslashes_array($_SESSION);
}
@set_magic_quotes_runtime(0);
?>