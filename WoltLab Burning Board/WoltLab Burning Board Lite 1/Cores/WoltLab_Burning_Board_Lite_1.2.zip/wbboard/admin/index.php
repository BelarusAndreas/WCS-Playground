<?php
require "./global.php"; 

// ####################### Define variables ######################
if(!isset($_POST['mode'])) $_POST['mode'] = "";
if(!isset($mode)) $mode = "";

# If install.php or update.php exists die() for security reasons
checkfiles();

if($_POST['mode'] == "login") {
	$_POST['userpassword'] = md5($_POST['userpassword']);
	$check = $db_zugriff->query_first("SELECT userid FROM bb".$n."_user_table WHERE username = '".addslashes(htmlspecialchars(trim($_POST['username'])))."' AND userpassword = '".$_POST['userpassword']."'");
	if($check['userid']) {
	
		$user_id = $check['userid'];
		$user_password = $_POST['userpassword'];
		wbb_session_register("user_id");
		wbb_session_register("user_password");
		setcookie("user_id", "$user_id", time()+(3600*24*365));
		setcookie("user_password", "$user_password", time()+(3600*24*365));
		
		header("LOCATION: index.php?sid=$sid");
		exit;
	}
	else $error = "Zugriff verweigert!";
}

if(getUser_stat($user_id,$user_password)) eval("dooutput(\"".gettemplate("frameset")."\");");
else {
	eval ("\$headinclude = \"".gettemplate("headinclude")."\";");	
	eval("dooutput(\"".gettemplate("login")."\");");
}
?>