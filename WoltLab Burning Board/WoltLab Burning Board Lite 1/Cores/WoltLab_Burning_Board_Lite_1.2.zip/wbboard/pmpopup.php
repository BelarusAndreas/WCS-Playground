<?php
require "global.php";
eval ("\$headinclude = \"".gettemplate("headinclude")."\";");


if($user_id && $pms && $userdata['canusepms'])
{
	$lastpmpopup = $userdata['lastpmpopup'];

	$pms_result=$db_zugriff->query("SELECT pmid,subject,userid,username FROM bb".$n."_pms 
	LEFT JOIN bb".$n."_user_table ON (bb".$n."_user_table.userid=bb".$n."_pms.senderid) 
	WHERE recipientid=$user_id AND view=0 AND sendtime>=$lastpmpopup AND sendtime>=$old_time");
	$pm_count = $db_zugriff->num_rows($pms_result);
	// neue PNs zum anzeigen im Popup
	if($pm_count)
	{
		$showpmpopup=1;
		$pmpopup_bit="";
		while($pmbit=$db_zugriff->fetch_array($pms_result))
		{
			eval ("\$pmpopup_bit .= \"".gettemplate("pmpopup_bit")."\";");
		}
		eval("dooutput(\"".gettemplate("pmpopup")."\");");
	}
	else header("Location: pms.php?$session2");
	
	// lastpmpopup aktualisieren
	$lastpmpopup = time();
	$db_zugriff->query("UPDATE bb".$n."_user_table SET lastpmpopup='$lastpmpopup' WHERE userid='$user_id'");
}
else
{
	header("Location: misc.php?action=access_error$session");
	exit;
}
?>