<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

if(isset($_POST['postid'])) $postid = intval($_POST['postid']);
elseif(isset($_GET['postid'])) $postid = intval($_GET['postid']);
else $postid = 0;
$post = $db_zugriff->query_first("SELECT boardparentid, threadparentid, userid, message, disable_smilies, signature FROM bb".$n."_posts WHERE postid='$postid'");

if($boardid != $post['boardparentid'] || $threadid != $post['threadparentid']) {
	eval("dooutput(\"".gettemplate("hack_error")."\");");
	exit;
}


if(($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod")) || $userdata['issupermod'] || ($post['userid'] && $userdata['caneditownpost'] && $user_id == $post['userid']))
{
	if(!isset($_POST['action'])) $_POST['action']="";
	if(!isset($_POST['preview'])) $_POST['preview']="";
	if(!isset($_POST['delete'])) $_POST['delete']="";
	if($_POST['action'] == "send" && !$_POST['preview'])
	{
		if(!$_POST['delete'] && (!trim($_POST['message']) || check_posts(trim($_POST['message'])))) eval ("\$error = \"".gettemplate("newthread_error")."\";");
		else
		{
			/*
			* Beitrag l�schen ..
			*/
			if($_POST['delete'] && (($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod")) || $userdata['issupermod'] || ($post['userid'] && $userdata['candelownpost'] && $user_id == $post['userid'])))
			{
				$result = delPost($_POST['postid'],$_POST['threadid'],$_POST['boardid']);
				if($result==1)
				{
					eval ("\$output = \"".gettemplate("note15")."\";");
					$ride = "thread.php?boardid=$boardid&styleid=$styleid&threadid=$threadid$session";
				}
				if($result==2)
				{
					eval ("\$output = \"".gettemplate("note16")."\";");
					$ride = "board.php?boardid=$boardid&styleid=$styleid$session";
				}
			}
			
			/*
			* Beitrag speichern.
			*/
        	else
			{
				$thread_info = $db_zugriff->query_first("SELECT flags FROM bb".$n."_threads WHERE threadid='$threadid'");
				if($thread_info['flags']) eval ("\$output = \"".gettemplate("note17")."\";");
                else
				{
					if(isset($_POST['appendnote']) && $_POST['appendnote'])
					{
						$time = time();
						$editorid = $user_id;
					}
					else
					{
						$time=0;
						$editorid=0;
					}
					
					$message = $_POST['message'];
					if(isset($_POST['previewed']) && $_POST['previewed']) $message = rehtmlspecialchars($message);
					if(isset($_POST['parseurl']) && $_POST['parseurl']) $message = parseURL($message);
					if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $disablesmilies = intval($_POST['disablesmilies']);
					else $disablesmilies = 0;
					$db_zugriff->query("UPDATE bb".$n."_posts SET edittime='$time', editorid = '$editorid', message='".addslashes($message)."', disable_smilies='".$disablesmilies."' WHERE postid='".$_POST['postid']."'");
					if(isset($_POST['appendnote']) && $_POST['appendnote']) $db_zugriff->query("UPDATE bb".$n."_threads SET timelastreply='$time' WHERE threadid='$threadid'");
					eval ("\$output = \"".gettemplate("note8")."\";");
				}
			}

        	if(!isset($ride) || !$ride)
			{
				$post_result = $db_zugriff->query("SELECT postid FROM bb".$n."_posts WHERE threadparentid='$post[threadparentid]' ORDER by posttime ".ifelse($postorder,"DESC","ASC"));
				$i=1;
				while($row = $db_zugriff->fetch_array($post_result))
				{
					if($postid == $row['postid']) break;
					$i++;
				}
				$db_zugriff->free_result($post_result);
				$pages=(int)($i/$eproseite);
				if(($i/$eproseite)-$pages>0) $pages++;
				$ride = "thread.php?threadid=$post[threadparentid]&boardid=$post[boardparentid]&styleid=$styleid$session&page=".$pages."#".$i;
			}

			header("Location: $ride");
			exit;
		}
	}

	if(!isset($preview)) $preview="";
	if(!isset($previewed)) $previewed = 0;
	if(!isset($error)) $error="";
	if(!isset($note)) $note="";
	$checked=array("","","","");
	
	if($_POST['preview'] || $error)
	{
		$previewed = 1;
		$edit = htmlspecialchars($_POST['message']);
		$message = $_POST['message'];
		if($_POST['preview'] && !$error)
		{
			if(isset($_POST['disablesmilies'])) $disablesmilies=intval($_POST['disablesmilies']);
			else $disablesmilies=0;
			if(isset($_POST['posticon']) && $_POST['posticon']) $pre_posticon = "<img src=\"".$_POST['posticon']."\">";
			else $pre_posticon = "&nbsp;";
			if($user_id && $userdata['signatur'] && $post['signature'] && !$hide_signature)
			{
				$signatur = editSignatur($userdata['signatur'],$disablesmilies);
				eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
			}
			else $pre_signature="";
			$post = editPost($_POST['message'],$disablesmilies);
			$subject="";
			eval ("\$preview = \"".gettemplate("preview")."\";");
		}

		if(isset($_POST['parseurl']) && $_POST['parseurl']) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if(isset($_POST['delete']) && $_POST['delete']) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if(isset($_POST['appendnote']) && $_POST['appendnote']) $checked[3] = "CHECKED";
		else $checked[3] = "";
	}
	else
	{
		$edit = htmlspecialchars($post['message']);
		if($ch_parseurl) $checked[0] = "CHECKED";
		if($post['disable_smilies']) $checked[1] = "CHECKED";
	}

	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);

	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

	$navi_chain = makenavichain("edit",$boardid,$threadid);

	if(($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod")) || $userdata['issupermod'] || ($post['userid'] && $userdata['candelownpost'] && $user_id == $post['userid'])) eval ("\$edit_del = \"".gettemplate("edit_del")."\";");
	else $edit_del="";
	if(!$userdata['appendeditnote']) eval ("\$edit_appendnote = \"".gettemplate("edit_appendnote")."\";");
	else $edit_appendnote = "<input type=\"hidden\" value=\"1\" name=\"appendnote\">";
	eval("dooutput(\"".gettemplate("edit")."\");");
}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>
