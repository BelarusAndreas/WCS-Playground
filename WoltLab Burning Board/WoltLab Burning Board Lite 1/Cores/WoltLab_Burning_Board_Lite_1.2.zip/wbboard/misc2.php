<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

if(!isset($_GET['action'])) $_GET['action']="";
if(!isset($_POST['action'])) $_POST['action']="";

if($_GET['action'] == "ip") {
	if(isset($_GET['page'])) $page=intval($_GET['page']);
	else $page=1;
	$post = $db_zugriff->query_first("SELECT boardparentid, userid, ip FROM bb".$n."_posts WHERE postid='".$_GET['postid']."'");
	if($userdata['canuseacp'] || $userdata['issupermod'] || ($userdata['ismod'] && check_boardobject($boardid,$user_id,"mod"))) {
		$author = getUsername($post['userid']);
		eval("dooutput(\"".gettemplate("show_ip")."\");");
	}
	else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
}

if($_GET['action'] == "report") {
	if(isset($_GET['postid'])) $postid=intval($_GET['postid']);
	else $postid=0;
	if(isset($_GET['page'])) $page=intval($_GET['page']);
	else $page=1;
	if(!$user_id) header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
	else {
		if($session) $session_post = "<input type=\"hidden\" name=\"sid\" value=\"$sid\">";
		eval("dooutput(\"".gettemplate("report")."\");");
	}
}

if($_GET['action'] == "smilies") {

	$result = $db_zugriff->query("SELECT * FROM bb".$n."_smilies");
	$help_smiliebit = "";
	while($row = $db_zugriff->fetch_array($result)) eval ("\$help_smiliebit .= \"".gettemplate("help_smiliebit")."\";");
	eval("dooutput(\"".gettemplate("help_smilies")."\");");
}

if($_GET['action'] == "showrank") {
	$rank = $db_zugriff->query_first("SELECT bb".$n."_ranks.*, bb".$n."_groups.title as groupname FROM bb".$n."_ranks, bb".$n."_groups WHERE bb".$n."_ranks.groupid = bb".$n."_groups.id AND bb".$n."_ranks.id='$id'");
		$grafik = "";
		$grafik = str_repeat("<img src=\"".$rank['grafik']."\">",$rank['mal']);
		$status = $rank['groupname'];
		$rankname = $rank['rank'];
	eval("dooutput(\"".gettemplate("show_rank")."\");");
}

if($_GET['action'] == "faq") {
	if(isset($_GET['page'])) $page=intval($_GET['page']);
	else $page=0;
	if(!$page) eval("dooutput(\"".gettemplate("faq")."\");");
	if($page==1) {
		$rankbit = "";
		$result = $db_zugriff->query("SELECT bb".$n."_ranks.*, bb".$n."_groups.title as groupname FROM bb".$n."_ranks, bb".$n."_groups WHERE bb".$n."_ranks.groupid = bb".$n."_groups.id ORDER by bb".$n."_ranks.groupid DESC, bb".$n."_ranks.posts ASC");
		while($row = $db_zugriff->fetch_array($result)) {
			$backcolor = rowcolor($j++);
			unset($grafik);
			$grafik = str_repeat("<img src=\"".$row['grafik']."\">",$row['mal']);
			$rank = $row['rank'];
			$status = $row['groupname'];
			eval ("\$rankbit .= \"".gettemplate("faq_rankbit")."\";");
		}
		eval("dooutput(\"".gettemplate("faq_page1")."\");");
	}
	if($page==2) eval("dooutput(\"".gettemplate("faq_page2")."\");");
	if($page==3) eval("dooutput(\"".gettemplate("faq_page3")."\");");
}

if($_GET['action'] == "forgotpw" || $_POST['action'] == "forgotpw") {
	if(isset($_POST['send']) && $_POST['send'] == "send") {
		$result = $db_zugriff->query_first("SELECT userid, username, userpassword, useremail FROM bb".$n."_user_table WHERE username = '".addslashes(htmlspecialchars(trim($_POST['username'])))."'");
		if(!$result['userid']) {
			eval ("\$output = \"".gettemplate("error1")."\";");
			eval("dooutput(\"".gettemplate("action_error")."\");");
			exit;
		}
		eval ("\$betreff = \"".gettemplate("forgotpw_betreff1","txt")."\";");
		eval ("\$inhalt = \"".gettemplate("forgotpw_mail1","txt")."\";");
		mail($result['useremail'],$betreff,$inhalt,"From: $master_email");

		header("Location: main.php$session2");
		exit;
	}

	$action = "forgotpw";
	eval("dooutput(\"".gettemplate("forgotpw")."\");");
}
?>

