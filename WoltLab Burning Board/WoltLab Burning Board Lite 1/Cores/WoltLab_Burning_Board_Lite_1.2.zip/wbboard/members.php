<?php
require("global.php");
require("_header.php");
require("_board_jump.php");

/*
* Initialisieren von $mode, wobei POST vorrang hat.
*/
if(isset($_POST['mode'])) $mode = $_POST['mode'];
elseif(isset($_GET['mode'])) $mode = $_GET['mode'];



/*
* Mitgliederliste ansehen
*/
if($mode == "view")
{
	$uproseite = 30;
	$anzahl = $db_zugriff->query_first("SELECT COUNT(userid)as anzahl FROM bb".$n."_user_table WHERE activation='1'");
	$anzahl = $anzahl['anzahl'];
	
	if(isset($_GET['page'])) $page=intval($_GET['page']);
	else $page = 1;
	if(isset($_GET['by'])) $by = $_GET['by'];
	else $by = "userposts";
	if(isset($_GET['order'])) $order = $_GET['order'];
	else $order = "DESC";
	switch($by)
	{
		case "username"; break;
		case "regdate": break;
		default: $by = "userposts"; break;
	}
	switch($order)
	{
		case "ASC"; break;
		default: $order = "DESC"; break;
	}

	$user_result = $db_zugriff->query("SELECT * FROM bb".$n."_user_table WHERE activation='1' ORDER by ".$by." ".$order." LIMIT ".($uproseite*($page-1)).",".$uproseite);
	$pages=ceil($anzahl/$uproseite);
	$members_view_memberbit="";
	while($users = $db_zugriff->fetch_array($user_result))
	{
		if($users['users_may_email']) eval ("\$email = \"".gettemplate("members_view_email")."\";");
		else $email = "&nbsp;";

		if($users['userhp'])
		{
			$users['userhp']=htmlspecialchars($users['userhp']);
			eval ("\$userhp = \"".gettemplate("members_view_hp")."\";");
		}
		else $userhp = "&nbsp;";

		if(intval($users['usericq']))
		{
			$users['usericq']=htmlspecialchars(intval($users['usericq']));
			eval ("\$icq = \"".gettemplate("members_view_icq")."\";");
		}
		else $icq = "&nbsp;";

		if($users['aim'])
		{
			$users['aim']=htmlspecialchars($users['aim']);
			eval ("\$aim = \"".gettemplate("members_view_aim")."\";");
		}
		else $aim = "&nbsp;";

		if($users['yim'])
		{
			$users['yim']=htmlspecialchars($users['yim']);
			eval ("\$yim = \"".gettemplate("members_view_yim")."\";");
		}
		else $yim = "&nbsp;";

		$regdate = formatdate($users['regdate'],$shortdateformat);
		eval ("\$members_view_memberbit .= \"".gettemplate("members_view_memberbit")."\";");
	}

	if($pages>1) $page_link = makepagelink("members.php?mode=view&boardid=$boardid&styleid=$styleid&by=$by&order=$order$session", $page, $pages);
	else $page_link = "";
	eval("dooutput(\"".gettemplate("members_view")."\");");
}







/*
* Profil eines Benutzers ansehen
*/
elseif($mode=="profile")
{
	$user_info = $db_zugriff->query_first("SELECT users.*, avatars.extension FROM bb".$n."_user_table users LEFT JOIN bb".$n."_avatars avatars ON (avatars.id=users.avatarid) WHERE users.userid='$userid'");
	if(!$user_info['userid'])
	{
		eval ("\$output = \"".gettemplate("error3")."\";");
		eval("dooutput(\"".gettemplate("action_error")."\");");
		exit;
	}
	
	$regdate = formatdate($user_info['regdate'],$shortdateformat);

	$dabeiseit = (time() - $user_info['regdate']) / 86400;
	if ($dabeiseit < 1) $beitragprotag = $user_info['userposts'];
	else $beitragprotag = sprintf("%.2f",($user_info['userposts'] / $dabeiseit));

	if($user_info['usertext']) $user_text = prepare_topic($user_info['usertext']);
	else $user_text = "";
	
	if($user_info['gender'])
	{
		if($user_info['gender']==1) eval ("\$gender = \"".gettemplate("profile_male")."\";");
		else eval ("\$gender  = \"".gettemplate("profile_female")."\";");
	}
	else eval ("\$gender = \"".gettemplate("profile_nodeclaration")."\";");

	$rank = $db_zugriff->query_first("SELECT * FROM bb".$n."_ranks WHERE groupid = '".$user_info['groupid']."' AND posts<='".$user_info['userposts']."' ORDER by posts DESC");
	#for($i = 0; $i<$rank[mal]; $i++) $stars .= "<img src=\"$rank[grafik]\" border=\"0\">";
	$stars =  "<a href=\"javascript:rank($rank[id])\" title=\"Informationen zum Rang $rank[rank]\">".str_repeat("<img src=\"".$rank['grafik']."\" border=\"0\">",$rank['mal'])."</a>";;

	if($user_info['statusextra']) $user_rang = htmlspecialchars($user_info['statusextra']);
	else $user_rang = $rank['rank'];
	if($user_info['avatarid'] && !$hide_userpic && $avatars) $userpic = "<br><img src=\"images/avatars/avatar-".$user_info['avatarid'].".".$user_info['extension']."\" border=0>";
	else $userpic="";

	if($user_info['show_email_global']) $useremail = "<a href=\"mailto:".$user_info['useremail']."\" class=\"link\">".htmlspecialchars($user_info['useremail'])."</a>";
	else eval ("\$useremail = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['users_may_email'])
	{
		$posts = $user_info;
		eval ("\$email = \"".gettemplate("thread_email")."\";");
	}
	else $email ="";
	
	if($pms)
	{
		$posts = $user_info;
		eval ("\$pn = \"".gettemplate("thread_pm")."\";");
	}
	else $pn = "";
	
	if($user_info['userhp']) $userhp = "<a class=\"link\" href=\"".htmlspecialchars($user_info['userhp'])."\" target=\"_blank\">".htmlspecialchars($user_info['userhp'])."</a>";
	else eval ("\$userhp = \"".gettemplate("profile_nodeclaration")."\";");

	if(intval($user_info['usericq'])) $usericq = htmlspecialchars(intval($user_info['usericq']));
	else eval ("\$usericq = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['aim']) $aim = htmlspecialchars($user_info['aim']);
	else eval ("\$aim = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['yim']) $yim = htmlspecialchars($user_info['yim']);
	else eval ("\$yim = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['location']) $location = htmlspecialchars($user_info['location']);
	else  eval ("\$location = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['work']) $work = htmlspecialchars($user_info['work']);
	else  eval ("\$work = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['interests']) $interests = htmlspecialchars($user_info['interests']);
	else  eval ("\$interests = \"".gettemplate("profile_nodeclaration")."\";");

	if($user_info['age_m'] && $user_info['age_d'] && $user_info['age_y']) $birthday = $user_info['age_d'].". ".$user_info['age_m']." ".$user_info['age_y'];
	else eval ("\$birthday = \"".gettemplate("profile_nodeclaration")."\";");
	eval("dooutput(\"".gettemplate("members_profile")."\");");
}
?>

