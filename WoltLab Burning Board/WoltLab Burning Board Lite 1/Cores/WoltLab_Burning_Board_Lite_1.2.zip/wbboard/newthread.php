<?php
require("global.php");
require("_header.php");
include("posticons.php");


if(!isset($_POST['action'])) $_POST['action']="";
if(!isset($_POST['preview'])) $_POST['preview']="";
if(!isset($_POST['p_fields'])) $_POST['p_fields']=0;
if(!isset($_POST['pfield'])) $_POST['pfield']=array();

if($userdata['canstarttopic'] && check_boardobject($boardid,$user_group,"startpermission"))
{
	if($_POST['action'] == "send" && check_posts(trim($_POST['message']))) eval ("\$error = \"".gettemplate("newthread_error")."\";");
	if($_POST['action'] == "send" && !$_POST['preview'] && (!isset($_POST['post_poll']) || !$_POST['post_poll']))
	{
		// Eingabefehler => Cancel
		if(!trim($_POST['subject']) || !trim($_POST['message'])  || $_POST['p_fields'] != count($_POST['pfield']) || ($_POST['p_fields'] && !$_POST['ptitle']) || check_posts($_POST['message'])) {
			if($_POST['p_fields'])
			{
				$previewed = 1;
				$_POST['post_poll'] = 1;
				#$post_poll = 1;
				$poll_fields = $_POST['p_fields'];
			}
			eval ("\$error = \"".gettemplate("newthread_error")."\";");
		}
		
		// korrekte Eingabe => weitermachen
		else
		{
			// Floodcontrol => Cancel
			if($user_id && !$userdata['avoidfc'] && floodcontrol($user_id))
			{
				require("_board_jump.php");
				eval("dooutput(\"".gettemplate("floodcontrol")."\");");
				exit;
			}
			
			// speichern vorbereiten
			$time = time();
			$subject = $_POST['subject'];
			$message = $_POST['message'];
			if($_POST['previewed'])
			{
				$subject = rehtmlspecialchars($subject);
				$message = rehtmlspecialchars($message);
			}
			$subject = addslashes($subject);
			$message = addslashes($message);
        	if(isset($_POST['parse_url']) && $_POST['parseurl']) $message = parseURL($message);
        	if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']==1) $disablesmilies=1;
			else $disablesmilies=0;
       		if(isset($_POST['signature']) && $_POST['signature']==1) $signature=1;
			else $signature=0;
			if(isset($_POST['posticon']))
			{
				$posticon = $_POST['posticon'];
				if(!in_array($posticon,$posticons)) $posticon="";
			}
			else $posticon="";
			
			// Speichern
			$db_zugriff->query("UPDATE bb".$n."_user_table SET userposts=userposts+1 WHERE userid='$user_id'");
			$db_zugriff->query("INSERT INTO bb".$n."_threads (boardparentid,threadname,starttime,authorid,author,lastposterid,timelastreply,topicicon) VALUES ('$boardid','$subject','$time','$user_id','".addslashes(($user_name))."','$user_id','$time','".addslashes($posticon)."')");
			$nr = $db_zugriff->insert_id();
			if((isset($_POST['email']) && $_POST['email']) && $user_id) $db_zugriff->query("INSERT INTO bb".$n."_notify (threadid,userid) VALUES ($nr,$user_id)");
			$db_zugriff->query("INSERT INTO bb".$n."_posts (boardparentid,threadparentid,userid,posttime,posttopic,message,posticon,disable_smilies,signature,ip) VALUES ('$boardid','$nr','$user_id','$time','$subject','$message','$posticon','$disablesmilies','$signature','$REMOTE_ADDR')");
			$postid = $db_zugriff->insert_id();
			$db_zugriff->query("UPDATE bb".$n."_boards SET threads=threads+1, posts=posts+1, lastposttime = '$time', lastpostid = '$postid' WHERE boardid = '$boardid'");
			
			// Umfrage
			if($_POST['p_fields'])
			{
				$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion = '".addslashes(rehtmlspecialchars($_POST['ptitle']))."', ptimeout = '".(int)($_POST['poll_timeout'])."' WHERE threadid = '$nr'");
				#for($i = 0; $i < $_POST['p_fields']; $i++) $db_zugriff->query("INSERT INTO bb".$n."_poll (id,threadid,field,votes) VALUES ('','$nr','".addslashes($pfield[$i])."','0')");
				$vote_sql = "";
				for($i = 0; $i < $_POST['p_fields']; $i++) $vote_sql .= ",('','$nr','".addslashes(rehtmlspecialchars($_POST['pfield'][$i]))."','0')";
				$db_zugriff->query("INSERT INTO bb".$n."_poll (id,threadid,field,votes) VALUES ".substr($vote_sql,1));
			}

			$ride = getLastPost($user_id,4);
			header("Location: $ride");
			exit;
		}
	}// Speichern ende ... 
	
	
	
	//preview + form
	if(!isset($poll)) $poll="";
	if(!isset($preview)) $preview="";
	if(!isset($previewed)) $previewed = 0;
	if(!isset($error)) $error="";
	
	$checked=array("","","","");
	if($ch_parseurl) $checked[0] = "CHECKED";
	if($ch_email) $checked[1] = "CHECKED";
	if($ch_disablesmilies) $checked[2] = "CHECKED";
	if($ch_signature) $checked[3] = "CHECKED";

	if(isset($_POST['subject'])) $subject = htmlspecialchars($_POST['subject']);
	else $subject = "";
	if(isset($_POST['message'])) $message = htmlspecialchars($_POST['message']);
	else $message = "";
	
	// Umfrage vorbereiten
	if(isset($_POST['post_poll']) && $_POST['post_poll'])
	{
		$previewed = 1;
        if(isset($_POST['parseurl']) && $_POST['parseurl']) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if(isset($_POST['email']) && $_POST['email']) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if(isset($_POST['signature']) && $_POST['signature']) $checked[3] = "CHECKED";
		else $checked[3] = "";

		$poll_fields = $_POST['poll_fields'];
		$fields="";
		$ptitle="";
		for($i = 0; $i < $_POST['poll_fields']; $i++)
		{
			$j = $i+1;
			if(isset($_POST['pfield'][$i])) $wert = htmlspecialchars($_POST['pfield'][$i]);
			else $wert="";
			eval ("\$fields .= \"".gettemplate("newthread_pollbit")."\";");
		}
		eval ("\$poll .= \"".gettemplate("newthread_poll")."\";");
	}

	


	
	// Vorschau 
	if($_POST['preview'] || $error)
	{
		$previewed = 1;
		if($_POST['preview'] && !$error)
		{
			$disablesmilies=1;
			if(!isset($_POST['disablesmilies'])) $disablesmilies=0;
			if(isset($_POST['posticon']) && $_POST['posticon']) $pre_posticon = "<img src=\"".$_POST['posticon']."\">";
	        else $pre_posticon = "&nbsp;";
	        if(($user_id && $userdata['signatur']) && (isset($_POST['signature']) && $_POST['signature']) && !$hide_signature)
			{
	         	$signatur = editPost($userdata['signatur'],$disablesmilies);
				eval ("\$pre_signature = \"".gettemplate("thread_signature")."\";");
			}
			else $pre_signature="";
		    $post = editPost($_POST['message'],$disablesmilies);
	        eval ("\$preview = \"".gettemplate("preview")."\";");
        }
    
        if(isset($_POST['parseurl']) && $_POST['parseurl']) $checked[0] = "CHECKED";
		else $checked[0] = "";
		if(isset($_POST['email']) && $_POST['email']) $checked[1] = "CHECKED";
		else $checked[1] = "";
		if(isset($_POST['disablesmilies']) && $_POST['disablesmilies']) $checked[2] = "CHECKED";
		else $checked[2] = "";
		if(isset($_POST['signature']) && $_POST['signature']) $checked[3] = "CHECKED";
		else $checked[3] = "";

		if(isset($_POST['p_fields']) && $_POST['p_fields'])
		{
			$ptitle = htmlspecialchars($_POST['ptitle']);
			$fields="";
			for($i = 0; $i < $_POST['p_fields']; $i++)
			{
				$j = $i+1;
				if(isset($_POST['pfield'][$i])) $wert = htmlspecialchars($_POST['pfield'][$i]);
				else $wert="";
				eval ("\$fields .= \"".gettemplate("newthread_pollbit")."\";");
			}
			$poll_fields = $_POST['p_fields'];
			eval ("\$poll = \"".gettemplate("newthread_poll")."\";");
			eval ("\$poll_check = \"".gettemplate("newthread_pollcheck")."\";");
			$_POST['post_poll'] = 1;
			$post_poll = 1;
		}
	}

	
	
	if($bbcode && $u_bbcode) $bbcode_buttons = getcodebuttons();
	if($smilies && $u_bbcode) $bbcode_smilies = getclickysmilies(3,$anzahl_smilies);

	$note="";
	if($html) eval ("\$note .= \"".gettemplate("newthread_html_enable")."\";");
	else eval ("\$note .= \"".gettemplate("newthread_html_disable")."\";");
	if(!$smilies) eval ("\$note .= \"".gettemplate("newthread_smilies_disable")."\";");
	if(!$bbcode) eval ("\$note .= \"".gettemplate("newthread_bbcode_disable")."\";");

	$choice_posticons="";
	for($i = 0; $i < count($posticons); $i++) {
		if(is_int($i/6) && $i) $choice_posticons .= "<br>";
		elseif($i) $choice_posticons .= "&nbsp;&nbsp;&nbsp;&nbsp;";
		$choice_posticons .= "<INPUT type=\"radio\" name=\"posticon\" value=\"$posticons[$i]\"";
		if(isset($_POST['posticon']) && $_POST['posticon'] == $posticons[$i]) $choice_posticons .= " CHECKED";
		$choice_posticons .= ">&nbsp;&nbsp;<img src=\"$posticons[$i]\">";
	}
	if(!isset($_POST['posticon']) || !$_POST['posticon']) $noicon[0] = "CHECKED";
	else $noicon[0]="";

	$navi_chain = makenavichain("newthread",$boardid);
	if((!isset($_POST['post_poll']) || !$_POST['post_poll']) && $polls && $userdata['canpostpoll']) eval ("\$poll .= \"".gettemplate("newthread_startpoll")."\";");


	
	if($user_id) eval ("\$quick_logout = \"".gettemplate("newthread_logout")."\";");
	else $quick_logout="";
	eval("dooutput(\"".gettemplate("newthread")."\");");

}
else header("LOCATION: misc.php?action=access_error&boardid=$boardid&styleid=$styleid$session");
?>
