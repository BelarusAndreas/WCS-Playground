<?php
# requirements
require "./_functions.php";
require "./admin/incomingdata.php";
require "./admin/class_db_zugriff.php";
require "./admin/_data.inc.php";

if(!isset($_POST['send'])) $_POST['send']="";

if(isset($_POST['step'])) $step = intval($_POST['step']);
elseif(isset($_GET['step'])) $step = intval($_GET['step']);
else $step=0;
if(isset($_POST['mode'])) $mode = intval($_POST['mode']);
elseif(isset($_GET['mode'])) $mode = intval($_GET['mode']);
else $mode=0;

# set permissions (Only work on *nix when the webserver runs as the same user like the script)
@chmod("./admin/_data.inc.php", 0777);
@chmod("./images/avatars/", 0777);
@chmod("./images/smilies/", 0777);

# define the tables

$tables = array(
"bb".$n."_announcements",
"bb".$n."_avatars",
"bb".$n."_bbcode",
"bb".$n."_boards",
"bb".$n."_config",
"bb".$n."_folders",
"bb".$n."_groups",
"bb".$n."_notify",
"bb".$n."_object2board",
"bb".$n."_object2user",
"bb".$n."_pms",
"bb".$n."_pmsend",
"bb".$n."_poll",
"bb".$n."_posts",
"bb".$n."_ranks",
"bb".$n."_smilies",
"bb".$n."_style",
"bb".$n."_threads",
"bb".$n."_user_table",
"bb".$n."_useronline",
"bb".$n."_vote"
); 



# Startpage
if($mode==0)
{
?>
<html>
<head>
<title>Woltlab Burning Board 1.2 - Installation</title>
<link rel='stylesheet' href='other.css'>
</head>
<body>
<form method='post' action='install.php'>
<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Herzlich Willkommen bei der Installation des WoltLab Burning Board 1.2</b></td></tr>
<tr bgcolor='white'><td>Systemvoraussetzungen:</td></tr>
<tr bgcolor='white' align='center'><td><table border='0' width='100%'>
<tr><td><u>Vorraussetzung</u></td><td><u>erforderlich<u></td><td><u>vorhanden<u></td></tr>
<tr><td>PHP Version</td><td>4.0.1</td>
<td><?php
$phpver = phpversion();
echo "<font color='".($phpver>"4.0.1" ? "green" : "red")."'>".$phpver."</font>";
?></td>
</tr>
<!--<tr><td>safe_mode deaktiviert</td><td>Ja</td>
<td><?php
$mode = ini_get("safe_mode");
echo "<font color='".($mode!="1" ? "green" : "red")."'>".($mode!="1" ? "Ja" : "Nein")."</font>";
?></td>
</tr>-->
<tr><td>upload_max_filesize</td><td>< 0</td>
<td><?php
$size = ini_get("upload_max_filesize");
echo "<font color='".($size>"0" ? "green" : "red")."'>".$size."</font>";
?></td>
</tr>
<tr><td>Schreibrechte auf "admin/_data.inc.php"</td><td>Ja</td>
<td><?php
echo "<font color='".(is_writeable("./admin/_data.inc.php") ? "green" : "red")."'>".(is_writeable("./admin/_data.inc.php") ? "Ja" : "Nein")."</font>";
?></td></tr>
<tr><td>Schreibrechte in "images/avatars"</td><td>Ja</td>
<td>
<?php
echo "<font color='".(is_writeable("./images/avatars") ? "green" : "red")."'>".(is_writeable("./images/avatars") ? "Ja" : "Nein")."</font>";
?>
</td></tr>
<tr><td>Schreibrechte in "images/smilies"</td><td>Ja</td>
<td>
<?php
echo "<font color='".(is_writeable("./images/smilies") ? "green" : "red")."'>".(is_writeable("./images/smilies") ? "Ja" : "Nein")."</font>";
?></td></tr>
</table></td></tr>
<tr bgcolor='white' align='center'><td><i>Sollten eine oder mehrere Voraussetzungen nicht erf�llt sein,<BR> kann ein einwandfreier Betrieb des Forum nicht gew�hrleistet werden.</i></td></tr>
<tr bgcolor='white' align='center'><td>
<select name='mode'>
<option value='0' SELECTED>Bitte w�hlen Sie die Einrichtungsart:</option>
<option value='1'>Neuinstallation</option>
<option value='2'>Update von wBB 1.1.1</option>
</select>&nbsp;&nbsp;
<input type='hidden' name='step' value='1'>
<input type='submit' value='Fortsetzen'></td></tr>
</table>
</form>
</body>
</html>
<?php
}


# new installation
elseif($mode==1)
{

	# First step of the installation, new installation
	if($step == "1"){
	
	?>
		<html>
		<head>
		<title>Woltlab Burning Board 1.2 - Installation</title>
		<link rel='stylesheet' href='other.css'>
		</head>
		<body>
		<form method='post' action='install.php'>
		<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
		<tr bgcolor='#314477'><td colspan='2'><font size='2' color='white' face='Tahoma'><b>� Einstellen der Datenbankzugriffsdaten:</b></td></tr>
		<tr bgcolor='white'><td>Adresse des Datenbankservers:</td><td align='center'>
		<input type='text' name='dburl' value='<?php echo $mysqlhost; ?>'>
		</td></tr> 
		<tr bgcolor='white'><td>Datenbank-Benutzername:</td><td align='center'>
		<input type='text' name='dbuser' value='<?php echo $mysqluser; ?>'>
		</td></tr>  
		<tr bgcolor='white'><td>Datenbank-Benutzerpasswort:</td><td align='center'>
		<input type='text' name='dbpw' value='<?php echo $mysqlpassword; ?>'>
		</td></tr>  
		<tr bgcolor='white'><td>Datenbankname:</td><td align='center'>
		<input type='text' name='dbname' value='<?php echo $mysqldb; ?>'>
		</td></tr>  
		<tr bgcolor='white'><td>Nummer des Forums:</td><td align='center'>
		<input type='text' name='dbforumnr' value='<?php echo $n; ?>'>
		</td></tr>  
		<tr bgcolor='white'><td>eMail des technischen Administators:</td><td align='center'>
		<input type='text' name='dbtechmail' value='<?php echo $adminmail; ?>'>
		</td></tr>
		<tr bgcolor='white' align='center'><td colspan='2'>
		<input type='submit' value='Speichern'>&nbsp;
		<input type='reset' value='Zur&uuml;cksetzen'>
		<input type='hidden' name='step' value='2'>
		<input type='hidden' name='mode' value='1'>
		</td>
		</tr>
		<tr bgcolor='white' align='center'><td colspan='2'>
		Falls Sie bereits die Datei "./admin/_data.inc.php" von Hand konfiguriert haben,<BR> k�nnen Sie diesen Schritt �berspringen. Klicken Sie daf�r bitte <a href='./install.php?step=3'>hier<a>. 
		</td></tr>
		</table>
		</form>
		</body>
		</html>
<?php
	#exit();
	}

	# second step
	elseif($step == 2){
		$connid = @mysql_connect($_POST['dburl'], $_POST['dbuser'], $_POST['dbpw']);
		if(!$connid) die("Die von Ihnen eingegebenen Daten sind nicht korrekt, bitte klicken Sie <a href='javascript:history.back()'>hier</a> um sie zu korrigieren!");
		mysql_close($connid);
		$fp = fopen("./admin/_data.inc.php", "w+");
		fwrite($fp, "<?php
// Hostname oder IP des MySQL-Servers
\$mysqlhost = \"".str_replace("\"","\\\\\"",$_POST['dburl'])."\";
// Username und Passwort zum einloggen in den Datenbankserver
\$mysqluser = \"".str_replace("\"","\\\\\"",$_POST['dbuser'])."\";
\$mysqlpassword = \"".str_replace("\"","\\\\\"",$_POST['dbpw'])."\";
// Name der Datenbank
\$mysqldb = \"".str_replace("\"","\\\\\"",$_POST['dbname'])."\";
// Nummer des Boards
\$n = \"".str_replace("\"","\\\\\"",$_POST['dbforumnr'])."\";
// Email des Admins
\$adminmail = \"".str_replace("\"","\\\\\"",$_POST['dbtechmail'])."\";
?>");
		fclose($fp);
		#header("Location: install.php?mode=1&step=3");
		nextstep();

	}

	# third step
	elseif($step==3)
	{
		
		$db_zugriff = new db_zugriff;
		
		$db_zugriff->appname="WoltLab Burning Board";
		$db_zugriff->database=$mysqldb;
		$db_zugriff->server=$mysqlhost;
		$db_zugriff->user=$mysqluser;
		$db_zugriff->password=$mysqlpassword;
		
		$db_zugriff->connect();
	
		$result = mysql_list_tables($mysqldb);
		$check=0;
		for($i=0;$i<mysql_num_rows($result);$i++){
			if(in_Array(mysql_tablename($result,$i),$tables)){
				$check="1";
				break;
			}
		}
		if(!$check){
			#header("Location: install.php?step=4");
			nextstep();
		}
		else
		{
		?>
		<html>
		<head>
		<title>Woltlab Burning Board 1.2 - Installation</title>
		<link rel='stylesheet' href='other.css'>
		</head>
		<body>
		<form method='post' action='install.php'>
		<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
		<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� <font color='red'>Hinweis!</font></b></td></tr>
		<tr bgcolor='white'><td>Die Datenbank ist nicht leer! Es wurde festgestellt das sich bereits Tabellen des wBB's mit dieser Forennummer in der Datenbank befinden. Bitte w�hlen Sie das weitere Vorgehen.</td></tr> 
		<tr bgcolor='white' align='center'><td>
		<select name='step'>
		<option value='3' SELECTED>Bitte w�hlen Sie eine Vorgehensweise:</option>
		<option value='4'>Fortfahren, Tabellen �berschreiben</option>
		<option value='5'>Fortfahren, Tabellen nicht �berschreiben</option>
		<option value='1'>Abbrechen, andere Forennummer w�hlen</option>
		</select>&nbsp;&nbsp;
		<input type='hidden' name='mode' value='1'>
		<input type='submit' value='Ausf�hren'>&nbsp;
		</td>
		</tr>
		</table>
		</form>
		</body>
		</html>
		<?php
		exit();	
		}
	}
	
	
	# fourth step
	elseif($step==4)
	{
		$db_zugriff = new db_zugriff;
		
		$db_zugriff->appname="WoltLab Burning Board";
		$db_zugriff->database=$mysqldb;
		$db_zugriff->server=$mysqlhost;
		$db_zugriff->user=$mysqluser;
		$db_zugriff->password=$mysqlpassword;

		$db_zugriff->connect();
		$result = mysql_list_tables($mysqldb);
		for($i=0;$i<mysql_num_rows($result);$i++){
			if(in_Array(mysql_tablename($result,$i),$tables)){
				$db_zugriff->query("DROP TABLE ".mysql_tablename($result, $i));
			}
		}
	?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Tabellen werden erstellt...</b></td></tr>
	<tr bgcolor='white'><td>
<?php
	$db_zugriff->query("CREATE TABLE bb".$n."_announcements (
  announcementid mediumint(8) unsigned NOT NULL auto_increment,
  boardid mediumint(8) unsigned NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  endtime int(11) NOT NULL default '0',
  topic varchar(70) NOT NULL default '',
  message mediumtext NOT NULL,
  PRIMARY KEY  (announcementid)
) TYPE=MyISAM;");
	echo "bb".$n."_announcements Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_avatars (
  id mediumint(8) unsigned NOT NULL auto_increment,
  name varchar(250) NOT NULL default '',
  extension varchar(7) NOT NULL default '',
  groupid smallint(5) unsigned NOT NULL default '0',
  posts mediumint(8) unsigned NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY userid (userid)
) TYPE=MyISAM;");
	echo "bb".$n."_avatars Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_bbcode (
  id smallint(5) unsigned NOT NULL auto_increment,
  bbcodetag varchar(250) NOT NULL default '',
  bbcodereplace varchar(250) NOT NULL default '',
  params tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (id)
) TYPE=MyISAM;");
	echo "bb".$n."_bbcode Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_boards (
  boardid mediumint(8) unsigned NOT NULL auto_increment,
  boardparentid mediumint(8) unsigned NOT NULL default '0',
  boardname varchar(70) NOT NULL default '',
  boardpassword varchar(25) NOT NULL default '',
  descriptiontext text NOT NULL,
  threads int(10) unsigned NOT NULL default '0',
  posts int(10) unsigned NOT NULL default '0',
  lastposttime int(10) unsigned NOT NULL default '0',
  lastpostid int(10) unsigned NOT NULL default '0',
  sort mediumint(8) unsigned NOT NULL default '0',
  isboard tinyint(1) NOT NULL default '0',
  invisible tinyint(1) NOT NULL default '0',
  style_set smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (boardid),
  KEY boardparentid (boardparentid)
) TYPE=MyISAM;");
	echo "bb".$n."_boards Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_config (
  php_path varchar(200) NOT NULL default '',
  master_board_name varchar(50) NOT NULL default '',
  master_email varchar(70) NOT NULL default '',
  html tinyint(1) NOT NULL default '0',
  smilies tinyint(1) NOT NULL default '0',
  bbcode tinyint(1) NOT NULL default '0',
  maximage tinyint(3) unsigned NOT NULL default '0',
  polls tinyint(1) NOT NULL default '0',
  image tinyint(1) NOT NULL default '0',
  image_ext text NOT NULL,
  tproseite tinyint(2) unsigned NOT NULL default '0',
  eproseite tinyint(2) unsigned NOT NULL default '0',
  timeoffset tinyint(2) NOT NULL default '0',
  rekord smallint(5) unsigned NOT NULL default '0',
  rekordtime int(10) unsigned NOT NULL default '0',
  timeout tinyint(3) unsigned NOT NULL default '0',
  useronlinelastemptied int(10) unsigned NOT NULL default '0',
  default_daysprune smallint(4) unsigned NOT NULL default '0',
  hotthread_reply tinyint(3) unsigned NOT NULL default '0',
  hotthread_view tinyint(3) unsigned NOT NULL default '0',
  show_subboards tinyint(1) NOT NULL default '0',
  anzahl_smilies tinyint(3) unsigned NOT NULL default '0',
  cover char(1) NOT NULL default '',
  badwords text NOT NULL,
  ch_parseurl tinyint(1) NOT NULL default '0',
  ch_email tinyint(1) NOT NULL default '0',
  ch_disablesmilies tinyint(1) NOT NULL default '0',
  ch_signature tinyint(1) NOT NULL default '0',
  boardoff tinyint(1) NOT NULL default '0',
  boardoff_text text NOT NULL,
  regdateformat varchar(30) NOT NULL default '',
  shortdateformat varchar(30) NOT NULL default '',
  longdateformat varchar(30) NOT NULL default '',
  today varchar(30) NOT NULL default '',
  timetype tinyint(1) NOT NULL default '0',
  postorder tinyint(1) NOT NULL default '0',
  register tinyint(1) NOT NULL default '0',
  act_code tinyint(1) NOT NULL default '0',
  act_permail tinyint(1) NOT NULL default '0',
  regnotify tinyint(1) NOT NULL default '0',
  multi_email tinyint(1) NOT NULL default '0',
  banname text NOT NULL,
  banemail text NOT NULL,
  sigsmilies tinyint(1) NOT NULL default '0',
  sigbbcode tinyint(1) NOT NULL default '0',
  sightml tinyint(1) NOT NULL default '0',
  sigimage tinyint(1) NOT NULL default '0',
  sigmaximage tinyint(3) unsigned NOT NULL default '0',
  sigimage_ext text NOT NULL,
  siglength smallint(5) unsigned NOT NULL default '0',
  avatars tinyint(1) NOT NULL default '0',
  avatarimage_ext text NOT NULL,
  avatar_width tinyint(3) unsigned NOT NULL default '0',
  avatar_height tinyint(3) unsigned NOT NULL default '0',
  avatar_size mediumint(8) unsigned NOT NULL default '0',
  usertextlength smallint(5) unsigned NOT NULL default '0',
  favboards smallint(5) unsigned NOT NULL default '0',
  favthreads smallint(5) unsigned NOT NULL default '0',
  pms tinyint(1) NOT NULL default '0',
  maxpms smallint(5) unsigned NOT NULL default '0',
  maxfolder smallint(5) unsigned NOT NULL default '0',
  forumid varchar(32) NOT NULL default ''
) TYPE=MyISAM;");
	echo "bb".$n."_config Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_folders (
  folderid mediumint(8) unsigned NOT NULL auto_increment,
  userid int(10) unsigned NOT NULL default '0',
  foldername varchar(100) NOT NULL default '',
  PRIMARY KEY  (folderid)
) TYPE=MyISAM;");
	echo "bb".$n."_folders Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_groups (
  id smallint(5) unsigned NOT NULL auto_increment,
  title varchar(30) NOT NULL default '',
  canviewboard tinyint(1) NOT NULL default '0',
  canviewoffboard tinyint(1) NOT NULL default '0',
  canusesearch tinyint(1) NOT NULL default '0',
  canusepms tinyint(1) NOT NULL default '0',
  canstarttopic tinyint(1) NOT NULL default '0',
  canreplyowntopic tinyint(1) NOT NULL default '0',
  canreplytopic tinyint(1) NOT NULL default '0',
  caneditownpost tinyint(1) NOT NULL default '0',
  candelownpost tinyint(1) NOT NULL default '0',
  cancloseowntopic tinyint(1) NOT NULL default '0',
  candelowntopic tinyint(1) NOT NULL default '0',
  canpostpoll tinyint(1) NOT NULL default '0',
  canvotepoll tinyint(1) NOT NULL default '0',
  canuploadavatar tinyint(1) NOT NULL default '0',
  appendeditnote tinyint(1) NOT NULL default '0',
  avoidfc tinyint(1) NOT NULL default '0',
  ismod tinyint(1) NOT NULL default '0',
  issupermod tinyint(1) NOT NULL default '0',
  canuseacp tinyint(1) NOT NULL default '0',
  default_group tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY default_group (default_group)
) TYPE=MyISAM;");
	echo "bb".$n."_groups Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_notify (
  threadid int(10) unsigned NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0'
) TYPE=MyISAM;");
	echo "bb".$n."_notify Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_object2board (
  boardid mediumint(8) unsigned NOT NULL default '0',
  objectid int(10) unsigned NOT NULL default '0',
  mod tinyint(1) NOT NULL default '0',
  boardpermission tinyint(1) NOT NULL default '0',
  startpermission tinyint(1) NOT NULL default '0',
  replypermission tinyint(1) NOT NULL default '0',
  KEY boardid (boardid)
) TYPE=MyISAM;");
	echo "bb".$n."_object2board Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_object2user (
  userid int(10) unsigned NOT NULL default '0',
  objectid int(10) unsigned NOT NULL default '0',
  favboards tinyint(1) NOT NULL default '0',
  favthreads tinyint(1) NOT NULL default '0',
  buddylist tinyint(1) NOT NULL default '0',
  ignorelist tinyint(1) NOT NULL default '0',
  pmsend tinyint(1) NOT NULL default '0'
) TYPE=MyISAM;");
	echo "bb".$n."_object2user Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_pms (
  senderid int(10) unsigned NOT NULL default '0',
  recipientid int(10) unsigned NOT NULL default '0',
  pmid int(10) unsigned NOT NULL auto_increment,
  folderid mediumint(8) unsigned NOT NULL default '0',
  view tinyint(1) NOT NULL default '0',
  reply tinyint(1) NOT NULL default '0',
  forward tinyint(1) NOT NULL default '0',
  sendtime int(10) unsigned NOT NULL default '0',
  subject varchar(70) NOT NULL default '',
  message text NOT NULL,
  icon varchar(200) NOT NULL default '',
  disable_smilies tinyint(1) NOT NULL default '0',
  signature tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (pmid),
  KEY recipientid (recipientid)
) TYPE=MyISAM;");
	echo "bb".$n."_pms Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_pmsend (
  userid int(10) unsigned NOT NULL default '0',
  recipientid int(10) unsigned NOT NULL default '0',
  pmparentid int(10) unsigned NOT NULL default '0',
  pmid int(10) unsigned NOT NULL auto_increment,
  sendtime int(10) unsigned NOT NULL default '0',
  subject varchar(70) NOT NULL default '',
  message text NOT NULL,
  icon varchar(200) NOT NULL default '',
  disable_smilies tinyint(1) NOT NULL default '0',
  signature tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (pmid)
) TYPE=MyISAM;");
	echo "bb".$n."_pmsend Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_poll (
  id int(10) unsigned NOT NULL auto_increment,
  threadid int(10) unsigned NOT NULL default '0',
  field varchar(200) NOT NULL default '',
  votes mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY threadid (threadid)
) TYPE=MyISAM;");
	echo "bb".$n."_poll Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_posts (
  boardparentid mediumint(8) unsigned NOT NULL default '0',
  threadparentid int(10) unsigned NOT NULL default '0',
  postid int(10) unsigned NOT NULL auto_increment,
  userid int(10) unsigned NOT NULL default '0',
  posttime int(10) unsigned NOT NULL default '0',
  edittime int(10) unsigned NOT NULL default '0',
  editorid int(10) unsigned NOT NULL default '0',
  posttopic varchar(70) NOT NULL default '',
  message mediumtext NOT NULL,
  posticon varchar(200) NOT NULL default '0',
  disable_smilies tinyint(1) NOT NULL default '0',
  signature tinyint(1) NOT NULL default '0',
  ip varchar(15) NOT NULL default '',
  PRIMARY KEY  (postid),
  KEY boardparentid (boardparentid,threadparentid),
  KEY userid (userid)
) TYPE=MyISAM;");
	echo "bb".$n."_posts Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_ranks (
  id mediumint(8) unsigned NOT NULL auto_increment,
  groupid smallint(5) unsigned NOT NULL default '1',
  posts mediumint(8) unsigned NOT NULL default '0',
  rank varchar(30) NOT NULL default '',
  grafik varchar(250) NOT NULL default '',
  mal tinyint(2) unsigned NOT NULL default '1',
  PRIMARY KEY  (id)
) TYPE=MyISAM;");
	echo "bb".$n."_ranks Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_smilies (
  id smallint(5) unsigned NOT NULL auto_increment,
  smiliespath varchar(255) NOT NULL default '',
  smiliestext varchar(50) NOT NULL default '',
  smiliestitle varchar(50) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;");
	echo "bb".$n."_smilies Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_style (
  styleid smallint(5) unsigned NOT NULL auto_increment,
  stylename varchar(50) NOT NULL default '',
  templatefolder varchar(200) NOT NULL default '',
  imagefolder varchar(200) NOT NULL default '',
  font varchar(100) NOT NULL default '',
  fontcolor varchar(7) NOT NULL default '',
  fontcolorsec varchar(7) NOT NULL default '',
  fontcolorthi varchar(7) NOT NULL default '',
  fontcolorfour varchar(7) NOT NULL default '',
  bgcolor varchar(7) NOT NULL default '',
  tablebg varchar(7) NOT NULL default '',
  tablea varchar(7) NOT NULL default '',
  tableb varchar(7) NOT NULL default '',
  tablec varchar(7) NOT NULL default '',
  tabled varchar(7) NOT NULL default '',
  imageurl varchar(250) NOT NULL default '',
  css text NOT NULL,
  bgimage varchar(250) NOT NULL default '',
  bgfixed tinyint(1) NOT NULL default '0',
  default_style tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (styleid)
) TYPE=MyISAM;");
	echo "bb".$n."_style Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_threads (
  boardparentid mediumint(8) unsigned NOT NULL default '0',
  starttime int(10) unsigned NOT NULL default '0',
  threadid int(10) unsigned NOT NULL auto_increment,
  threadname varchar(70) NOT NULL default '',
  authorid int(10) unsigned NOT NULL default '0',
  author varchar(50) NOT NULL default '',
  lastposterid int(10) unsigned NOT NULL default '0',
  replies mediumint(8) unsigned NOT NULL default '0',
  views mediumint(8) unsigned NOT NULL default '0',
  timelastreply int(10) unsigned NOT NULL default '0',
  flags tinyint(1) NOT NULL default '0',
  topicicon varchar(200) NOT NULL default '',
  rate_points mediumint(8) unsigned NOT NULL default '0',
  rated smallint(5) unsigned NOT NULL default '0',
  putoffid mediumint(8) unsigned NOT NULL default '0',
  important tinyint(1) NOT NULL default '0',
  pquestion varchar(250) NOT NULL default '',
  ptimeout int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (threadid),
  KEY boardparentid (boardparentid)
) TYPE=MyISAM;");
	echo "bb".$n."_threads Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_user_table (
  userid int(10) unsigned NOT NULL auto_increment,
  username varchar(50) NOT NULL default '',
  userpassword varchar(32) NOT NULL default '',
  useremail varchar(150) NOT NULL default '',
  regemail varchar(150) NOT NULL default '',
  userposts mediumint(8) unsigned NOT NULL default '0',
  groupid smallint(5) unsigned NOT NULL default '0',
  statusextra varchar(50) default NULL,
  regdate int(10) unsigned NOT NULL default '0',
  lastvisit int(10) unsigned NOT NULL default '0',
  lastactivity int(10) unsigned NOT NULL default '0',
  session_link tinyint(1) NOT NULL default '0',
  signatur text NOT NULL,
  usericq varchar(30) NOT NULL default '',
  aim varchar(30) NOT NULL default '',
  yim varchar(30) NOT NULL default '',
  userhp varchar(200) NOT NULL default '',
  age_m varchar(10) NOT NULL default '',
  age_d tinyint(2) unsigned NOT NULL default '0',
  age_y smallint(4) unsigned NOT NULL default '0',
  avatarid mediumint(8) unsigned NOT NULL default '0',
  interests varchar(250) NOT NULL default '',
  location varchar(250) NOT NULL default '',
  work varchar(250) NOT NULL default '',
  gender tinyint(1) NOT NULL default '0',
  usertext text NOT NULL,
  show_email_global tinyint(1) NOT NULL default '0',
  mods_may_email tinyint(1) NOT NULL default '1',
  users_may_email tinyint(1) NOT NULL default '1',
  invisible tinyint(1) NOT NULL default '0',
  hide_signature tinyint(1) NOT NULL default '0',
  hide_userpic tinyint(1) NOT NULL default '0',
  prunedays smallint(4) unsigned NOT NULL default '0',
  umaxposts tinyint(2) unsigned NOT NULL default '0',
  bbcode tinyint(1) NOT NULL default '1',
  lastpmpopup int(10) unsigned NOT NULL default '0',
  style_set smallint(5) unsigned NOT NULL default '0',
  activation int(10) unsigned NOT NULL default '0',
  blocked tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (userid),
  KEY username (username),
  KEY groupid (groupid),
  KEY avatarid (avatarid)
) TYPE=MyISAM;");
	echo "bb".$n."_user_table Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_useronline (
  sid varchar(32) NOT NULL default '',
  zeit int(10) unsigned NOT NULL default '0',
  ip varchar(15) NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (sid)
) TYPE=MyISAM;");
	echo "bb".$n."_useronline Tabelle erstellt<br>";
	
	$db_zugriff->query("CREATE TABLE bb".$n."_vote (
  threadid int(10) unsigned NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0'
) TYPE=MyISAM;");
	echo "bb".$n."_vote Tabelle erstellt<br>";
	
	// useronline Tabelle als HEAP
	list($version) = $db_zugriff->query_first("SELECT VERSION()");
	if(preg_match("/^(3\.23)|(4\.)/", $version)) $db_zugriff->query("ALTER TABLE bb".$n."_useronline TYPE=HEAP",1);
	?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Tabellen wurden erfolgreich erstellt! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='5'>
	<input type='hidden' name='mode' value='1'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
	<?php
		exit();
	}

	#fifth step
	elseif($step==5)
	{
		$db_zugriff = new db_zugriff;
	
		$db_zugriff->appname="WoltLab Burning Board";
		$db_zugriff->database=$mysqldb;
		$db_zugriff->server=$mysqlhost;
		$db_zugriff->user=$mysqluser;
		$db_zugriff->password=$mysqlpassword;
	
		$db_zugriff->connect();
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '1', 'b', '<b>\\\\1</b>', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '2', 'i', '<i>\\\\1</i>', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '3', 'email', '<a href=\"mailto:\\\\1\">\\\\1</a>', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '4', 'email', '<a href=\"mailto:\\\\2\">\\\\3</a>', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '5', 'size', '<font size=\"\\\\2\">\\\\3</font>', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '6', 'quote', '<blockquote><font size=1>Zitat:</font><hr>\\\\1<hr></blockquote>', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '7', 'u', '<u>\\\\1</u>', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '8', 'color', '<font color=\"\\\\2\">\\\\3</font>', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '9', 'font', '<font face=\"\\\\2\">\\\\3</font>', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '10', 'align', '<div align=\"\\\\2\">\\\\3</div>', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_bbcode VALUES ( '11', 'mark', '<span style=\"background-color: \\\\2\">\\\\3</span>', '2');");
		
		$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '1', 'Administratoren', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '0');");
		$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '2', 'Moderatoren', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '0', '0', '0');");
		$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '3', 'User', '1', '0', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1', '0', '1', '0', '0', '0', '0', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '4', 'G�ste', '1', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_groups VALUES ( '5', 'Super Moderatoren', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '1', '1', '0', '0');");
		
		#$db_zugriff->query("INSERT INTO bb".$n."_style VALUES ( '1', 'Standard', 'templates', 'images/style', 'Tahoma, Helvetica, Verdana, Arial, sans-serif', '#000000', '#FEC254', '#000000', '#444444', '#808080', '#000000', '#646464', '#EFEFEF', '#DEDEDE', '#646464', 'images/bblogo.gif', 'BODY { SCROLLBAR-BASE-COLOR: #646464; SCROLLBAR-ARROW-COLOR: #FEC254; } SELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } TEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #CFCFCF } #bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; } #bg A:hover { COLOR: #000000; TEXT-DECORATION: none; } #cat A:link, #cat A:visited, #cat A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #cat A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; } #title A:link, #title A:visited, #title A:active { COLOR: #FEC254; TEXT-DECORATION: none; } #title A:hover { COLOR: #FEC254; TEXT-DECORATION: underline; }  ', '', '1', '1');");
		#$db_zugriff->query("INSERT INTO bb".$n."_style VALUES ( '1', 'Standard', 'templates', 'images/style', 'Tahoma, Helvetica, Verdana, Arial, sans-serif', '#000000', '#000000', '#000000', '#000000', '#F5F5F5', '#7C8C9E', '#FFFFFF', '#F5F5F5', '#E6EAEE', '#B8C4D1', 'images/style/bblogo.gif', 'BODY { SCROLLBAR-BASE-COLOR: #B8C4D1; SCROLLBAR-ARROW-COLOR: #F5F5F5; }\r\n\r\nSELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\nTEXTAREA, .input { FONT-SIZE: 11px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\n\r\n#bg A:link, #bg A:visited, #bg A:active { COLOR: #495665; TEXT-DECORATION: underline; }\r\n#bg A:hover { COLOR: #000000; TEXT-DECORATION: none; } \r\n\r\n#cat A:link, #cat A:visited, #cat A:active { COLOR: #FFFFFF; TEXT-DECORATION: none; }\r\n#cat A:hover { COLOR: #FFFFFF; TEXT-DECORATION: underline; }\r\n\r\n#title A:link, #title A:visited, #title A:active { COLOR: #000000; TEXT-DECORATION: none; }\r\n#title A:hover { COLOR: #697B8F; TEXT-DECORATION: underline; }\r\n\r\n\r\n\r\n#title font {\r\nfont-size: 11px;}\r\n#tableb font {\r\nfont-size: 11px; }\r\n#tablea font {\r\nfont-size: 11px;}\r\nfont {\r\nfont-size: 11px;}', '', 0, 1)");
		#$db_zugriff->query("INSERT INTO bb".$n."_style VALUES ('1', 'Standard', 'templates', 'images/style', 'Tahoma, Helvetica, Verdana, Arial, sans-serif', '#000000', '#FFFFFF', '#000000', '#000000', '#004671', '#0B6295', '#0B6295', '#f5f5f5', '#EDEDED', '#3F92D9', '', 'BODY { SCROLLBAR-BASE-COLOR: #0B6295; SCROLLBAR-ARROW-COLOR: #FFFFFF; }\r\n\r\nSELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\nTEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\n\r\n#bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; }\r\n#bg A:hover { COLOR: #1E436D; TEXT-DECORATION: none; } \r\n\r\n#cat A:link, #cat A:visited, #cat A:active { COLOR: #FFFFFF; TEXT-DECORATION: none; }\r\n#cat A:hover { COLOR: #FFFFFF; TEXT-DECORATION: underline; }\r\n\r\n#title A:link, #title A:visited, #title A:active { COLOR: #FFFFFF; TEXT-DECORATION: none; }\r\n#title A:hover { COLOR: #000000; TEXT-DECORATION: underline; }\r\n\r\n\r\n\r\ntable.out {\r\n width: 100%;\r\n border: 1px dotted #FFFFFF;\r\n background-color: #037BB6;\r\n padding: 10px;\r\n background-attachment: fixed;\r\n background-image: url({imagefolder}/background.gif);\r\n background-repeat: no-repeat;\r\n background-position: 0px 0px;\r\n}\r\n\r\n', '', '0', '1')");
		$db_zugriff->query("INSERT INTO bb".$n."_style VALUES (1, 'Standard', 'templates', 'images/style', 'Tahoma, Helvetica, Verdana, Arial, sans-serif', '#000000', '#FFFFFF', '#000000', '#000000', '#004671', '#0B6295', '#0B6295', '#f5f5f5', '#EDEDED', '#3F92D9', 'images/style/background.gif', 'BODY { SCROLLBAR-BASE-COLOR: #0B6295; SCROLLBAR-ARROW-COLOR: #FFFFFF; }\r\n\r\nSELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\nTEXTAREA, .input { FONT-SIZE: 12px; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR: #000000; BACKGROUND-COLOR: #F5F5F5}\r\n\r\n#bg A:link, #bg A:visited, #bg A:active { COLOR: #000000; TEXT-DECORATION: underline; }\r\n#bg A:hover { COLOR: #1E436D; TEXT-DECORATION: none; } \r\n\r\n#cat A:link, #cat A:visited, #cat A:active { COLOR: #FFFFFF; TEXT-DECORATION: none; }\r\n#cat A:hover { COLOR: #FFFFFF; TEXT-DECORATION: underline; }\r\n\r\n#title A:link, #title A:visited, #title A:active { COLOR: #FFFFFF; TEXT-DECORATION: none; }\r\n#title A:hover { COLOR: #000000; TEXT-DECORATION: underline; }\r\n\r\n\r\n\r\ntable.out {\r\nwidth: 100%;\r\nborder: 1px dotted #FFFFFF;\r\nbackground-color: #037BB6;\r\npadding: 10px;\r\nbackground-attachment: fixed;\r\nbackground-repeat: no-repeat;\r\nbackground-position: 0px 0px;\r\n}', '', 0, 1)");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '1', '1', '0', 'Administrator', 'images/star3.gif', '6');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '2', '2', '0', 'Moderator', 'images/star3.gif', '4');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '3', '3', '0', 'Gr�nschnabel', 'images/star.gif', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '4', '3', '10', 'Jungspunt', 'images/star.gif', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '5', '3', '25', 'Mitglied', 'images/star.gif', '3');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '6', '3', '50', 'Eroberer', 'images/star.gif', '4');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '7', '3', '75', 'Foren As', 'images/star.gif', '5');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '8', '3', '100', 'Doppel-As', 'images/star2.gif', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '9', '3', '150', 'Tripel-As', 'images/star2.gif', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '10', '3', '250', 'Routinier', 'images/star2.gif', '3');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '11', '3', '500', 'Haudegen', 'images/star2.gif', '4');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '12', '3', '750', 'K�nig', 'images/star2.gif', '5');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '13', '3', '1000', 'Kaiser', 'images/star3.gif', '1');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '14', '3', '1500', 'Lebende Foren Legende', 'images/star3.gif', '2');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '15', '3', '2000', 'Foren Gott', 'images/star3.gif', '3');");
		$db_zugriff->query("INSERT INTO bb".$n."_ranks VALUES ( '16', '5', '0', 'Super Moderator', 'images/star3.gif', '5');");
		
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '2', 'images/smilies/biggrin.gif', ':D', 'gro�es Grinsen')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '3', 'images/smilies/redface.gif', ':O', 'rotes Gesicht')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '4', 'images/smilies/confused.gif', '?(', 'verwirrt')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '5', 'images/smilies/cool.gif', '8)', 'cool')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '6', 'images/smilies/crying.gif', ';(', 'traurig')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '7', 'images/smilies/eek.gif', '8o', 'geschockt')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '8', 'images/smilies/pleased.gif', ':]', 'Freude')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '9', 'images/smilies/frown.gif', ':(', 'ungl�cklich')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '10', 'images/smilies/happy.gif', ':))', 'fr�hlich')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '11', 'images/smilies/mad.gif', 'X(', 'b�se')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '12', 'images/smilies/smile.gif', ':)', 'smile')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '13', 'images/smilies/tongue.gif', ':P', 'Zunge raus')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '14', 'images/smilies/wink.gif', ';)', 'Augenzwinkern')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '15', 'images/smilies/rolleyes.gif', ':rolleyes:', 'Augen rollen')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '16', 'images/smilies/baby.gif', ':baby:', 'Baby')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '17', 'images/smilies/evil.gif', ':evil:', 'Teufel')");
		$db_zugriff->query("INSERT INTO bb".$n."_smilies VALUES ( '18', 'images/smilies/tongue2.gif', ':tongue:', 'Zunge raus')");
		
		$db_zugriff->query("INSERT INTO bb".$n."_config VALUES ( 'http://www.ihredomain.de/wbboard', 'Burning Board', 'email@ihredomain.de', '0', '1', '1', '10', '1', '1', 'gif
jpeg
jpg
', '30', '20', '0', '0', '".time()."', '5','', '1000', '15', '150', '1', '15', '*', '{boeseswort=guteswort}', '1', '0', '0', '1', '0', '', 'MN YYYY', 'DD.MM.YYYY', 'DD.MM.YYYY, HH:II', 'DD.MM.YYYY=<b>Heute</b>', '0', '0', '1', '1', '1', '0', '0', '', '', '1', '1', '0', '1', '1', 'gif
jpeg
jpg', '300', '1', 'jpg
gif
jpeg', '90', '90', '10000', '50', '5', '20', '1', '100', '5','".md5(uniqid(microtime()))."')");
		#header("Location: install.php?step=6");
		#exit();
		nextstep();
	}

	# sixth step
	elseif($step==6)
	{
		$error ="";
		if(!isset($_POST['username'])) $_POST['username']="";
		if(!isset($_POST['useremail'])) $_POST['useremail']="";
		if(!isset($_POST['userpassword'])) $_POST['userpassword']="";
		if($_POST['send'] == "send"){
			if(!$_POST['username'] || !$_POST['useremail'] || !$_POST['userpassword']){
				$error = "<tr bgcolor='white' align='center'><td colspan='2'><font color='red'><b>Es wurden nicht alle Felder ausgef�llt!</b></font></td></tr>";
			}else{
				$db_zugriff = new db_zugriff;
	
				$db_zugriff->appname="WoltLab Burning Board";
				$db_zugriff->database=$mysqldb;
				$db_zugriff->server=$mysqlhost;
				$db_zugriff->user=$mysqluser;
				$db_zugriff->password=$mysqlpassword;
	
				$db_zugriff->connect();
				$time = time();
				$db_zugriff->query("INSERT INTO bb".$n."_user_table (username,userpassword,useremail,regemail,groupid,regdate,lastvisit,lastactivity,activation) VALUES ('".addslashes(htmlspecialchars($_POST['username']))."','".md5($_POST['userpassword'])."','".$_POST['useremail']."','".$_POST['useremail']."','1','$time','$time','$time','1')");
				#header("Location: install.php?step=7");
				#exit;
				nextstep();
			}
		}
	?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td colspan='2'><font size='2' color='white' face='Tahoma'><b>� Registrierung des Administrators</b></td></tr>
	<tr bgcolor='white'><td>
	<table border='0' width='100%' align='center'>
	<tr bgcolor='white' align='center'>
	<td>
	<?php
	if($_POST['send'] == "send" AND !$_POST['username']){
		echo "<b>Name:</b>";
	}else{
		echo "Name:";
	}
	?>
	</td>
	<td><input name="username" value="<?php echo $_POST['username']; ?>" maxlength=30></td>
	</tr>
	<tr bgcolor='white' align='center'>
	<td>
	<?php
	if($_POST['send'] == "send" AND !$_POST['useremail']){
		echo "<b>eMail:</b>";
	}else{
		echo "eMail:";
	}
	?>
	</td>
	<td><input name="useremail" value="<?php echo $_POST['useremail']; ?>" maxlength=150></td>
	</tr>
	<tr bgcolor='white' align='center'>
	<td>
	<?php
	if($_POST['send'] == "send" AND !$_POST['userpassword']){
		echo "<b>Passwort:</b>";
	}else{
		echo "Passwort:";
	}
	?>
	</td>
	<td><input name="userpassword" value="<?php echo $_POST['userpassword']; ?>" maxlength=20></td>
	</tr>
	</table>
	</td></tr>
	<?php echo $error; ?>
	<tr bgcolor='white' align='center'><td colspan='2'>
	<input type='hidden' name='send' value='send'>
	<input type='hidden' name='step' value='6'>
	<input type='hidden' name='mode' value='1'>
	<input type='submit' value='Speichern'>&nbsp;
	<input type='reset' value='Zur&uuml;cksetzen'>
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
	<?php
		exit();
	}

	# seventh step (last step)
	elseif($step==7)
	{
	?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Herzlichen Gl�ckwunsch</b></td></tr>
	<tr bgcolor='white'><td><b>Die Einrichtung wurde erfolgreich abgeschlossen.</b><BR>Bitte l�schen Sie die "install.php", um sich gegen ein sp�teres �berschreiben Ihres Forums zu sch�tzen.
	</td></tr>    
	<tr bgcolor='white' align='center'><td>
	Klicken Sie <a href="./admin/index.php">hier</a>, um ins Admin Control Panel zu gelangen 
	</td>
	</tr>
	</table>
	</body>
	</html>
	<?php
		exit();
	}
}

// Update von wbb".$n.".1.1
elseif($mode==2)
{
	$db_zugriff = new db_zugriff;
	
	$db_zugriff->appname="WoltLab Burning Board";
	$db_zugriff->database=$mysqldb;
	$db_zugriff->server=$mysqlhost;
	$db_zugriff->user=$mysqluser;
	$db_zugriff->password=$mysqlpassword;
	
	$db_zugriff->connect();

	// Step 1, DB-Struktur updaten ..
	if($step==1)
	{
		?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Tabellen werden aktualisiert...</b></td></tr>
	<tr bgcolor='white'><td>		
		<?php
		$db_zugriff->query("ALTER TABLE bb".$n."_announcements 
		CHANGE announcementid announcementid mediumint(8) unsigned not null auto_increment, 
		CHANGE boardid boardid mediumint(8) unsigned default '0' not null, 
		CHANGE userid userid int(10) unsigned default '0' not null, 
		CHANGE starttime starttime int(10) unsigned default '0' not null, 
		CHANGE message message mediumtext not null");
		echo "bb".$n."_announcements Tabelle aktualisiert<br>";
		
		$db_zugriff->query("ALTER TABLE bb".$n."_avatars  
		CHANGE id id mediumint(8) unsigned not null auto_increment, 
		CHANGE groupid groupid smallint(5) unsigned default '0' not null, 
		CHANGE posts posts mediumint(8) unsigned default '0' not null, 
		CHANGE userid userid int(10) unsigned default '0' not null");
		echo "bb".$n."_avatars Tabelle aktualisiert<br>";
		
		$db_zugriff->query("ALTER TABLE bb".$n."_bbcode  
		CHANGE id id smallint(5) unsigned not null auto_increment, 
		CHANGE params params tinyint(1) unsigned default '0' not null");
		echo "bb".$n."_bbcode Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_boards 
		CHANGE boardid boardid mediumint(8) unsigned not null auto_increment, 
		CHANGE boardparentid boardparentid mediumint(8) unsigned default '0' not null, 
		CHANGE threads threads int(10) unsigned default '0' not null, 
		CHANGE posts posts int(10) unsigned default '0' not null, 
		CHANGE lastposttime lastposttime int(10) unsigned default '0' not null, 
		CHANGE lastpostid lastpostid int(10) unsigned default '0' not null, 
		CHANGE sort sort mediumint(8) unsigned default '0' not null, 
		CHANGE isboard isboard tinyint(1) default '0' not null, 
		CHANGE invisible invisible tinyint(1) default '0' not null, 
		CHANGE style_set style_set smallint(5) unsigned default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_boards 
		ADD INDEX boardparentid (boardparentid)",1);
		echo "bb".$n."_boards Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_config  
		CHANGE html html tinyint(1) default '0' not null, 
		CHANGE smilies smilies tinyint(1) default '0' not null, 
		CHANGE bbcode bbcode tinyint(1) default '0' not null, 
		CHANGE maximage maximage tinyint(3) unsigned default '0' not null, 
		CHANGE polls polls tinyint(1) default '0' not null, 
		CHANGE image image tinyint(1) default '0' not null, 
		CHANGE tproseite tproseite tinyint(2) unsigned default '0' not null, 
		CHANGE eproseite eproseite tinyint(2) unsigned default '0' not null, 
		CHANGE timeoffset timeoffset tinyint(2) default '0' not null, 
		CHANGE rekord rekord smallint(5) unsigned default '0' not null, 
		CHANGE rekordtime rekordtime int(10) unsigned default '0' not null, 
		CHANGE timeout timeout tinyint(3) unsigned default '0' not null, 
		CHANGE default_daysprune default_daysprune smallint(4) unsigned default '0' not null, 
		CHANGE hotthread_reply hotthread_reply tinyint(3) unsigned default '0' not null, 
		CHANGE hotthread_view hotthread_view tinyint(3) unsigned default '0' not null, 
		CHANGE show_subboards show_subboards tinyint(1) default '0' not null, 
		CHANGE anzahl_smilies anzahl_smilies tinyint(3) unsigned default '0' not null, 
		CHANGE ch_parseurl ch_parseurl tinyint(1) default '0' not null, 
		CHANGE ch_email ch_email tinyint(1) default '0' not null, 
		CHANGE ch_disablesmilies ch_disablesmilies tinyint(1) default '0' not null, 
		CHANGE ch_signature ch_signature tinyint(1) default '0' not null, 
		CHANGE boardoff boardoff tinyint(1) default '0' not null, 
		CHANGE timetype timetype tinyint(1) default '0' not null, 
		CHANGE postorder postorder tinyint(1) default '0' not null, 
		CHANGE register register tinyint(1) default '0' not null, 
		CHANGE act_code act_code tinyint(1) default '0' not null, 
		CHANGE act_permail act_permail tinyint(1) default '0' not null, 
		CHANGE regnotify regnotify tinyint(1) default '0' not null, 
		CHANGE multi_email multi_email tinyint(1) default '0' not null, 
		CHANGE sigsmilies sigsmilies tinyint(1) default '0' not null, 
		CHANGE sigbbcode sigbbcode tinyint(1) default '0' not null, 
		CHANGE sightml sightml tinyint(1) default '0' not null, 
		CHANGE sigimage sigimage tinyint(1) default '0' not null, 
		CHANGE sigmaximage sigmaximage tinyint(3) unsigned default '0' not null, 
		CHANGE siglength siglength smallint(5) unsigned default '0' not null, 
		CHANGE avatars avatars tinyint(1) default '0' not null, 
		CHANGE avatar_width avatar_width tinyint(3) unsigned default '0' not null, 
		CHANGE avatar_height avatar_height tinyint(3) unsigned default '0' not null, 
		CHANGE avatar_size avatar_size mediumint(8) unsigned default '0' not null, 
		CHANGE usertextlength usertextlength smallint(5) unsigned default '0' not null, 
		CHANGE favboards favboards smallint(5) unsigned default '0' not null, 
		CHANGE favthreads favthreads smallint(5) unsigned default '0' not null, 
		CHANGE pms pms tinyint(1) default '0' not null, 
		CHANGE maxpms maxpms smallint(5) unsigned default '0' not null, 
		CHANGE maxfolder maxfolder smallint(5) unsigned default '0' not null");
		$check=$db_zugriff->query_first("SHOW FIELDS FROM bb".$n."_config LIKE 'useronlinelastemptied'");
		if($check['Field']=="useronlinelastemptied") $db_zugriff->query("ALTER TABLE bb".$n."_config DROP useronlinelastemptied",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_config 
		ADD useronlinelastemptied int(10) unsigned default '0' not null AFTER timeout",1);
		echo "bb".$n."_config Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_folders 
		CHANGE folderid folderid smallint(5) unsigned not null auto_increment, 
		CHANGE userid userid int(10) unsigned default '0' not null");
		echo "bb".$n."_folders Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_groups 
		CHANGE id id smallint(5) unsigned not null auto_increment, 
		CHANGE canviewboard canviewboard tinyint(1) default '0' not null, 
		CHANGE canviewoffboard canviewoffboard tinyint(1) default '0' not null, 
		CHANGE canusesearch canusesearch tinyint(1) default '0' not null, 
		CHANGE canusepms canusepms tinyint(1) default '0' not null, 
		CHANGE canstarttopic canstarttopic tinyint(1) default '0' not null, 
		CHANGE canreplyowntopic canreplyowntopic tinyint(1) default '0' not null, 
		CHANGE canreplytopic canreplytopic tinyint(1) default '0' not null, 
		CHANGE caneditownpost caneditownpost tinyint(1) default '0' not null, 
		CHANGE candelownpost candelownpost tinyint(1) default '0' not null, 
		CHANGE cancloseowntopic cancloseowntopic tinyint(1) default '0' not null, 
		CHANGE candelowntopic candelowntopic tinyint(1) default '0' not null, 
		CHANGE canpostpoll canpostpoll tinyint(1) default '0' not null, 
		CHANGE canvotepoll canvotepoll tinyint(1) default '0' not null, 
		CHANGE canuploadavatar canuploadavatar tinyint(1) default '0' not null, 
		CHANGE appendeditnote appendeditnote tinyint(1) default '0' not null, 
		CHANGE avoidfc avoidfc tinyint(1) default '0' not null, 
		CHANGE ismod ismod tinyint(1) default '0' not null, 
		CHANGE issupermod issupermod tinyint(1) default '0' not null, 
		CHANGE canuseacp canuseacp tinyint(1) default '0' not null, 
		CHANGE default_group default_group tinyint(1) default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_groups ADD INDEX default_group (default_group)",1);
		echo "bb".$n."_groups Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_notify 
		CHANGE threadid threadid int(10) unsigned default '0' not null, 
		CHANGE userid userid int(10) unsigned default '0' not null");
		echo "bb".$n."_notify Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_object2board 
		CHANGE boardid boardid mediumint(8) unsigned default '0' not null, 
		CHANGE objectid objectid int(10) unsigned default '0' not null, 
		CHANGE mod mod tinyint(1) default '0' not null, 
		CHANGE boardpermission boardpermission tinyint(1) default '0' not null, 
		CHANGE startpermission startpermission tinyint(1) default '0' not null, 
		CHANGE replypermission replypermission tinyint(1) default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_object2board ADD INDEX boardid (boardid)",1);
		echo "bb".$n."_object2board Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_object2user 
		CHANGE userid userid mediumint(8) unsigned default '0' not null, 
		CHANGE objectid objectid int(10) unsigned default '0' not null, 
		CHANGE favboards favboards tinyint(1) default '0' not null, 
		CHANGE favthreads favthreads tinyint(1) default '0' not null, 
		CHANGE buddylist buddylist tinyint(1) default '0' not null, 
		CHANGE ignorelist ignorelist tinyint(1) default '0' not null, 
		CHANGE pmsend pmsend tinyint(1) default '0' not null");
		echo "bb".$n."_object2user Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_pms  
		CHANGE pmid pmid int(10) unsigned not null auto_increment, 
		CHANGE senderid senderid int(10) unsigned default '0' not null, 
		CHANGE recipientid recipientid int(10) unsigned default '0' not null, 
		CHANGE folderid folderid mediumint(8) unsigned default '0' not null, 
		CHANGE view view tinyint(1) default '0' not null, 
		CHANGE reply reply tinyint(1) default '0' not null, 
		CHANGE forward forward tinyint(1) default '0' not null, 
		CHANGE sendtime sendtime int(10) unsigned default '0' not null, 
		CHANGE disable_smilies disable_smilies tinyint(1) default '0' not null, 
		CHANGE signature signature tinyint(1) default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_pms ADD INDEX recipientid (recipientid)",1);
		echo "bb".$n."_pms Tabelle aktualisiert<br>";


		$db_zugriff->query("ALTER TABLE bb".$n."_pmsend  
		CHANGE pmid pmid int(10) unsigned not null auto_increment, 
		CHANGE userid userid int(10) unsigned default '0' not null, 
		CHANGE recipientid recipientid int(10) unsigned default '0' not null, 
		CHANGE pmparentid pmparentid int(10) unsigned default '0' not null, 
		CHANGE sendtime sendtime int(10) unsigned default '0' not null, 
		CHANGE disable_smilies disable_smilies tinyint(1) default '0' not null, 
		CHANGE signature signature tinyint(1) default '0' not null");
		echo "bb".$n."_pmsend Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_poll  
		CHANGE id id int(10) unsigned not null auto_increment, 
		CHANGE threadid threadid int(10) unsigned default '0' not null, 
		CHANGE votes votes mediumint(8) unsigned default '0' not null");
		echo "bb".$n."_poll Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_posts  
		CHANGE postid postid int(10) unsigned not null auto_increment, 
		CHANGE userid userid int(10) unsigned default '0' not null, 
		CHANGE threadparentid threadparentid int(10) unsigned default '0' not null, 
		CHANGE boardparentid boardparentid mediumint(8) unsigned default '0' not null, 
		CHANGE posttime posttime int(10) unsigned default '0' not null, 
		CHANGE edittime edittime int(10) unsigned default '0' not null, 
		CHANGE editorid editorid int(10) unsigned default '0' not null, 
		CHANGE disable_smilies disable_smilies tinyint(1) default '0' not null, 
		CHANGE signature signature tinyint(1) default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_posts ADD INDEX boardparentid (boardparentid,threadparentid)",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_posts ADD INDEX userid (userid)",1);
		echo "bb".$n."_posts Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_ranks  
		CHANGE id id mediumint(8) unsigned not null auto_increment, 
		CHANGE groupid groupid smallint(5) unsigned default '0' not null, 
		CHANGE posts posts mediumint(8) unsigned default '0' not null, 
		CHANGE mal mal tinyint(2) unsigned default '0' not null");
		echo "bb".$n."_ranks Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_smilies  
		CHANGE id id smallint(5) unsigned not null auto_increment");
		echo "bb".$n."_smilies Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_style  
		CHANGE styleid styleid smallint(5) unsigned not null auto_increment, 
		CHANGE bgfixed bgfixed tinyint(1) default '0' not null, 
		CHANGE default_style default_style tinyint(1) default '0' not null");
		$check=$db_zugriff->query_first("SHOW FIELDS FROM bb".$n."_style LIKE 'imagefolder'");
		if($check['Field']=="imagefolder") $db_zugriff->query("ALTER TABLE bb".$n."_style DROP imagefolder",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_style 
		ADD imagefolder varchar(200) not null AFTER templatefolder",1);
		echo "bb".$n."_style Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_threads  
		CHANGE threadid threadid int(10) unsigned not null auto_increment, 
		CHANGE boardparentid boardparentid mediumint(8) unsigned default '0' not null, 
		CHANGE starttime starttime int(10) unsigned default '0' not null, 
		CHANGE authorid authorid int(10) unsigned default '0' not null, 
		CHANGE lastposterid lastposterid int(10) unsigned default '0' not null, 
		CHANGE replies replies mediumint(8) unsigned default '0' not null, 
		CHANGE views views mediumint(8) unsigned default '0' not null, 
		CHANGE timelastreply timelastreply int(10) unsigned default '0' not null, 
		CHANGE flags flags tinyint(1) default '0' not null, 
		CHANGE rate_points rate_points mediumint(8) unsigned default '0' not null, 
		CHANGE rated rated smallint(5) unsigned default '0' not null, 
		CHANGE putoffid putoffid mediumint(8) unsigned default '0' not null, 
		CHANGE important important tinyint(1) default '0' not null, 
		CHANGE ptimeout ptimeout int(10) unsigned default '0' not null");
		$db_zugriff->query("ALTER TABLE bb".$n."_threads 
		ADD INDEX boardparentid (boardparentid)",1);
		echo "bb".$n."_threads Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_user_table  
		CHANGE userid userid int(10) unsigned not null auto_increment, 
		CHANGE userposts userposts mediumint(8) unsigned default '0' not null, 
		CHANGE groupid groupid smallint(5) unsigned default '0' not null, 
		CHANGE regdate regdate int(10) unsigned default '0' not null, 
		CHANGE lastvisit lastvisit int(10) unsigned default '0' not null, 
		CHANGE lastactivity lastactivity int(10) unsigned default '0' not null, 
		CHANGE session_link session_link tinyint(1) default '0' not null, 
		CHANGE age_d age_d tinyint(2) unsigned default '0' not null, 
		CHANGE age_y age_y smallint(4) unsigned default '0' not null, 
		CHANGE avatarid avatarid mediumint(8) unsigned default '0' not null, 
		CHANGE gender gender tinyint(1) default '0' not null, 
		CHANGE show_email_global show_email_global tinyint(1) default '0' not null, 
		CHANGE mods_may_email mods_may_email tinyint(1) default '0' not null, 
		CHANGE users_may_email users_may_email tinyint(1) default '0' not null, 
		CHANGE invisible invisible tinyint(1) default '0' not null, 
		CHANGE hide_signature hide_signature tinyint(1) default '0' not null, 
		CHANGE hide_userpic hide_userpic tinyint(1) default '0' not null, 
		CHANGE prunedays prunedays smallint(4) unsigned default '0' not null, 
		CHANGE umaxposts umaxposts tinyint(2) unsigned default '0' not null, 
		CHANGE bbcode bbcode tinyint(1) default '0' not null, 
		CHANGE style_set style_set smallint(5) unsigned default '0' not null, 
		CHANGE activation activation int(10) unsigned default '0' not null, 
		CHANGE blocked blocked tinyint(1) default '0' not null");
		$check=$db_zugriff->query_first("SHOW FIELDS FROM bb".$n."_user_table LIKE 'lastpmpopup'");
		if($check['Field']=="lastpmpopup") $db_zugriff->query("ALTER TABLE bb".$n."_user_table DROP lastpmpopup",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_user_table 
		ADD lastpmpopup int(10) unsigned default '0' not null AFTER bbcode",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_user_table 
		ADD INDEX username (username), ADD INDEX groupid (groupid), ADD INDEX avatarid (avatarid)",1);
		echo "bb".$n."_user_table Tabelle aktualisiert<br>";

		$db_zugriff->query("DELETE FROM bb".$n."_useronline");
		$db_zugriff->query("ALTER TABLE bb".$n."_useronline 
		CHANGE zeit zeit int(10) unsigned default '0' not null, 
		CHANGE userid userid int(10) unsigned default '0' not null");
		$check=$db_zugriff->query_first("SHOW FIELDS FROM bb".$n."_useronline LIKE 'sid'");
		if($check['Field']=="sid") $db_zugriff->query("ALTER TABLE bb".$n."_useronline DROP sid",1);
		$db_zugriff->query("ALTER TABLE bb".$n."_useronline 
		ADD sid varchar(32) not null FIRST");
		$db_zugriff->query("ALTER TABLE bb".$n."_useronline 
		ADD PRIMARY KEY(sid)");
		echo "bb".$n."_useronline Tabelle aktualisiert<br>";

		$db_zugriff->query("ALTER TABLE bb".$n."_vote 
		CHANGE threadid threadid int(10) unsigned default '0' not null, 
		CHANGE userid userid int(10) unsigned default '0' not null");
		echo "bb".$n."_vote Tabelle aktualisiert<br>";

		// useronline Tabelle als HEAP
		list($version) = $db_zugriff->query_first("SELECT VERSION()");
		if(preg_match("/^(3\.23)|(4\.)/", $version))
		{
			$check=0;
			$result=$db_zugriff->query("SHOW FIELDS FROM bb".$n."_useronline");
			while($row=$db_zugriff->fetch_array($result)) if(strstr($row['Type'],"text") || strstr($row['Type'],"blob")) $check=1;
			if($check==0) $db_zugriff->query("ALTER TABLE bb".$n."_useronline TYPE=HEAP",1);
		}
		?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Tabellen wurden erfolgreich aktualisieren! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='2'>
	<input type='hidden' name='mode' value='2'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
		<?php
	}
	
	// User
	elseif($step==2)
	{
		?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Benutzer werden aktualisiert...</b></td></tr>
	<tr bgcolor='white'><td>
	<?php
		// User ...
		$db_zugriff->query("UPDATE bb".$n."_user_table SET username=REPLACE(REPLACE(username,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_user_table SET signatur=REPLACE(REPLACE(signatur,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_user_table SET usertext=REPLACE(REPLACE(usertext,'&quot;','\"'),'&acute;','\'')");
		?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Benutzer wurden erfolgreicht aktualisiert! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='3'>
	<input type='hidden' name='mode' value='2'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
		<?php
	}
	
	elseif($step==3)
	{
		?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Foren werden aktualisiert...</b></td></tr>
	<tr bgcolor='white'><td>
	<?php
		// Boards ...
		$db_zugriff->query("UPDATE bb".$n."_boards SET boardname=REPLACE(REPLACE(boardname,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_boards SET boardpassword=REPLACE(REPLACE(boardpassword,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_boards SET descriptiontext=REPLACE(REPLACE(descriptiontext,'&quot;','\"'),'&acute;','\'')");
		?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Foren wurden erfolgreicht aktualisiert! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='4'>
	<input type='hidden' name='mode' value='2'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
		<?php
	}
	
	elseif($step==4)
	{
	?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Themen werden aktualisiert...</b></td></tr>
	<tr bgcolor='white'><td>
	<?php
		// Threads ...
		$db_zugriff->query("UPDATE bb".$n."_threads SET threadname=REPLACE(REPLACE(threadname,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_threads SET author=REPLACE(REPLACE(author,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_threads SET pquestion=REPLACE(REPLACE(pquestion,'&quot;','\"'),'&acute;','\'')");
		?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Themen wurden erfolgreicht aktualisiert! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='5'>
	<input type='hidden' name='mode' value='2'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
		<?php
	}
	
	elseif($step==5)
	{
	?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<form method='post' action='install.php'>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Beitr�ge werden aktualisiert...</b></td></tr>
	<tr bgcolor='white'><td>
	<?php
		// Posts ...
		$db_zugriff->query("UPDATE bb".$n."_posts SET posttopic=REPLACE(REPLACE(posttopic,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_posts SET message=REPLACE(REPLACE(message,'&quot;','\"'),'&acute;','\'')");
		?>
	</td></tr>
	<tr bgcolor='white' align='center'><td>
	Die Beitr�ge wurden erfolgreicht aktualisiert! Klicken Sie bitte auf "Fortfahren".
	</td></tr> 
	<tr bgcolor='white' align='center'><td>
	<input type='hidden' name='step' value='6'>
	<input type='hidden' name='mode' value='2'>
	<input type='submit' value='Fortfahren'>&nbsp;
	</td>
	</tr>
	</table>
	</form>
	</body>
	</html>
		<?php
	}
	
	elseif($step==6)
	{
		// Ank�ndigungen ...
		$db_zugriff->query("UPDATE bb".$n."_announcements SET topic=REPLACE(REPLACE(topic,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_announcements SET message=REPLACE(REPLACE(message,'&quot;','\"'),'&acute;','\'')");
		
		// Konfiguration ...
		$db_zugriff->query("UPDATE bb".$n."_config SET master_board_name=REPLACE(REPLACE(master_board_name,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_config SET badwords=REPLACE(REPLACE(badwords,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_config SET boardoff_text=REPLACE(REPLACE(boardoff_text,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_config SET today=REPLACE(REPLACE(today,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_config SET banname=REPLACE(REPLACE(banname,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_config SET banemail=REPLACE(REPLACE(banemail,'&quot;','\"'),'&acute;','\'')");
		
		// PM Folder ...
		$db_zugriff->query("UPDATE bb".$n."_folders SET foldername=REPLACE(REPLACE(foldername,'&quot;','\"'),'&acute;','\'')");
		
		// Gruppen ...
		$db_zugriff->query("UPDATE bb".$n."_groups SET title=REPLACE(REPLACE(title,'&quot;','\"'),'&acute;','\'')");
		
		// PMS ...
		$db_zugriff->query("UPDATE bb".$n."_pms SET subject=REPLACE(REPLACE(subject,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_pms SET message=REPLACE(REPLACE(message,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_pmsend SET subject=REPLACE(REPLACE(subject,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_pmsend SET message=REPLACE(REPLACE(message,'&quot;','\"'),'&acute;','\'')");

		// Umfragen ...
		$db_zugriff->query("UPDATE bb".$n."_poll SET field=REPLACE(REPLACE(field,'&quot;','\"'),'&acute;','\'')");

		// Ranks ...
		$db_zugriff->query("UPDATE bb".$n."_ranks SET rank=REPLACE(REPLACE(rank,'&quot;','\"'),'&acute;','\'')");

		// Smilies ...
		$db_zugriff->query("UPDATE bb".$n."_smilies SET smiliestext=REPLACE(REPLACE(smiliestext,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_smilies SET smiliestitle=REPLACE(REPLACE(smiliestitle,'&quot;','\"'),'&acute;','\'')");

		// Styles ...
		$db_zugriff->query("UPDATE bb".$n."_style SET stylename=REPLACE(REPLACE(stylename,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_style SET css=REPLACE(REPLACE(css,'&quot;','\"'),'&acute;','\'')");
		$db_zugriff->query("UPDATE bb".$n."_style SET imagefolder='images'");
		?>
	<html>
	<head>
	<title>Woltlab Burning Board 1.2 - Installation</title>
	<link rel='stylesheet' href='other.css'>
	</head>
	<body>
	<table cellpadding='4' cellspacing='1' width='50%' bgcolor='#000000' align='center'>
	<tr bgcolor='#314477'><td><font size='2' color='white' face='Tahoma'><b>� Herzlichen Gl�ckwunsch</b></td></tr>
	<tr bgcolor='white'><td><b>Das Update auf wBB 1.2 wurde erfolgreich abgeschlossen.</b><BR>Bitte l�schen Sie die "install.php", um sich gegen ein sp�teres �berschreiben Ihres Forums zu sch�tzen.
	</td></tr>    
	<tr bgcolor='white' align='center'><td>
	Klicken Sie <a href="./admin/index.php">hier</a>, um ins Admin Control Panel zu gelangen 
	</td>
	</tr>
	</table>
	</body>
	</html>
		<?php
	}
}

















// update von wbb 1.0 beta 4.5
elseif($mode==3)
{
	// machen wir das �berhaupt ??
}



function nextstep()
{
	global $step,$mode;
	header("Location: install.php?mode=$mode&step=".($step+1));
	exit;
}
?>

