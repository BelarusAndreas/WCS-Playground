++++++++++++ WoltLab Burning Board 1.2 ++++++++++++

I.	Installation
II.	Update von 1.1.1
III.	Copyright & Special Thanks

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++

++++++++++++++++ I. Installation +++++++++++++++

-- 1. entpacken des ZIP-Archivs wbboard.zip auf die lokalte Festplatte
-- 2. Kopieren Sie alle Dateien auf den Server
      Beim Upload FTP Tool auf Auto Mode stellen
      falls nicht vorhanden:
      .php Dateien im ASCII Mode
      .jpg/.gif Dateien im Bin�r Mode
-- 3. Die Datei "./admin/_data.inc.php" mit den Rechten 777 versehen.
-- 4. Die Verzeichnisse /images/avatars und /images/smilies mit den Rechten 777 versehen.
-- 5. aufruf der install.php im Browser
-- 6. W�hlen Sie als Einrichtungsart "Neuinstallation" aus und klicken Sie auf Fortsetzen.
-- 7. Geben Sie im folgenden Fenster den Hostnamen des MySQL Server, Ihren Benutzernamen  
      und Ihr Passwort f�r den MySQL Server, den Namen Ihrer Datenbank und die Nummer des
      Boards an (falls Sie mehrere Boards installieren m�chten, ansonsten 1).
-- 8. den Anweisungen folgen
-- 9. nach erfolgreicher Installation -> install.php l�schen
-- 10. im Admin Control Panel einloggen und Einstellungen vornehmen
       Wichtig: Einstellungen -> Boardoptionen -> Url zum Board: http://www.deinedomain.de/wbboard
-- 11. Boards erstellen etc.
-- 12. Fertig!

Wichtig: Die Datei /admin/_data.inc.php muss beschreibbar sein.
Das Verzeichnis images/avatars mu� die Rechte 777 bekommen, wenn man Avatars hochladen m�chte.
Das Verzeichnis images/smilies mu� die Rechte 777 bekommen, wenn man Smilies hochladen m�chte.




++++++++++++++++ II. Update von wBB 1.1.1 +++++++++++++++

-- 1. Forum in Offline Modus schalten
-- 2. entpacken des ZIP-Archivs wbboard.zip auf die lokalte Festplatte
-- 3. L�schen Sie die Dateien class_db_zugriff.php aus dem Hauptordner ihres wBB 1.1.1.
-- 4. Verschieben Sie die Datei _data.inc.php aus dem Hauptordner in das Verzeichnis admin
-- 5. Kopieren aller (mit Ausnahme von admin/_data.inc.php) Dateien auf den Server
      Beim Upload FTP Tool auf Auto Mode stellen
      falls nicht vorhanden:
      .php Dateien im ASCII Mode
      .jpg/.gif Dateien im Bin�r Mode
-- 5. aufruf der install.php im Browser
-- 6. W�hlen Sie als Einrichtungsart "Update von wBB 1.1.1" aus und klicken Sie auf Fortsetzen.
-- 7. den Anweisungen folgen
-- 8. nach erfolgreichm Update -> install.php l�schen
-- 9. im Admin Control Panel einloggen und Einstellungen vornehmen/alten Einstellungen �berpr�fen
-- 10. Fertig!


++++++++++++++++ III. Copyright & Special Thanks +++++++++++++++

Copyright 2001-2003 WoltLab GmbH (www.woltlab.de) - Gesch�ftsf�hrer Marcel Werk
Special thanks to... PerfectPixel, Malick, OnkelDoc


  