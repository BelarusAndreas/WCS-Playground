<?php
// Hostname oder IP des MySQL-Servers
$sqlhost = "localhost";
// Username und Passwort zum einloggen in den Datenbankserver
$sqluser = "root";
$sqlpassword = "";
// Name der Datenbank
$sqldb = "wbblite";
// Nummer des Boards
$n = "1";
// Email des Admins
$adminmail = "xyz@xyz.de";
?>
