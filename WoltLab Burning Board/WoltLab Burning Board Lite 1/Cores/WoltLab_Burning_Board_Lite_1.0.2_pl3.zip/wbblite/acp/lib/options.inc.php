<?php
// automatic generated option file
// do not change

$rekordtime = "0";
$rekord = "0";
$dateformat = "d.m.Y";
$timeformat = "H:i";
$index_depth = "2";
$show_subboards = "0";
$showlastposttitle = "1";
$master_board_name = "Name des Forums";
$showuseronline = "1";
$showpmonindex = "0";
$minusernamelength = "3";
$maxusernamelength = "15";
$multipleemailuse = "0";
$emailverifymode = "1";
$dostopshooting = "1";
$showpostsinreply = "10";
$smilie_table_cols = "3";
$smilie_table_rows = "15";
$maxpolloptions = "10";
$postmaxchars = "10000";
$newthread_default_checked_0 = "1";
$newthread_default_checked_2 = "0";
$newthread_default_checked_3 = "1";
$maxnotifymails = "3";
$frommail = "xyz@xyz.de";
$addreply_default_checked_0 = "1";
$addreply_default_checked_2 = "0";
$addreply_default_checked_3 = "1";
$useronlinetimeout = "15";
$board_depth = "2";
$default_threadsperpage = "20";
$default_daysprune = "100";
$default_postsperpage = "20";
$showmultipages = "4";
$showavatar = "1";
$showregdateinthread = "1";
$showuserpostsinthread = "1";
$showgenderinthread = "1";
$showonlineinthread = "1";
$editpost_default_checked_0 = "1";
$membersperpage = "30";
$showlastpostinprofile = "1";
$allowregister = "1";
$showdisclaimer = "1";
$default_timezoneoffset = "1";
$allowsightml = "0";
$allowsigbbcode = "1";
$allowsigsmilies = "1";
$maxsigimage = "1";
$avatarsperpage = "25";
$gzip = "0";
$gziplevel = "1";
$minwordlength = "3";
$maxwordlength = "20";
$showstats = "0";
$usecode = "1";
$showpagelinks = "3";
$modids = "3";
$smodids = "2";
$adminids = "1";
$url2board = "http://www.xyz.de/wbb";
$webmastermail = "xyz@xyz.de";
$sendheaders = "0";
$sendnocacheheaders = "0";
$default_hotthread_reply = "20";
$default_hotthread_view = "100";
$maxpms = "50";
$showboardjump = "1";
$maxfolders = "2";
$pm_allowsmilies = "1";
$pm_allowbbcode = "1";
$pm_allowhtml = "0";
$pm_allowimages = "1";
$pmmaxchars = "10000";
$newpm_default_checked_0 = "1";
$newpm_default_checked_1 = "0";
$newpm_default_checked_2 = "1";
$newpm_default_checked_3 = "1";
$newpm_default_checked_4 = "1";
$docensor = "0";
$offlinemessage = "";
$offline = "0";
$dpvtime = "86400";
$fctime = "30";
$showsmiliesrandom = "0";
$badsearchwords = "den
das
mit
sich
des
ist
dem
nicht
ein
die
als
werden
aus
hat
da�
wird
einer
der
sind
noch
einem
einen
sie
war
haben
oder
vor
mehr
man
sein
wurde
sei
hatte
kann
gegen
vom
k�nnen
habe
ihre
soll
ich
eines
jahr
jahren
wieder
keine
uhr
seiner
worden
und
will
zwischen
immer
sagte
gibt
alle
diesem
mu�
wurden
beim
doch
waren
drei
jahre
neue
neuen
damit
bereits
auch
seinen
m�ssen
ihrer
nach
ohne
sondern
selbst
ersten
etwa
bei
ihren
weil
ihm
seien
anderen
werde
sagt
wir
eine
rund
f�r
aber
ihn
ende
jedoch
zeit
sollen
ins
wenn
seinem
uns
geht
sehr
ganz
wollen
sowie
hatten
kein
machen
lassen
andere
dieses
steht
dabei
wegen
weiter
denn
beiden
einmal
etwas
wie
nichts
allerdings
vier
gut
viel
alles
auf
w�re
kommt
vergangenen
denen
fast
f�nf
k�nnte
h�tten
daf�r
kommen
diesen
letzten
zwar
diese
gro�en
von
mann
sollte
w�rde
also
bisher
konnte
ihrem
zehn
w�rden
stehen
hei�t
dies
zur�ck
dessen
ihnen
deren
sogar
frage
gewesen
erste
gab
liegt
gar
davon
gestern
geben
teil
dass
h�tte
eigenen
kaum
sieht
gro�e
weitere
was
sehen
macht
angaben
weniger
gerade
l��t
allen
darauf
wohl
sp�ter
k�nne
aller
kam
mich
gegen�ber
n�chsten
bleibt
wenig
lange
gemacht
fall
mir
gehen
weg
wollte
sechs
keinen
woche
dagegen
alten
m�glich
gilt
erkl�rte
m�sse
k�nnten
zusammen
finden
tag
art
erhalten
wochen
jeder
nie
bleiben
besonders
jahres
zun�chst
derzeit
allein
deutlich
wei�
einige
sollten
pr�sident
geworden
statt
platz
inzwischen
nur
pro
seines
einfach
geh�rt
eher
oft
zahl
neben
h�lt
weit
meisten
thema
zeigt
zweiten
insgesamt
mu�te
anfang
hinter
ebenfalls
ging
dar�ber
vielen
ziel
darf
seite
fest
hin
erkl�rt
namen
haus
damals
hilfe
mai
seit
tage
halten
gleich
nehmen
solche
besser
alte
leute
ergebnis
sagen
m�rz
tun
kleinen
lang
knapp
bringen
wissen
bekannt
findet
daran
k�nftig
wer
acht
gr�nen
schnell
grund
scheint
bin
liegen
stellt
sieben
n�mlich
�berhaupt
eigene
dann
gegeben
stunden
eigentlich
lie�
probleme
vielleicht
ebenso
bereich
bis
h�he
w�hrend
bild
l�ndern
informationen
schwer
zuvor
genau
neu
erwartet
sicher
f�hren
mal
�ber
mehrere
programm
offenbar
hier
weiteren
nat�rlich
konnten
stark
ganze
kommenden
bekommen
eben
kleine
trotz
wirklich
lage
leicht
gekommen
laut
kurz
f�hrt
innerhalb
unsere
meint
anders
ihres
v�llig
beispielsweise
gute
bislang
jede
erreicht
beide
d�rfen
unter
jeweils
einigen
zum
umsatz
spielen
welche
m��ten
hie�
paar
nachdem
gebracht
problem
jeden
recht
erneut
l�ngst
beginn
besteht
seine
mindestens
machte
jetzt
bietet
au�erdem
bald
schon
fragen
klar
durch
seiten
geh�ren
dort
erstmals
zeigen
gr��ten
setzt
wert
m�chte
daher
wolle
lediglich
nimmt
zuletzt
hohen
leben
dieser
weiterhin
gebe
gestellt
zweite
situation
gefunden
sonst
stand
h�lfte
m�glichkeit
versucht
blieb
junge
arbeiten
berichtet
letzte
wollten
ihr
zw�lf
zumindest
genug
weise
hoch
beginnt
obwohl
spielt
verloren
erst
jedem
erreichen
setzen
spricht
fr�her
teilte
landes
zudem
einzelnen
bereit
gemeinsam
bedeutung
dazu
zwei
besten
ansicht
endlich
stelle
direkt
viele
solchen
solle
jungen
einsatz
richtig
gr��te
sofort
neuer
ehemaligen
unserer
d�rfte
schaffen
augen
neun
kamen
einzige
meine
nun
niemand
weder
tats�chlich
heute
gef�hrt
guten
durchaus
darin
meist
gro�
zufolge
genommen
gleichen
verschiedenen
neues
stellte
danach
anderer
gesagt
handelt
lag
sprach
frei
dennoch
hohe
bzw.
etc.
etc
bzw
zur
entwickelt
fand
diskussion
bringt
deshalb
hause
per
zugleich
fr�heren
dadurch
ganzen
abend
erz�hlt
streit
jedenfalls
gesehen
darunter
forderte
beispiel
meinung
wenigen
sowohl
meinte
mag
hinaus
verletzt
weltweit
bevor
mu�ten
keiner
braucht
sprechen
gleichzeitig
sogenannten
geplant
her
freilich
gro�er
wenige
�ffentlichen
dritten
nahm
bedeutet
dr.
oben
gesetzt
z.b.
jedes
ziehen
berichtete
aufgrund
stellen
warum
heraus
heutigen
anteil
herr
frau
rechnen
f�llt
w�ren
idee
verlassen
insbesondere
offen
stets
�ndern
entschieden
angesichts
gelten
erwarten
l�uft
fordert
stimmen
w�hlen
gewinnen
bieten
n�he
j�hrlich
hingegen
anderes
immerhin
schlie�lich
betonte
mittlerweile
suchen
zahlen
gesamte
indem
ehemalige
entscheiden
genannt
tragen
langen
h�ufig
chancen
alt
�bernehmen
st�rker
ohnehin
zeigte
geplanten
darum
verhindern
begann
verkauft
wichtig
sah
gesamten
einst
verwendet
vorbei
helfen
folgen
bezeichnet";
$turnoff_formmail = "0";
$installdate = "0";
$cookiepath = "";
$cookiedomain = "";
$ban_ip = "";
$censorwords = "";
$censorcover = "*";
$ban_name = "";
$ban_email = "";
$boardversion = "1.0.0";
$default_register_invisible = "0";
$default_register_nosessionhash = "1";
$default_register_usecookies = "1";
$default_register_admincanemail = "1";
$default_register_showemail = "0";
$default_register_usercanemail = "1";
$default_register_emailnotify = "0";
$default_register_receivepm = "1";
$default_register_emailonpm = "0";
$default_register_pmpopup = "0";
$default_register_showsignatures = "1";
$default_register_showavatars = "1";
$default_register_showimages = "1";
$sessiontimeout = "1800";
$adminsession_timeout = "1800";
$regnotify = "1";
?>
