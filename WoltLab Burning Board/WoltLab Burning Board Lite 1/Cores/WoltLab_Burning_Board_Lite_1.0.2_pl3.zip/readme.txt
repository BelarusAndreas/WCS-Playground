---- Installation Anleitung f�r das WoltLab Burning Board Lite 1.0.2 ----

Folgende Schritte sind f�r eine korrekte Installation notwendig:

1) Entpacken des Zip Archivs
Entpacken Sie das Zip Archiv auf Ihrer Festplatte.

2) Hochladen aller Dateien aus dem Ordner "wbblite"
Auf Ihrer Festplatte sollte sich jetzt ein Ordner "wbblite" befinden. Laden Sie diesen bzw. seinen Inhalt auf den Server, wo Sie das wBBLite installieren m�chten. Das Hochladen geschieht normalerweise per FTP. Dazu ben�tigen Sie ein FTP Programm, wie z.B. WSFTP oder CuteFTP. Als Transfermodus sollten Sie "automatisch" w�hlen.

3) Rechte setzen
Sollte der Server ein UNIX System sein, m�ssen in folgenden Unterordnern auf dem Server Schreibrechte vorhanden sein:
 /images/avatars
 /acp/lib
 
 und Dateien:
 /acp/lib/config.inc.php
 /acp/lib/options.inc.php
  
Die Rechte k�nnen Sie mit dem chmod Befehl �ndern. Diesen f�hren Sie entweder direkt per Konsole aus oder nutzen die Option in Ihrem FTP Programm.

4) Beim Update von wBB1
Falls Sie eine Konvertierung der Daten von einem wBB1 vornehmen m�chten, m�ssen Sie die Datei _data.inc.php vom wBB1 in den Unterordner /acp vom wBBLite kopieren. Sie sollte sich auch noch einmal vergewissern welche Boardnummer das wBB1 benutzt (wichtig f�r Schritt 5).

5) Starten der Installation
Sie k�nnen jetzt im Browser folgende Adresse aufrufen: http://www.ihre-domain.de/wbblite/acp/setup.php
An dieser Stelle m�ssen Sie ausw�hlen, ob Sie eine Neuinstallation oder eine Update von wBB1 durchf�hren m�chten. Wenn Sie "Fortfahren" klicken, gelangen Sie auf einen Bildschirm, wo Sie die Datenbankzugriffsdaten eingeben m�ssen. Sollte es sich nicht um einen eigenen Server handeln, erfahren Sie die Zugangsdaten bei Ihrem Hoster. Als "Nummer des Forums" empfiehlt sich im Normalfall die Nummer 1. Sollten Sie aber bereits anderen Burning Boards in der selben Datenbank installiert haben, m�ssen Sie wom�glich eine andere Nummer angeben. 

Im Falle eines Update von wBB1, ist es wichtig, dass Sie hier eine andere Nummer eingeben als beim wBB1 (siehe Schritt 4 - _data.inc.php)

Klicken Sie auf "speichern" und folgen der Installation.

6) Installation abgeschlossen
Sollte die Installation erfolgreich abgeschlossen sein, m�ssen Sie aus Sicherheitsgr�nden die Dateien "setup.php" und "update.php" aus dem Unterordner /acp entfernen. Ansonsten gelangen Sie nicht in das Admin Control Panel.

7) Nach der Installation
Nach der Installation sollten Sie unbedingt die Einstellungen im Admin Control Panel durchgehen. Besonders die Globalen Optionen sind sehr wichtig.



---- Weitere Information zum Update von wBB1 (unbedingt lesen!) ----

1) Vor dem Update sollte man das wBB1 in den Offline-Modus schalten.

2) Es werden keine Benutzergruppen �bernommen. Als Admin sollte man sich unbedingt in der Standard-Administratoren Gruppe befinden, ansonsten ist man nach dem Update nur ein normaler User und kommt nicht ins Admin Control Panel.

3) Nach dem Update m�ssen die Rechte f�r Foren neu gesetzt werden. Am schnellsten geht das mit "Gruppen bearbeiten" -> "Zugriffsrechte".
