/**
 * @author  Joshua Ruesweg
 * @copyright  2001-2021 WoltLab GmbH
 * @license  GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @deprecated Use the Module WoltLabSuite/Core/Ui/Object/Action/Toggle instead.
 */

export { setup } from "./Toggle";
