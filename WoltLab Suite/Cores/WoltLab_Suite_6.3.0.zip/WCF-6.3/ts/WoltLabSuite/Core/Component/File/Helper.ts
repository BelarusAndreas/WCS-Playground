import WoltlabCoreFileElement from "WoltLabSuite/Core/Component/File/woltlab-core-file";
import { getPhrase } from "WoltLabSuite/Core/Language";
import { formatFilesize } from "WoltLabSuite/Core/FileUtil";

// This import has the side effect of registering the `<woltlab-core-file>`
// element. Do not remove!
import "WoltLabSuite/Core/Component/File/woltlab-core-file";

export function trackUploadProgress(element: HTMLElement, file: WoltlabCoreFileElement): void {
  const progress = document.createElement("progress");
  progress.classList.add("fileList__item__progress__bar");
  progress.max = 100;
  const readout = document.createElement("span");
  readout.classList.add("fileList__item__progress__readout");

  file.addEventListener("uploadProgress", (event: CustomEvent<number>) => {
    progress.value = event.detail;
    readout.textContent = `${event.detail}%`;

    if (progress.parentNode === null) {
      element.classList.add("fileProcessor__item--uploading");

      const wrapper = document.createElement("div");
      wrapper.classList.add("fileList__item__progress");
      wrapper.append(progress, readout);

      element.append(wrapper);
    }
  });
}

export function removeUploadProgress(element: HTMLElement): void {
  if (!element.classList.contains("fileProcessor__item--uploading")) {
    return;
  }

  element.classList.remove("fileProcessor__item--uploading");
  element.querySelector(".fileList__item__progress")?.remove();
}

export function getErrorMessageFromFile(file: WoltlabCoreFileElement): string {
  if (file.apiError === undefined) {
    throw new Error("There is no recorded API error for this file.", {
      cause: {
        file,
      },
    });
  }

  let errorMessage: string;

  const validationError = file.apiError.getValidationError();
  if (validationError !== undefined) {
    switch (validationError.param) {
      case "preflight":
        errorMessage = getPhrase(`wcf.upload.error.${validationError.code}`);
        break;
      case "validation":
        errorMessage = getPhrase(`wcf.upload.validation.error.${validationError.code}`);
        break;

      default:
        errorMessage = "Unrecognized error type: " + JSON.stringify(validationError);
        break;
    }
  } else {
    errorMessage = `Unexpected server error: [${file.apiError.type}] ${file.apiError.message}`;
  }

  return errorMessage;
}

export function fileInitializationFailed(element: HTMLElement, file: WoltlabCoreFileElement, reason: unknown): void {
  if (reason instanceof Error) {
    throw reason;
  }

  markElementAsErroneous(element, getErrorMessageFromFile(file));
}

function markElementAsErroneous(element: HTMLElement, errorMessage: string): void {
  element.classList.add("fileList__item--error");

  const errorElement = document.createElement("div");
  errorElement.classList.add("fileList__item__errorMessage");
  errorElement.textContent = errorMessage;

  element.append(errorElement);
}

export function insertFileInformation(container: HTMLElement, file: WoltlabCoreFileElement): void {
  const fileWrapper = document.createElement("div");
  fileWrapper.classList.add("fileList__item__file");
  fileWrapper.append(file);

  const filename = document.createElement("div");
  filename.classList.add("fileList__item__filename");
  filename.textContent = file.filename || file.dataset.filename!;

  const fileSize = document.createElement("div");
  fileSize.classList.add("fileList__item__fileSize");
  fileSize.textContent = formatFilesize(file.fileSize || parseInt(file.dataset.fileSize!));

  container.append(fileWrapper, filename, fileSize);
}

export function updateFileInformation(container: HTMLElement, file: WoltlabCoreFileElement): void {
  const filename = container.querySelector(".fileList__item__filename")!;
  filename.textContent = file.filename || file.dataset.filename!;

  const fileSize = container.querySelector(".fileList__item__fileSize")!;
  fileSize.textContent = formatFilesize(file.fileSize || parseInt(file.dataset.fileSize!));
}
