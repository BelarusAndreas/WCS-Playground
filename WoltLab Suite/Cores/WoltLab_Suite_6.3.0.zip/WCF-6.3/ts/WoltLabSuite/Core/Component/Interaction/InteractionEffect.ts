/**
 * Represents an effect that is to be applied after an interaction has been executed.
 *
 * @author Marcel Werk
 * @copyright 2001-2025 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @since 6.2
 */

export enum InteractionEffect {
  ReloadItem = "ReloadItem",
  ReloadList = "ReloadList",
  ReloadPage = "ReloadPage",
  RemoveItem = "RemoveItem",
}
