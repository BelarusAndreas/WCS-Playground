#!/bin/sh
node _buildAll.js ../../
