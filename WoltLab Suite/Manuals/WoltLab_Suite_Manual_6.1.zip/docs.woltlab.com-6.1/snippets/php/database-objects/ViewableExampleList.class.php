<?php
namespace wcf\data\example;

class ViewableExampleList extends ExampleList {
    public $decoratorClassName = ViewableExample::class;
}