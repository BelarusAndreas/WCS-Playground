<?php

// include config
/** @noinspection PhpIncludeInspection */
require_once(__DIR__ . '/app.config.inc.php');

// include wcf
/** @noinspection PhpIncludeInspection */
require_once(RELATIVE_WCF_DIR . 'global.php');
