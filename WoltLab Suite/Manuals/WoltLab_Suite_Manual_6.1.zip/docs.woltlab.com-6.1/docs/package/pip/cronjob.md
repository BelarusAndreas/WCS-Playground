# Cronjob Package Installation Plugin

Registers new cronjobs.
The cronjob schedular works similar to the `cron(8)` daemon, which might not available to web applications on regular webspaces.
The main difference is that WoltLab Suite’s cronjobs do not guarantee execution at the specified points in time:
WoltLab Suite’s cronjobs are triggered by regular visitors in an AJAX request, once the next execution point lies in the past.

## Components

Each cronjob is described as an `<cronjob>` element with the mandatory attribute `name`.

### `<classname>`

The name of the class providing the cronjob's behaviour,
the class has to implement the `wcf\system\cronjob\ICronjob` interface.

### `<description>`

!!! info "The `language` attribute is optional and should specify the [ISO-639-1](https://en.wikipedia.org/wiki/ISO_639-1) language code."

Provides a human readable description for the administrator.

### `<expression>`

The cronjob schedule.
The expression accepts the same syntax as described in [`crontab(5)`](https://linux.die.net/man/5/crontab) of a cron daemon.

### `<canbeedited>`

Controls whether the administrator may edit the fields of the cronjob.
Defaults to `1`.

### `<canbedisabled>`

Controls whether the administrator may disable the cronjob.
Defaults to `1`.

### `<isdisabled>`

Controls whether the cronjob is disabled by default.
Defaults to `0`.

### `<options>`

The options element can contain a comma-separated list of options of which at least one needs to be enabled for the cronjob to be executed.

## Example

{jinja{ codebox(
  title="cronjob.xml",
  language="xml",
  filepath="package/pip/cronjob.xml"
) }}
