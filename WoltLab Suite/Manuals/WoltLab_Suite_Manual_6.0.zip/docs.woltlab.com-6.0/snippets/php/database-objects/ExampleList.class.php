<?php
namespace wcf\data\example;
use wcf\data\DatabaseObjectList;

class ExampleList extends DatabaseObjectList {
    public $className = Example::class;
}