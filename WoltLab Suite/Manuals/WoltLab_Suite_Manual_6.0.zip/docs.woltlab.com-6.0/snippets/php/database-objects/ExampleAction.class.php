<?php
namespace wcf\data\example;
use wcf\data\AbstractDatabaseObjectAction;

class ExampleAction extends AbstractDatabaseObjectAction {
    public $className = ExampleEditor::class;
}