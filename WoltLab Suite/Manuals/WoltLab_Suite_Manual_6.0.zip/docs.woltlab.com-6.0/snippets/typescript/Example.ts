import * as Language from "WoltLabSuite/Core/Language";

export function run() {
  alert(Language.get("wcf.foo.bar"));
}