<?php

namespace wcf\page;

use wcf\data\person\PersonList;

/**
 * Shows the list of people.
 *
 * @author  Matthias Schmidt
 * @copyright   2001-2021 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
class PersonListPage extends SortablePage
{
    /**
     * @inheritDoc
     */
    public $defaultSortField = 'lastName';

    /**
     * @inheritDoc
     */
    public $objectListClassName = PersonList::class;

    /**
     * @inheritDoc
     */
    public $validSortFields = ['personID', 'firstName', 'lastName'];
}
