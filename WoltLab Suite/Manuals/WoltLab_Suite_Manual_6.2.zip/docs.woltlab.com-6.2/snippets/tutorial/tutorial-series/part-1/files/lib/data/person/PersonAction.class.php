<?php

namespace wcf\data\person;

use wcf\data\AbstractDatabaseObjectAction;

/**
 * Executes person-related actions.
 *
 * @author      Matthias Schmidt
 * @copyright   2001-2021 WoltLab GmbH
 * @license     GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 *
 * @extends AbstractDatabaseObjectAction<Person, PersonEditor>
 */
class PersonAction extends AbstractDatabaseObjectAction {}
