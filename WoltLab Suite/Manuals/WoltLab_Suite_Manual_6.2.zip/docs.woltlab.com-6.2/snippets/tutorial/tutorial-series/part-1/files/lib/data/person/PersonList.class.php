<?php

namespace wcf\data\person;

use wcf\data\DatabaseObjectList;

/**
 * Represents a list of people.
 *
 * @author      Matthias Schmidt
 * @copyright   2001-2021 WoltLab GmbH
 * @license     GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 *
 * @extends DatabaseObjectList<Person>
 */
class PersonList extends DatabaseObjectList {}
