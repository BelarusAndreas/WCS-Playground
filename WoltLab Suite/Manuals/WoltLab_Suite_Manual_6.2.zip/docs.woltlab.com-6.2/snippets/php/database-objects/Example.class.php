<?php
namespace wcf\data\example;
use wcf\data\DatabaseObject;

class Example extends DatabaseObject {}
