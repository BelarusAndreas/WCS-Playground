# Template Package Installation Plugin

Add templates for frontend pages and forms by providing an archive containing the template files.

!!! warning "You cannot overwrite templates provided by other packages."

This package installation plugin behaves exactly like the [acpTemplate package installation plugin](acp-template.md) except for installing frontend templates instead of backend/acp templates.
