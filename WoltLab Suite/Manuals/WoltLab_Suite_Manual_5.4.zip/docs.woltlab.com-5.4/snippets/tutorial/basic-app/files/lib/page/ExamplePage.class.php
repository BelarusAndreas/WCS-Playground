<?php
namespace app\page;
use wcf\page\AbstractPage;

class ExamplePage extends AbstractPage {}
