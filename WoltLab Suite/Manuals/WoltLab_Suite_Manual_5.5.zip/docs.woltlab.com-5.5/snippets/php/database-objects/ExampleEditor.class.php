<?php
namespace wcf\data\example;
use wcf\data\DatabaseObjectEditor;

class ExampleEditor extends DatabaseObjectEditor {
    protected static $baseClass = Example::class;
}