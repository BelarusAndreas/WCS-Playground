# Slovenia 🇸🇮

| ![brio] | ![kanal-a] | ![nickelodeon] | ![nova-24] | ![oto] | ![pop-kino] |
|:---:|:---:|:---:|:---:|:---:|:---:|
| ![pop] | ![rtvslo] | ![tv-slo-1] | ![tv-slo-2] | ![tv-slo-3] | ![tv3] |
| ![space] | ![space] | ![space] | ![space] | ![space] | ![space] |


[brio]:brio-si.png
[kanal-a]:kanal-a-si.png
[nickelodeon]:nickelodeon-si.png
[nova-24]:nova-24-si.png
[oto]:oto-si.png
[pop-kino]:pop-kino-si.png
[pop]:pop-si.png
[rtvslo]:rtvslo-si.png
[tv-slo-1]:tv-slo-1-si.png
[tv-slo-2]:tv-slo-2-si.png
[tv-slo-3]:tv-slo-3-si.png
[tv3]:tv3-si.png

[space]:../../misc/space-1500.png "Space"

