# Switzerland 🇨🇭

| ![3-plus] | ![4-plus] | ![5-plus] | ![6-plus] | ![7-plus] | ![be-curious-tv] |
|:---:|:---:|:---:|:---:|:---:|:---:|
| ![booster-tv] | ![canal-alpha] | ![canal-alpha-ju] | ![canal-alpha-ne] | ![canal-plus-sport-2] | ![canal9] |
| ![carac1] | ![carac2] | ![carac3] | ![carac4] | ![folx-music-television] | ![grand-geneve-tv] |
| ![la-tele] | ![lemanbleu-tv] | ![lfm-tv] | ![m6] | ![max-tv] | ![my-sports-10] |
| ![my-sports-2] | ![my-sports-3] | ![my-sports-4] | ![my-sports-5] | ![my-sports-6] | ![my-sports-7] |
| ![my-sports-8] | ![my-sports-9] | ![my-sports-eins] | ![my-sports-un] | ![nickelodeon-schweiz] | ![nrtv] |
| ![one-tv] | ![rouge-tv] | ![rsi-la1] | ![rsi-la2] | ![rtr-televisiun-rumantscha] | ![rts-deux] |
| ![rts-info] | ![rts-un] | ![s1] | ![schaffhauser-fernsehen] | ![srf-1] | ![srf-info] |
| ![srf-zwei] | ![star-tv] | ![swiss1] | ![tele-barn] | ![tele-bielingue] | ![tele-m1] |
| ![tele-ticino] | ![tele-top] | ![tele-zuri] | ![tele1] | ![telebasel] | ![tv-sudostschweiz] |
| ![tv24] | ![tv25] | ![tvo] | ![space] | ![space] | ![space] |
| ![space] | ![space] | ![space] | ![space] | ![space] | ![space] |


[3-plus]:3-plus-ch.png
[4-plus]:4-plus-ch.png
[5-plus]:5-plus-ch.png
[6-plus]:6-plus-ch.png
[7-plus]:7-plus-ch.png
[be-curious-tv]:be-curious-tv-ch.png
[booster-tv]:booster-tv-ch.png
[canal-alpha]:canal-alpha-ch.png
[canal-alpha-ju]:canal-alpha-ju-ch.png
[canal-alpha-ne]:canal-alpha-ne-ch.png
[canal-plus-sport-2]:canal-plus-sport-2-ch.png
[canal9]:canal9-ch.png
[carac1]:carac1-ch.png
[carac2]:carac2-ch.png
[carac3]:carac3-ch.png
[carac4]:carac4-ch.png
[folx-music-television]:folx-music-television-ch.png
[grand-geneve-tv]:grand-geneve-tv-ch.png
[la-tele]:la-tele-ch.png
[lemanbleu-tv]:lemanbleu-tv-ch.png
[lfm-tv]:lfm-tv-ch.png
[m6]:m6-ch.png
[max-tv]:max-tv-ch.png
[my-sports-10]:my-sports-10-ch.png
[my-sports-2]:my-sports-2-ch.png
[my-sports-3]:my-sports-3-ch.png
[my-sports-4]:my-sports-4-ch.png
[my-sports-5]:my-sports-5-ch.png
[my-sports-6]:my-sports-6-ch.png
[my-sports-7]:my-sports-7-ch.png
[my-sports-8]:my-sports-8-ch.png
[my-sports-9]:my-sports-9-ch.png
[my-sports-eins]:my-sports-eins-ch.png
[my-sports-un]:my-sports-un-ch.png
[nickelodeon-schweiz]:nickelodeon-schweiz-ch.png
[nrtv]:nrtv-ch.png
[one-tv]:one-tv-ch.png
[rouge-tv]:rouge-tv-ch.png
[rsi-la1]:rsi-la1-ch.png
[rsi-la2]:rsi-la2-ch.png
[rtr-televisiun-rumantscha]:rtr-televisiun-rumantscha-ch.png
[rts-deux]:rts-deux-ch.png
[rts-info]:rts-info-ch.png
[rts-un]:rts-un-ch.png
[s1]:s1-ch.png
[schaffhauser-fernsehen]:schaffhauser-fernsehen-ch.png
[srf-1]:srf-1-ch.png
[srf-info]:srf-info-ch.png
[srf-zwei]:srf-zwei-ch.png
[star-tv]:star-tv-ch.png
[swiss1]:swiss1-ch.png
[tele-barn]:tele-barn-ch.png
[tele-bielingue]:tele-bielingue-ch.png
[tele-m1]:tele-m1-ch.png
[tele-ticino]:tele-ticino-ch.png
[tele-top]:tele-top-ch.png
[tele-zuri]:tele-zuri-ch.png
[tele1]:tele1-ch.png
[telebasel]:telebasel-ch.png
[tv-sudostschweiz]:tv-sudostschweiz-ch.png
[tv24]:tv24-ch.png
[tv25]:tv25-ch.png
[tvo]:tvo-ch.png

[space]:../../misc/space-1500.png "Space"

