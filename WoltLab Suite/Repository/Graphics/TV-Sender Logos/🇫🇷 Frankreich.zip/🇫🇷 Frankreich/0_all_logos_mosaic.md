# France 🇫🇷

| ![6ter] | ![ab1] | ![action] | ![altice-studio] | ![animaux] | ![arte] |
|:---:|:---:|:---:|:---:|:---:|:---:|
| ![arte-hd] | ![automoto-la-chaine] | ![b-smart] | ![bein-sports-1-french] | ![bein-sports-2-french] | ![bein-sports-3-french] |
| ![bein-sports] | ![bet] | ![bfm-business] | ![bfm-grand-lille] | ![bfm-grand-littoral] | ![bfm-lyon] |
| ![bfm-paris] | ![bfm-tv] | ![boing] | ![boomerang] | ![c-news] | ![c-star] |
| ![c-star-hits-france] | ![c8] | ![canal-j] | ![canal-plus-4k-uhd] | ![canal-plus-box-office] | ![canal-plus-cinema-hd] |
| ![canal-plus-cinemas] | ![canal-plus-decale-hd] | ![canal-plus-docs] | ![canal-plus-docs-hd] | ![canal-plus-family-hd] | ![canal-plus-foot] |
| ![canal-plus-formula1] | ![canal-plus] | ![canal-plus-grand-ecran] | ![canal-plus-hello] | ![canal-plus-kids] | ![canal-plus-kids-hd] |
| ![canal-plus-ligue1] | ![canal-plus-moto-gp] | ![canal-plus-outremer] | ![canal-plus-premier-league] | ![canal-plus-series] | ![canal-plus-series-hd] |
| ![canal-plus-sport-360] | ![canal-plus-sport] | ![canal-plus-sport-hd] | ![canal-plus-story] | ![canal-plus-top-14-rugby] | ![cartoon-network] |
| ![chasse-et-peche] | ![cherie-25] | ![cine-plus-classic] | ![cine-plus-classic-hd] | ![cine-plus-club-hd] | ![cine-plus-emotion] |
| ![cine-plus-emotion-hd] | ![cine-plus-family] | ![cine-plus-famiz-hd] | ![cine-plus-festival] | ![cine-plus-frisson] | ![cine-plus-frisson-hd] |
| ![cine-plus-ocs] | ![cine-plus-premier] | ![cine-plus-premier-hd] | ![comedie-plus] | ![crime-district] | ![culturebox] |
| ![disney-channel] | ![disney-jr] | ![dreamsee] | ![drive-in-movie-channel] | ![equidia] | ![eurosport-1] |
| ![eurosport-1-hd] | ![eurosport-2] | ![eurosport-2-hd] | ![eurosport-4k] | ![france-2] | ![france-24] |
| ![france-3] | ![france-4] | ![france-5] | ![franceinfo] | ![game-one] | ![golf-plus] |
| ![gulli] | ![histoire-tv] | ![infosport-plus] | ![j-one] | ![kto] | ![la-chaine-meteo] |
| ![lci] | ![lcp] | ![lequipe] | ![m6] | ![m6-hd] | ![m6-music] |
| ![mangas] | ![mcm] | ![mcm-pop] | ![mcm-top] | ![melody] | ![mezzo] |
| ![mezzo-live] | ![mgg-tv] | ![mon-nickelodeon-junior] | ![motorvision-plus] | ![motorvision-tv] | ![multisports-1] |
| ![multisports-2] | ![multisports-3] | ![multisports-4] | ![multisports-5] | ![multisports-6] | ![multisports] |
| ![nickelodeon] | ![nickelodeon-junior] | ![nickelodeon-plus] | ![nickelodeon-teen] | ![nolife] | ![non-stop-people] |
| ![novelas-tv] | ![novo19] | ![nrj-12] | ![nrj-hits] | ![ocs-choc] | ![ocs-city] |
| ![ocs] | ![ocs-geants] | ![ocs-max] | ![ocs-pulp] | ![ol-tv] | ![olympia-tv] |
| ![one-tv] | ![paramount-channel-decale] | ![paramount-channel] | ![paris-premiere] | ![pitchoun-tv] | ![piwi-plus] |
| ![planete-plus-aventure] | ![planete-plus-crime] | ![planete-plus] | ![polar-plus] | ![public-senat] | ![rfm-tv] |
| ![rmc-decouverte] | ![rmc-sport-1] | ![rmc-sport-1-uhd] | ![rmc-sport-2] | ![rmc-sport-2-uhd] | ![rmc-sport-3] |
| ![rmc-sport-4] | ![rmc-sport-access-1] | ![rmc-sport-access-2] | ![rmc-sport-access-3] | ![rmc-sport] | ![rmc-sport-live-10] |
| ![rmc-sport-live-11] | ![rmc-sport-live-12] | ![rmc-sport-live-13] | ![rmc-sport-live-14] | ![rmc-sport-live-15] | ![rmc-sport-live-16] |
| ![rmc-sport-live-5] | ![rmc-sport-live-6] | ![rmc-sport-live-7] | ![rmc-sport-live-8] | ![rmc-sport-live-9] | ![rmc-sport-news] |
| ![rmc-story] | ![rt-france] | ![rtl9] | ![rtl9-hd] | ![science-and-vie-tv] | ![seasons] |
| ![serie-club] | ![sport-en-france] | ![stingray-brava] | ![stingray-djazz] | ![t18] | ![tcm-cinema] |
| ![teletoon-plus-1] | ![teletoon-plus] | ![teva] | ![tf1] | ![tf1-hd] | ![tf1-plus] |
| ![tf1-series-films] | ![tfx] | ![tiji] | ![tlc] | ![tmc] | ![tmc-plus] |
| ![toute-lhistoire] | ![trace-caribbean] | ![trace-latina] | ![trace-sport-stars] | ![trace-urban] | ![trek] |
| ![tv-breizh] | ![tv5-monde] | ![ultra-nature] | ![ushuaia-tv] | ![w9] | ![warner-tv] |
| ![warner-tv-next] | ![space] | ![space] | ![space] | ![space] | ![space] |
| ![space] | ![space] | ![space] | ![space] | ![space] | ![space] |


[6ter]:6ter-fr.png
[ab1]:ab1-fr.png
[action]:action-fr.png
[altice-studio]:altice-studio-fr.png
[animaux]:animaux-fr.png
[arte]:arte-fr.png
[arte-hd]:hd/arte-hd-fr.png
[automoto-la-chaine]:automoto-la-chaine-fr.png
[b-smart]:b-smart-fr.png
[bein-sports-1-french]:bein-sports-1-french-fr.png
[bein-sports-2-french]:bein-sports-2-french-fr.png
[bein-sports-3-french]:bein-sports-3-french-fr.png
[bein-sports]:bein-sports-fr.png
[bet]:bet-fr.png
[bfm-business]:bfm-business-fr.png
[bfm-grand-lille]:bfm-grand-lille-fr.png
[bfm-grand-littoral]:bfm-grand-littoral-fr.png
[bfm-lyon]:bfm-lyon-fr.png
[bfm-paris]:bfm-paris-fr.png
[bfm-tv]:bfm-tv-fr.png
[boing]:boing-fr.png
[boomerang]:boomerang-fr.png
[c-news]:c-news-fr.png
[c-star]:c-star-fr.png
[c-star-hits-france]:c-star-hits-france-fr.png
[c8]:c8-fr.png
[canal-j]:canal-j-fr.png
[canal-plus-4k-uhd]:hd/canal-plus-4k-uhd-fr.png
[canal-plus-box-office]:canal-plus-box-office-fr.png
[canal-plus-cinema-hd]:hd/canal-plus-cinema-hd-fr.png
[canal-plus-cinemas]:canal-plus-cinemas-fr.png
[canal-plus-decale-hd]:hd/canal-plus-decale-hd-fr.png
[canal-plus-docs]:canal-plus-docs-fr.png
[canal-plus-docs-hd]:hd/canal-plus-docs-hd-fr.png
[canal-plus-family-hd]:hd/canal-plus-family-hd-fr.png
[canal-plus-foot]:canal-plus-foot-fr.png
[canal-plus-formula1]:canal-plus-formula1-fr.png
[canal-plus]:canal-plus-fr.png
[canal-plus-grand-ecran]:canal-plus-grand-ecran-fr.png
[canal-plus-hello]:canal-plus-hello-fr.png
[canal-plus-kids]:canal-plus-kids-fr.png
[canal-plus-kids-hd]:hd/canal-plus-kids-hd-fr.png
[canal-plus-ligue1]:canal-plus-ligue1-fr.png
[canal-plus-moto-gp]:canal-plus-moto-gp-fr.png
[canal-plus-outremer]:canal-plus-outremer-fr.png
[canal-plus-premier-league]:canal-plus-premier-league-fr.png
[canal-plus-series]:canal-plus-series-fr.png
[canal-plus-series-hd]:hd/canal-plus-series-hd-fr.png
[canal-plus-sport-360]:canal-plus-sport-360-fr.png
[canal-plus-sport]:canal-plus-sport-fr.png
[canal-plus-sport-hd]:hd/canal-plus-sport-hd-fr.png
[canal-plus-story]:canal-plus-story-fr.png
[canal-plus-top-14-rugby]:canal-plus-top-14-rugby-fr.png
[cartoon-network]:cartoon-network-fr.png
[chasse-et-peche]:chasse-et-peche-fr.png
[cherie-25]:cherie-25-fr.png
[cine-plus-classic]:cine-plus-classic-fr.png
[cine-plus-classic-hd]:hd/cine-plus-classic-hd-fr.png
[cine-plus-club-hd]:hd/cine-plus-club-hd-fr.png
[cine-plus-emotion]:cine-plus-emotion-fr.png
[cine-plus-emotion-hd]:hd/cine-plus-emotion-hd-fr.png
[cine-plus-family]:cine-plus-family-fr.png
[cine-plus-famiz-hd]:hd/cine-plus-famiz-hd-fr.png
[cine-plus-festival]:cine-plus-festival-fr.png
[cine-plus-frisson]:cine-plus-frisson-fr.png
[cine-plus-frisson-hd]:hd/cine-plus-frisson-hd-fr.png
[cine-plus-ocs]:cine-plus-ocs-fr.png
[cine-plus-premier]:cine-plus-premier-fr.png
[cine-plus-premier-hd]:hd/cine-plus-premier-hd-fr.png
[comedie-plus]:comedie-plus-fr.png
[crime-district]:crime-district-fr.png
[culturebox]:culturebox-fr.png
[disney-channel]:disney-channel-fr.png
[disney-jr]:disney-jr-fr.png
[dreamsee]:dreamsee-fr.png
[drive-in-movie-channel]:drive-in-movie-channel-fr.png
[equidia]:equidia-fr.png
[eurosport-1]:eurosport-1-fr.png
[eurosport-1-hd]:hd/eurosport-1-hd-fr.png
[eurosport-2]:eurosport-2-fr.png
[eurosport-2-hd]:hd/eurosport-2-hd-fr.png
[eurosport-4k]:hd/eurosport-4k-fr.png
[france-2]:france-2-fr.png
[france-24]:france-24-fr.png
[france-3]:france-3-fr.png
[france-4]:france-4-fr.png
[france-5]:france-5-fr.png
[franceinfo]:franceinfo-fr.png
[game-one]:game-one-fr.png
[golf-plus]:golf-plus-fr.png
[gulli]:gulli-fr.png
[histoire-tv]:histoire-tv-fr.png
[infosport-plus]:infosport-plus-fr.png
[j-one]:j-one-fr.png
[kto]:kto-fr.png
[la-chaine-meteo]:la-chaine-meteo-fr.png
[lci]:lci-fr.png
[lcp]:lcp-fr.png
[lequipe]:lequipe-fr.png
[m6]:m6-fr.png
[m6-hd]:hd/m6-hd-fr.png
[m6-music]:m6-music-fr.png
[mangas]:mangas-fr.png
[mcm]:mcm-fr.png
[mcm-pop]:mcm-pop-fr.png
[mcm-top]:mcm-top-fr.png
[melody]:melody-fr.png
[mezzo]:mezzo-fr.png
[mezzo-live]:mezzo-live-fr.png
[mgg-tv]:mgg-tv-fr.png
[mon-nickelodeon-junior]:mon-nickelodeon-junior-fr.png
[motorvision-plus]:motorvision-plus-fr.png
[motorvision-tv]:motorvision-tv-fr.png
[multisports-1]:multisports-1-fr.png
[multisports-2]:multisports-2-fr.png
[multisports-3]:multisports-3-fr.png
[multisports-4]:multisports-4-fr.png
[multisports-5]:multisports-5-fr.png
[multisports-6]:multisports-6-fr.png
[multisports]:multisports-fr.png
[nickelodeon]:nickelodeon-fr.png
[nickelodeon-junior]:nickelodeon-junior-fr.png
[nickelodeon-plus]:nickelodeon-plus-fr.png
[nickelodeon-teen]:nickelodeon-teen-fr.png
[nolife]:nolife-fr.png
[non-stop-people]:non-stop-people-fr.png
[novelas-tv]:novelas-tv-fr.png
[novo19]:novo19-fr.png
[nrj-12]:nrj-12-fr.png
[nrj-hits]:nrj-hits-fr.png
[ocs-choc]:ocs-choc-fr.png
[ocs-city]:ocs-city-fr.png
[ocs]:ocs-fr.png
[ocs-geants]:ocs-geants-fr.png
[ocs-max]:ocs-max-fr.png
[ocs-pulp]:ocs-pulp-fr.png
[ol-tv]:ol-tv-fr.png
[olympia-tv]:olympia-tv-fr.png
[one-tv]:one-tv-fr.png
[paramount-channel-decale]:paramount-channel-decale-fr.png
[paramount-channel]:paramount-channel-fr.png
[paris-premiere]:paris-premiere-fr.png
[pitchoun-tv]:pitchoun-tv-fr.png
[piwi-plus]:piwi-plus-fr.png
[planete-plus-aventure]:planete-plus-aventure-fr.png
[planete-plus-crime]:planete-plus-crime-fr.png
[planete-plus]:planete-plus-fr.png
[polar-plus]:polar-plus-fr.png
[public-senat]:public-senat-fr.png
[rfm-tv]:rfm-tv-fr.png
[rmc-decouverte]:rmc-decouverte-fr.png
[rmc-sport-1]:rmc-sport-1-fr.png
[rmc-sport-1-uhd]:hd/rmc-sport-1-uhd-fr.png
[rmc-sport-2]:rmc-sport-2-fr.png
[rmc-sport-2-uhd]:hd/rmc-sport-2-uhd-fr.png
[rmc-sport-3]:rmc-sport-3-fr.png
[rmc-sport-4]:rmc-sport-4-fr.png
[rmc-sport-access-1]:rmc-sport-access-1-fr.png
[rmc-sport-access-2]:rmc-sport-access-2-fr.png
[rmc-sport-access-3]:rmc-sport-access-3-fr.png
[rmc-sport]:rmc-sport-fr.png
[rmc-sport-live-10]:rmc-sport-live-10-fr.png
[rmc-sport-live-11]:rmc-sport-live-11-fr.png
[rmc-sport-live-12]:rmc-sport-live-12-fr.png
[rmc-sport-live-13]:rmc-sport-live-13-fr.png
[rmc-sport-live-14]:rmc-sport-live-14-fr.png
[rmc-sport-live-15]:rmc-sport-live-15-fr.png
[rmc-sport-live-16]:rmc-sport-live-16-fr.png
[rmc-sport-live-5]:rmc-sport-live-5-fr.png
[rmc-sport-live-6]:rmc-sport-live-6-fr.png
[rmc-sport-live-7]:rmc-sport-live-7-fr.png
[rmc-sport-live-8]:rmc-sport-live-8-fr.png
[rmc-sport-live-9]:rmc-sport-live-9-fr.png
[rmc-sport-news]:rmc-sport-news-fr.png
[rmc-story]:rmc-story-fr.png
[rt-france]:rt-france-fr.png
[rtl9]:rtl9-fr.png
[rtl9-hd]:hd/rtl9-hd-fr.png
[science-and-vie-tv]:science-and-vie-tv-fr.png
[seasons]:seasons-fr.png
[serie-club]:serie-club-fr.png
[sport-en-france]:sport-en-france-fr.png
[stingray-brava]:stingray-brava-fr.png
[stingray-djazz]:stingray-djazz-fr.png
[t18]:t18-fr.png
[tcm-cinema]:tcm-cinema-fr.png
[teletoon-plus-1]:teletoon-plus-1-fr.png
[teletoon-plus]:teletoon-plus-fr.png
[teva]:teva-fr.png
[tf1]:tf1-fr.png
[tf1-hd]:hd/tf1-hd-fr.png
[tf1-plus]:tf1-plus-fr.png
[tf1-series-films]:tf1-series-films-fr.png
[tfx]:tfx-fr.png
[tiji]:tiji-fr.png
[tlc]:tlc-fr.png
[tmc]:tmc-fr.png
[tmc-plus]:tmc-plus-fr.png
[toute-lhistoire]:toute-lhistoire-fr.png
[trace-caribbean]:trace-caribbean-fr.png
[trace-latina]:trace-latina-fr.png
[trace-sport-stars]:trace-sport-stars-fr.png
[trace-urban]:trace-urban-fr.png
[trek]:trek-fr.png
[tv-breizh]:tv-breizh-fr.png
[tv5-monde]:tv5-monde-fr.png
[ultra-nature]:ultra-nature-fr.png
[ushuaia-tv]:ushuaia-tv-fr.png
[w9]:w9-fr.png
[warner-tv]:warner-tv-fr.png
[warner-tv-next]:warner-tv-next-fr.png

[space]:../../misc/space-1500.png "Space"

